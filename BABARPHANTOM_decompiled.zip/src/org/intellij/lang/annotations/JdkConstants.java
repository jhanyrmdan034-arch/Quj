package org.intellij.lang.annotations;

/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/com.yt.phantombabar/dex/classes5.dex */
@Deprecated
public final class JdkConstants {

    public @interface AdjustableOrientation {
    }

    public @interface BoxLayoutAxis {
    }

    public @interface CalendarMonth {
    }

    public @interface CursorType {
    }

    public @interface FlowLayoutAlignment {
    }

    public @interface FontStyle {
    }

    public @interface HorizontalAlignment {
    }

    public @interface HorizontalScrollBarPolicy {
    }

    public @interface InputEventMask {
    }

    public @interface ListSelectionMode {
    }

    public @interface PatternFlags {
    }

    public @interface TabLayoutPolicy {
    }

    public @interface TabPlacement {
    }

    public @interface TitledBorderJustification {
    }

    public @interface TitledBorderTitlePosition {
    }

    public @interface TreeSelectionMode {
    }

    public @interface VerticalScrollBarPolicy {
    }

    private JdkConstants() {
        throw new AssertionError("JdkConstants should not be instantiated");
    }
}