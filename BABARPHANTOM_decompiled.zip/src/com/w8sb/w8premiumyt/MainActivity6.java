package com.w8sb.w8premiumyt;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.os.Handler;
import android.os.Looper;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.widget.Toast;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: renamed from: com.w8sb.w8premiumyt.MainActivity$speakTextReceiver$1, reason: use source file name */
/* JADX INFO: compiled from: MainActivity.kt */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/com.yt.phantombabar/dex/classes3.dex */
@Metadata(d1 = {"\u0000\u001d\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000*\u0001\u0000\b\n\u0018\u00002\u00020\u0001J\u001c\u0010\u0002\u001a\u00020\u00032\b\u0010\u0004\u001a\u0004\u0018\u00010\u00052\b\u0010\u0006\u001a\u0004\u0018\u00010\u0007H\u0016¨\u0006\b"}, d2 = {"com/w8sb/w8premiumyt/MainActivity$speakTextReceiver$1", "Landroid/content/BroadcastReceiver;", "onReceive", "", "context", "Landroid/content/Context;", "intent", "Landroid/content/Intent;", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class MainActivity6 extends BroadcastReceiver {
    final /* synthetic */ MainActivity this$0;

    MainActivity6(MainActivity $receiver) {
        this.this$0 = $receiver;
    }

    @Override // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) {
        final String text;
        if (!Intrinsics.areEqual(intent != null ? intent.getAction() : null, "com.w8sb.w8premiumyt.SPEAK_TEXT") || (text = intent.getStringExtra("speak_text")) == null) {
            return;
        }
        Log.d("MainActivity", "Received speak text: " + text);
        Handler handler = new Handler(Looper.getMainLooper());
        final MainActivity mainActivity = this.this$0;
        handler.post(new Runnable() { // from class: com.w8sb.w8premiumyt.MainActivity$speakTextReceiver$1$$ExternalSyntheticLambda1
            @Override // java.lang.Runnable
            public final void run() {
                MainActivity6.onReceive$lambda$1(mainActivity, text);
            }
        });
    }

    private static final void onReceive$lambda$1(final MainActivity this$0, final String $text) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter($text, "$text");
        try {
            if (MainActivity.access$getTts$p(this$0) == null) {
                MainActivity.access$setTts$p(this$0, new TextToSpeech(this$0.getApplicationContext(), new TextToSpeech.OnInitListener() { // from class: com.w8sb.w8premiumyt.MainActivity$speakTextReceiver$1$$ExternalSyntheticLambda0
                    @Override // android.speech.tts.TextToSpeech.OnInitListener
                    public final void onInit(int i) {
                        MainActivity6.onReceive$lambda$1$lambda$0(this$0, $text, i);
                    }
                }));
                return;
            }
            TextToSpeech textToSpeechAccess$getTts$p = MainActivity.access$getTts$p(this$0);
            if (textToSpeechAccess$getTts$p != null) {
                textToSpeechAccess$getTts$p.setAudioAttributes(new AudioAttributes.Builder().setUsage(1).setContentType(1).build());
            }
            TextToSpeech textToSpeechAccess$getTts$p2 = MainActivity.access$getTts$p(this$0);
            if (textToSpeechAccess$getTts$p2 != null) {
                textToSpeechAccess$getTts$p2.speak($text, 0, null, null);
            }
        } catch (Exception e) {
            Toast.makeText(this$0.getApplicationContext(), "TTS error: " + e.getMessage(), 0).show();
        }
    }

    private static final void onReceive$lambda$1$lambda$0(MainActivity this$0, String $text, int status) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter($text, "$text");
        if (status != 0) {
            Toast.makeText(this$0.getApplicationContext(), "TTS init failed", 0).show();
            return;
        }
        TextToSpeech textToSpeechAccess$getTts$p = MainActivity.access$getTts$p(this$0);
        if (textToSpeechAccess$getTts$p != null) {
            textToSpeechAccess$getTts$p.setAudioAttributes(new AudioAttributes.Builder().setUsage(1).setContentType(1).build());
        }
        TextToSpeech textToSpeechAccess$getTts$p2 = MainActivity.access$getTts$p(this$0);
        if (textToSpeechAccess$getTts$p2 != null) {
            textToSpeechAccess$getTts$p2.speak($text, 0, null, null);
        }
    }
}