package com.w8sb.w8premiumyt.ui.theme;

import androidx.compose.runtime.State;
import androidx.compose.runtime.internal.LiveLiteralFileInfo;
import androidx.compose.runtime.internal.LiveLiteralInfo;
import androidx.compose.runtime.internal.LiveLiteralKt;
import kotlin.Metadata;

/* JADX INFO: renamed from: com.w8sb.w8premiumyt.ui.theme.LiveLiterals$ThemeKt, reason: use source file name */
/* JADX INFO: compiled from: Theme.kt */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/com.yt.phantombabar/dex/classes4.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
@LiveLiteralFileInfo(file = "C:/Users/User/Desktop/W8PremiumYT All Ine One Source Code/W8PremiumYT All Ine One/W8SBTST/app/src/main/java/com/w8sb/w8premiumyt/ui/theme/Theme.kt")
public final class Theme {

    /* JADX INFO: renamed from: State$Boolean$param-dynamicColor$fun-W8GLTSTheme, reason: not valid java name */
    private static State<Boolean> f۱State$Boolean$paramdynamicColor$funW8GLTSTheme;
    public static final Theme INSTANCE = new Theme();

    /* JADX INFO: renamed from: Boolean$param-dynamicColor$fun-W8GLTSTheme, reason: not valid java name */
    private static boolean f۰Boolean$paramdynamicColor$funW8GLTSTheme = true;

    @LiveLiteralInfo(key = "Boolean$param-dynamicColor$fun-W8GLTSTheme", offset = 1163)
    /* JADX INFO: renamed from: Boolean$param-dynamicColor$fun-W8GLTSTheme, reason: not valid java name */
    public final boolean m۰Boolean$paramdynamicColor$funW8GLTSTheme() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۰Boolean$paramdynamicColor$funW8GLTSTheme;
        }
        State<Boolean> stateLiveLiteral = f۱State$Boolean$paramdynamicColor$funW8GLTSTheme;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$param-dynamicColor$fun-W8GLTSTheme", Boolean.valueOf(f۰Boolean$paramdynamicColor$funW8GLTSTheme));
            f۱State$Boolean$paramdynamicColor$funW8GLTSTheme = stateLiveLiteral;
        }
        return ((Boolean) stateLiveLiteral.getValue()).booleanValue();
    }
}