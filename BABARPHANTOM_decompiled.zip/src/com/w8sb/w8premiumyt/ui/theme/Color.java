package com.w8sb.w8premiumyt.ui.theme;

import kotlin.Metadata;

/* JADX INFO: renamed from: com.w8sb.w8premiumyt.ui.theme.ColorKt, reason: use source file name */
/* JADX INFO: compiled from: Color.kt */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/com.yt.phantombabar/dex/classes4.dex */
@Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u000e\"\u0016\u0010\u0000\u001a\u00020\u0001ø\u0001\u0000¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u0002\u0010\u0003\"\u0016\u0010\u0005\u001a\u00020\u0001ø\u0001\u0000¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u0006\u0010\u0003\"\u0016\u0010\u0007\u001a\u00020\u0001ø\u0001\u0000¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\b\u0010\u0003\"\u0016\u0010\t\u001a\u00020\u0001ø\u0001\u0000¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\n\u0010\u0003\"\u0016\u0010\u000b\u001a\u00020\u0001ø\u0001\u0000¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\f\u0010\u0003\"\u0016\u0010\r\u001a\u00020\u0001ø\u0001\u0000¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u000e\u0010\u0003\u0082\u0002\u0004\n\u0002\b\u0019¨\u0006\u000f"}, d2 = {"Pink40", "Landroidx/compose/ui/graphics/Color;", "getPink40", "()J", "J", "Pink80", "getPink80", "Purple40", "getPurple40", "Purple80", "getPurple80", "PurpleGrey40", "getPurpleGrey40", "PurpleGrey80", "getPurpleGrey80", "app_debug"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class Color {
    private static final long Purple80 = androidx.compose.ui.graphics.ColorKt.Color(4291869951L);
    private static final long PurpleGrey80 = androidx.compose.ui.graphics.ColorKt.Color(4291609308L);
    private static final long Pink80 = androidx.compose.ui.graphics.ColorKt.Color(4293900488L);
    private static final long Purple40 = androidx.compose.ui.graphics.ColorKt.Color(4284895396L);
    private static final long PurpleGrey40 = androidx.compose.ui.graphics.ColorKt.Color(4284636017L);
    private static final long Pink40 = androidx.compose.ui.graphics.ColorKt.Color(4286403168L);

    public static final long getPurple80() {
        return Purple80;
    }

    public static final long getPurpleGrey80() {
        return PurpleGrey80;
    }

    public static final long getPink80() {
        return Pink80;
    }

    public static final long getPurple40() {
        return Purple40;
    }

    public static final long getPurpleGrey40() {
        return PurpleGrey40;
    }

    public static final long getPink40() {
        return Pink40;
    }
}