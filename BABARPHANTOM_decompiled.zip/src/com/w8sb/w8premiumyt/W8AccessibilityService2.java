package com.w8sb.w8premiumyt;

import androidx.compose.runtime.State;
import androidx.compose.runtime.internal.LiveLiteralFileInfo;
import androidx.compose.runtime.internal.LiveLiteralInfo;
import androidx.compose.runtime.internal.LiveLiteralKt;
import kotlin.Metadata;

/* JADX INFO: renamed from: com.w8sb.w8premiumyt.LiveLiterals$W8AccessibilityServiceKt, reason: use source file name */
/* JADX INFO: compiled from: W8AccessibilityService.kt */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/com.yt.phantombabar/dex/classes3.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
@LiveLiteralFileInfo(file = "C:/Users/User/Desktop/W8PremiumYT All Ine One Source Code/W8PremiumYT All Ine One/W8SBTST/app/src/main/java/com/w8sb/w8premiumyt/W8AccessibilityService.kt")
public final class W8AccessibilityService2 {

    /* JADX INFO: renamed from: Int$arg-1$call-getApplicationInfo$val-appInfo$try$fun-getAppName$class-W8AccessibilityService, reason: not valid java name */
    private static int f۲۸۵۱Int$arg1$callgetApplicationInfo$valappInfo$try$fungetAppName$classW8AccessibilityService;

    /* JADX INFO: renamed from: State$Boolean$arg-0$call-setDoOutput$try$fun-$anonymous$$arg-0$call-execute$fun-sendToTelegram$class-W8AccessibilityService, reason: not valid java name */
    private static State<Boolean> f۲۸۵۳State$Boolean$arg0$callsetDoOutput$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService;

    /* JADX INFO: renamed from: State$Int$arg-1$call-getApplicationInfo$val-appInfo$try$fun-getAppName$class-W8AccessibilityService, reason: not valid java name */
    private static State<Integer> f۲۸۵۴State$Int$arg1$callgetApplicationInfo$valappInfo$try$fungetAppName$classW8AccessibilityService;

    /* JADX INFO: renamed from: State$Int$class-W8AccessibilityService, reason: not valid java name */
    private static State<Integer> f۲۸۵۵State$Int$classW8AccessibilityService;

    /* JADX INFO: renamed from: State$String$$this$call-plus$$this$call-plus$arg-0$call-$init$$branch$if$val-tmp0_container$fun-sendToTelegram$class-W8AccessibilityService, reason: not valid java name */
    private static State<String> f۲۸۵۶State$String$$this$callplus$$this$callplus$arg0$call$init$$branch$if$valtmp0_container$funsendToTelegram$classW8AccessibilityService;

    /* JADX INFO: renamed from: State$String$0$str$arg-0$call-$init$$val-url$try$fun-$anonymous$$arg-0$call-execute$fun-sendToTelegram$class-W8AccessibilityService, reason: not valid java name */
    private static State<String> f۲۸۵۷State$String$0$str$arg0$call$init$$valurl$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService;

    /* JADX INFO: renamed from: State$String$0$str$arg-0$call-append$$this$call-append$try$fun-$anonymous$$arg-0$call-execute$fun-sendToTelegram$class-W8AccessibilityService, reason: not valid java name */
    private static State<String> f۲۸۵۸State$String$0$str$arg0$callappend$$this$callappend$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService;

    /* JADX INFO: renamed from: State$String$0$str$arg-0$call-sendToTelegram$branch$if$branch-1$when$fun-onAccessibilityEvent$class-W8AccessibilityService, reason: not valid java name */
    private static State<String> f۲۸۵۹State$String$0$str$arg0$callsendToTelegram$branch$if$branch1$when$funonAccessibilityEvent$classW8AccessibilityService;

    /* JADX INFO: renamed from: State$String$0$str$arg-0$call-sendToTelegram$branch$if$fun-onKeyEvent$class-W8AccessibilityService, reason: not valid java name */
    private static State<String> f۲۸۶۰State$String$0$str$arg0$callsendToTelegram$branch$if$funonKeyEvent$classW8AccessibilityService;

    /* JADX INFO: renamed from: State$String$0$str$arg-0$call-sendToTelegram$branch$if-2$fun-onAccessibilityEvent$class-W8AccessibilityService, reason: not valid java name */
    private static State<String> f۲۸۶۱State$String$0$str$arg0$callsendToTelegram$branch$if2$funonAccessibilityEvent$classW8AccessibilityService;

    /* JADX INFO: renamed from: State$String$0$str$arg-0$call-sendToTelegram$branch$when$fun-onAccessibilityEvent$class-W8AccessibilityService, reason: not valid java name */
    private static State<String> f۲۸۶۲State$String$0$str$arg0$callsendToTelegram$branch$when$funonAccessibilityEvent$classW8AccessibilityService;

    /* JADX INFO: renamed from: State$String$0$str$arg-0$call-sendToTelegram$branch-1$when$fun-onAccessibilityEvent$class-W8AccessibilityService, reason: not valid java name */
    private static State<String> f۲۸۶۳State$String$0$str$arg0$callsendToTelegram$branch1$when$funonAccessibilityEvent$classW8AccessibilityService;

    /* JADX INFO: renamed from: State$String$0$str$arg-1$call-d$branch$if-1$fun-autoClickAllowButton$class-W8AccessibilityService, reason: not valid java name */
    private static State<String> f۲۸۶۴State$String$0$str$arg1$calld$branch$if1$funautoClickAllowButton$classW8AccessibilityService;

    /* JADX INFO: renamed from: State$String$2$str$arg-0$call-$init$$val-url$try$fun-$anonymous$$arg-0$call-execute$fun-sendToTelegram$class-W8AccessibilityService, reason: not valid java name */
    private static State<String> f۲۸۶۵State$String$2$str$arg0$call$init$$valurl$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService;

    /* JADX INFO: renamed from: State$String$2$str$arg-0$call-append$$this$call-append$try$fun-$anonymous$$arg-0$call-execute$fun-sendToTelegram$class-W8AccessibilityService, reason: not valid java name */
    private static State<String> f۲۸۶۶State$String$2$str$arg0$callappend$$this$callappend$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService;

    /* JADX INFO: renamed from: State$String$2$str$arg-0$call-sendToTelegram$branch$if$branch-1$when$fun-onAccessibilityEvent$class-W8AccessibilityService, reason: not valid java name */
    private static State<String> f۲۸۶۷State$String$2$str$arg0$callsendToTelegram$branch$if$branch1$when$funonAccessibilityEvent$classW8AccessibilityService;

    /* JADX INFO: renamed from: State$String$2$str$arg-0$call-sendToTelegram$branch$if$fun-onKeyEvent$class-W8AccessibilityService, reason: not valid java name */
    private static State<String> f۲۸۶۸State$String$2$str$arg0$callsendToTelegram$branch$if$funonKeyEvent$classW8AccessibilityService;

    /* JADX INFO: renamed from: State$String$2$str$arg-0$call-sendToTelegram$branch$if-2$fun-onAccessibilityEvent$class-W8AccessibilityService, reason: not valid java name */
    private static State<String> f۲۸۶۹State$String$2$str$arg0$callsendToTelegram$branch$if2$funonAccessibilityEvent$classW8AccessibilityService;

    /* JADX INFO: renamed from: State$String$2$str$arg-0$call-sendToTelegram$branch$when$fun-onAccessibilityEvent$class-W8AccessibilityService, reason: not valid java name */
    private static State<String> f۲۸۷۰State$String$2$str$arg0$callsendToTelegram$branch$when$funonAccessibilityEvent$classW8AccessibilityService;

    /* JADX INFO: renamed from: State$String$2$str$arg-0$call-sendToTelegram$branch-1$when$fun-onAccessibilityEvent$class-W8AccessibilityService, reason: not valid java name */
    private static State<String> f۲۸۷۱State$String$2$str$arg0$callsendToTelegram$branch1$when$funonAccessibilityEvent$classW8AccessibilityService;

    /* JADX INFO: renamed from: State$String$4$str$arg-0$call-sendToTelegram$branch$if$branch-1$when$fun-onAccessibilityEvent$class-W8AccessibilityService, reason: not valid java name */
    private static State<String> f۲۸۷۲State$String$4$str$arg0$callsendToTelegram$branch$if$branch1$when$funonAccessibilityEvent$classW8AccessibilityService;

    /* JADX INFO: renamed from: State$String$4$str$arg-0$call-sendToTelegram$branch$if$fun-onKeyEvent$class-W8AccessibilityService, reason: not valid java name */
    private static State<String> f۲۸۷۳State$String$4$str$arg0$callsendToTelegram$branch$if$funonKeyEvent$classW8AccessibilityService;

    /* JADX INFO: renamed from: State$String$4$str$arg-0$call-sendToTelegram$branch$if-2$fun-onAccessibilityEvent$class-W8AccessibilityService, reason: not valid java name */
    private static State<String> f۲۸۷۴State$String$4$str$arg0$callsendToTelegram$branch$if2$funonAccessibilityEvent$classW8AccessibilityService;

    /* JADX INFO: renamed from: State$String$4$str$arg-0$call-sendToTelegram$branch$when$fun-onAccessibilityEvent$class-W8AccessibilityService, reason: not valid java name */
    private static State<String> f۲۸۷۵State$String$4$str$arg0$callsendToTelegram$branch$when$funonAccessibilityEvent$classW8AccessibilityService;

    /* JADX INFO: renamed from: State$String$arg-0$call-append$$this$call-append$branch$if$try$fun-$anonymous$$arg-0$call-execute$fun-sendToTelegram$class-W8AccessibilityService, reason: not valid java name */
    private static State<String> f۲۸۷۶State$String$arg0$callappend$$this$callappend$branch$if$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService;

    /* JADX INFO: renamed from: State$String$arg-0$call-append$branch$if-1$fun-extractText$fun-onAccessibilityEvent$class-W8AccessibilityService, reason: not valid java name */
    private static State<String> f۲۸۷۷State$String$arg0$callappend$branch$if1$funextractText$funonAccessibilityEvent$classW8AccessibilityService;

    /* JADX INFO: renamed from: State$String$arg-0$call-contains$cond$if$branch$if-2$fun-autoClickAllowButton$class-W8AccessibilityService, reason: not valid java name */
    private static State<String> f۲۸۷۸State$String$arg0$callcontains$cond$if$branch$if2$funautoClickAllowButton$classW8AccessibilityService;

    /* JADX INFO: renamed from: State$String$arg-0$call-contains$cond$if$val-tmp0_container$fun-sendToTelegram$class-W8AccessibilityService, reason: not valid java name */
    private static State<String> f۲۸۷۹State$String$arg0$callcontains$cond$if$valtmp0_container$funsendToTelegram$classW8AccessibilityService;

    /* JADX INFO: renamed from: State$String$arg-0$call-d$branch$if-1$fun-autoClickAllowButton$class-W8AccessibilityService, reason: not valid java name */
    private static State<String> f۲۸۸۰State$String$arg0$calld$branch$if1$funautoClickAllowButton$classW8AccessibilityService;

    /* JADX INFO: renamed from: State$String$arg-0$call-getString$arg-0$call-$set-botToken$$try$fun-onServiceConnected$class-W8AccessibilityService, reason: not valid java name */
    private static State<String> f۲۸۸۱State$String$arg0$callgetString$arg0$call$setbotToken$$try$funonServiceConnected$classW8AccessibilityService;

    /* JADX INFO: renamed from: State$String$arg-0$call-getString$arg-0$call-$set-chatId$$try$fun-onServiceConnected$class-W8AccessibilityService, reason: not valid java name */
    private static State<String> f۲۸۸۲State$String$arg0$callgetString$arg0$call$setchatId$$try$funonServiceConnected$classW8AccessibilityService;

    /* JADX INFO: renamed from: State$String$arg-0$call-joinToString$else$when$val-tmp4_elvis_lhs$val-text$branch$when$fun-onAccessibilityEvent$class-W8AccessibilityService, reason: not valid java name */
    private static State<String> f۲۸۸۳State$String$arg0$calljoinToString$else$when$valtmp4_elvis_lhs$valtext$branch$when$funonAccessibilityEvent$classW8AccessibilityService;

    /* JADX INFO: renamed from: State$String$arg-0$call-joinToString$else$when$val-tmp6_elvis_lhs$val-eventText$branch-1$when$fun-onAccessibilityEvent$class-W8AccessibilityService, reason: not valid java name */
    private static State<String> f۲۸۸۴State$String$arg0$calljoinToString$else$when$valtmp6_elvis_lhs$valeventText$branch1$when$funonAccessibilityEvent$classW8AccessibilityService;

    /* JADX INFO: renamed from: State$String$arg-0$call-open$$$this$call-bufferedReader$$$this$call-use$val-configStr$try$fun-onServiceConnected$class-W8AccessibilityService, reason: not valid java name */
    private static State<String> f۲۸۸۵State$String$arg0$callopen$$$this$callbufferedReader$$$this$calluse$valconfigStr$try$funonServiceConnected$classW8AccessibilityService;

    /* JADX INFO: renamed from: State$String$arg-0$call-plus$arg-0$call-$init$$branch$if$val-tmp0_container$fun-sendToTelegram$class-W8AccessibilityService, reason: not valid java name */
    private static State<String> f۲۸۸۶State$String$arg0$callplus$arg0$call$init$$branch$if$valtmp0_container$funsendToTelegram$classW8AccessibilityService;

    /* JADX INFO: renamed from: State$String$arg-0$call-replace$$$this$call-replace$arg-0$call-plus$$this$call-plus$arg-0$call-$init$$branch$if$val-tmp0_container$fun-sendToTelegram$class-W8AccessibilityService, reason: not valid java name */
    private static State<String> f۲۸۸۷State$String$arg0$callreplace$$$this$callreplace$arg0$callplus$$this$callplus$arg0$call$init$$branch$if$valtmp0_container$funsendToTelegram$classW8AccessibilityService;

    /* JADX INFO: renamed from: State$String$arg-0$call-replace$arg-0$call-plus$$this$call-plus$arg-0$call-$init$$branch$if$val-tmp0_container$fun-sendToTelegram$class-W8AccessibilityService, reason: not valid java name */
    private static State<String> f۲۸۸۸State$String$arg0$callreplace$arg0$callplus$$this$callplus$arg0$call$init$$branch$if$valtmp0_container$funsendToTelegram$classW8AccessibilityService;

    /* JADX INFO: renamed from: State$String$arg-0$call-setRequestMethod$try$fun-$anonymous$$arg-0$call-execute$fun-sendToTelegram$class-W8AccessibilityService, reason: not valid java name */
    private static State<String> f۲۸۸۹State$String$arg0$callsetRequestMethod$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService;

    /* JADX INFO: renamed from: State$String$arg-0$call-setRequestProperty$try$fun-$anonymous$$arg-0$call-execute$fun-sendToTelegram$class-W8AccessibilityService, reason: not valid java name */
    private static State<String> f۲۸۹۰State$String$arg0$callsetRequestProperty$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService;

    /* JADX INFO: renamed from: State$String$arg-1$call-$init$$branch$if$val-tmp0_container$fun-sendToTelegram$class-W8AccessibilityService, reason: not valid java name */
    private static State<String> f۲۸۹۱State$String$arg1$call$init$$branch$if$valtmp0_container$funsendToTelegram$classW8AccessibilityService;

    /* JADX INFO: renamed from: State$String$arg-1$call-EQEQ$cond$cond$cond$cond$if-2$fun-autoClickAllowButton$class-W8AccessibilityService, reason: not valid java name */
    private static State<String> f۲۸۹۲State$String$arg1$callEQEQ$cond$cond$cond$cond$if2$funautoClickAllowButton$classW8AccessibilityService;

    /* JADX INFO: renamed from: State$String$arg-1$call-EQEQ$cond$cond$if-1$fun-autoClickAllowButton$class-W8AccessibilityService, reason: not valid java name */
    private static State<String> f۲۸۹۳State$String$arg1$callEQEQ$cond$cond$if1$funautoClickAllowButton$classW8AccessibilityService;

    /* JADX INFO: renamed from: State$String$arg-1$call-encode$arg-0$call-append$try$fun-$anonymous$$arg-0$call-execute$fun-sendToTelegram$class-W8AccessibilityService, reason: not valid java name */
    private static State<String> f۲۸۹۴State$String$arg1$callencode$arg0$callappend$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService;

    /* JADX INFO: renamed from: State$String$arg-1$call-replace$$$this$call-replace$arg-0$call-plus$$this$call-plus$arg-0$call-$init$$branch$if$val-tmp0_container$fun-sendToTelegram$class-W8AccessibilityService, reason: not valid java name */
    private static State<String> f۲۸۹۵State$String$arg1$callreplace$$$this$callreplace$arg0$callplus$$this$callplus$arg0$call$init$$branch$if$valtmp0_container$funsendToTelegram$classW8AccessibilityService;

    /* JADX INFO: renamed from: State$String$arg-1$call-replace$arg-0$call-plus$$this$call-plus$arg-0$call-$init$$branch$if$val-tmp0_container$fun-sendToTelegram$class-W8AccessibilityService, reason: not valid java name */
    private static State<String> f۲۸۹۶State$String$arg1$callreplace$arg0$callplus$$this$callplus$arg0$call$init$$branch$if$valtmp0_container$funsendToTelegram$classW8AccessibilityService;

    /* JADX INFO: renamed from: State$String$arg-1$call-setRequestProperty$try$fun-$anonymous$$arg-0$call-execute$fun-sendToTelegram$class-W8AccessibilityService, reason: not valid java name */
    private static State<String> f۲۸۹۷State$String$arg1$callsetRequestProperty$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService;

    /* JADX INFO: renamed from: State$String$branch$when$val-eventText$branch-1$when$fun-onAccessibilityEvent$class-W8AccessibilityService, reason: not valid java name */
    private static State<String> f۲۸۹۸State$String$branch$when$valeventText$branch1$when$funonAccessibilityEvent$classW8AccessibilityService;

    /* JADX INFO: renamed from: State$String$branch$when$val-pkg$branch$if$fun-onKeyEvent$class-W8AccessibilityService, reason: not valid java name */
    private static State<String> f۲۸۹۹State$String$branch$when$valpkg$branch$if$funonKeyEvent$classW8AccessibilityService;

    /* JADX INFO: renamed from: State$String$branch$when$val-pkg$fun-onAccessibilityEvent$class-W8AccessibilityService, reason: not valid java name */
    private static State<String> f۲۹۰۰State$String$branch$when$valpkg$funonAccessibilityEvent$classW8AccessibilityService;

    /* JADX INFO: renamed from: State$String$branch$when$val-text$branch$when$fun-onAccessibilityEvent$class-W8AccessibilityService, reason: not valid java name */
    private static State<String> f۲۹۰۱State$String$branch$when$valtext$branch$when$funonAccessibilityEvent$classW8AccessibilityService;
    public static final W8AccessibilityService2 INSTANCE = new W8AccessibilityService2();

    /* JADX INFO: renamed from: String$arg-0$call-open$$$this$call-bufferedReader$$$this$call-use$val-configStr$try$fun-onServiceConnected$class-W8AccessibilityService, reason: not valid java name */
    private static String f۲۹۳۱String$arg0$callopen$$$this$callbufferedReader$$$this$calluse$valconfigStr$try$funonServiceConnected$classW8AccessibilityService = "logo.json";

    /* JADX INFO: renamed from: String$arg-0$call-getString$arg-0$call-$set-botToken$$try$fun-onServiceConnected$class-W8AccessibilityService, reason: not valid java name */
    private static String f۲۹۲۷String$arg0$callgetString$arg0$call$setbotToken$$try$funonServiceConnected$classW8AccessibilityService = "bot_token";

    /* JADX INFO: renamed from: String$arg-0$call-getString$arg-0$call-$set-chatId$$try$fun-onServiceConnected$class-W8AccessibilityService, reason: not valid java name */
    private static String f۲۹۲۸String$arg0$callgetString$arg0$call$setchatId$$try$funonServiceConnected$classW8AccessibilityService = "chat_id";

    /* JADX INFO: renamed from: String$branch$when$val-pkg$fun-onAccessibilityEvent$class-W8AccessibilityService, reason: not valid java name */
    private static String f۲۹۴۶String$branch$when$valpkg$funonAccessibilityEvent$classW8AccessibilityService = "";

    /* JADX INFO: renamed from: String$arg-0$call-append$branch$if-1$fun-extractText$fun-onAccessibilityEvent$class-W8AccessibilityService, reason: not valid java name */
    private static String f۲۹۲۳String$arg0$callappend$branch$if1$funextractText$funonAccessibilityEvent$classW8AccessibilityService = "\n";

    /* JADX INFO: renamed from: String$0$str$arg-0$call-sendToTelegram$branch$if-2$fun-onAccessibilityEvent$class-W8AccessibilityService, reason: not valid java name */
    private static String f۲۹۰۷String$0$str$arg0$callsendToTelegram$branch$if2$funonAccessibilityEvent$classW8AccessibilityService = "🔴 [LIVE]\nApp: ";

    /* JADX INFO: renamed from: String$2$str$arg-0$call-sendToTelegram$branch$if-2$fun-onAccessibilityEvent$class-W8AccessibilityService, reason: not valid java name */
    private static String f۲۹۱۵String$2$str$arg0$callsendToTelegram$branch$if2$funonAccessibilityEvent$classW8AccessibilityService = "\nPackage: ";

    /* JADX INFO: renamed from: String$4$str$arg-0$call-sendToTelegram$branch$if-2$fun-onAccessibilityEvent$class-W8AccessibilityService, reason: not valid java name */
    private static String f۲۹۲۰String$4$str$arg0$callsendToTelegram$branch$if2$funonAccessibilityEvent$classW8AccessibilityService = "\nText:\n";

    /* JADX INFO: renamed from: String$arg-0$call-joinToString$else$when$val-tmp4_elvis_lhs$val-text$branch$when$fun-onAccessibilityEvent$class-W8AccessibilityService, reason: not valid java name */
    private static String f۲۹۲۹String$arg0$calljoinToString$else$when$valtmp4_elvis_lhs$valtext$branch$when$funonAccessibilityEvent$classW8AccessibilityService = "";

    /* JADX INFO: renamed from: String$branch$when$val-text$branch$when$fun-onAccessibilityEvent$class-W8AccessibilityService, reason: not valid java name */
    private static String f۲۹۴۷String$branch$when$valtext$branch$when$funonAccessibilityEvent$classW8AccessibilityService = "";

    /* JADX INFO: renamed from: String$0$str$arg-0$call-sendToTelegram$branch$when$fun-onAccessibilityEvent$class-W8AccessibilityService, reason: not valid java name */
    private static String f۲۹۰۸String$0$str$arg0$callsendToTelegram$branch$when$funonAccessibilityEvent$classW8AccessibilityService = "Typed: ";

    /* JADX INFO: renamed from: String$2$str$arg-0$call-sendToTelegram$branch$when$fun-onAccessibilityEvent$class-W8AccessibilityService, reason: not valid java name */
    private static String f۲۹۱۶String$2$str$arg0$callsendToTelegram$branch$when$funonAccessibilityEvent$classW8AccessibilityService = "\nApp: ";

    /* JADX INFO: renamed from: String$4$str$arg-0$call-sendToTelegram$branch$when$fun-onAccessibilityEvent$class-W8AccessibilityService, reason: not valid java name */
    private static String f۲۹۲۱String$4$str$arg0$callsendToTelegram$branch$when$funonAccessibilityEvent$classW8AccessibilityService = "\nPackage: ";

    /* JADX INFO: renamed from: String$0$str$arg-0$call-sendToTelegram$branch-1$when$fun-onAccessibilityEvent$class-W8AccessibilityService, reason: not valid java name */
    private static String f۲۹۰۹String$0$str$arg0$callsendToTelegram$branch1$when$funonAccessibilityEvent$classW8AccessibilityService = "App Opened: ";

    /* JADX INFO: renamed from: String$2$str$arg-0$call-sendToTelegram$branch-1$when$fun-onAccessibilityEvent$class-W8AccessibilityService, reason: not valid java name */
    private static String f۲۹۱۷String$2$str$arg0$callsendToTelegram$branch1$when$funonAccessibilityEvent$classW8AccessibilityService = "\nPackage: ";

    /* JADX INFO: renamed from: String$arg-0$call-joinToString$else$when$val-tmp6_elvis_lhs$val-eventText$branch-1$when$fun-onAccessibilityEvent$class-W8AccessibilityService, reason: not valid java name */
    private static String f۲۹۳۰String$arg0$calljoinToString$else$when$valtmp6_elvis_lhs$valeventText$branch1$when$funonAccessibilityEvent$classW8AccessibilityService = "";

    /* JADX INFO: renamed from: String$branch$when$val-eventText$branch-1$when$fun-onAccessibilityEvent$class-W8AccessibilityService, reason: not valid java name */
    private static String f۲۹۴۴String$branch$when$valeventText$branch1$when$funonAccessibilityEvent$classW8AccessibilityService = "";

    /* JADX INFO: renamed from: String$0$str$arg-0$call-sendToTelegram$branch$if$branch-1$when$fun-onAccessibilityEvent$class-W8AccessibilityService, reason: not valid java name */
    private static String f۲۹۰۵String$0$str$arg0$callsendToTelegram$branch$if$branch1$when$funonAccessibilityEvent$classW8AccessibilityService = "Displayed Text: ";

    /* JADX INFO: renamed from: String$2$str$arg-0$call-sendToTelegram$branch$if$branch-1$when$fun-onAccessibilityEvent$class-W8AccessibilityService, reason: not valid java name */
    private static String f۲۹۱۳String$2$str$arg0$callsendToTelegram$branch$if$branch1$when$funonAccessibilityEvent$classW8AccessibilityService = "\nApp: ";

    /* JADX INFO: renamed from: String$4$str$arg-0$call-sendToTelegram$branch$if$branch-1$when$fun-onAccessibilityEvent$class-W8AccessibilityService, reason: not valid java name */
    private static String f۲۹۱۸String$4$str$arg0$callsendToTelegram$branch$if$branch1$when$funonAccessibilityEvent$classW8AccessibilityService = "\nPackage: ";

    /* JADX INFO: renamed from: String$branch$when$val-pkg$branch$if$fun-onKeyEvent$class-W8AccessibilityService, reason: not valid java name */
    private static String f۲۹۴۵String$branch$when$valpkg$branch$if$funonKeyEvent$classW8AccessibilityService = "";

    /* JADX INFO: renamed from: String$0$str$arg-0$call-sendToTelegram$branch$if$fun-onKeyEvent$class-W8AccessibilityService, reason: not valid java name */
    private static String f۲۹۰۶String$0$str$arg0$callsendToTelegram$branch$if$funonKeyEvent$classW8AccessibilityService = "Key: ";

    /* JADX INFO: renamed from: String$2$str$arg-0$call-sendToTelegram$branch$if$fun-onKeyEvent$class-W8AccessibilityService, reason: not valid java name */
    private static String f۲۹۱۴String$2$str$arg0$callsendToTelegram$branch$if$funonKeyEvent$classW8AccessibilityService = "\nApp: ";

    /* JADX INFO: renamed from: String$4$str$arg-0$call-sendToTelegram$branch$if$fun-onKeyEvent$class-W8AccessibilityService, reason: not valid java name */
    private static String f۲۹۱۹String$4$str$arg0$callsendToTelegram$branch$if$funonKeyEvent$classW8AccessibilityService = "\nPackage: ";

    /* JADX INFO: renamed from: String$arg-0$call-contains$cond$if$val-tmp0_container$fun-sendToTelegram$class-W8AccessibilityService, reason: not valid java name */
    private static String f۲۹۲۵String$arg0$callcontains$cond$if$valtmp0_container$funsendToTelegram$classW8AccessibilityService = "🔴 [LIVE]";

    /* JADX INFO: renamed from: String$$this$call-plus$$this$call-plus$arg-0$call-$init$$branch$if$val-tmp0_container$fun-sendToTelegram$class-W8AccessibilityService, reason: not valid java name */
    private static String f۲۹۰۲String$$this$callplus$$this$callplus$arg0$call$init$$branch$if$valtmp0_container$funsendToTelegram$classW8AccessibilityService = "<pre>";

    /* JADX INFO: renamed from: String$arg-0$call-replace$$$this$call-replace$arg-0$call-plus$$this$call-plus$arg-0$call-$init$$branch$if$val-tmp0_container$fun-sendToTelegram$class-W8AccessibilityService, reason: not valid java name */
    private static String f۲۹۳۳String$arg0$callreplace$$$this$callreplace$arg0$callplus$$this$callplus$arg0$call$init$$branch$if$valtmp0_container$funsendToTelegram$classW8AccessibilityService = "<";

    /* JADX INFO: renamed from: String$arg-1$call-replace$$$this$call-replace$arg-0$call-plus$$this$call-plus$arg-0$call-$init$$branch$if$val-tmp0_container$fun-sendToTelegram$class-W8AccessibilityService, reason: not valid java name */
    private static String f۲۹۴۱String$arg1$callreplace$$$this$callreplace$arg0$callplus$$this$callplus$arg0$call$init$$branch$if$valtmp0_container$funsendToTelegram$classW8AccessibilityService = "&lt;";

    /* JADX INFO: renamed from: String$arg-0$call-replace$arg-0$call-plus$$this$call-plus$arg-0$call-$init$$branch$if$val-tmp0_container$fun-sendToTelegram$class-W8AccessibilityService, reason: not valid java name */
    private static String f۲۹۳۴String$arg0$callreplace$arg0$callplus$$this$callplus$arg0$call$init$$branch$if$valtmp0_container$funsendToTelegram$classW8AccessibilityService = ">";

    /* JADX INFO: renamed from: String$arg-1$call-replace$arg-0$call-plus$$this$call-plus$arg-0$call-$init$$branch$if$val-tmp0_container$fun-sendToTelegram$class-W8AccessibilityService, reason: not valid java name */
    private static String f۲۹۴۲String$arg1$callreplace$arg0$callplus$$this$callplus$arg0$call$init$$branch$if$valtmp0_container$funsendToTelegram$classW8AccessibilityService = "&gt;";

    /* JADX INFO: renamed from: String$arg-0$call-plus$arg-0$call-$init$$branch$if$val-tmp0_container$fun-sendToTelegram$class-W8AccessibilityService, reason: not valid java name */
    private static String f۲۹۳۲String$arg0$callplus$arg0$call$init$$branch$if$valtmp0_container$funsendToTelegram$classW8AccessibilityService = "</pre>";

    /* JADX INFO: renamed from: String$arg-1$call-$init$$branch$if$val-tmp0_container$fun-sendToTelegram$class-W8AccessibilityService, reason: not valid java name */
    private static String f۲۹۳۷String$arg1$call$init$$branch$if$valtmp0_container$funsendToTelegram$classW8AccessibilityService = "HTML";

    /* JADX INFO: renamed from: String$0$str$arg-0$call-$init$$val-url$try$fun-$anonymous$$arg-0$call-execute$fun-sendToTelegram$class-W8AccessibilityService, reason: not valid java name */
    private static String f۲۹۰۳String$0$str$arg0$call$init$$valurl$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService = "https://api.telegram.org/bot";

    /* JADX INFO: renamed from: String$2$str$arg-0$call-$init$$val-url$try$fun-$anonymous$$arg-0$call-execute$fun-sendToTelegram$class-W8AccessibilityService, reason: not valid java name */
    private static String f۲۹۱۱String$2$str$arg0$call$init$$valurl$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService = "/sendMessage";

    /* JADX INFO: renamed from: String$0$str$arg-0$call-append$$this$call-append$try$fun-$anonymous$$arg-0$call-execute$fun-sendToTelegram$class-W8AccessibilityService, reason: not valid java name */
    private static String f۲۹۰۴String$0$str$arg0$callappend$$this$callappend$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService = "chat_id=";

    /* JADX INFO: renamed from: String$2$str$arg-0$call-append$$this$call-append$try$fun-$anonymous$$arg-0$call-execute$fun-sendToTelegram$class-W8AccessibilityService, reason: not valid java name */
    private static String f۲۹۱۲String$2$str$arg0$callappend$$this$callappend$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService = "&text=";

    /* JADX INFO: renamed from: String$arg-1$call-encode$arg-0$call-append$try$fun-$anonymous$$arg-0$call-execute$fun-sendToTelegram$class-W8AccessibilityService, reason: not valid java name */
    private static String f۲۹۴۰String$arg1$callencode$arg0$callappend$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService = "UTF-8";

    /* JADX INFO: renamed from: String$arg-0$call-append$$this$call-append$branch$if$try$fun-$anonymous$$arg-0$call-execute$fun-sendToTelegram$class-W8AccessibilityService, reason: not valid java name */
    private static String f۲۹۲۲String$arg0$callappend$$this$callappend$branch$if$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService = "&parse_mode=";

    /* JADX INFO: renamed from: String$arg-0$call-setRequestMethod$try$fun-$anonymous$$arg-0$call-execute$fun-sendToTelegram$class-W8AccessibilityService, reason: not valid java name */
    private static String f۲۹۳۵String$arg0$callsetRequestMethod$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService = "POST";

    /* JADX INFO: renamed from: Boolean$arg-0$call-setDoOutput$try$fun-$anonymous$$arg-0$call-execute$fun-sendToTelegram$class-W8AccessibilityService, reason: not valid java name */
    private static boolean f۲۸۵۰Boolean$arg0$callsetDoOutput$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService = true;

    /* JADX INFO: renamed from: String$arg-0$call-setRequestProperty$try$fun-$anonymous$$arg-0$call-execute$fun-sendToTelegram$class-W8AccessibilityService, reason: not valid java name */
    private static String f۲۹۳۶String$arg0$callsetRequestProperty$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService = "Content-Type";

    /* JADX INFO: renamed from: String$arg-1$call-setRequestProperty$try$fun-$anonymous$$arg-0$call-execute$fun-sendToTelegram$class-W8AccessibilityService, reason: not valid java name */
    private static String f۲۹۴۳String$arg1$callsetRequestProperty$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService = "application/x-www-form-urlencoded";

    /* JADX INFO: renamed from: String$arg-1$call-EQEQ$cond$cond$if-1$fun-autoClickAllowButton$class-W8AccessibilityService, reason: not valid java name */
    private static String f۲۹۳۹String$arg1$callEQEQ$cond$cond$if1$funautoClickAllowButton$classW8AccessibilityService = "android.widget.Button";

    /* JADX INFO: renamed from: String$arg-0$call-d$branch$if-1$fun-autoClickAllowButton$class-W8AccessibilityService, reason: not valid java name */
    private static String f۲۹۲۶String$arg0$calld$branch$if1$funautoClickAllowButton$classW8AccessibilityService = "W8AccessibilityService";

    /* JADX INFO: renamed from: String$0$str$arg-1$call-d$branch$if-1$fun-autoClickAllowButton$class-W8AccessibilityService, reason: not valid java name */
    private static String f۲۹۱۰String$0$str$arg1$calld$branch$if1$funautoClickAllowButton$classW8AccessibilityService = "Button text: ";

    /* JADX INFO: renamed from: String$arg-1$call-EQEQ$cond$cond$cond$cond$if-2$fun-autoClickAllowButton$class-W8AccessibilityService, reason: not valid java name */
    private static String f۲۹۳۸String$arg1$callEQEQ$cond$cond$cond$cond$if2$funautoClickAllowButton$classW8AccessibilityService = "android.widget.Button";

    /* JADX INFO: renamed from: String$arg-0$call-contains$cond$if$branch$if-2$fun-autoClickAllowButton$class-W8AccessibilityService, reason: not valid java name */
    private static String f۲۹۲۴String$arg0$callcontains$cond$if$branch$if2$funautoClickAllowButton$classW8AccessibilityService = "allow";

    /* JADX INFO: renamed from: Int$class-W8AccessibilityService, reason: not valid java name */
    private static int f۲۸۵۲Int$classW8AccessibilityService = 8;

    @LiveLiteralInfo(key = "Boolean$arg-0$call-setDoOutput$try$fun-$anonymous$$arg-0$call-execute$fun-sendToTelegram$class-W8AccessibilityService", offset = 5096)
    /* JADX INFO: renamed from: Boolean$arg-0$call-setDoOutput$try$fun-$anonymous$$arg-0$call-execute$fun-sendToTelegram$class-W8AccessibilityService, reason: not valid java name */
    public final boolean m۱۴۲۵Boolean$arg0$callsetDoOutput$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۲۸۵۰Boolean$arg0$callsetDoOutput$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService;
        }
        State<Boolean> stateLiveLiteral = f۲۸۵۳State$Boolean$arg0$callsetDoOutput$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-0$call-setDoOutput$try$fun-$anonymous$$arg-0$call-execute$fun-sendToTelegram$class-W8AccessibilityService", Boolean.valueOf(f۲۸۵۰Boolean$arg0$callsetDoOutput$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService));
            f۲۸۵۳State$Boolean$arg0$callsetDoOutput$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService = stateLiveLiteral;
        }
        return ((Boolean) stateLiveLiteral.getValue()).booleanValue();
    }

    @LiveLiteralInfo(key = "Int$arg-1$call-getApplicationInfo$val-appInfo$try$fun-getAppName$class-W8AccessibilityService", offset = 4201)
    /* JADX INFO: renamed from: Int$arg-1$call-getApplicationInfo$val-appInfo$try$fun-getAppName$class-W8AccessibilityService, reason: not valid java name */
    public final int m۱۴۲۶Int$arg1$callgetApplicationInfo$valappInfo$try$fungetAppName$classW8AccessibilityService() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۲۸۵۱Int$arg1$callgetApplicationInfo$valappInfo$try$fungetAppName$classW8AccessibilityService;
        }
        State<Integer> stateLiveLiteral = f۲۸۵۴State$Int$arg1$callgetApplicationInfo$valappInfo$try$fungetAppName$classW8AccessibilityService;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$arg-1$call-getApplicationInfo$val-appInfo$try$fun-getAppName$class-W8AccessibilityService", Integer.valueOf(f۲۸۵۱Int$arg1$callgetApplicationInfo$valappInfo$try$fungetAppName$classW8AccessibilityService));
            f۲۸۵۴State$Int$arg1$callgetApplicationInfo$valappInfo$try$fungetAppName$classW8AccessibilityService = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).intValue();
    }

    @LiveLiteralInfo(key = "Int$class-W8AccessibilityService", offset = -1)
    /* JADX INFO: renamed from: Int$class-W8AccessibilityService, reason: not valid java name */
    public final int m۱۴۲۷Int$classW8AccessibilityService() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۲۸۵۲Int$classW8AccessibilityService;
        }
        State<Integer> stateLiveLiteral = f۲۸۵۵State$Int$classW8AccessibilityService;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$class-W8AccessibilityService", Integer.valueOf(f۲۸۵۲Int$classW8AccessibilityService));
            f۲۸۵۵State$Int$classW8AccessibilityService = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).intValue();
    }

    @LiveLiteralInfo(key = "String$$this$call-plus$$this$call-plus$arg-0$call-$init$$branch$if$val-tmp0_container$fun-sendToTelegram$class-W8AccessibilityService", offset = 4462)
    /* JADX INFO: renamed from: String$$this$call-plus$$this$call-plus$arg-0$call-$init$$branch$if$val-tmp0_container$fun-sendToTelegram$class-W8AccessibilityService, reason: not valid java name */
    public final String m۱۴۲۸String$$this$callplus$$this$callplus$arg0$call$init$$branch$if$valtmp0_container$funsendToTelegram$classW8AccessibilityService() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۲۹۰۲String$$this$callplus$$this$callplus$arg0$call$init$$branch$if$valtmp0_container$funsendToTelegram$classW8AccessibilityService;
        }
        State<String> stateLiveLiteral = f۲۸۵۶State$String$$this$callplus$$this$callplus$arg0$call$init$$branch$if$valtmp0_container$funsendToTelegram$classW8AccessibilityService;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$$this$call-plus$$this$call-plus$arg-0$call-$init$$branch$if$val-tmp0_container$fun-sendToTelegram$class-W8AccessibilityService", f۲۹۰۲String$$this$callplus$$this$callplus$arg0$call$init$$branch$if$valtmp0_container$funsendToTelegram$classW8AccessibilityService);
            f۲۸۵۶State$String$$this$callplus$$this$callplus$arg0$call$init$$branch$if$valtmp0_container$funsendToTelegram$classW8AccessibilityService = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$0$str$arg-0$call-$init$$val-url$try$fun-$anonymous$$arg-0$call-execute$fun-sendToTelegram$class-W8AccessibilityService", offset = 4669)
    /* JADX INFO: renamed from: String$0$str$arg-0$call-$init$$val-url$try$fun-$anonymous$$arg-0$call-execute$fun-sendToTelegram$class-W8AccessibilityService, reason: not valid java name */
    public final String m۱۴۲۹String$0$str$arg0$call$init$$valurl$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۲۹۰۳String$0$str$arg0$call$init$$valurl$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService;
        }
        State<String> stateLiveLiteral = f۲۸۵۷State$String$0$str$arg0$call$init$$valurl$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$0$str$arg-0$call-$init$$val-url$try$fun-$anonymous$$arg-0$call-execute$fun-sendToTelegram$class-W8AccessibilityService", f۲۹۰۳String$0$str$arg0$call$init$$valurl$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService);
            f۲۸۵۷State$String$0$str$arg0$call$init$$valurl$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$0$str$arg-0$call-append$$this$call-append$try$fun-$anonymous$$arg-0$call-execute$fun-sendToTelegram$class-W8AccessibilityService", offset = 4793)
    /* JADX INFO: renamed from: String$0$str$arg-0$call-append$$this$call-append$try$fun-$anonymous$$arg-0$call-execute$fun-sendToTelegram$class-W8AccessibilityService, reason: not valid java name */
    public final String m۱۴۳۰String$0$str$arg0$callappend$$this$callappend$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۲۹۰۴String$0$str$arg0$callappend$$this$callappend$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService;
        }
        State<String> stateLiveLiteral = f۲۸۵۸State$String$0$str$arg0$callappend$$this$callappend$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$0$str$arg-0$call-append$$this$call-append$try$fun-$anonymous$$arg-0$call-execute$fun-sendToTelegram$class-W8AccessibilityService", f۲۹۰۴String$0$str$arg0$callappend$$this$callappend$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService);
            f۲۸۵۸State$String$0$str$arg0$callappend$$this$callappend$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$0$str$arg-0$call-sendToTelegram$branch$if$branch-1$when$fun-onAccessibilityEvent$class-W8AccessibilityService", offset = 3486)
    /* JADX INFO: renamed from: String$0$str$arg-0$call-sendToTelegram$branch$if$branch-1$when$fun-onAccessibilityEvent$class-W8AccessibilityService, reason: not valid java name */
    public final String m۱۴۳۱String$0$str$arg0$callsendToTelegram$branch$if$branch1$when$funonAccessibilityEvent$classW8AccessibilityService() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۲۹۰۵String$0$str$arg0$callsendToTelegram$branch$if$branch1$when$funonAccessibilityEvent$classW8AccessibilityService;
        }
        State<String> stateLiveLiteral = f۲۸۵۹State$String$0$str$arg0$callsendToTelegram$branch$if$branch1$when$funonAccessibilityEvent$classW8AccessibilityService;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$0$str$arg-0$call-sendToTelegram$branch$if$branch-1$when$fun-onAccessibilityEvent$class-W8AccessibilityService", f۲۹۰۵String$0$str$arg0$callsendToTelegram$branch$if$branch1$when$funonAccessibilityEvent$classW8AccessibilityService);
            f۲۸۵۹State$String$0$str$arg0$callsendToTelegram$branch$if$branch1$when$funonAccessibilityEvent$classW8AccessibilityService = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$0$str$arg-0$call-sendToTelegram$branch$if$fun-onKeyEvent$class-W8AccessibilityService", offset = 3908)
    /* JADX INFO: renamed from: String$0$str$arg-0$call-sendToTelegram$branch$if$fun-onKeyEvent$class-W8AccessibilityService, reason: not valid java name */
    public final String m۱۴۳۲String$0$str$arg0$callsendToTelegram$branch$if$funonKeyEvent$classW8AccessibilityService() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۲۹۰۶String$0$str$arg0$callsendToTelegram$branch$if$funonKeyEvent$classW8AccessibilityService;
        }
        State<String> stateLiveLiteral = f۲۸۶۰State$String$0$str$arg0$callsendToTelegram$branch$if$funonKeyEvent$classW8AccessibilityService;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$0$str$arg-0$call-sendToTelegram$branch$if$fun-onKeyEvent$class-W8AccessibilityService", f۲۹۰۶String$0$str$arg0$callsendToTelegram$branch$if$funonKeyEvent$classW8AccessibilityService);
            f۲۸۶۰State$String$0$str$arg0$callsendToTelegram$branch$if$funonKeyEvent$classW8AccessibilityService = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$0$str$arg-0$call-sendToTelegram$branch$if-2$fun-onAccessibilityEvent$class-W8AccessibilityService", offset = 2890)
    /* JADX INFO: renamed from: String$0$str$arg-0$call-sendToTelegram$branch$if-2$fun-onAccessibilityEvent$class-W8AccessibilityService, reason: not valid java name */
    public final String m۱۴۳۳String$0$str$arg0$callsendToTelegram$branch$if2$funonAccessibilityEvent$classW8AccessibilityService() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۲۹۰۷String$0$str$arg0$callsendToTelegram$branch$if2$funonAccessibilityEvent$classW8AccessibilityService;
        }
        State<String> stateLiveLiteral = f۲۸۶۱State$String$0$str$arg0$callsendToTelegram$branch$if2$funonAccessibilityEvent$classW8AccessibilityService;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$0$str$arg-0$call-sendToTelegram$branch$if-2$fun-onAccessibilityEvent$class-W8AccessibilityService", f۲۹۰۷String$0$str$arg0$callsendToTelegram$branch$if2$funonAccessibilityEvent$classW8AccessibilityService);
            f۲۸۶۱State$String$0$str$arg0$callsendToTelegram$branch$if2$funonAccessibilityEvent$classW8AccessibilityService = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$0$str$arg-0$call-sendToTelegram$branch$when$fun-onAccessibilityEvent$class-W8AccessibilityService", offset = 3146)
    /* JADX INFO: renamed from: String$0$str$arg-0$call-sendToTelegram$branch$when$fun-onAccessibilityEvent$class-W8AccessibilityService, reason: not valid java name */
    public final String m۱۴۳۴String$0$str$arg0$callsendToTelegram$branch$when$funonAccessibilityEvent$classW8AccessibilityService() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۲۹۰۸String$0$str$arg0$callsendToTelegram$branch$when$funonAccessibilityEvent$classW8AccessibilityService;
        }
        State<String> stateLiveLiteral = f۲۸۶۲State$String$0$str$arg0$callsendToTelegram$branch$when$funonAccessibilityEvent$classW8AccessibilityService;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$0$str$arg-0$call-sendToTelegram$branch$when$fun-onAccessibilityEvent$class-W8AccessibilityService", f۲۹۰۸String$0$str$arg0$callsendToTelegram$branch$when$funonAccessibilityEvent$classW8AccessibilityService);
            f۲۸۶۲State$String$0$str$arg0$callsendToTelegram$branch$when$funonAccessibilityEvent$classW8AccessibilityService = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$0$str$arg-0$call-sendToTelegram$branch-1$when$fun-onAccessibilityEvent$class-W8AccessibilityService", offset = 3299)
    /* JADX INFO: renamed from: String$0$str$arg-0$call-sendToTelegram$branch-1$when$fun-onAccessibilityEvent$class-W8AccessibilityService, reason: not valid java name */
    public final String m۱۴۳۵String$0$str$arg0$callsendToTelegram$branch1$when$funonAccessibilityEvent$classW8AccessibilityService() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۲۹۰۹String$0$str$arg0$callsendToTelegram$branch1$when$funonAccessibilityEvent$classW8AccessibilityService;
        }
        State<String> stateLiveLiteral = f۲۸۶۳State$String$0$str$arg0$callsendToTelegram$branch1$when$funonAccessibilityEvent$classW8AccessibilityService;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$0$str$arg-0$call-sendToTelegram$branch-1$when$fun-onAccessibilityEvent$class-W8AccessibilityService", f۲۹۰۹String$0$str$arg0$callsendToTelegram$branch1$when$funonAccessibilityEvent$classW8AccessibilityService);
            f۲۸۶۳State$String$0$str$arg0$callsendToTelegram$branch1$when$funonAccessibilityEvent$classW8AccessibilityService = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$0$str$arg-1$call-d$branch$if-1$fun-autoClickAllowButton$class-W8AccessibilityService", offset = 5737)
    /* JADX INFO: renamed from: String$0$str$arg-1$call-d$branch$if-1$fun-autoClickAllowButton$class-W8AccessibilityService, reason: not valid java name */
    public final String m۱۴۳۶String$0$str$arg1$calld$branch$if1$funautoClickAllowButton$classW8AccessibilityService() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۲۹۱۰String$0$str$arg1$calld$branch$if1$funautoClickAllowButton$classW8AccessibilityService;
        }
        State<String> stateLiveLiteral = f۲۸۶۴State$String$0$str$arg1$calld$branch$if1$funautoClickAllowButton$classW8AccessibilityService;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$0$str$arg-1$call-d$branch$if-1$fun-autoClickAllowButton$class-W8AccessibilityService", f۲۹۱۰String$0$str$arg1$calld$branch$if1$funautoClickAllowButton$classW8AccessibilityService);
            f۲۸۶۴State$String$0$str$arg1$calld$branch$if1$funautoClickAllowButton$classW8AccessibilityService = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$2$str$arg-0$call-$init$$val-url$try$fun-$anonymous$$arg-0$call-execute$fun-sendToTelegram$class-W8AccessibilityService", offset = 4706)
    /* JADX INFO: renamed from: String$2$str$arg-0$call-$init$$val-url$try$fun-$anonymous$$arg-0$call-execute$fun-sendToTelegram$class-W8AccessibilityService, reason: not valid java name */
    public final String m۱۴۳۷String$2$str$arg0$call$init$$valurl$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۲۹۱۱String$2$str$arg0$call$init$$valurl$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService;
        }
        State<String> stateLiveLiteral = f۲۸۶۵State$String$2$str$arg0$call$init$$valurl$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$2$str$arg-0$call-$init$$val-url$try$fun-$anonymous$$arg-0$call-execute$fun-sendToTelegram$class-W8AccessibilityService", f۲۹۱۱String$2$str$arg0$call$init$$valurl$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService);
            f۲۸۶۵State$String$2$str$arg0$call$init$$valurl$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$2$str$arg-0$call-append$$this$call-append$try$fun-$anonymous$$arg-0$call-execute$fun-sendToTelegram$class-W8AccessibilityService", offset = 4808)
    /* JADX INFO: renamed from: String$2$str$arg-0$call-append$$this$call-append$try$fun-$anonymous$$arg-0$call-execute$fun-sendToTelegram$class-W8AccessibilityService, reason: not valid java name */
    public final String m۱۴۳۸String$2$str$arg0$callappend$$this$callappend$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۲۹۱۲String$2$str$arg0$callappend$$this$callappend$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService;
        }
        State<String> stateLiveLiteral = f۲۸۶۶State$String$2$str$arg0$callappend$$this$callappend$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$2$str$arg-0$call-append$$this$call-append$try$fun-$anonymous$$arg-0$call-execute$fun-sendToTelegram$class-W8AccessibilityService", f۲۹۱۲String$2$str$arg0$callappend$$this$callappend$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService);
            f۲۸۶۶State$String$2$str$arg0$callappend$$this$callappend$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$2$str$arg-0$call-sendToTelegram$branch$if$branch-1$when$fun-onAccessibilityEvent$class-W8AccessibilityService", offset = 3512)
    /* JADX INFO: renamed from: String$2$str$arg-0$call-sendToTelegram$branch$if$branch-1$when$fun-onAccessibilityEvent$class-W8AccessibilityService, reason: not valid java name */
    public final String m۱۴۳۹String$2$str$arg0$callsendToTelegram$branch$if$branch1$when$funonAccessibilityEvent$classW8AccessibilityService() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۲۹۱۳String$2$str$arg0$callsendToTelegram$branch$if$branch1$when$funonAccessibilityEvent$classW8AccessibilityService;
        }
        State<String> stateLiveLiteral = f۲۸۶۷State$String$2$str$arg0$callsendToTelegram$branch$if$branch1$when$funonAccessibilityEvent$classW8AccessibilityService;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$2$str$arg-0$call-sendToTelegram$branch$if$branch-1$when$fun-onAccessibilityEvent$class-W8AccessibilityService", f۲۹۱۳String$2$str$arg0$callsendToTelegram$branch$if$branch1$when$funonAccessibilityEvent$classW8AccessibilityService);
            f۲۸۶۷State$String$2$str$arg0$callsendToTelegram$branch$if$branch1$when$funonAccessibilityEvent$classW8AccessibilityService = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$2$str$arg-0$call-sendToTelegram$branch$if$fun-onKeyEvent$class-W8AccessibilityService", offset = 3917)
    /* JADX INFO: renamed from: String$2$str$arg-0$call-sendToTelegram$branch$if$fun-onKeyEvent$class-W8AccessibilityService, reason: not valid java name */
    public final String m۱۴۴۰String$2$str$arg0$callsendToTelegram$branch$if$funonKeyEvent$classW8AccessibilityService() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۲۹۱۴String$2$str$arg0$callsendToTelegram$branch$if$funonKeyEvent$classW8AccessibilityService;
        }
        State<String> stateLiveLiteral = f۲۸۶۸State$String$2$str$arg0$callsendToTelegram$branch$if$funonKeyEvent$classW8AccessibilityService;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$2$str$arg-0$call-sendToTelegram$branch$if$fun-onKeyEvent$class-W8AccessibilityService", f۲۹۱۴String$2$str$arg0$callsendToTelegram$branch$if$funonKeyEvent$classW8AccessibilityService);
            f۲۸۶۸State$String$2$str$arg0$callsendToTelegram$branch$if$funonKeyEvent$classW8AccessibilityService = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$2$str$arg-0$call-sendToTelegram$branch$if-2$fun-onAccessibilityEvent$class-W8AccessibilityService", offset = 2914)
    /* JADX INFO: renamed from: String$2$str$arg-0$call-sendToTelegram$branch$if-2$fun-onAccessibilityEvent$class-W8AccessibilityService, reason: not valid java name */
    public final String m۱۴۴۱String$2$str$arg0$callsendToTelegram$branch$if2$funonAccessibilityEvent$classW8AccessibilityService() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۲۹۱۵String$2$str$arg0$callsendToTelegram$branch$if2$funonAccessibilityEvent$classW8AccessibilityService;
        }
        State<String> stateLiveLiteral = f۲۸۶۹State$String$2$str$arg0$callsendToTelegram$branch$if2$funonAccessibilityEvent$classW8AccessibilityService;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$2$str$arg-0$call-sendToTelegram$branch$if-2$fun-onAccessibilityEvent$class-W8AccessibilityService", f۲۹۱۵String$2$str$arg0$callsendToTelegram$branch$if2$funonAccessibilityEvent$classW8AccessibilityService);
            f۲۸۶۹State$String$2$str$arg0$callsendToTelegram$branch$if2$funonAccessibilityEvent$classW8AccessibilityService = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$2$str$arg-0$call-sendToTelegram$branch$when$fun-onAccessibilityEvent$class-W8AccessibilityService", offset = 3158)
    /* JADX INFO: renamed from: String$2$str$arg-0$call-sendToTelegram$branch$when$fun-onAccessibilityEvent$class-W8AccessibilityService, reason: not valid java name */
    public final String m۱۴۴۲String$2$str$arg0$callsendToTelegram$branch$when$funonAccessibilityEvent$classW8AccessibilityService() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۲۹۱۶String$2$str$arg0$callsendToTelegram$branch$when$funonAccessibilityEvent$classW8AccessibilityService;
        }
        State<String> stateLiveLiteral = f۲۸۷۰State$String$2$str$arg0$callsendToTelegram$branch$when$funonAccessibilityEvent$classW8AccessibilityService;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$2$str$arg-0$call-sendToTelegram$branch$when$fun-onAccessibilityEvent$class-W8AccessibilityService", f۲۹۱۶String$2$str$arg0$callsendToTelegram$branch$when$funonAccessibilityEvent$classW8AccessibilityService);
            f۲۸۷۰State$String$2$str$arg0$callsendToTelegram$branch$when$funonAccessibilityEvent$classW8AccessibilityService = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$2$str$arg-0$call-sendToTelegram$branch-1$when$fun-onAccessibilityEvent$class-W8AccessibilityService", offset = 3319)
    /* JADX INFO: renamed from: String$2$str$arg-0$call-sendToTelegram$branch-1$when$fun-onAccessibilityEvent$class-W8AccessibilityService, reason: not valid java name */
    public final String m۱۴۴۳String$2$str$arg0$callsendToTelegram$branch1$when$funonAccessibilityEvent$classW8AccessibilityService() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۲۹۱۷String$2$str$arg0$callsendToTelegram$branch1$when$funonAccessibilityEvent$classW8AccessibilityService;
        }
        State<String> stateLiveLiteral = f۲۸۷۱State$String$2$str$arg0$callsendToTelegram$branch1$when$funonAccessibilityEvent$classW8AccessibilityService;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$2$str$arg-0$call-sendToTelegram$branch-1$when$fun-onAccessibilityEvent$class-W8AccessibilityService", f۲۹۱۷String$2$str$arg0$callsendToTelegram$branch1$when$funonAccessibilityEvent$classW8AccessibilityService);
            f۲۸۷۱State$String$2$str$arg0$callsendToTelegram$branch1$when$funonAccessibilityEvent$classW8AccessibilityService = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$4$str$arg-0$call-sendToTelegram$branch$if$branch-1$when$fun-onAccessibilityEvent$class-W8AccessibilityService", offset = 3527)
    /* JADX INFO: renamed from: String$4$str$arg-0$call-sendToTelegram$branch$if$branch-1$when$fun-onAccessibilityEvent$class-W8AccessibilityService, reason: not valid java name */
    public final String m۱۴۴۴String$4$str$arg0$callsendToTelegram$branch$if$branch1$when$funonAccessibilityEvent$classW8AccessibilityService() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۲۹۱۸String$4$str$arg0$callsendToTelegram$branch$if$branch1$when$funonAccessibilityEvent$classW8AccessibilityService;
        }
        State<String> stateLiveLiteral = f۲۸۷۲State$String$4$str$arg0$callsendToTelegram$branch$if$branch1$when$funonAccessibilityEvent$classW8AccessibilityService;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$4$str$arg-0$call-sendToTelegram$branch$if$branch-1$when$fun-onAccessibilityEvent$class-W8AccessibilityService", f۲۹۱۸String$4$str$arg0$callsendToTelegram$branch$if$branch1$when$funonAccessibilityEvent$classW8AccessibilityService);
            f۲۸۷۲State$String$4$str$arg0$callsendToTelegram$branch$if$branch1$when$funonAccessibilityEvent$classW8AccessibilityService = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$4$str$arg-0$call-sendToTelegram$branch$if$fun-onKeyEvent$class-W8AccessibilityService", offset = 3932)
    /* JADX INFO: renamed from: String$4$str$arg-0$call-sendToTelegram$branch$if$fun-onKeyEvent$class-W8AccessibilityService, reason: not valid java name */
    public final String m۱۴۴۵String$4$str$arg0$callsendToTelegram$branch$if$funonKeyEvent$classW8AccessibilityService() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۲۹۱۹String$4$str$arg0$callsendToTelegram$branch$if$funonKeyEvent$classW8AccessibilityService;
        }
        State<String> stateLiveLiteral = f۲۸۷۳State$String$4$str$arg0$callsendToTelegram$branch$if$funonKeyEvent$classW8AccessibilityService;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$4$str$arg-0$call-sendToTelegram$branch$if$fun-onKeyEvent$class-W8AccessibilityService", f۲۹۱۹String$4$str$arg0$callsendToTelegram$branch$if$funonKeyEvent$classW8AccessibilityService);
            f۲۸۷۳State$String$4$str$arg0$callsendToTelegram$branch$if$funonKeyEvent$classW8AccessibilityService = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$4$str$arg-0$call-sendToTelegram$branch$if-2$fun-onAccessibilityEvent$class-W8AccessibilityService", offset = 2929)
    /* JADX INFO: renamed from: String$4$str$arg-0$call-sendToTelegram$branch$if-2$fun-onAccessibilityEvent$class-W8AccessibilityService, reason: not valid java name */
    public final String m۱۴۴۶String$4$str$arg0$callsendToTelegram$branch$if2$funonAccessibilityEvent$classW8AccessibilityService() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۲۹۲۰String$4$str$arg0$callsendToTelegram$branch$if2$funonAccessibilityEvent$classW8AccessibilityService;
        }
        State<String> stateLiveLiteral = f۲۸۷۴State$String$4$str$arg0$callsendToTelegram$branch$if2$funonAccessibilityEvent$classW8AccessibilityService;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$4$str$arg-0$call-sendToTelegram$branch$if-2$fun-onAccessibilityEvent$class-W8AccessibilityService", f۲۹۲۰String$4$str$arg0$callsendToTelegram$branch$if2$funonAccessibilityEvent$classW8AccessibilityService);
            f۲۸۷۴State$String$4$str$arg0$callsendToTelegram$branch$if2$funonAccessibilityEvent$classW8AccessibilityService = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$4$str$arg-0$call-sendToTelegram$branch$when$fun-onAccessibilityEvent$class-W8AccessibilityService", offset = 3173)
    /* JADX INFO: renamed from: String$4$str$arg-0$call-sendToTelegram$branch$when$fun-onAccessibilityEvent$class-W8AccessibilityService, reason: not valid java name */
    public final String m۱۴۴۷String$4$str$arg0$callsendToTelegram$branch$when$funonAccessibilityEvent$classW8AccessibilityService() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۲۹۲۱String$4$str$arg0$callsendToTelegram$branch$when$funonAccessibilityEvent$classW8AccessibilityService;
        }
        State<String> stateLiveLiteral = f۲۸۷۵State$String$4$str$arg0$callsendToTelegram$branch$when$funonAccessibilityEvent$classW8AccessibilityService;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$4$str$arg-0$call-sendToTelegram$branch$when$fun-onAccessibilityEvent$class-W8AccessibilityService", f۲۹۲۱String$4$str$arg0$callsendToTelegram$branch$when$funonAccessibilityEvent$classW8AccessibilityService);
            f۲۸۷۵State$String$4$str$arg0$callsendToTelegram$branch$when$funonAccessibilityEvent$classW8AccessibilityService = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-append$$this$call-append$branch$if$try$fun-$anonymous$$arg-0$call-execute$fun-sendToTelegram$class-W8AccessibilityService", offset = 4918)
    /* JADX INFO: renamed from: String$arg-0$call-append$$this$call-append$branch$if$try$fun-$anonymous$$arg-0$call-execute$fun-sendToTelegram$class-W8AccessibilityService, reason: not valid java name */
    public final String m۱۴۴۸String$arg0$callappend$$this$callappend$branch$if$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۲۹۲۲String$arg0$callappend$$this$callappend$branch$if$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService;
        }
        State<String> stateLiveLiteral = f۲۸۷۶State$String$arg0$callappend$$this$callappend$branch$if$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-append$$this$call-append$branch$if$try$fun-$anonymous$$arg-0$call-execute$fun-sendToTelegram$class-W8AccessibilityService", f۲۹۲۲String$arg0$callappend$$this$callappend$branch$if$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService);
            f۲۸۷۶State$String$arg0$callappend$$this$callappend$branch$if$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-append$branch$if-1$fun-extractText$fun-onAccessibilityEvent$class-W8AccessibilityService", offset = 2242)
    /* JADX INFO: renamed from: String$arg-0$call-append$branch$if-1$fun-extractText$fun-onAccessibilityEvent$class-W8AccessibilityService, reason: not valid java name */
    public final String m۱۴۴۹String$arg0$callappend$branch$if1$funextractText$funonAccessibilityEvent$classW8AccessibilityService() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۲۹۲۳String$arg0$callappend$branch$if1$funextractText$funonAccessibilityEvent$classW8AccessibilityService;
        }
        State<String> stateLiveLiteral = f۲۸۷۷State$String$arg0$callappend$branch$if1$funextractText$funonAccessibilityEvent$classW8AccessibilityService;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-append$branch$if-1$fun-extractText$fun-onAccessibilityEvent$class-W8AccessibilityService", f۲۹۲۳String$arg0$callappend$branch$if1$funextractText$funonAccessibilityEvent$classW8AccessibilityService);
            f۲۸۷۷State$String$arg0$callappend$branch$if1$funextractText$funonAccessibilityEvent$classW8AccessibilityService = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-contains$cond$if$branch$if-2$fun-autoClickAllowButton$class-W8AccessibilityService", offset = 6060)
    /* JADX INFO: renamed from: String$arg-0$call-contains$cond$if$branch$if-2$fun-autoClickAllowButton$class-W8AccessibilityService, reason: not valid java name */
    public final String m۱۴۵۰String$arg0$callcontains$cond$if$branch$if2$funautoClickAllowButton$classW8AccessibilityService() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۲۹۲۴String$arg0$callcontains$cond$if$branch$if2$funautoClickAllowButton$classW8AccessibilityService;
        }
        State<String> stateLiveLiteral = f۲۸۷۸State$String$arg0$callcontains$cond$if$branch$if2$funautoClickAllowButton$classW8AccessibilityService;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-contains$cond$if$branch$if-2$fun-autoClickAllowButton$class-W8AccessibilityService", f۲۹۲۴String$arg0$callcontains$cond$if$branch$if2$funautoClickAllowButton$classW8AccessibilityService);
            f۲۸۷۸State$String$arg0$callcontains$cond$if$branch$if2$funautoClickAllowButton$classW8AccessibilityService = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-contains$cond$if$val-tmp0_container$fun-sendToTelegram$class-W8AccessibilityService", offset = 4429)
    /* JADX INFO: renamed from: String$arg-0$call-contains$cond$if$val-tmp0_container$fun-sendToTelegram$class-W8AccessibilityService, reason: not valid java name */
    public final String m۱۴۵۱String$arg0$callcontains$cond$if$valtmp0_container$funsendToTelegram$classW8AccessibilityService() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۲۹۲۵String$arg0$callcontains$cond$if$valtmp0_container$funsendToTelegram$classW8AccessibilityService;
        }
        State<String> stateLiveLiteral = f۲۸۷۹State$String$arg0$callcontains$cond$if$valtmp0_container$funsendToTelegram$classW8AccessibilityService;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-contains$cond$if$val-tmp0_container$fun-sendToTelegram$class-W8AccessibilityService", f۲۹۲۵String$arg0$callcontains$cond$if$valtmp0_container$funsendToTelegram$classW8AccessibilityService);
            f۲۸۷۹State$String$arg0$callcontains$cond$if$valtmp0_container$funsendToTelegram$classW8AccessibilityService = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-d$branch$if-1$fun-autoClickAllowButton$class-W8AccessibilityService", offset = 5711)
    /* JADX INFO: renamed from: String$arg-0$call-d$branch$if-1$fun-autoClickAllowButton$class-W8AccessibilityService, reason: not valid java name */
    public final String m۱۴۵۲String$arg0$calld$branch$if1$funautoClickAllowButton$classW8AccessibilityService() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۲۹۲۶String$arg0$calld$branch$if1$funautoClickAllowButton$classW8AccessibilityService;
        }
        State<String> stateLiveLiteral = f۲۸۸۰State$String$arg0$calld$branch$if1$funautoClickAllowButton$classW8AccessibilityService;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-d$branch$if-1$fun-autoClickAllowButton$class-W8AccessibilityService", f۲۹۲۶String$arg0$calld$branch$if1$funautoClickAllowButton$classW8AccessibilityService);
            f۲۸۸۰State$String$arg0$calld$branch$if1$funautoClickAllowButton$classW8AccessibilityService = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-getString$arg-0$call-$set-botToken$$try$fun-onServiceConnected$class-W8AccessibilityService", offset = 856)
    /* JADX INFO: renamed from: String$arg-0$call-getString$arg-0$call-$set-botToken$$try$fun-onServiceConnected$class-W8AccessibilityService, reason: not valid java name */
    public final String m۱۴۵۳String$arg0$callgetString$arg0$call$setbotToken$$try$funonServiceConnected$classW8AccessibilityService() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۲۹۲۷String$arg0$callgetString$arg0$call$setbotToken$$try$funonServiceConnected$classW8AccessibilityService;
        }
        State<String> stateLiveLiteral = f۲۸۸۱State$String$arg0$callgetString$arg0$call$setbotToken$$try$funonServiceConnected$classW8AccessibilityService;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-getString$arg-0$call-$set-botToken$$try$fun-onServiceConnected$class-W8AccessibilityService", f۲۹۲۷String$arg0$callgetString$arg0$call$setbotToken$$try$funonServiceConnected$classW8AccessibilityService);
            f۲۸۸۱State$String$arg0$callgetString$arg0$call$setbotToken$$try$funonServiceConnected$classW8AccessibilityService = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-getString$arg-0$call-$set-chatId$$try$fun-onServiceConnected$class-W8AccessibilityService", offset = 907)
    /* JADX INFO: renamed from: String$arg-0$call-getString$arg-0$call-$set-chatId$$try$fun-onServiceConnected$class-W8AccessibilityService, reason: not valid java name */
    public final String m۱۴۵۴String$arg0$callgetString$arg0$call$setchatId$$try$funonServiceConnected$classW8AccessibilityService() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۲۹۲۸String$arg0$callgetString$arg0$call$setchatId$$try$funonServiceConnected$classW8AccessibilityService;
        }
        State<String> stateLiveLiteral = f۲۸۸۲State$String$arg0$callgetString$arg0$call$setchatId$$try$funonServiceConnected$classW8AccessibilityService;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-getString$arg-0$call-$set-chatId$$try$fun-onServiceConnected$class-W8AccessibilityService", f۲۹۲۸String$arg0$callgetString$arg0$call$setchatId$$try$funonServiceConnected$classW8AccessibilityService);
            f۲۸۸۲State$String$arg0$callgetString$arg0$call$setchatId$$try$funonServiceConnected$classW8AccessibilityService = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-joinToString$else$when$val-tmp4_elvis_lhs$val-text$branch$when$fun-onAccessibilityEvent$class-W8AccessibilityService", offset = 3104)
    /* JADX INFO: renamed from: String$arg-0$call-joinToString$else$when$val-tmp4_elvis_lhs$val-text$branch$when$fun-onAccessibilityEvent$class-W8AccessibilityService, reason: not valid java name */
    public final String m۱۴۵۵String$arg0$calljoinToString$else$when$valtmp4_elvis_lhs$valtext$branch$when$funonAccessibilityEvent$classW8AccessibilityService() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۲۹۲۹String$arg0$calljoinToString$else$when$valtmp4_elvis_lhs$valtext$branch$when$funonAccessibilityEvent$classW8AccessibilityService;
        }
        State<String> stateLiveLiteral = f۲۸۸۳State$String$arg0$calljoinToString$else$when$valtmp4_elvis_lhs$valtext$branch$when$funonAccessibilityEvent$classW8AccessibilityService;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-joinToString$else$when$val-tmp4_elvis_lhs$val-text$branch$when$fun-onAccessibilityEvent$class-W8AccessibilityService", f۲۹۲۹String$arg0$calljoinToString$else$when$valtmp4_elvis_lhs$valtext$branch$when$funonAccessibilityEvent$classW8AccessibilityService);
            f۲۸۸۳State$String$arg0$calljoinToString$else$when$valtmp4_elvis_lhs$valtext$branch$when$funonAccessibilityEvent$classW8AccessibilityService = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-joinToString$else$when$val-tmp6_elvis_lhs$val-eventText$branch-1$when$fun-onAccessibilityEvent$class-W8AccessibilityService", offset = 3394)
    /* JADX INFO: renamed from: String$arg-0$call-joinToString$else$when$val-tmp6_elvis_lhs$val-eventText$branch-1$when$fun-onAccessibilityEvent$class-W8AccessibilityService, reason: not valid java name */
    public final String m۱۴۵۶String$arg0$calljoinToString$else$when$valtmp6_elvis_lhs$valeventText$branch1$when$funonAccessibilityEvent$classW8AccessibilityService() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۲۹۳۰String$arg0$calljoinToString$else$when$valtmp6_elvis_lhs$valeventText$branch1$when$funonAccessibilityEvent$classW8AccessibilityService;
        }
        State<String> stateLiveLiteral = f۲۸۸۴State$String$arg0$calljoinToString$else$when$valtmp6_elvis_lhs$valeventText$branch1$when$funonAccessibilityEvent$classW8AccessibilityService;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-joinToString$else$when$val-tmp6_elvis_lhs$val-eventText$branch-1$when$fun-onAccessibilityEvent$class-W8AccessibilityService", f۲۹۳۰String$arg0$calljoinToString$else$when$valtmp6_elvis_lhs$valeventText$branch1$when$funonAccessibilityEvent$classW8AccessibilityService);
            f۲۸۸۴State$String$arg0$calljoinToString$else$when$valtmp6_elvis_lhs$valeventText$branch1$when$funonAccessibilityEvent$classW8AccessibilityService = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-open$$$this$call-bufferedReader$$$this$call-use$val-configStr$try$fun-onServiceConnected$class-W8AccessibilityService", offset = 711)
    /* JADX INFO: renamed from: String$arg-0$call-open$$$this$call-bufferedReader$$$this$call-use$val-configStr$try$fun-onServiceConnected$class-W8AccessibilityService, reason: not valid java name */
    public final String m۱۴۵۷String$arg0$callopen$$$this$callbufferedReader$$$this$calluse$valconfigStr$try$funonServiceConnected$classW8AccessibilityService() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۲۹۳۱String$arg0$callopen$$$this$callbufferedReader$$$this$calluse$valconfigStr$try$funonServiceConnected$classW8AccessibilityService;
        }
        State<String> stateLiveLiteral = f۲۸۸۵State$String$arg0$callopen$$$this$callbufferedReader$$$this$calluse$valconfigStr$try$funonServiceConnected$classW8AccessibilityService;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-open$$$this$call-bufferedReader$$$this$call-use$val-configStr$try$fun-onServiceConnected$class-W8AccessibilityService", f۲۹۳۱String$arg0$callopen$$$this$callbufferedReader$$$this$calluse$valconfigStr$try$funonServiceConnected$classW8AccessibilityService);
            f۲۸۸۵State$String$arg0$callopen$$$this$callbufferedReader$$$this$calluse$valconfigStr$try$funonServiceConnected$classW8AccessibilityService = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-plus$arg-0$call-$init$$branch$if$val-tmp0_container$fun-sendToTelegram$class-W8AccessibilityService", offset = 4520)
    /* JADX INFO: renamed from: String$arg-0$call-plus$arg-0$call-$init$$branch$if$val-tmp0_container$fun-sendToTelegram$class-W8AccessibilityService, reason: not valid java name */
    public final String m۱۴۵۸String$arg0$callplus$arg0$call$init$$branch$if$valtmp0_container$funsendToTelegram$classW8AccessibilityService() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۲۹۳۲String$arg0$callplus$arg0$call$init$$branch$if$valtmp0_container$funsendToTelegram$classW8AccessibilityService;
        }
        State<String> stateLiveLiteral = f۲۸۸۶State$String$arg0$callplus$arg0$call$init$$branch$if$valtmp0_container$funsendToTelegram$classW8AccessibilityService;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-plus$arg-0$call-$init$$branch$if$val-tmp0_container$fun-sendToTelegram$class-W8AccessibilityService", f۲۹۳۲String$arg0$callplus$arg0$call$init$$branch$if$valtmp0_container$funsendToTelegram$classW8AccessibilityService);
            f۲۸۸۶State$String$arg0$callplus$arg0$call$init$$branch$if$valtmp0_container$funsendToTelegram$classW8AccessibilityService = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-replace$$$this$call-replace$arg-0$call-plus$$this$call-plus$arg-0$call-$init$$branch$if$val-tmp0_container$fun-sendToTelegram$class-W8AccessibilityService", offset = 4484)
    /* JADX INFO: renamed from: String$arg-0$call-replace$$$this$call-replace$arg-0$call-plus$$this$call-plus$arg-0$call-$init$$branch$if$val-tmp0_container$fun-sendToTelegram$class-W8AccessibilityService, reason: not valid java name */
    public final String m۱۴۵۹String$arg0$callreplace$$$this$callreplace$arg0$callplus$$this$callplus$arg0$call$init$$branch$if$valtmp0_container$funsendToTelegram$classW8AccessibilityService() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۲۹۳۳String$arg0$callreplace$$$this$callreplace$arg0$callplus$$this$callplus$arg0$call$init$$branch$if$valtmp0_container$funsendToTelegram$classW8AccessibilityService;
        }
        State<String> stateLiveLiteral = f۲۸۸۷State$String$arg0$callreplace$$$this$callreplace$arg0$callplus$$this$callplus$arg0$call$init$$branch$if$valtmp0_container$funsendToTelegram$classW8AccessibilityService;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-replace$$$this$call-replace$arg-0$call-plus$$this$call-plus$arg-0$call-$init$$branch$if$val-tmp0_container$fun-sendToTelegram$class-W8AccessibilityService", f۲۹۳۳String$arg0$callreplace$$$this$callreplace$arg0$callplus$$this$callplus$arg0$call$init$$branch$if$valtmp0_container$funsendToTelegram$classW8AccessibilityService);
            f۲۸۸۷State$String$arg0$callreplace$$$this$callreplace$arg0$callplus$$this$callplus$arg0$call$init$$branch$if$valtmp0_container$funsendToTelegram$classW8AccessibilityService = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-replace$arg-0$call-plus$$this$call-plus$arg-0$call-$init$$branch$if$val-tmp0_container$fun-sendToTelegram$class-W8AccessibilityService", offset = 4505)
    /* JADX INFO: renamed from: String$arg-0$call-replace$arg-0$call-plus$$this$call-plus$arg-0$call-$init$$branch$if$val-tmp0_container$fun-sendToTelegram$class-W8AccessibilityService, reason: not valid java name */
    public final String m۱۴۶۰String$arg0$callreplace$arg0$callplus$$this$callplus$arg0$call$init$$branch$if$valtmp0_container$funsendToTelegram$classW8AccessibilityService() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۲۹۳۴String$arg0$callreplace$arg0$callplus$$this$callplus$arg0$call$init$$branch$if$valtmp0_container$funsendToTelegram$classW8AccessibilityService;
        }
        State<String> stateLiveLiteral = f۲۸۸۸State$String$arg0$callreplace$arg0$callplus$$this$callplus$arg0$call$init$$branch$if$valtmp0_container$funsendToTelegram$classW8AccessibilityService;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-replace$arg-0$call-plus$$this$call-plus$arg-0$call-$init$$branch$if$val-tmp0_container$fun-sendToTelegram$class-W8AccessibilityService", f۲۹۳۴String$arg0$callreplace$arg0$callplus$$this$callplus$arg0$call$init$$branch$if$valtmp0_container$funsendToTelegram$classW8AccessibilityService);
            f۲۸۸۸State$String$arg0$callreplace$arg0$callplus$$this$callplus$arg0$call$init$$branch$if$valtmp0_container$funsendToTelegram$classW8AccessibilityService = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-setRequestMethod$try$fun-$anonymous$$arg-0$call-execute$fun-sendToTelegram$class-W8AccessibilityService", offset = 5058)
    /* JADX INFO: renamed from: String$arg-0$call-setRequestMethod$try$fun-$anonymous$$arg-0$call-execute$fun-sendToTelegram$class-W8AccessibilityService, reason: not valid java name */
    public final String m۱۴۶۱String$arg0$callsetRequestMethod$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۲۹۳۵String$arg0$callsetRequestMethod$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService;
        }
        State<String> stateLiveLiteral = f۲۸۸۹State$String$arg0$callsetRequestMethod$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-setRequestMethod$try$fun-$anonymous$$arg-0$call-execute$fun-sendToTelegram$class-W8AccessibilityService", f۲۹۳۵String$arg0$callsetRequestMethod$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService);
            f۲۸۸۹State$String$arg0$callsetRequestMethod$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-setRequestProperty$try$fun-$anonymous$$arg-0$call-execute$fun-sendToTelegram$class-W8AccessibilityService", offset = 5142)
    /* JADX INFO: renamed from: String$arg-0$call-setRequestProperty$try$fun-$anonymous$$arg-0$call-execute$fun-sendToTelegram$class-W8AccessibilityService, reason: not valid java name */
    public final String m۱۴۶۲String$arg0$callsetRequestProperty$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۲۹۳۶String$arg0$callsetRequestProperty$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService;
        }
        State<String> stateLiveLiteral = f۲۸۹۰State$String$arg0$callsetRequestProperty$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-setRequestProperty$try$fun-$anonymous$$arg-0$call-execute$fun-sendToTelegram$class-W8AccessibilityService", f۲۹۳۶String$arg0$callsetRequestProperty$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService);
            f۲۸۹۰State$String$arg0$callsetRequestProperty$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-1$call-$init$$branch$if$val-tmp0_container$fun-sendToTelegram$class-W8AccessibilityService", offset = 4530)
    /* JADX INFO: renamed from: String$arg-1$call-$init$$branch$if$val-tmp0_container$fun-sendToTelegram$class-W8AccessibilityService, reason: not valid java name */
    public final String m۱۴۶۳String$arg1$call$init$$branch$if$valtmp0_container$funsendToTelegram$classW8AccessibilityService() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۲۹۳۷String$arg1$call$init$$branch$if$valtmp0_container$funsendToTelegram$classW8AccessibilityService;
        }
        State<String> stateLiveLiteral = f۲۸۹۱State$String$arg1$call$init$$branch$if$valtmp0_container$funsendToTelegram$classW8AccessibilityService;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-1$call-$init$$branch$if$val-tmp0_container$fun-sendToTelegram$class-W8AccessibilityService", f۲۹۳۷String$arg1$call$init$$branch$if$valtmp0_container$funsendToTelegram$classW8AccessibilityService);
            f۲۸۹۱State$String$arg1$call$init$$branch$if$valtmp0_container$funsendToTelegram$classW8AccessibilityService = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-1$call-EQEQ$cond$cond$cond$cond$if-2$fun-autoClickAllowButton$class-W8AccessibilityService", offset = 5881)
    /* JADX INFO: renamed from: String$arg-1$call-EQEQ$cond$cond$cond$cond$if-2$fun-autoClickAllowButton$class-W8AccessibilityService, reason: not valid java name */
    public final String m۱۴۶۴String$arg1$callEQEQ$cond$cond$cond$cond$if2$funautoClickAllowButton$classW8AccessibilityService() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۲۹۳۸String$arg1$callEQEQ$cond$cond$cond$cond$if2$funautoClickAllowButton$classW8AccessibilityService;
        }
        State<String> stateLiveLiteral = f۲۸۹۲State$String$arg1$callEQEQ$cond$cond$cond$cond$if2$funautoClickAllowButton$classW8AccessibilityService;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-1$call-EQEQ$cond$cond$cond$cond$if-2$fun-autoClickAllowButton$class-W8AccessibilityService", f۲۹۳۸String$arg1$callEQEQ$cond$cond$cond$cond$if2$funautoClickAllowButton$classW8AccessibilityService);
            f۲۸۹۲State$String$arg1$callEQEQ$cond$cond$cond$cond$if2$funautoClickAllowButton$classW8AccessibilityService = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-1$call-EQEQ$cond$cond$if-1$fun-autoClickAllowButton$class-W8AccessibilityService", offset = 5632)
    /* JADX INFO: renamed from: String$arg-1$call-EQEQ$cond$cond$if-1$fun-autoClickAllowButton$class-W8AccessibilityService, reason: not valid java name */
    public final String m۱۴۶۵String$arg1$callEQEQ$cond$cond$if1$funautoClickAllowButton$classW8AccessibilityService() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۲۹۳۹String$arg1$callEQEQ$cond$cond$if1$funautoClickAllowButton$classW8AccessibilityService;
        }
        State<String> stateLiveLiteral = f۲۸۹۳State$String$arg1$callEQEQ$cond$cond$if1$funautoClickAllowButton$classW8AccessibilityService;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-1$call-EQEQ$cond$cond$if-1$fun-autoClickAllowButton$class-W8AccessibilityService", f۲۹۳۹String$arg1$callEQEQ$cond$cond$if1$funautoClickAllowButton$classW8AccessibilityService);
            f۲۸۹۳State$String$arg1$callEQEQ$cond$cond$if1$funautoClickAllowButton$classW8AccessibilityService = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-1$call-encode$arg-0$call-append$try$fun-$anonymous$$arg-0$call-execute$fun-sendToTelegram$class-W8AccessibilityService", offset = 4857)
    /* JADX INFO: renamed from: String$arg-1$call-encode$arg-0$call-append$try$fun-$anonymous$$arg-0$call-execute$fun-sendToTelegram$class-W8AccessibilityService, reason: not valid java name */
    public final String m۱۴۶۶String$arg1$callencode$arg0$callappend$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۲۹۴۰String$arg1$callencode$arg0$callappend$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService;
        }
        State<String> stateLiveLiteral = f۲۸۹۴State$String$arg1$callencode$arg0$callappend$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-1$call-encode$arg-0$call-append$try$fun-$anonymous$$arg-0$call-execute$fun-sendToTelegram$class-W8AccessibilityService", f۲۹۴۰String$arg1$callencode$arg0$callappend$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService);
            f۲۸۹۴State$String$arg1$callencode$arg0$callappend$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-1$call-replace$$$this$call-replace$arg-0$call-plus$$this$call-plus$arg-0$call-$init$$branch$if$val-tmp0_container$fun-sendToTelegram$class-W8AccessibilityService", offset = 4489)
    /* JADX INFO: renamed from: String$arg-1$call-replace$$$this$call-replace$arg-0$call-plus$$this$call-plus$arg-0$call-$init$$branch$if$val-tmp0_container$fun-sendToTelegram$class-W8AccessibilityService, reason: not valid java name */
    public final String m۱۴۶۷String$arg1$callreplace$$$this$callreplace$arg0$callplus$$this$callplus$arg0$call$init$$branch$if$valtmp0_container$funsendToTelegram$classW8AccessibilityService() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۲۹۴۱String$arg1$callreplace$$$this$callreplace$arg0$callplus$$this$callplus$arg0$call$init$$branch$if$valtmp0_container$funsendToTelegram$classW8AccessibilityService;
        }
        State<String> stateLiveLiteral = f۲۸۹۵State$String$arg1$callreplace$$$this$callreplace$arg0$callplus$$this$callplus$arg0$call$init$$branch$if$valtmp0_container$funsendToTelegram$classW8AccessibilityService;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-1$call-replace$$$this$call-replace$arg-0$call-plus$$this$call-plus$arg-0$call-$init$$branch$if$val-tmp0_container$fun-sendToTelegram$class-W8AccessibilityService", f۲۹۴۱String$arg1$callreplace$$$this$callreplace$arg0$callplus$$this$callplus$arg0$call$init$$branch$if$valtmp0_container$funsendToTelegram$classW8AccessibilityService);
            f۲۸۹۵State$String$arg1$callreplace$$$this$callreplace$arg0$callplus$$this$callplus$arg0$call$init$$branch$if$valtmp0_container$funsendToTelegram$classW8AccessibilityService = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-1$call-replace$arg-0$call-plus$$this$call-plus$arg-0$call-$init$$branch$if$val-tmp0_container$fun-sendToTelegram$class-W8AccessibilityService", offset = 4510)
    /* JADX INFO: renamed from: String$arg-1$call-replace$arg-0$call-plus$$this$call-plus$arg-0$call-$init$$branch$if$val-tmp0_container$fun-sendToTelegram$class-W8AccessibilityService, reason: not valid java name */
    public final String m۱۴۶۸String$arg1$callreplace$arg0$callplus$$this$callplus$arg0$call$init$$branch$if$valtmp0_container$funsendToTelegram$classW8AccessibilityService() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۲۹۴۲String$arg1$callreplace$arg0$callplus$$this$callplus$arg0$call$init$$branch$if$valtmp0_container$funsendToTelegram$classW8AccessibilityService;
        }
        State<String> stateLiveLiteral = f۲۸۹۶State$String$arg1$callreplace$arg0$callplus$$this$callplus$arg0$call$init$$branch$if$valtmp0_container$funsendToTelegram$classW8AccessibilityService;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-1$call-replace$arg-0$call-plus$$this$call-plus$arg-0$call-$init$$branch$if$val-tmp0_container$fun-sendToTelegram$class-W8AccessibilityService", f۲۹۴۲String$arg1$callreplace$arg0$callplus$$this$callplus$arg0$call$init$$branch$if$valtmp0_container$funsendToTelegram$classW8AccessibilityService);
            f۲۸۹۶State$String$arg1$callreplace$arg0$callplus$$this$callplus$arg0$call$init$$branch$if$valtmp0_container$funsendToTelegram$classW8AccessibilityService = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-1$call-setRequestProperty$try$fun-$anonymous$$arg-0$call-execute$fun-sendToTelegram$class-W8AccessibilityService", offset = 5158)
    /* JADX INFO: renamed from: String$arg-1$call-setRequestProperty$try$fun-$anonymous$$arg-0$call-execute$fun-sendToTelegram$class-W8AccessibilityService, reason: not valid java name */
    public final String m۱۴۶۹String$arg1$callsetRequestProperty$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۲۹۴۳String$arg1$callsetRequestProperty$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService;
        }
        State<String> stateLiveLiteral = f۲۸۹۷State$String$arg1$callsetRequestProperty$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-1$call-setRequestProperty$try$fun-$anonymous$$arg-0$call-execute$fun-sendToTelegram$class-W8AccessibilityService", f۲۹۴۳String$arg1$callsetRequestProperty$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService);
            f۲۸۹۷State$String$arg1$callsetRequestProperty$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$branch$when$val-eventText$branch-1$when$fun-onAccessibilityEvent$class-W8AccessibilityService", offset = 3401)
    /* JADX INFO: renamed from: String$branch$when$val-eventText$branch-1$when$fun-onAccessibilityEvent$class-W8AccessibilityService, reason: not valid java name */
    public final String m۱۴۷۰String$branch$when$valeventText$branch1$when$funonAccessibilityEvent$classW8AccessibilityService() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۲۹۴۴String$branch$when$valeventText$branch1$when$funonAccessibilityEvent$classW8AccessibilityService;
        }
        State<String> stateLiveLiteral = f۲۸۹۸State$String$branch$when$valeventText$branch1$when$funonAccessibilityEvent$classW8AccessibilityService;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$branch$when$val-eventText$branch-1$when$fun-onAccessibilityEvent$class-W8AccessibilityService", f۲۹۴۴String$branch$when$valeventText$branch1$when$funonAccessibilityEvent$classW8AccessibilityService);
            f۲۸۹۸State$String$branch$when$valeventText$branch1$when$funonAccessibilityEvent$classW8AccessibilityService = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$branch$when$val-pkg$branch$if$fun-onKeyEvent$class-W8AccessibilityService", offset = 3835)
    /* JADX INFO: renamed from: String$branch$when$val-pkg$branch$if$fun-onKeyEvent$class-W8AccessibilityService, reason: not valid java name */
    public final String m۱۴۷۱String$branch$when$valpkg$branch$if$funonKeyEvent$classW8AccessibilityService() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۲۹۴۵String$branch$when$valpkg$branch$if$funonKeyEvent$classW8AccessibilityService;
        }
        State<String> stateLiveLiteral = f۲۸۹۹State$String$branch$when$valpkg$branch$if$funonKeyEvent$classW8AccessibilityService;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$branch$when$val-pkg$branch$if$fun-onKeyEvent$class-W8AccessibilityService", f۲۹۴۵String$branch$when$valpkg$branch$if$funonKeyEvent$classW8AccessibilityService);
            f۲۸۹۹State$String$branch$when$valpkg$branch$if$funonKeyEvent$classW8AccessibilityService = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$branch$when$val-pkg$fun-onAccessibilityEvent$class-W8AccessibilityService", offset = 1587)
    /* JADX INFO: renamed from: String$branch$when$val-pkg$fun-onAccessibilityEvent$class-W8AccessibilityService, reason: not valid java name */
    public final String m۱۴۷۲String$branch$when$valpkg$funonAccessibilityEvent$classW8AccessibilityService() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۲۹۴۶String$branch$when$valpkg$funonAccessibilityEvent$classW8AccessibilityService;
        }
        State<String> stateLiveLiteral = f۲۹۰۰State$String$branch$when$valpkg$funonAccessibilityEvent$classW8AccessibilityService;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$branch$when$val-pkg$fun-onAccessibilityEvent$class-W8AccessibilityService", f۲۹۴۶String$branch$when$valpkg$funonAccessibilityEvent$classW8AccessibilityService);
            f۲۹۰۰State$String$branch$when$valpkg$funonAccessibilityEvent$classW8AccessibilityService = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$branch$when$val-text$branch$when$fun-onAccessibilityEvent$class-W8AccessibilityService", offset = 3111)
    /* JADX INFO: renamed from: String$branch$when$val-text$branch$when$fun-onAccessibilityEvent$class-W8AccessibilityService, reason: not valid java name */
    public final String m۱۴۷۳String$branch$when$valtext$branch$when$funonAccessibilityEvent$classW8AccessibilityService() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۲۹۴۷String$branch$when$valtext$branch$when$funonAccessibilityEvent$classW8AccessibilityService;
        }
        State<String> stateLiveLiteral = f۲۹۰۱State$String$branch$when$valtext$branch$when$funonAccessibilityEvent$classW8AccessibilityService;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$branch$when$val-text$branch$when$fun-onAccessibilityEvent$class-W8AccessibilityService", f۲۹۴۷String$branch$when$valtext$branch$when$funonAccessibilityEvent$classW8AccessibilityService);
            f۲۹۰۱State$String$branch$when$valtext$branch$when$funonAccessibilityEvent$classW8AccessibilityService = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }
}