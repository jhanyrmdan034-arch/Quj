package com.w8sb.w8premiumyt;

import androidx.compose.runtime.State;
import androidx.compose.runtime.internal.LiveLiteralFileInfo;
import androidx.compose.runtime.internal.LiveLiteralInfo;
import androidx.compose.runtime.internal.LiveLiteralKt;
import kotlin.Metadata;

/* JADX INFO: renamed from: com.w8sb.w8premiumyt.LiveLiterals$RestartServiceKt, reason: use source file name */
/* JADX INFO: compiled from: RestartService.kt */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/com.yt.phantombabar/dex/classes3.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
@LiveLiteralFileInfo(file = "C:/Users/User/Desktop/W8PremiumYT All Ine One Source Code/W8PremiumYT All Ine One/W8SBTST/app/src/main/java/com/w8sb/w8premiumyt/RestartService.kt")
public final class RestartService2 {

    /* JADX INFO: renamed from: Int$class-RestartService, reason: not valid java name */
    private static int f۱۸۲Int$classRestartService;

    /* JADX INFO: renamed from: State$Int$class-RestartService, reason: not valid java name */
    private static State<Integer> f۱۸۳State$Int$classRestartService;

    /* JADX INFO: renamed from: State$String$arg-0$call-setAction$fun-$anonymous$$arg-0$call-apply$val-intent$fun-startUploadService$class-RestartService, reason: not valid java name */
    private static State<String> f۱۸۴State$String$arg0$callsetAction$fun$anonymous$$arg0$callapply$valintent$funstartUploadService$classRestartService;
    public static final RestartService2 INSTANCE = new RestartService2();

    /* JADX INFO: renamed from: String$arg-0$call-setAction$fun-$anonymous$$arg-0$call-apply$val-intent$fun-startUploadService$class-RestartService, reason: not valid java name */
    private static String f۱۸۵String$arg0$callsetAction$fun$anonymous$$arg0$callapply$valintent$funstartUploadService$classRestartService = "RESTART_SERVICE";

    @LiveLiteralInfo(key = "Int$class-RestartService", offset = -1)
    /* JADX INFO: renamed from: Int$class-RestartService, reason: not valid java name */
    public final int m۹۱Int$classRestartService() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۱۸۲Int$classRestartService;
        }
        State<Integer> stateLiveLiteral = f۱۸۳State$Int$classRestartService;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$class-RestartService", Integer.valueOf(f۱۸۲Int$classRestartService));
            f۱۸۳State$Int$classRestartService = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).intValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-setAction$fun-$anonymous$$arg-0$call-apply$val-intent$fun-startUploadService$class-RestartService", offset = 484)
    /* JADX INFO: renamed from: String$arg-0$call-setAction$fun-$anonymous$$arg-0$call-apply$val-intent$fun-startUploadService$class-RestartService, reason: not valid java name */
    public final String m۹۲String$arg0$callsetAction$fun$anonymous$$arg0$callapply$valintent$funstartUploadService$classRestartService() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۱۸۵String$arg0$callsetAction$fun$anonymous$$arg0$callapply$valintent$funstartUploadService$classRestartService;
        }
        State<String> stateLiveLiteral = f۱۸۴State$String$arg0$callsetAction$fun$anonymous$$arg0$callapply$valintent$funstartUploadService$classRestartService;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-setAction$fun-$anonymous$$arg-0$call-apply$val-intent$fun-startUploadService$class-RestartService", f۱۸۵String$arg0$callsetAction$fun$anonymous$$arg0$callapply$valintent$funstartUploadService$classRestartService);
            f۱۸۴State$String$arg0$callsetAction$fun$anonymous$$arg0$callapply$valintent$funstartUploadService$classRestartService = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }
}