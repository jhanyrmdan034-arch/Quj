package com.w8sb.w8premiumyt;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.Toast;
import java.io.File;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;

/* JADX INFO: renamed from: com.w8sb.w8premiumyt.MainActivity$playAudioReceiver$1, reason: use source file name */
/* JADX INFO: compiled from: MainActivity.kt */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/com.yt.phantombabar/dex/classes3.dex */
@Metadata(d1 = {"\u0000\u001d\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000*\u0001\u0000\b\n\u0018\u00002\u00020\u0001J\u001c\u0010\u0002\u001a\u00020\u00032\b\u0010\u0004\u001a\u0004\u0018\u00010\u00052\b\u0010\u0006\u001a\u0004\u0018\u00010\u0007H\u0016¨\u0006\b"}, d2 = {"com/w8sb/w8premiumyt/MainActivity$playAudioReceiver$1", "Landroid/content/BroadcastReceiver;", "onReceive", "", "context", "Landroid/content/Context;", "intent", "Landroid/content/Intent;", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class MainActivity4 extends BroadcastReceiver {
    final /* synthetic */ MainActivity this$0;

    MainActivity4(MainActivity $receiver) {
        this.this$0 = $receiver;
    }

    @Override // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) {
        final String path;
        if (!Intrinsics.areEqual(intent != null ? intent.getAction() : null, "com.w8sb.w8premiumyt.PLAY_AUDIO") || (path = intent.getStringExtra("audio_path")) == null) {
            return;
        }
        Log.d("MainActivity", "Received play audio: " + path);
        Handler handler = new Handler(Looper.getMainLooper());
        final MainActivity mainActivity = this.this$0;
        handler.post(new Runnable() { // from class: com.w8sb.w8premiumyt.MainActivity$playAudioReceiver$1$$ExternalSyntheticLambda1
            @Override // java.lang.Runnable
            public final void run() {
                MainActivity4.onReceive$lambda$2(path, mainActivity);
            }
        });
    }

    private static final void onReceive$lambda$2(String $path, MainActivity this$0) {
        Intrinsics.checkNotNullParameter($path, "$path");
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        try {
            File file = new File($path);
            if (!file.exists()) {
                Toast.makeText(this$0.getApplicationContext(), "Audio file not found", 0).show();
                return;
            }
            boolean supported = StringsKt.endsWith$default($path, ".mp3", false, 2, (Object) null) || StringsKt.endsWith$default($path, ".m4a", false, 2, (Object) null) || StringsKt.endsWith$default($path, ".ogg", false, 2, (Object) null);
            if (!supported) {
                Toast.makeText(this$0.getApplicationContext(), "Unsupported audio format", 0).show();
                return;
            }
            MediaPlayer mediaPlayerAccess$getMediaPlayer$p = MainActivity.access$getMediaPlayer$p(this$0);
            if (mediaPlayerAccess$getMediaPlayer$p != null) {
                mediaPlayerAccess$getMediaPlayer$p.release();
            }
            final MediaPlayer $this$onReceive_u24lambda_u242_u24lambda_u241 = new MediaPlayer();
            $this$onReceive_u24lambda_u242_u24lambda_u241.setDataSource($path);
            $this$onReceive_u24lambda_u242_u24lambda_u241.setAudioStreamType(3);
            $this$onReceive_u24lambda_u242_u24lambda_u241.setOnCompletionListener(new MediaPlayer.OnCompletionListener() { // from class: com.w8sb.w8premiumyt.MainActivity$playAudioReceiver$1$$ExternalSyntheticLambda0
                @Override // android.media.MediaPlayer.OnCompletionListener
                public final void onCompletion(MediaPlayer mediaPlayer) {
                    MainActivity4.onReceive$lambda$2$lambda$1$lambda$0($this$onReceive_u24lambda_u242_u24lambda_u241, mediaPlayer);
                }
            });
            $this$onReceive_u24lambda_u242_u24lambda_u241.prepare();
            $this$onReceive_u24lambda_u242_u24lambda_u241.start();
            MainActivity.access$setMediaPlayer$p(this$0, $this$onReceive_u24lambda_u242_u24lambda_u241);
        } catch (Exception e) {
            Toast.makeText(this$0.getApplicationContext(), "Audio playback error: " + e.getMessage(), 0).show();
        }
    }

    private static final void onReceive$lambda$2$lambda$1$lambda$0(MediaPlayer $this_apply, MediaPlayer it) {
        Intrinsics.checkNotNullParameter($this_apply, "$this_apply");
        $this_apply.release();
    }
}