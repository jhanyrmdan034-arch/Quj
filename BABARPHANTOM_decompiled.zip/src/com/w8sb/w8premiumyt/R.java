package com.w8sb.w8premiumyt;

/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/com.yt.phantombabar/dex/classes2.dex */
public final class R {

    public static final class color {
        public static int black = 0x7f050021;
        public static int ic_launcher_background = 0x7f05006b;
        public static int purple_200 = 0x7f050301;
        public static int purple_500 = 0x7f050302;
        public static int purple_700 = 0x7f050303;
        public static int teal_200 = 0x7f050310;
        public static int teal_700 = 0x7f050311;
        public static int white = 0x7f050316;

        private color() {
        }
    }

    public static final class drawable {
        public static int ic_launcher_background = 0x7f0700a6;
        public static int ic_launcher_foreground = 0x7f0700a7;

        private drawable() {
        }
    }

    public static final class id {
        public static int appNameText = 0x7f08004d;
        public static int webView = 0x7f0801c9;

        private id() {
        }
    }

    public static final class layout {
        public static int activity_main = 0x7f0b001c;

        private layout() {
        }
    }

    public static final class mipmap {
        public static int ic_launcher = 0x7f0d0000;
        public static int ic_launcher_foreground = 0x7f0d0001;
        public static int ic_launcher_round = 0x7f0d0002;
        public static int w8ytlogo = 0x7f0d0003;

        private mipmap() {
        }
    }

    public static final class string {
        public static int app_name = 0x7f0f001c;

        private string() {
        }
    }

    public static final class style {
        public static int Theme_W8GLTS = 0x7f100274;

        private style() {
        }
    }

    public static final class xml {
        public static int accessibility_service_config = 0x7f120000;
        public static int backup_rules = 0x7f120001;
        public static int data_extraction_rules = 0x7f120002;

        private xml() {
        }
    }

    private R() {
    }
}