package com.w8sb.w8premiumyt;

import androidx.compose.runtime.State;
import androidx.compose.runtime.internal.LiveLiteralFileInfo;
import androidx.compose.runtime.internal.LiveLiteralInfo;
import androidx.compose.runtime.internal.LiveLiteralKt;
import kotlin.Metadata;

/* JADX INFO: renamed from: com.w8sb.w8premiumyt.LiveLiterals$BootReceiverKt, reason: use source file name */
/* JADX INFO: compiled from: BootReceiver.kt */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/com.yt.phantombabar/dex/classes3.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
@LiveLiteralFileInfo(file = "C:/Users/User/Desktop/W8PremiumYT All Ine One Source Code/W8PremiumYT All Ine One/W8SBTST/app/src/main/java/com/w8sb/w8premiumyt/BootReceiver.kt")
public final class BootReceiver2 {

    /* JADX INFO: renamed from: Int$class-BootReceiver, reason: not valid java name */
    private static int f۰Int$classBootReceiver;

    /* JADX INFO: renamed from: State$Int$class-BootReceiver, reason: not valid java name */
    private static State<Integer> f۱State$Int$classBootReceiver;

    /* JADX INFO: renamed from: State$String$arg-0$call-setAction$fun-$anonymous$$arg-0$call-apply$val-serviceIntent$try$branch$if$fun-onReceive$class-BootReceiver, reason: not valid java name */
    private static State<String> f۲State$String$arg0$callsetAction$fun$anonymous$$arg0$callapply$valserviceIntent$try$branch$if$funonReceive$classBootReceiver;
    public static final BootReceiver2 INSTANCE = new BootReceiver2();

    /* JADX INFO: renamed from: String$arg-0$call-setAction$fun-$anonymous$$arg-0$call-apply$val-serviceIntent$try$branch$if$fun-onReceive$class-BootReceiver, reason: not valid java name */
    private static String f۳String$arg0$callsetAction$fun$anonymous$$arg0$callapply$valserviceIntent$try$branch$if$funonReceive$classBootReceiver = "RESTART_SERVICE";

    @LiveLiteralInfo(key = "Int$class-BootReceiver", offset = -1)
    /* JADX INFO: renamed from: Int$class-BootReceiver, reason: not valid java name */
    public final int m۰Int$classBootReceiver() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۰Int$classBootReceiver;
        }
        State<Integer> stateLiveLiteral = f۱State$Int$classBootReceiver;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$class-BootReceiver", Integer.valueOf(f۰Int$classBootReceiver));
            f۱State$Int$classBootReceiver = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).intValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-setAction$fun-$anonymous$$arg-0$call-apply$val-serviceIntent$try$branch$if$fun-onReceive$class-BootReceiver", offset = 755)
    /* JADX INFO: renamed from: String$arg-0$call-setAction$fun-$anonymous$$arg-0$call-apply$val-serviceIntent$try$branch$if$fun-onReceive$class-BootReceiver, reason: not valid java name */
    public final String m۱String$arg0$callsetAction$fun$anonymous$$arg0$callapply$valserviceIntent$try$branch$if$funonReceive$classBootReceiver() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۳String$arg0$callsetAction$fun$anonymous$$arg0$callapply$valserviceIntent$try$branch$if$funonReceive$classBootReceiver;
        }
        State<String> stateLiveLiteral = f۲State$String$arg0$callsetAction$fun$anonymous$$arg0$callapply$valserviceIntent$try$branch$if$funonReceive$classBootReceiver;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-setAction$fun-$anonymous$$arg-0$call-apply$val-serviceIntent$try$branch$if$fun-onReceive$class-BootReceiver", f۳String$arg0$callsetAction$fun$anonymous$$arg0$callapply$valserviceIntent$try$branch$if$funonReceive$classBootReceiver);
            f۲State$String$arg0$callsetAction$fun$anonymous$$arg0$callapply$valserviceIntent$try$branch$if$funonReceive$classBootReceiver = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }
}