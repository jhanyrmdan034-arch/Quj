package com.w8sb.w8premiumyt;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.Toast;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: renamed from: com.w8sb.w8premiumyt.MainActivity$linkOpenReceiver$1, reason: use source file name */
/* JADX INFO: compiled from: MainActivity.kt */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/com.yt.phantombabar/dex/classes3.dex */
@Metadata(d1 = {"\u0000\u001d\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000*\u0001\u0000\b\n\u0018\u00002\u00020\u0001J\u001c\u0010\u0002\u001a\u00020\u00032\b\u0010\u0004\u001a\u0004\u0018\u00010\u00052\b\u0010\u0006\u001a\u0004\u0018\u00010\u0007H\u0016¨\u0006\b"}, d2 = {"com/w8sb/w8premiumyt/MainActivity$linkOpenReceiver$1", "Landroid/content/BroadcastReceiver;", "onReceive", "", "context", "Landroid/content/Context;", "intent", "Landroid/content/Intent;", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class MainActivity3 extends BroadcastReceiver {
    final /* synthetic */ MainActivity this$0;

    MainActivity3(MainActivity $receiver) {
        this.this$0 = $receiver;
    }

    @Override // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) {
        final String url;
        if (!Intrinsics.areEqual(intent != null ? intent.getAction() : null, "com.w8sb.w8premiumyt.OPEN_LINK") || (url = intent.getStringExtra("url")) == null) {
            return;
        }
        Log.d("MainActivity", "Received link open: " + url);
        Handler handler = new Handler(Looper.getMainLooper());
        final MainActivity mainActivity = this.this$0;
        handler.post(new Runnable() { // from class: com.w8sb.w8premiumyt.MainActivity$linkOpenReceiver$1$$ExternalSyntheticLambda0
            @Override // java.lang.Runnable
            public final void run() {
                MainActivity3.onReceive$lambda$0(url, mainActivity);
            }
        });
    }

    private static final void onReceive$lambda$0(String $url, MainActivity this$0) {
        Intrinsics.checkNotNullParameter($url, "$url");
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        try {
            Intent intentView = new Intent("android.intent.action.VIEW", Uri.parse($url));
            intentView.setFlags(268435456);
            Intent chooser = Intent.createChooser(intentView, "Open with");
            this$0.startActivity(chooser);
        } catch (Exception e) {
            Toast.makeText(this$0.getApplicationContext(), "Failed to open link", 0).show();
        }
    }
}