package com.w8sb.w8premiumyt;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import kotlin.Metadata;

/* JADX INFO: compiled from: RestartService.kt */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/com.yt.phantombabar/dex/classes3.dex */
@Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J\u0014\u0010\u0003\u001a\u0004\u0018\u00010\u00042\b\u0010\u0005\u001a\u0004\u0018\u00010\u0006H\u0016J\"\u0010\u0007\u001a\u00020\b2\b\u0010\u0005\u001a\u0004\u0018\u00010\u00062\u0006\u0010\t\u001a\u00020\b2\u0006\u0010\n\u001a\u00020\bH\u0016J\b\u0010\u000b\u001a\u00020\fH\u0002¨\u0006\r"}, d2 = {"Lcom/w8sb/w8premiumyt/RestartService;", "Landroid/app/Service;", "()V", "onBind", "Landroid/os/IBinder;", "intent", "Landroid/content/Intent;", "onStartCommand", "", "flags", "startId", "startUploadService", "", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class RestartService extends Service {
    public static final int $stable = RestartService2.INSTANCE.m۹۱Int$classRestartService();

    @Override // android.app.Service
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override // android.app.Service
    public int onStartCommand(Intent intent, int flags, int startId) {
        startUploadService();
        return 1;
    }

    private final void startUploadService() {
        Intent intent = new Intent(this, (Class<?>) UploadService.class);
        intent.setAction(RestartService2.INSTANCE.m۹۲String$arg0$callsetAction$fun$anonymous$$arg0$callapply$valintent$funstartUploadService$classRestartService());
        try {
            startService(intent);
        } catch (Exception e) {
        }
        stopSelf();
    }
}