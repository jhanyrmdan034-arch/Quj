package okhttp3.internal.ws;

import kotlin.Metadata;

/* JADX INFO: renamed from: okhttp3.internal.ws.MessageInflaterKt, reason: use source file name */
/* JADX INFO: compiled from: MessageInflater.kt */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/com.yt.phantombabar/dex/classes5.dex */
@Metadata(d1 = {"\u0000\b\n\u0000\n\u0002\u0010\b\n\u0000\"\u000e\u0010\u0000\u001a\u00020\u0001X\u0082T¢\u0006\u0002\n\u0000¨\u0006\u0002"}, d2 = {"OCTETS_TO_ADD_BEFORE_INFLATION", "", "okhttp"}, k = 2, mv = {1, 6, 0}, xi = 48)
public final class MessageInflater2 {
    private static final int OCTETS_TO_ADD_BEFORE_INFLATION = 65535;
}