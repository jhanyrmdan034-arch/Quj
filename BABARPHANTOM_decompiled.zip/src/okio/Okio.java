package okio;

import java.io.Closeable;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.nio.file.OpenOption;
import java.security.MessageDigest;
import javax.crypto.Cipher;
import javax.crypto.Mac;
import kotlin.Metadata;
import kotlin.jvm.functions.Function1;

/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/com.yt.phantombabar/dex/classes5.dex */
@Metadata(d1 = {"okio/Okio__JvmOkioKt", "okio/Okio__OkioKt"}, k = 4, mv = {1, 6, 0}, xi = 48)
public final class Okio {
    public static final Sink appendingSink(File $this$appendingSink) throws FileNotFoundException {
        return JvmOkio2.appendingSink($this$appendingSink);
    }

    public static final FileSystem asResourceFileSystem(ClassLoader $this$asResourceFileSystem) {
        return JvmOkio2.asResourceFileSystem($this$asResourceFileSystem);
    }

    public static final Sink blackhole() {
        return Okio3.blackhole();
    }

    public static final BufferedSink buffer(Sink $this$buffer) {
        return Okio3.buffer($this$buffer);
    }

    public static final BufferedSource buffer(Source $this$buffer) {
        return Okio3.buffer($this$buffer);
    }

    public static final CipherSink cipherSink(Sink $this$cipherSink, Cipher cipher) {
        return JvmOkio2.cipherSink($this$cipherSink, cipher);
    }

    public static final CipherSource cipherSource(Source $this$cipherSource, Cipher cipher) {
        return JvmOkio2.cipherSource($this$cipherSource, cipher);
    }

    public static final HashingSink hashingSink(Sink $this$hashingSink, MessageDigest digest) {
        return JvmOkio2.hashingSink($this$hashingSink, digest);
    }

    public static final HashingSink hashingSink(Sink $this$hashingSink, Mac mac) {
        return JvmOkio2.hashingSink($this$hashingSink, mac);
    }

    public static final HashingSource hashingSource(Source $this$hashingSource, MessageDigest digest) {
        return JvmOkio2.hashingSource($this$hashingSource, digest);
    }

    public static final HashingSource hashingSource(Source $this$hashingSource, Mac mac) {
        return JvmOkio2.hashingSource($this$hashingSource, mac);
    }

    public static final boolean isAndroidGetsocknameError(AssertionError $this$isAndroidGetsocknameError) {
        return JvmOkio2.isAndroidGetsocknameError($this$isAndroidGetsocknameError);
    }

    public static final FileSystem openZip(FileSystem $this$openZip, Path zipPath) throws IOException {
        return JvmOkio2.openZip($this$openZip, zipPath);
    }

    public static final Sink sink(File $this$sink) throws FileNotFoundException {
        return JvmOkio2.sink($this$sink);
    }

    public static final Sink sink(File $this$sink, boolean append) throws FileNotFoundException {
        return JvmOkio2.sink($this$sink, append);
    }

    public static final Sink sink(OutputStream $this$sink) {
        return JvmOkio2.sink($this$sink);
    }

    public static final Sink sink(Socket $this$sink) throws IOException {
        return JvmOkio2.sink($this$sink);
    }

    public static final Sink sink(java.nio.file.Path $this$sink, OpenOption... options) throws IOException {
        return JvmOkio2.sink($this$sink, options);
    }

    public static final Source source(File $this$source) throws FileNotFoundException {
        return JvmOkio2.source($this$source);
    }

    public static final Source source(InputStream $this$source) {
        return JvmOkio2.source($this$source);
    }

    public static final Source source(Socket $this$source) throws IOException {
        return JvmOkio2.source($this$source);
    }

    public static final Source source(java.nio.file.Path $this$source, OpenOption... options) throws IOException {
        return JvmOkio2.source($this$source, options);
    }

    public static final <T extends Closeable, R> R use(T t, Function1<? super T, ? extends R> function1) {
        return (R) Okio3.use(t, function1);
    }
}